"""
Spectra Intelligence CLI

Invoke any registered Spectra Intelligence tool from the command line
and print the result as JSON to stdout.

Usage:
    python cli.py --list-tools
    python cli.py --login [--env-file PATH]
    python cli.py <tool_name> [--args '<json_object>']

Exit codes:
    0  Success            – JSON result printed to stdout
    1  API / runtime error – JSON error object printed to stderr
    2  Bad arguments      – plain error message printed to stderr
"""

import argparse
import asyncio
import inspect
import json
import sys
import types as _builtin_types
import typing
from pathlib import Path
from typing import NoReturn

from config import get_settings


def _read_version() -> str:
    # Prefer the installed package metadata (works after pip install).
    try:
        from importlib.metadata import version
        return version("rl-spectra-intel")
    except Exception:
        pass
    # Fall back to reading pyproject.toml directly (works when run from source).
    try:
        try:
            import tomllib
        except ImportError:
            try:
                import tomli as tomllib  # type: ignore[no-reuse]
            except ImportError:
                return "unknown"
        pyproject = Path(__file__).parent / "pyproject.toml"
        with pyproject.open("rb") as f:
            return tomllib.load(f)["project"]["version"]
    except Exception:
        return "unknown"


__version__ = _read_version()


# ---------------------------------------------------------------------------
# Exit helpers
# ---------------------------------------------------------------------------

def _exit_api_error(message: str, **extra) -> NoReturn:
    """Print a JSON error object to stderr and exit with code 1."""
    err = {"error": message, **{k: v for k, v in extra.items() if v is not None}}
    print(json.dumps(err), file=sys.stderr)
    sys.exit(1)


def _exit_usage_error(message: str) -> NoReturn:
    """Print a plain error message to stderr and exit with code 2."""
    print(f"error: {message}", file=sys.stderr)
    sys.exit(2)


# ---------------------------------------------------------------------------
# Schema generation (for --list-tools)
# ---------------------------------------------------------------------------

def _annotation_to_schema(annotation) -> dict:
    """Recursively convert a Python type annotation to a JSON Schema fragment."""
    origin = typing.get_origin(annotation)
    args = typing.get_args(annotation)

    # Union types: typing.Union[X, Y] and PEP 604 X | Y
    if origin is typing.Union or isinstance(annotation, _builtin_types.UnionType):
        non_none = [a for a in args if a is not type(None)]
        if len(non_none) == 1:
            return _annotation_to_schema(non_none[0])
        return {"anyOf": [_annotation_to_schema(a) for a in non_none]}

    # list[X]
    if origin is list:
        schema: dict = {"type": "array"}
        if args:
            schema["items"] = _annotation_to_schema(args[0])
        return schema

    return {
        str:   {"type": "string"},
        int:   {"type": "integer"},
        bool:  {"type": "boolean"},
        float: {"type": "number"},
    }.get(annotation, {})


def _parse_docstring(doc: str) -> tuple[str, dict[str, str]]:
    """Return (summary, {arg_name: description}) from a Google-style docstring."""
    if not doc:
        return "", {}

    lines = doc.strip().splitlines()

    # Summary: leading block of consecutive non-empty lines
    summary_parts: list[str] = []
    for line in lines:
        stripped = line.strip()
        if not stripped:
            break
        summary_parts.append(stripped)
    summary = " ".join(summary_parts)

    # Parse Args: section
    arg_descs: dict[str, str] = {}
    in_args = False
    current_arg: str | None = None
    current_parts: list[str] = []
    base_indent: int | None = None

    _STOP = {
        "Returns:", "Raises:", "Note:", "Notes:",
        "Example:", "Examples:", "Yields:", "See Also:",
    }

    for line in lines:
        stripped = line.strip()

        if stripped == "Args:":
            in_args = True
            base_indent = None
            continue

        if not in_args:
            continue
        if stripped in _STOP:
            break
        if not stripped:
            continue

        indent = len(line) - len(line.lstrip())
        if base_indent is None:
            base_indent = indent

        if indent == base_indent and ":" in stripped:
            # New arg entry — save any previous one first
            if current_arg is not None:
                arg_descs[current_arg] = " ".join(current_parts)
            name, _, desc = stripped.partition(":")
            current_arg = name.strip()
            current_parts = [desc.strip()] if desc.strip() else []
        elif current_arg is not None:
            # Continuation line for the current arg
            current_parts.append(stripped)

    if current_arg is not None:
        arg_descs[current_arg] = " ".join(current_parts)

    return summary, arg_descs


def _example_value(name: str, schema: dict) -> object:
    """Return a plausible placeholder value for an arg given its name and schema."""
    t = schema.get("type")
    if t == "string":
        if any(h in name for h in ("hash", "sha", "md5")):
            return "a1b2c3d4e5f6..."
        if "url" in name:
            return "https://example.com"
        if "thumbprint" in name:
            return "<thumbprint>"
        return f"<{name}>"
    if t == "integer":
        return 0
    if t == "boolean":
        return False
    if t == "array":
        return [_example_value("value", schema.get("items", {}))]
    if "anyOf" in schema:
        return _example_value(name, schema["anyOf"][0])
    return f"<{name}>"


def _build_tool_schema(fn) -> dict:
    """Build the JSON Schema descriptor dict for a single tool function."""
    # Unwrap @require_authorization (and any other @wraps decorators) to reach
    # the original function so that get_type_hints() uses the correct __globals__.
    original = inspect.unwrap(fn)

    summary, arg_descs = _parse_docstring(original.__doc__ or "")

    try:
        hints = typing.get_type_hints(original)
    except Exception:
        hints = getattr(original, "__annotations__", {})

    sig = inspect.signature(original)
    required: list[str] = []
    properties: dict = {}
    example_args: dict = {}

    for param_name, param in sig.parameters.items():
        if param.kind in (
            inspect.Parameter.VAR_POSITIONAL,
            inspect.Parameter.VAR_KEYWORD,
        ):
            continue

        annotation = hints.get(param_name, inspect.Parameter.empty)
        has_default = param.default is not inspect.Parameter.empty

        prop: dict = {}
        if annotation is not inspect.Parameter.empty:
            prop = _annotation_to_schema(annotation)
        if param_name in arg_descs:
            prop["description"] = arg_descs[param_name]

        properties[param_name] = prop

        if not has_default:
            required.append(param_name)
            example_args[param_name] = _example_value(param_name, prop)

    args_schema: dict = {"type": "object", "properties": properties}
    if required:
        args_schema["required"] = required

    example_json = json.dumps(example_args)
    example = f"rl-spectra-intel {fn.__name__} --args '{example_json}'"

    return {
        "name": fn.__name__,
        "description": summary,
        "args_schema": args_schema,
        "example": example,
    }


# ---------------------------------------------------------------------------
# Tool registry
# ---------------------------------------------------------------------------

def _build_registry() -> dict:
    """Return a mapping of tool name -> async callable for every registered tool."""
    from tools.file_tools import (
        get_sample_overview,
        get_sample_indicators,
        get_sample_detection_rules,
        get_sample_ttps,
        get_sample_similarity,
        start_auxiliary_analysis,
        start_dynamic_analysis,
        get_dynamic_analysis_status,
        get_sample_behavior,
        get_sample_strings,
        get_sample_content,
        submit_file,
        advanced_search,
        bulk_file_reputation_lookup,
    )
    from tools.url_tools import submit_url
    from tools.network_tools import (
        get_network_reputation,
        get_network_intelligence,
        get_downloaded_files,
        bulk_network_reputation_lookup,
    )
    from tools.yara_tools import (
        yara_hunt_start,
        yara_hunt_status_and_matches,
        yara_hunt_delete,
    )
    from tools.cert_tools import (
        get_certificate_index,
        get_certificate_analytics,
        search_certificate_thumbprints,
    )

    tools = [
        # File / sample tools
        get_sample_overview,
        get_sample_indicators,
        get_sample_detection_rules,
        get_sample_ttps,
        get_sample_similarity,
        start_auxiliary_analysis,
        start_dynamic_analysis,
        get_dynamic_analysis_status,
        get_sample_behavior,
        get_sample_strings,
        get_sample_content,
        submit_file,
        advanced_search,
        bulk_file_reputation_lookup,
        # URL tools
        submit_url,
        # Network tools
        get_network_reputation,
        get_network_intelligence,
        get_downloaded_files,
        bulk_network_reputation_lookup,
        # YARA tools
        yara_hunt_start,
        yara_hunt_status_and_matches,
        yara_hunt_delete,
        # Certificate tools
        get_certificate_index,
        get_certificate_analytics,
        search_certificate_thumbprints,
    ]
    return {fn.__name__: fn for fn in tools}


# ---------------------------------------------------------------------------
# Interactive login (--login)
# ---------------------------------------------------------------------------

def _resolve_env_path(cli_env: typing.Optional[str]) -> Path:
    """Pick the .env path to read/write for --login.

    Honours an explicit --env-file, otherwise defaults to ./.env in the current
    working directory so a fresh file can be created there.
    """
    if cli_env:
        return Path(cli_env).expanduser()
    return Path.cwd() / ".env"


def _write_env_credentials(env_path: Path, username: str, password: str) -> None:
    """Save the username and password into env_path, preserving other keys.

    Existing REVERSINGLABS_USERNAME / REVERSINGLABS_PASSWORD lines are replaced
    in place; every other line is kept verbatim. The file is created if absent
    and its permissions are tightened to 0600 since it now holds a plain-text
    password.
    """
    import os
    import stat

    updates = {
        "REVERSINGLABS_USERNAME": username,
        "REVERSINGLABS_PASSWORD": password,
    }

    lines: list[str] = []
    if env_path.exists():
        lines = env_path.read_text().splitlines()

    seen: set[str] = set()
    out: list[str] = []
    for line in lines:
        stripped = line.strip()
        key = None
        if "=" in stripped and not stripped.startswith("#"):
            key = stripped.split("=", 1)[0].strip()
        if key in updates:
            out.append(f"{key}={updates[key]}")
            seen.add(key)
        else:
            out.append(line)

    for key, value in updates.items():
        if key not in seen:
            out.append(f"{key}={value}")

    env_path.parent.mkdir(parents=True, exist_ok=True)
    env_path.write_text("\n".join(out) + "\n")
    try:
        os.chmod(env_path, stat.S_IRUSR | stat.S_IWUSR)  # 0600
    except OSError:
        pass


def _do_login(env_path: Path) -> NoReturn:
    """Prompt for a username and password, save them to env_path, then exit.

    Credentials are entered only at the interactive prompts — they never pass
    through a command argument, the chat, or shell history. The password input
    is hidden. Only the .env file on disk is written (chmod 600).
    """
    import getpass

    if not sys.stdin.isatty():
        _exit_usage_error("--login requires an interactive terminal")

    print(f"Spectra Intelligence login — credentials will be saved to {env_path}",
          file=sys.stderr)
    print("They authenticate you to the ReversingLabs API and are stored in "
          "plain text, readable only by you.", file=sys.stderr)

    username = input("Username: ").strip()
    if not username:
        _exit_usage_error("no username entered")
    password = getpass.getpass("Password: ")
    if not password:
        _exit_usage_error("no password entered")

    _write_env_credentials(env_path, username, password)

    print(f"Login successful. Credentials saved to {env_path} "
          "(permissions set to 600).", file=sys.stderr)
    sys.exit(0)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    # Suppress all logging below CRITICAL in CLI mode. This must be set before
    # any imports that trigger Settings initialisation (which configures logging
    # to INFO). logging.disable() is a global override that setLevel() cannot undo.
    import logging as _logging
    _logging.disable(_logging.ERROR)

    parser = argparse.ArgumentParser(
        prog="rl-spectra-intel",
        description=(
            "Invoke a Spectra Intelligence tool from the command line.\n"
            "Results are printed as JSON to stdout.\n\n"
            "Exit codes: 0=success  1=API/runtime error  2=bad arguments"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )
    parser.add_argument(
        "tool",
        nargs="?",
        metavar="TOOL",
        help="Name of the tool to invoke (see --list-tools).",
    )
    parser.add_argument(
        "--args",
        default="{}",
        metavar="JSON",
        help='Tool arguments as a JSON object, e.g. \'{"hash_value": "abc123"}\'.',
    )
    parser.add_argument(
        "--list-tools",
        action="store_true",
        help="Print all available tool names to stdout and exit.",
    )
    parser.add_argument(
        "--login",
        action="store_true",
        help="Prompt for a ReversingLabs Spectra Intelligence username and "
             "password and save them to the .env file (chmod 600), then exit. "
             "Credentials are entered only at the prompt, never on the command "
             "line, so they stay out of the chat and shell history.",
    )
    parser.add_argument(
        "--env-file",
        metavar="PATH",
        help="Path to the .env file that --login writes. Defaults to ./.env.",
    )

    parsed = parser.parse_args()

    if parsed.login:
        _do_login(_resolve_env_path(parsed.env_file))

    if parsed.list_tools:
        registry = _build_registry()
        schemas = [_build_tool_schema(registry[name]) for name in sorted(registry)]
        print(json.dumps(schemas, indent=2))
        sys.exit(0)

    if not parsed.tool:
        parser.print_help(sys.stderr)
        sys.exit(2)

    # Parse --args
    try:
        tool_kwargs = json.loads(parsed.args)
    except json.JSONDecodeError as exc:
        _exit_usage_error(f"--args is not valid JSON: {exc}")

    if not isinstance(tool_kwargs, dict):
        _exit_usage_error("--args must be a JSON object (not an array or scalar)")

    # Resolve the tool function
    registry = _build_registry()
    tool_fn = registry.get(parsed.tool)
    if tool_fn is None:
        _exit_usage_error(
            f"unknown tool '{parsed.tool}' — run --list-tools to see available tools"
        )

    # Validate credentials before invoking any tool
    settings = get_settings()
    if not settings.reversinglabs_username or not settings.reversinglabs_password:
        _exit_usage_error(
            "REVERSINGLABS_USERNAME and REVERSINGLABS_PASSWORD must be set"
        )

    # Invoke the tool
    try:
        result = asyncio.run(tool_fn(**tool_kwargs))
    except TypeError as exc:
        # Wrong keyword argument names or arity mismatch
        _exit_usage_error(f"invalid arguments for '{parsed.tool}': {exc}")
    except ValueError as exc:
        # Tool-level input validation (e.g. empty ruleset_name, bad hash length)
        _exit_usage_error(f"invalid argument value for '{parsed.tool}': {exc}")
    except Exception as exc:
        import httpx
        if isinstance(exc, httpx.HTTPStatusError):
            try:
                body = exc.response.text.strip() or None
            except httpx.ResponseNotRead:
                body = None
            _exit_api_error(
                str(exc),
                status_code=exc.response.status_code,
                response_body=body,
                exception_type="HTTPStatusError",
            )
        _exit_api_error(str(exc), exception_type=type(exc).__name__)

    # Serialize result to stdout
    try:
        print(json.dumps(result, default=str))
    except (TypeError, ValueError) as exc:
        _exit_api_error(f"failed to serialize result to JSON: {exc}")


if __name__ == "__main__":
    main()
