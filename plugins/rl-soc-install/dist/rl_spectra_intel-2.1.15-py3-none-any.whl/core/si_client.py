"""
Spectra Intelligence API Client

Thin async client for the ReversingLabs Spectra Intelligence (SI) API.
Supports TCA-0103 (multi-AV scan records), TCA-0104 (file analysis),
TCA-0106 (dynamic analysis reports), TCA-0202/0203 (file & metadata
submission), TCA-0207 (dynamic analysis submission), TCA-0320 (expression
search), TCA-0321 (RHA1 analytics), TCA-0403 (URL threat intelligence),
TCA-0404 (URL analysis submission), TCA-0405 (domain threat intelligence),
TCA-0406 (IP threat intelligence), TCA-0407 (bulk network reputation),
TCA-0501 (certificate index), TCA-0502 (certificate analytics),
TCA-0503 (certificate thumbprint search), TCAI-0101 (RCA2 classification),
and TCAI-0106 (auxiliary analysis).

Results are cached per unique call signature for a configurable TTL
(default: 60 seconds). A cache miss occurs whenever any parameter differs
from the previously cached call.
"""

import base64
import logging
import time
from typing import Any

import httpx

from config import get_settings

logger = logging.getLogger(__name__)

_HASH_TYPES: dict[int, str] = {32: "md5", 40: "sha1", 64: "sha256"}


def _detect_hash_type(hash_value: str) -> str:
    hash_type = _HASH_TYPES.get(len(hash_value))
    if hash_type is None:
        raise ValueError(
            f"Cannot determine hash type from value of length {len(hash_value)}; "
            "expected MD5 (32), SHA-1 (40), or SHA-256 (64) hex characters."
        )
    return hash_type


class SpectraIntelligenceClient:
    """
    Async client for the Spectra Intelligence REST API.

    Authentication uses HTTP Basic auth with credentials from Settings.
    Results are cached for ``cache_ttl`` seconds; the cache is keyed on the
    exact combination of endpoint and all call parameters so different
    arguments always trigger a fresh request.

    Typical usage::

        client = SpectraIntelligenceClient()
        result = await client.tca_0104_file_analysis("abc123...sha256hash...")
    """

    def __init__(self, cache_ttl: int | None = None) -> None:
        settings = get_settings()
        self._base_url = f"https://{settings.reversinglabs_host}"
        self._auth = (settings.reversinglabs_username, settings.reversinglabs_password)
        self._verify_ssl = settings.reversinglabs_verify_ssl
        self._cache_ttl: int = cache_ttl if cache_ttl is not None else settings.si_cache_ttl
        # Cache: key → (result, expires_at)
        self._cache: dict[tuple, tuple[Any, float]] = {}

    def _cache_get(self, key: tuple) -> Any | None:
        entry = self._cache.get(key)
        if entry is None:
            return None
        result, expires_at = entry
        if time.monotonic() > expires_at:
            del self._cache[key]
            return None
        return result

    def _cache_set(self, key: tuple, result: Any) -> None:
        if self._cache_ttl > 0:
            self._cache[key] = (result, time.monotonic() + self._cache_ttl)

    async def _get(self, path: str, params: dict | None = None, timeout: float = 30.0) -> dict:
        url = self._base_url + path
        logger.debug("SI API GET %s params=%s", url, params)
        async with httpx.AsyncClient(
            auth=self._auth, verify=self._verify_ssl, timeout=timeout
        ) as client:
            response = await client.get(url, params=params)
        response.raise_for_status()
        return response.json()

    async def _delete(self, path: str) -> None:
        url = self._base_url + path
        logger.debug("SI API DELETE %s", url)
        async with httpx.AsyncClient(
            auth=self._auth, verify=self._verify_ssl, timeout=30.0
        ) as client:
            response = await client.delete(url)
        response.raise_for_status()

    async def _post(self, path: str, body: dict) -> dict:
        url = self._base_url + path
        logger.debug("SI API POST %s", url)
        async with httpx.AsyncClient(
            auth=self._auth, verify=self._verify_ssl, timeout=30.0
        ) as client:
            response = await client.post(url, json=body)
        response.raise_for_status()
        return response.json()

    async def _post_octet_stream(
        self, path: str, data: bytes, content_type: str = "application/octet-stream"
    ) -> None:
        url = self._base_url + path
        logger.debug("SI API POST (%s) %s (%d bytes)", content_type, url, len(data))
        async with httpx.AsyncClient(
            auth=self._auth, verify=self._verify_ssl, timeout=120.0
        ) as client:
            response = await client.post(
                url,
                content=data,
                headers={"Content-Type": content_type},
            )
        response.raise_for_status()

    # ------------------------------------------------------------------ #
    # TCA-0201 – File Download                                             #
    # ------------------------------------------------------------------ #

    async def tca_0201_stream_sample(self, hash_value: str):
        """
        Stream a file sample in 64 KB chunks (TCA-0201).

        GET /api/spex/download/v2/query/{hash_type}/{hash_value}

        This is an async generator. At most one chunk is held in memory at a
        time; the caller is responsible for processing each chunk before the
        next is consumed. The file is never written to disk.

        Args:
            hash_value: MD5, SHA-1, or SHA-256 hash of the file to download.

        Yields:
            Raw bytes chunks of up to 64 KB.
        """
        hash_type = _detect_hash_type(hash_value)
        url = self._base_url + f"/api/spex/download/v2/query/{hash_type}/{hash_value}"
        logger.debug("SI API GET (stream) %s", url)
        async with httpx.AsyncClient(
            auth=self._auth, verify=self._verify_ssl, timeout=300.0
        ) as client:
            async with client.stream("GET", url) as response:
                response.raise_for_status()
                async for chunk in response.aiter_bytes(chunk_size=65536):
                    yield chunk

    async def internal_stream_sample(self, sha1: str):
        """
        Stream a private file sample in 64 KB chunks via the internal SAMS API.

        GET /api/sams/v1/download/query/sha1/{sha1}

        Used as a fallback when TCA-0201 returns 403 (private sample) and
        REVERSINGLABS_INTERNAL is enabled. Only available on the internal network.

        Args:
            sha1: SHA-1 hash of the file to download.

        Yields:
            Raw bytes chunks of up to 64 KB.
        """
        url = "https://alt-internal-api01.rl.lan" + f"/api/sams/v1/download/query/sha1/{sha1}"
        logger.debug("SI API GET (stream, internal) %s", url)
        async with httpx.AsyncClient(
            auth=self._auth, verify=False, timeout=300.0
        ) as client:
            async with client.stream("GET", url) as response:
                response.raise_for_status()
                async for chunk in response.aiter_bytes(chunk_size=65536):
                    yield chunk

    async def fetch_sample_content(
        self,
        hash_value: str,
        offset: int = 0,
        length: int = 722 * 1024,
    ) -> tuple[bytes, int]:
        """
        Return a byte slice of a file sample together with its total size.

        Tries TCA-0201 first.  On HTTP 403 (private sample) and when
        ``REVERSINGLABS_INTERNAL`` is enabled, retries via the internal
        SAMS API (SHA-1 only).  Reads ``Content-Length`` from the response
        headers for the total file size and stops streaming as soon as the
        requested window has been collected.

        Args:
            hash_value: MD5, SHA-1, or SHA-256 hash.
            offset:     First byte to include in the returned slice.
            length:     Maximum number of bytes to return.

        Returns:
            ``(raw_bytes, file_size)`` where ``raw_bytes`` is the slice
            ``[offset, offset+length)`` and ``file_size`` is the value of
            the ``Content-Length`` response header.
        """
        try:
            return await self._fetch_content_slice(
                self._base_url + f"/api/spex/download/v2/query/{_detect_hash_type(hash_value)}/{hash_value}",
                verify=self._verify_ssl,
                offset=offset,
                length=length,
            )
        except httpx.HTTPStatusError as exc:
            if exc.response.status_code != 403 or not get_settings().reversinglabs_internal:
                raise

        logger.info(
            "fetch_sample_content: TCA-0201 returned 403 (private sample), "
            "falling back to internal SAMS API for %s",
            hash_value,
        )
        if len(hash_value) != 40:
            raise ValueError(
                "Internal SAMS download fallback requires a SHA-1 hash "
                f"(40 hex chars); got length {len(hash_value)}. "
                "Re-submit using the SHA-1 of the sample."
            )
        return await self._fetch_content_slice(
            f"https://alt-internal-api01.rl.lan/api/sams/v1/download/query/sha1/{hash_value}",
            verify=False,
            offset=offset,
            length=length,
        )

    async def _fetch_content_slice(
        self,
        url: str,
        verify: bool,
        offset: int,
        length: int,
    ) -> tuple[bytes, int]:
        """Stream ``url``, return ``([offset, offset+length)`` bytes, file size)."""
        end = offset + length
        raw = bytearray()
        streamed = 0

        async with httpx.AsyncClient(
            auth=self._auth, verify=verify, timeout=300.0
        ) as client:
            async with client.stream("GET", url) as response:
                response.raise_for_status()
                file_size = int(response.headers.get("content-length", 0))
                async for chunk in response.aiter_bytes(chunk_size=65536):
                    chunk_start = streamed
                    chunk_end = streamed + len(chunk)
                    streamed = chunk_end

                    if chunk_end > offset and chunk_start < end:
                        slice_start = max(0, offset - chunk_start)
                        slice_end = min(len(chunk), end - chunk_start)
                        raw.extend(chunk[slice_start:slice_end])

                    if streamed >= end:
                        break

        return bytes(raw), file_size

    # ------------------------------------------------------------------ #
    # TCA-0202/0203 – File & Metadata Submission                           #
    # ------------------------------------------------------------------ #

    async def tca_0202_upload_sample(self, sha1: str, file_bytes: bytes) -> None:
        """
        Upload a file sample (TCA-0202).

        POST /api/spex/upload/{sha1}

        Args:
            sha1:       SHA-1 hash of the file.
            file_bytes: Raw bytes to upload (caller is responsible for any
                        archiving or encryption before calling this method).
        """
        await self._post_octet_stream(f"/api/spex/upload/{sha1}", file_bytes)

    async def tca_0203_upload_metadata(
        self,
        sha1: str,
        filename: str,
        archive_password: str | None = None,
    ) -> None:
        """
        Upload filename metadata for a previously submitted sample (TCA-0203).

        POST /api/spex/upload/{sha1}/meta

        Args:
            sha1:             SHA-1 hash of the sample.
            filename:         Original filename to associate with the sample.
            archive_password: Password used to encrypt the submitted archive.
                              When provided it is included in the metadata XML
                              so Spectra Intelligence can unpack the archive.
                              Standard passwords (infected, password, 1234)
                              need not be specified but may be included.
        """
        archive_xml = (
            f"<archive>"
            f"<archive_passwords>"
            f"<password>{archive_password}</password>"
            f"</archive_passwords>"
            f"</archive>"
            if archive_password is not None
            else ""
        )
        xml = (
            "<rl>"
            "<properties>"
            "<property>"
            "<name>file_name</name>"
            f"<value>{filename}</value>"
            "</property>"
            "</properties>"
            "<domain></domain>"
            f"{archive_xml}"
            "</rl>"
        )
        await self._post_octet_stream(f"/api/spex/upload/{sha1}/meta", xml.encode())

    # ------------------------------------------------------------------ #
    # TCA-0104 – File Analysis                                             #
    # ------------------------------------------------------------------ #

    async def tca_0104_file_analysis(self, hash_value: str) -> dict:
        """
        Fetch static analysis data for a single file (TCA-0104).

        GET /api/databrowser/rldata/query/{hash_type}/{hash_value}?format=json

        Args:
            hash_value: MD5, SHA-1, or SHA-256 hash of the file.

        Returns:
            Parsed JSON response from the SI API.
        """
        hash_type = _detect_hash_type(hash_value)
        cache_key = ("tca_0104_file_analysis", hash_type, hash_value)
        if (cached := self._cache_get(cache_key)) is not None:
            logger.debug("Cache hit: tca_0104_file_analysis %s", hash_value)
            return cached
        path = f"/api/databrowser/rldata/query/{hash_type}/{hash_value}"
        result = await self._get(path, params={"format": "json"})
        self._cache_set(cache_key, result)
        return result

    async def tca_0104_file_analysis_bulk(
        self, hash_values: list[str], hash_type: str
    ) -> dict:
        """
        Fetch static analysis data for up to 100 files in a single request (TCA-0104).

        POST /api/databrowser/rldata/bulk_query/json

        Args:
            hash_values: List of hashes (max 100). All must be of ``hash_type``.
            hash_type:   One of "md5", "sha1", or "sha256".

        Returns:
            Parsed JSON response from the SI API.
        """
        if len(hash_values) > 100:
            raise ValueError(
                "TCA-0104 bulk query accepts at most 100 hashes per request."
            )
        cache_key = ("tca_0104_file_analysis_bulk", hash_type, tuple(hash_values))
        if (cached := self._cache_get(cache_key)) is not None:
            logger.debug(
                "Cache hit: tca_0104_file_analysis_bulk (%d hashes)", len(hash_values)
            )
            return cached
        body = {"rl": {"query": {"hash_type": hash_type, "hashes": hash_values}}}
        result = await self._post("/api/databrowser/rldata/bulk_query/json", body)
        self._cache_set(cache_key, result)
        return result

    # ------------------------------------------------------------------ #
    # TCAI-0106 – Auxiliary Analysis                                       #
    # ------------------------------------------------------------------ #

    async def tcai_0106_submit_auxiliary_analysis(self, hash_value: str) -> dict:
        """
        Submit a file for auxiliary dynamic analysis (TCAI-0106).

        POST /api/dynamic/auxiliary/analyze/v1/submit

        Results can be retrieved with :meth:`tcai_0106_auxiliary_report` once
        processing is complete.

        Args:
            hash_value: MD5, SHA-1, or SHA-256 hash of the file.

        Returns:
            Parsed JSON response from the SI API.
        """
        hash_type = _detect_hash_type(hash_value)
        body = {"rl": {hash_type: hash_value}}
        # Submissions are never cached — each call triggers a new analysis.
        return await self._post("/api/dynamic/auxiliary/analyze/v1/submit", body)

    async def tcai_0106_auxiliary_report(self, hash_value: str) -> dict:
        """
        Retrieve an auxiliary dynamic analysis report (TCAI-0106).

        GET /api/dynamic/auxiliary/report/v1/query/{hash_type}/{hash_value}/latest

        Args:
            hash_value: MD5, SHA-1, or SHA-256 hash of the file.

        Returns:
            Parsed JSON response from the SI API.
        """
        hash_type = _detect_hash_type(hash_value)
        cache_key = ("tcai_0106_auxiliary_report", hash_type, hash_value)
        if (cached := self._cache_get(cache_key)) is not None:
            logger.debug("Cache hit: tcai_0106_auxiliary_report %s", hash_value)
            return cached
        path = f"/api/dynamic/auxiliary/report/v1/query/{hash_type}/{hash_value}/latest"
        result = await self._get(path, params={"format": "json"})
        self._cache_set(cache_key, result)
        return result

    # ------------------------------------------------------------------ #
    # TCA-0207 – Dynamic Analysis Submission                               #
    # ------------------------------------------------------------------ #

    _VALID_PLATFORMS = frozenset({
        "windows11", "windows10", "windows7", "macos11", "linux", "android12"
    })
    _VALID_GEOLOCATIONS = frozenset({
        "us", "uk", "in", "br", "de", "jp", "sg", "it", "es", "fr", "tor"
    })
    _VALID_LOCALES = frozenset({
        "en-US", "en-GB", "pt-BR", "de-DE", "ja-JP", "it-IT", "es-ES", "fr-FR"
    })

    async def tca_0207_start_dynamic_analysis(
        self,
        platform: str,
        *,
        hash_value: str | None = None,
        url: str | None = None,
        timeout: int = 200,
        internet_simulation: bool = False,
        geolocation: str | None = None,
        locale: str | None = None,
        sample_name: str | None = None,
    ) -> dict:
        """
        Submit a file or URL for dynamic analysis (TCA-0207).

        POST /api/dynamic/analysis/analyze/v1/query/json

        Exactly one of ``hash_value`` or ``url`` must be provided.
        Results become available approximately 15 minutes after submission
        via TCA-0106. Rate limit: 3 requests per minute.

        Args:
            platform:            Sandbox environment. One of: windows11,
                                 windows10, windows7, macos11, linux, android12.
            hash_value:          MD5, SHA-1, or SHA-256 hash of the file.
            url:                 URL to submit for dynamic analysis.
            timeout:             Analysis duration in seconds (30–500, default 200).
                                 Applies to both file and URL submissions.
            internet_simulation: Allow simulated internet access during analysis.
            geolocation:         Simulate traffic from a specific region.
                                 One of: us, uk, in, br, de, jp, sg, it, es, fr, tor.
            locale:              System locale for the sandbox.
                                 One of: en-US, en-GB, pt-BR, de-DE, ja-JP,
                                 it-IT, es-ES, fr-FR.
            sample_name:         Override the filename used during analysis.

        Returns:
            Parsed JSON response containing analysis_id, status, and
            requested_hash.

        Raises:
            ValueError: If neither or both of hash_value/url are provided,
                        or if timeout is outside 30–500.
        """
        if (hash_value is None) == (url is None):
            raise ValueError("Exactly one of 'hash_value' or 'url' must be provided.")
        if platform not in self._VALID_PLATFORMS:
            logger.warning(
                "tca_0207: unrecognised platform '%s' (known: %s) – proceeding anyway",
                platform,
                ", ".join(sorted(self._VALID_PLATFORMS)),
            )
        if not 30 <= timeout <= 500:
            raise ValueError(f"timeout must be between 30 and 500, got {timeout}")
        if geolocation is not None and geolocation not in self._VALID_GEOLOCATIONS:
            logger.warning(
                "tca_0207: unrecognised geolocation '%s' (known: %s) – proceeding anyway",
                geolocation,
                ", ".join(sorted(self._VALID_GEOLOCATIONS)),
            )
        if locale is not None and locale not in self._VALID_LOCALES:
            logger.warning(
                "tca_0207: unrecognised locale '%s' (known: %s) – proceeding anyway",
                locale,
                ", ".join(sorted(self._VALID_LOCALES)),
            )

        if hash_value is not None:
            hash_type = _detect_hash_type(hash_value)
            rl_body: dict = {
                hash_type: hash_value,
                "platform": platform,
                "response_format": "json",
                "timeout": timeout,
            }
        else:
            rl_body = {
                "url": url,
                "platform": platform,
                "response_format": "json",
                "timeout": timeout,
            }

        optional_parts = []
        if hash_value is not None:
            optional_parts.append("skip_file_type_check=true")
        if geolocation is not None:
            optional_parts.append(f"geolocation={geolocation}")
        if locale is not None:
            optional_parts.append(f"locale={locale}")
        if sample_name is not None:
            optional_parts.append(f"sample_name={sample_name}")
        if optional_parts:
            rl_body["optional_parameters"] = ",".join(optional_parts)

        body: dict = {"rl": rl_body}
        if internet_simulation:
            body["rl"]["internet_simulation"] = True

        # Submissions are never cached — each call triggers a new analysis.
        return await self._post(
            "/api/dynamic/analysis/analyze/v1/query/json", body
        )

    # ------------------------------------------------------------------ #
    # TCAI-0101 – RCA2 Classification                                      #
    # ------------------------------------------------------------------ #

    async def tcai_0101_rca2(self, hash_value: str) -> dict:
        """
        Fetch the RCA2 (Reversing Classification Architecture 2) report (TCAI-0101).

        GET /api/rca2/v1/query/{hash_type}/{hash_value}?format=json&extended=true

        Args:
            hash_value: MD5, SHA-1, or SHA-256 hash of the file.

        Returns:
            Parsed JSON response from the SI API.
        """
        hash_type = _detect_hash_type(hash_value)
        cache_key = ("tcai_0101_rca2", hash_type, hash_value)
        if (cached := self._cache_get(cache_key)) is not None:
            logger.debug("Cache hit: tcai_0101_rca2 %s", hash_value)
            return cached
        path = f"/api/rca2/v1/query/{hash_type}/{hash_value}"
        result = await self._get(path, params={"format": "json", "extended": "true"})
        logger.info(f'Fetching RCA2 classification from SI {hash_type} with hash value {hash_value}')
        self._cache_set(cache_key, result)
        return result

    async def tcai_0101_rca2_bulk(self, hash_values: list[str], hash_type: str) -> dict:
        """
        Fetch RCA2 classification for up to 100 files in a single request (TCAI-0101).

        POST /api/rca2/v1/bulk_query/json?extended=true

        Args:
            hash_values: List of hashes (max 100). All must be of ``hash_type``.
            hash_type:   One of "md5", "sha1", or "sha256".

        Returns:
            Parsed JSON response with ``rl.rca2.entries`` and
            ``rl.rca2.invalid_hashes``.
        """
        if len(hash_values) > 100:
            raise ValueError(
                "TCAI-0101 bulk query accepts at most 100 hashes per request."
            )
        body = {"rl": {"query": {"hash_type": hash_type, "hashes": hash_values}}}
        # Bulk queries are never cached — different callers may submit different
        # subsets and caching by full list would have very low hit rates.
        return await self._post("/api/rca2/v1/bulk_query/json?extended=true", body)

    # ------------------------------------------------------------------ #
    # TCA-0101 – File Reputation (Malware Presence)                        #
    # ------------------------------------------------------------------ #

    async def tca_0101_malware_presence(self, hash_value: str) -> dict[str, Any] | None:
        """Get file reputation from TICloud (TCA-0101).
        
        Args:
            hash_value: File hash (SHA1, SHA256, or MD5)
            
        Returns:
            Reputation data dictionary or None if not found
        """
        
        hash_type = _detect_hash_type(hash_value)
        cache_key = ("tca_0101_malware_presence", hash_type, hash_value)
        if (cached := self._cache_get(cache_key)) is not None:
            logger.debug("Cache hit: tca_0101_malware_presence %s", hash_value)
            return cached
        path = f"/api/databrowser/malware_presence/query/{hash_type}/{hash_value}"
        result = await self._get(path, params={"extended": "true", "format": "json"})
        self._cache_set(cache_key, result)
        return result

    # ------------------------------------------------------------------ #
    # TCA-0103 – Historic Multi-AV Scan Records                            #
    # ------------------------------------------------------------------ #

    async def tca_0103_av_scanners(self, hash_value: str) -> dict:
        """
        Fetch the most recent multi-AV scan record for a file (TCA-0103).

        GET /api/xref/v2/query/{hash_type}/{hash_value}?format=json

        Returns the latest scan result (``history=false``) including each
        scanner's name, verdict, and version.

        Args:
            hash_value: MD5, SHA-1, or SHA-256 hash of the file.

        Returns:
            Parsed JSON response from the SI API.
        """
        hash_type = _detect_hash_type(hash_value)
        cache_key = ("tca_0103_av_scanners", hash_type, hash_value)
        if (cached := self._cache_get(cache_key)) is not None:
            logger.debug("Cache hit: tca_0103_av_scanners %s", hash_value)
            return cached
        path = f"/api/xref/v2/query/{hash_type}/{hash_value}"
        result = await self._get(path, params={"format": "json"})
        self._cache_set(cache_key, result)
        return result

    # ------------------------------------------------------------------ #
    # TCA-0106 – Dynamic Analysis Report (merged)                          #
    # ------------------------------------------------------------------ #

    # ------------------------------------------------------------------ #
    # Extracted Samples                                                    #
    # ------------------------------------------------------------------ #

    async def extracted_samples_query(
        self,
        sha1: str,
        *,
        next_page_sha1: str | None = None,
    ) -> dict:
        """
        Fetch SHA-1 hashes of files extracted from the given sample.

        GET /api/children/v1/query/sha1/{sha1}[/start_sha1/{next_page_sha1}]

        Args:
            sha1:           SHA-1 hash of the parent sample.
            next_page_sha1: Cursor for the next page of results (from
                            ``rl.next_page`` of a previous response).

        Returns:
            Parsed JSON with ``rl.children`` (list of SHA-1 strings) and
            ``rl.next_page`` (SHA-1 cursor or null).

        Raises:
            ValueError: If sha1 is not a 40-character hex string.
        """
        if len(sha1) != 40:
            raise ValueError(
                f"extracted_samples_query requires a SHA-1 hash (40 hex chars), "
                f"got length {len(sha1)}."
            )
        path = f"/api/children/v1/query/sha1/{sha1}"
        if next_page_sha1 is not None:
            path = f"{path}/start_sha1/{next_page_sha1}"
        cache_key = ("extracted_samples_query", sha1, next_page_sha1)
        if (cached := self._cache_get(cache_key)) is not None:
            logger.debug("Cache hit: extracted_samples_query %s", sha1)
            return cached
        result = await self._get(path)
        self._cache_set(cache_key, result)
        return result

    # ------------------------------------------------------------------ #
    # TCA-0302 – ImpHash Similarity                                        #
    # ------------------------------------------------------------------ #

    async def tca_0302_imphash_index(
        self,
        imphash: str,
        *,
        next_page_sha1: str | None = None,
    ) -> dict:
        """
        Fetch SHA-1 hashes of files that share the given imphash (TCA-0302).

        GET /api/imphash_index/v1/query/{imphash}[/start_sha1/{next_page_sha1}]

        Args:
            imphash:        The imphash string to look up.
            next_page_sha1: SHA-1 of the first entry on the next page
                            (for pagination).

        Returns:
            Parsed JSON response with ``rl.imphash_index.sha1_list``.
        """
        path = f"/api/imphash_index/v1/query/{imphash}"
        if next_page_sha1 is not None:
            path = f"{path}/start_sha1/{next_page_sha1}"
        cache_key = ("tca_0302_imphash_index", imphash, next_page_sha1)
        if (cached := self._cache_get(cache_key)) is not None:
            logger.debug("Cache hit: tca_0302_imphash_index %s", imphash)
            return cached
        result = await self._get(path, params={"format": "json"})
        self._cache_set(cache_key, result)
        return result

    # ------------------------------------------------------------------ #
    # TCA-0301 – RHA1 Functional Similarity (Group by RHA1)                #
    # ------------------------------------------------------------------ #

    async def tca_0301_group_by_rha1(
        self,
        sha1: str,
        rha1_type: str = "pe01",
        *,
        limit: int = 50,
    ) -> dict:
        """
        Fetch functionally similar files for a SHA-1 hash (TCA-0301).

        GET /api/group_by_rha1/v1/query/{rha1_type}/{sha1}?format=json&limit=N&extended=true

        Returns:
            Parsed JSON with ``rl.group_by_rha1.sha1_list`` containing similar
            file entries (sha1, classification, threat_name).
        """
        if len(sha1) != 40:
            raise ValueError(
                f"TCA-0301 requires a SHA-1 hash (40 hex characters), got length {len(sha1)}."
            )
        cache_key = ("tca_0301_group_by_rha1", rha1_type, sha1, limit)
        if (cached := self._cache_get(cache_key)) is not None:
            logger.debug("Cache hit: tca_0301_group_by_rha1 %s (%s)", sha1, rha1_type)
            return cached
        path = f"/api/group_by_rha1/v1/query/{rha1_type}/{sha1}"
        params = {"format": "json", "limit": limit, "extended": "true"}
        result = await self._get(path, params=params)
        self._cache_set(cache_key, result)
        return result

    # ------------------------------------------------------------------ #
    # TCA-0321 – RHA1 Analytics                                            #
    # ------------------------------------------------------------------ #

    _VALID_RHA1_TYPES = frozenset({"pe01", "pe02", "elf01", "macho01"})

    async def tca_0321_rha1_analytics(
        self,
        sha1: str,
        rha1_type: str,
        *,
        extended: bool = False,
    ) -> dict:
        """
        Fetch counts of functionally similar samples for a file (TCA-0321).

        Only works for executable file types (PE, ELF, Mach-O).

        GET /api/rha1/analytics/v1/query/{rha1_type}/{sha1}?format=json

        Args:
            sha1:      SHA-1 hash of the file.
            rha1_type: Similarity bucket precision. One of: pe01, pe02,
                       elf01, macho01.
            extended:  When True, include per-sample metadata in the response
                       (md5, sha256, classification, threat_name, etc.).

        Returns:
            Parsed JSON response containing ``rha1_counters`` with
            ``sample_counters`` (malicious, suspicious, known, total) and,
            when extended=True, ``sample_metadata``.

        Raises:
            ValueError: If rha1_type is not one of the valid options, or if
                        sha1 is not a 40-character hex string.
        """
        if rha1_type not in self._VALID_RHA1_TYPES:
            raise ValueError(
                f"Invalid rha1_type '{rha1_type}'. "
                f"Must be one of: {', '.join(sorted(self._VALID_RHA1_TYPES))}"
            )
        if len(sha1) != 40:
            raise ValueError(
                f"rha1_type analytics requires a SHA-1 hash (40 hex characters), "
                f"got length {len(sha1)}."
            )

        cache_key = ("tca_0321_rha1_analytics", rha1_type, sha1, extended)
        if (cached := self._cache_get(cache_key)) is not None:
            logger.debug("Cache hit: tca_0321_rha1_analytics %s (%s)", sha1, rha1_type)
            return cached

        path = f"/api/rha1/analytics/v1/query/{rha1_type}/{sha1}"
        params: dict = {"format": "json"}
        if extended:
            params["extended"] = "true"

        result = await self._get(path, params=params)
        self._cache_set(cache_key, result)
        return result

    async def tca_0321_rha1_analytics_bulk(
        self,
        sha1_hashes: list[str],
        rha1_type: str,
        *,
        extended: bool = False,
    ) -> dict:
        """
        Fetch RHA1 analytics for multiple files in a single request (TCA-0321).

        POST /api/rha1/analytics/v1/query/json

        Args:
            sha1_hashes: List of SHA-1 hashes. All must be 40-character hex strings.
            rha1_type:   Similarity bucket precision. One of: pe01, pe02,
                         elf01, macho01.
            extended:    When True, include per-sample metadata in the response.

        Returns:
            Parsed JSON response containing ``entries``, ``invalid_hashes``,
            and ``unknown_hashes``.

        Raises:
            ValueError: If rha1_type is invalid or any hash is not 40 characters.
        """
        if rha1_type not in self._VALID_RHA1_TYPES:
            raise ValueError(
                f"Invalid rha1_type '{rha1_type}'. "
                f"Must be one of: {', '.join(sorted(self._VALID_RHA1_TYPES))}"
            )
        bad = [h for h in sha1_hashes if len(h) != 40]
        if bad:
            raise ValueError(
                f"All hashes must be SHA-1 (40 hex characters). "
                f"Invalid: {bad[:5]}"
            )

        cache_key = (
            "tca_0321_rha1_analytics_bulk", rha1_type, tuple(sha1_hashes), extended
        )
        if (cached := self._cache_get(cache_key)) is not None:
            logger.debug(
                "Cache hit: tca_0321_rha1_analytics_bulk (%d hashes)", len(sha1_hashes)
            )
            return cached

        body: dict = {
            "rl": {
                "query": {
                    "rha1_type": rha1_type,
                    "response_format": "json",
                    "extended": "true" if extended else "false",
                    "hashes": sha1_hashes,
                }
            }
        }
        result = await self._post("/api/rha1/analytics/v1/query/json", body)
        self._cache_set(cache_key, result)
        return result

    # ------------------------------------------------------------------ #
    # TCA-0320 – Expression Search                                         #
    # ------------------------------------------------------------------ #

    _VALID_SORT_FIELDS = frozenset({
        "sha1", "firstseen", "threatname", "sampletype", "filecount", "size"
    })

    async def tca_0320_expression_search(
        self,
        query: str,
        *,
        page: int = 1,
        records_per_page: int = 10000,
        sort: str | None = None,
    ) -> dict:
        """
        Search Spectra Intelligence using an expression query (TCA-0320).

        POST /api/search/v1/query

        Args:
            query:            Search expression (up to 7,000 characters).
            page:             Page number (1-based, default 1).
            records_per_page: Results per page (1–10,000, default 10,000).
            sort:             Optional sort field with direction, e.g.
                              ``"firstseen asc"`` or ``"size desc"``. Field
                              must be one of: sha1, firstseen, threatname,
                              sampletype, filecount, size.

        Returns:
            Parsed JSON response containing ``total_count``, ``sample_count``,
            ``more_pages``, ``next_page``, and ``entries``.

        Raises:
            ValueError: If records_per_page is outside 1–10,000, or if the
                        sort field is not one of the valid options.
        """
        if not 1 <= records_per_page <= 10000:
            raise ValueError(
                f"records_per_page must be between 1 and 10,000, got {records_per_page}"
            )
        if sort is not None:
            field = sort.split()[0]
            if field not in self._VALID_SORT_FIELDS:
                raise ValueError(
                    f"Invalid sort field '{field}'. "
                    f"Must be one of: {', '.join(sorted(self._VALID_SORT_FIELDS))}"
                )

        cache_key = ("tca_0320_expression_search", query, page, records_per_page, sort)
        if (cached := self._cache_get(cache_key)) is not None:
            logger.debug("Cache hit: tca_0320_expression_search page=%d", page)
            return cached

        body: dict = {
            "query": query,
            "format": "json",
            "page": page,
            "records_per_page": records_per_page,
        }
        if sort is not None:
            body["sort"] = sort

        result = await self._post("/api/search/v1/query", body)
        self._cache_set(cache_key, result)
        return result

    async def tca_0106_dynamic_analysis_merged(
        self, hash_value: str, *, artifacts_url: bool = False, analysis_id: str | None = None
    ) -> dict:
        """
        Fetch the merged dynamic analysis report for a file (TCA-0106).

        Returns the combined view across all analyses for the given hash,
        including the ``history_analysis`` field that summarises every run.

        GET /api/dynamic/analysis/report/v1/query/{hash_type}/{hash_value}[/{analysis_id}]?format=json

        When ``analysis_id`` is provided the path targets that specific run.
        If the API returns 404 for a specific analysis_id, the response body
        contains a JSON status object (e.g. ``{"status": "analyzing", ...}``)
        which is returned directly rather than raising an error.

        Args:
            hash_value:    MD5, SHA-1, or SHA-256 hash of the file.
            artifacts_url: When True, include download links for PCAP,
                           memory strings, screenshots, and dropped files.
                           Links expire after one hour.
            analysis_id:   When provided, fetch the report for this specific
                           analysis run only.

        Returns:
            Parsed JSON response from the SI API, or a status dict if the
            analysis is still in progress.
        """
        hash_type = _detect_hash_type(hash_value)
        cache_key = (
            "tca_0106_dynamic_analysis_merged",
            hash_type,
            hash_value,
            artifacts_url,
            analysis_id,
        )
        if analysis_id is None and (cached := self._cache_get(cache_key)) is not None:
            logger.debug(
                "Cache hit: tca_0106_dynamic_analysis_merged %s", hash_value
            )
            return cached
        path = f"/api/dynamic/analysis/report/v1/query/{hash_type}/{hash_value}"
        if analysis_id is not None:
            path = f"{path}/{analysis_id}"
        params: dict = {"format": "json"}
        request_timeout: float = 30.0
        if artifacts_url:
            params["artifacts_url"] = "True"
        if artifacts_url or analysis_id is not None:
            # increasing timeout for single report or artifacts due to the API taking longer
            # then the merged but having a hard cut off
            request_timeout = 60.0
        try:
            result = await self._get(path, params=params, timeout=request_timeout)
        except httpx.HTTPStatusError as exc:
            if exc.response.status_code == 404 and analysis_id is not None:
                try:
                    return exc.response.json()
                except Exception:
                    pass
            raise
        if analysis_id is None:
            self._cache_set(cache_key, result)
        return result

    async def tca_0106_url_dynamic_analysis(
        self, url: str, *, artifacts_url: bool = False, analysis_id: str | None = None
    ) -> dict:
        """
        Fetch the dynamic analysis report for a URL (TCA-0106).

        GET /api/dynamic/analysis/report/v1/query/url/base64/{b64_url}[/{analysis_id}]?format=json

        The URL is base64url-encoded (no padding) before being placed in the
        path, matching the SDK's ``get_dynamic_analysis_results(url=...)``
        behaviour.

        When ``analysis_id`` is provided the path targets that specific run.
        If the API returns 404 for a specific analysis_id, the response body
        contains a JSON status object (e.g. ``{"status": "analyzing", ...}``)
        which is returned directly rather than raising an error.

        Args:
            url:           The URL that was submitted for dynamic analysis.
            artifacts_url: When True, include download links for PCAP,
                           screenshots, and dropped files.
                           Links expire after one hour.
            analysis_id:   When provided, fetch the report for this specific
                           analysis run only.

        Returns:
            Parsed JSON response from the SI API, or a status dict if the
            analysis is still in progress.
        """
        b64 = base64.urlsafe_b64encode(url.encode()).rstrip(b"=").decode()
        cache_key = ("tca_0106_url_dynamic_analysis", b64, artifacts_url, analysis_id)
        if analysis_id is None and (cached := self._cache_get(cache_key)) is not None:
            logger.debug("Cache hit: tca_0106_url_dynamic_analysis %s", url)
            return cached
        path = f"/api/dynamic/analysis/report/v1/query/url/base64/{b64}"
        if analysis_id is not None:
            path = f"{path}/{analysis_id}"
        params: dict = {"format": "json"}
        request_timeout: float | None = 30.0
        if artifacts_url:
            params["artifacts_url"] = "True"
        if artifacts_url or analysis_id is not None:
            # slightly longer for an analysis_id specific report or artifacts 
            # more likely server side API timeout first but use this as fall back so 
            # no infinite looping 
            request_timeout = 60
        try:
            result = await self._get(path, params=params, timeout=request_timeout)
        except httpx.HTTPStatusError as exc:
            if exc.response.status_code == 404 and analysis_id is not None:
                try:
                    return exc.response.json()
                except Exception:
                    pass
            raise
        if analysis_id is None:
            self._cache_set(cache_key, result)
        return result

    # ------------------------------------------------------------------ #
    # TCA-0303 – YARA Hunting                                              #
    # ------------------------------------------------------------------ #

    _VALID_YARA_TIME_FORMATS = frozenset({"timestamp", "utc"})

    async def tca_0303_create_or_update_ruleset(
        self,
        ruleset_name: str,
        text: str,
        sample_available: bool = True,
    ) -> dict:
        """
        Create or update a YARA ruleset (TCA-0303).

        POST /api/yara/admin/v1/ruleset

        Args:
            ruleset_name:     Name of the ruleset to create or update.
            text:             YARA rule content.
            sample_available: Whether to include sample availability data
                              in match results (default True).

        Returns:
            Parsed JSON response with ``ruleset_name`` and ``ruleset_sha1``.
        """
        body = {
            "ruleset_name": ruleset_name,
            "text": text,
            "sample_available": sample_available,
        }
        return await self._post("/api/yara/admin/v1/ruleset", body)

    async def tca_0303_list_rulesets(self) -> dict:
        """
        List all YARA rulesets (TCA-0303).

        GET /api/yara/admin/v1/ruleset

        Returns:
            Parsed JSON response containing an array of ruleset objects
            with ``ruleset_name``, ``valid``, and ``approved`` fields.
        """
        return await self._get("/api/yara/admin/v1/ruleset")

    async def tca_0303_get_ruleset(self, ruleset_name: str) -> dict:
        """
        Get information about a specific YARA ruleset (TCA-0303).

        GET /api/yara/admin/v1/ruleset/{ruleset_name}

        Args:
            ruleset_name: Name of the ruleset.

        Returns:
            Parsed JSON response with ``ruleset_name``, ``valid``,
            and ``approved`` fields.
        """
        return await self._get(f"/api/yara/admin/v1/ruleset/{ruleset_name}")

    async def tca_0303_get_ruleset_text(self, ruleset_name: str) -> dict:
        """
        Get the YARA rule content of a ruleset (TCA-0303).

        GET /api/yara/admin/v1/ruleset/{ruleset_name}/text

        Args:
            ruleset_name: Name of the ruleset.

        Returns:
            Parsed JSON response with a ``text`` field containing the
            raw YARA rule content.
        """
        return await self._get(f"/api/yara/admin/v1/ruleset/{ruleset_name}/text")

    async def tca_0303_delete_ruleset(self, ruleset_name: str) -> None:
        """
        Delete a YARA ruleset (TCA-0303).

        DELETE /api/yara/admin/v1/ruleset/{ruleset_name}

        Args:
            ruleset_name: Name of the ruleset to delete.
        """
        await self._delete(f"/api/yara/admin/v1/ruleset/{ruleset_name}")

    async def tca_0303_get_matches(
        self,
        time_format: str,
        time_value: str,
        *,
        extended: bool = False,
    ) -> dict:
        """
        Query the YARA match feed (TCA-0303).

        GET /api/feed/yara/v1/query/{time_format}/{time_value}

        Args:
            time_format: Time format for the query start point.
                         One of: ``"timestamp"`` or ``"utc"``.
            time_value:  Start of the time range to query.
            extended:    When True, include additional fields in results.

        Returns:
            Parsed JSON response containing match feed entries.

        Raises:
            ValueError: If time_format is not one of the valid options.
        """
        if time_format not in self._VALID_YARA_TIME_FORMATS:
            raise ValueError(
                f"Invalid time_format '{time_format}'. "
                f"Must be one of: {', '.join(sorted(self._VALID_YARA_TIME_FORMATS))}"
            )
        params: dict = {"format": "json"}
        if extended:
            params["extended"] = "true"
        return await self._get(
            f"/api/feed/yara/v1/query/{time_format}/{time_value}", params=params
        )

    # ------------------------------------------------------------------ #
    # TCA-0319 – YARA Retro Hunting                                        #
    # ------------------------------------------------------------------ #

    async def tca_0319_start_retro_hunt(self, ruleset_name: str) -> dict:
        """
        Start a YARA retro hunt for a ruleset (TCA-0319).

        POST /api/yara/admin/v1/ruleset/start-retro-hunt

        Args:
            ruleset_name: Name of the ruleset to run the retro hunt against.

        Returns:
            Parsed JSON response with ``ruleset_name`` and ``ruleset_sha1``.
        """
        return await self._post(
            "/api/yara/admin/v1/ruleset/start-retro-hunt",
            {"ruleset_name": ruleset_name},
        )

    async def tca_0319_cancel_retro_hunt(self, ruleset_name: str) -> dict:
        """
        Cancel a running YARA retro hunt (TCA-0319).

        POST /api/yara/admin/v1/ruleset/cancel-retro-hunt

        Args:
            ruleset_name: Name of the ruleset whose retro hunt to cancel.

        Returns:
            Parsed JSON response with ``ruleset_name`` and ``ruleset_sha1``.
        """
        return await self._post(
            "/api/yara/admin/v1/ruleset/cancel-retro-hunt",
            {"ruleset_name": ruleset_name},
        )

    async def tca_0319_get_retro_hunt_status(self, ruleset_name: str) -> dict:
        """
        Get the status of a YARA retro hunt (TCA-0319).

        GET /api/yara/admin/v1/ruleset/{ruleset_name}/status-retro-hunt

        Args:
            ruleset_name: Name of the ruleset to check.

        Returns:
            Parsed JSON response with ``retro_status``, ``progress``,
            ``start_time``, ``finish_time``, and ``estimated_finish_time``.
        """
        return await self._get(
            f"/api/yara/admin/v1/ruleset/{ruleset_name}/status-retro-hunt"
        )

    async def tca_0319_get_retro_matches(
        self,
        time_format: str,
        time_value: str,
        *,
        extended: bool = False,
    ) -> dict:
        """
        Query the YARA retro hunt match feed (TCA-0319).

        GET /api/feed/yara/retro/v1/query/{time_format}/{time_value}

        Args:
            time_format: Time format for the query start point.
                         One of: ``"timestamp"`` or ``"utc"``.
            time_value:  Start of the time range to query.
            extended:    When True, include additional fields in results.

        Returns:
            Parsed JSON response containing retro match feed entries.

        Raises:
            ValueError: If time_format is not one of the valid options.
        """
        if time_format not in self._VALID_YARA_TIME_FORMATS:
            raise ValueError(
                f"Invalid time_format '{time_format}'. "
                f"Must be one of: {', '.join(sorted(self._VALID_YARA_TIME_FORMATS))}"
            )
        params: dict = {"format": "json"}
        if extended:
            params["extended"] = "true"
        return await self._get(
            f"/api/feed/yara/retro/v1/query/{time_format}/{time_value}", params=params
        )

    # ------------------------------------------------------------------ #
    # TCA-0501 – Certificate Index                                         #
    # ------------------------------------------------------------------ #

    async def tca_0501_certificate_index(
        self,
        thumbprint: str,
        *,
        page: str | None = None,
        limit: int = 100,
        extended: bool = False,
        classification: str | None = None,
    ) -> dict:
        """
        Fetch a list of samples signed with a specific certificate (TCA-0501).

        GET /api/certificate/index/v1/query/thumbprint/{thumbprint}[/page/{page}]

        Args:
            thumbprint:     MD5, SHA-1, or SHA-256 thumbprint of the certificate.
            page:           Pagination token from a previous response's
                            ``next_page`` field.
            limit:          Number of samples to return (1–100, default 100).
            extended:       When True, include extended sample metadata.
            classification: Filter by sample classification. One of: ``KNOWN``,
                            ``SUSPICIOUS``, ``MALICIOUS``, ``UNKNOWN``.

        Returns:
            Parsed JSON response containing ``rl.samples`` and optionally
            ``rl.next_page`` for pagination.
        """
        cache_key = ("tca_0501_certificate_index", thumbprint, page, limit, extended, classification)
        if (cached := self._cache_get(cache_key)) is not None:
            logger.debug("Cache hit: tca_0501_certificate_index %s", thumbprint)
            return cached
        path = f"/api/certificate/index/v1/query/thumbprint/{thumbprint}"
        if page is not None:
            path = f"{path}/page/{page}"
        params: dict = {"format": "json", "limit": limit}
        if extended:
            params["extended"] = "true"
        if classification is not None:
            params["classification"] = classification
        # Extended queries return full sample metadata and can be slow on
        # high-volume certs (e.g. certs abused across thousands of samples).
        request_timeout = 90.0 if extended else 30.0
        result = await self._get(path, params=params, timeout=request_timeout)
        self._cache_set(cache_key, result)
        return result

    # ------------------------------------------------------------------ #
    # TCA-0502 – Certificate Analytics                                     #
    # ------------------------------------------------------------------ #

    async def tca_0502_certificate_analytics(self, thumbprint: str) -> dict:
        """
        Fetch analytics for a single certificate thumbprint (TCA-0502).

        GET /api/certificate/analytics/v1/query/thumbprint/{thumbprint}?format=json

        Returns sample counts by classification, blacklist/whitelist status,
        trust factor, threat level, and the certificate chain of trust.

        Args:
            thumbprint: MD5, SHA-1, or SHA-256 thumbprint of the certificate.

        Returns:
            Parsed JSON response containing ``rl.certificate_analytics``.
        """
        cache_key = ("tca_0502_certificate_analytics", thumbprint)
        if (cached := self._cache_get(cache_key)) is not None:
            logger.debug("Cache hit: tca_0502_certificate_analytics %s", thumbprint)
            return cached
        path = f"/api/certificate/analytics/v1/query/thumbprint/{thumbprint}"
        result = await self._get(path, params={"format": "json"})
        self._cache_set(cache_key, result)
        return result

    async def tca_0502_certificate_analytics_bulk(
        self, thumbprints: list[str]
    ) -> dict:
        """
        Fetch analytics for up to 100 certificate thumbprints (TCA-0502).

        POST /api/certificate/analytics/v1/query/thumbprint/json

        Args:
            thumbprints: List of MD5, SHA-1, or SHA-256 thumbprints (max 100).

        Returns:
            Parsed JSON response containing ``rl.certificate_analytics`` (list)
            and ``rl.invalid_thumbprints``.

        Raises:
            ValueError: If more than 100 thumbprints are provided.
        """
        if len(thumbprints) > 100:
            raise ValueError(
                "TCA-0502 bulk query accepts at most 100 thumbprints per request."
            )
        cache_key = ("tca_0502_certificate_analytics_bulk", tuple(thumbprints))
        if (cached := self._cache_get(cache_key)) is not None:
            logger.debug(
                "Cache hit: tca_0502_certificate_analytics_bulk (%d thumbprints)",
                len(thumbprints),
            )
            return cached
        body = {"rl": {"query": {"thumbprints": thumbprints, "format": "json"}}}
        result = await self._post(
            "/api/certificate/analytics/v1/query/thumbprint/json", body
        )
        self._cache_set(cache_key, result)
        return result

    # ------------------------------------------------------------------ #
    # TCA-0503 – Certificate Thumbprint Search                             #
    # ------------------------------------------------------------------ #

    async def tca_0503_certificate_search(
        self,
        common_name: str,
        *,
        limit: int = 100,
        page_common_name: str | None = None,
        page_thumbprint: str | None = None,
    ) -> dict:
        """
        Search for certificate thumbprints by common name (TCA-0503).

        POST /api/certificate/search/v1/query/subject/json

        Supports wildcard ``*`` to match variable character sequences
        (e.g. ``"Microsoft*"`` matches any common name starting with
        "Microsoft").

        Args:
            common_name:        Certificate common name or partial name.
                                Use ``*`` as a wildcard.
            limit:              Number of results to return (1–100, default 100).
            page_common_name:   Pagination token from a previous response's
                                ``next_page_common_name`` field.
            page_thumbprint:    Pagination token from a previous response's
                                ``next_page_thumbprint`` field.

        Returns:
            Parsed JSON response containing ``rl.search`` (list of common
            names with associated thumbprints) and pagination tokens
            ``rl.next_page_common_name`` / ``rl.next_page_thumbprint``.
        """
        cache_key = (
            "tca_0503_certificate_search",
            common_name,
            limit,
            page_common_name,
            page_thumbprint,
        )
        if (cached := self._cache_get(cache_key)) is not None:
            logger.debug("Cache hit: tca_0503_certificate_search %s", common_name)
            return cached
        query: dict = {
            "common_name": common_name,
            "response_format": "json",
            "limit": limit,
        }
        if page_common_name is not None:
            query["page_common_name"] = page_common_name
        if page_thumbprint is not None:
            query["page_thumbprint"] = page_thumbprint
        result = await self._post(
            "/api/certificate/search/v1/query/subject/json", {"rl": {"query": query}}
        )
        self._cache_set(cache_key, result)
        return result

    # ------------------------------------------------------------------ #
    # TCA-0406 – IP Threat Intelligence                                    #
    # ------------------------------------------------------------------ #

    async def tca_0406_ip_report(self, ip: str) -> dict:
        """
        Fetch the threat intelligence report for an IP address (TCA-0406).

        POST /api/networking/ip/report/v1/query/json?extended=true

        Returns third-party reputations, downloaded file statistics, top
        threats, WHOIS, and GeoIP data.

        Args:
            ip: IP address to query.

        Returns:
            Parsed JSON response from the SI API.
        """
        cache_key = ("tca_0406_ip_report", ip)
        if (cached := self._cache_get(cache_key)) is not None:
            logger.debug("Cache hit: tca_0406_ip_report %s", ip)
            return cached
        query: dict = {"ip": ip, "response_format": "json"}
        result = await self._post(
            "/api/networking/ip/report/v1/query/json?extended=true",
            {"rl": {"query": query}},
        )
        self._cache_set(cache_key, result)
        return result

    async def tca_0406_ip_downloaded_files(
        self,
        ip: str,
        *,
        limit: int = 1000,
        extended: bool = False,
        classification: str | None = None,
        page: str | None = None,
    ) -> dict:
        """
        Fetch files downloaded from an IP address (TCA-0406).

        POST /api/networking/ip/downloaded_files/v1/query/json

        Args:
            ip:             IP address to query.
            limit:          Maximum number of files to return (default 1000).
            extended:       When True, include extended file metadata.
            classification: Filter by classification. One of: ``KNOWN``,
                            ``SUSPICIOUS``, ``MALICIOUS``, ``UNKNOWN``.
            page:           Pagination token from a previous response's
                            ``next_page`` field.

        Returns:
            Parsed JSON response from the SI API.
        """
        cache_key = ("tca_0406_ip_downloaded_files", ip, limit, extended, classification, page)
        if (cached := self._cache_get(cache_key)) is not None:
            logger.debug("Cache hit: tca_0406_ip_downloaded_files %s", ip)
            return cached
        query: dict = {"ip": ip, "response_format": "json", "limit": limit}
        if extended:
            query["extended"] = True
        if classification is not None:
            query["classification"] = classification
        if page is not None:
            query["page"] = page
        result = await self._post(
            "/api/networking/ip/downloaded_files/v1/query/json",
            {"rl": {"query": query}},
        )
        self._cache_set(cache_key, result)
        return result

    async def tca_0406_ip_related_urls(
        self,
        ip: str,
        *,
        limit: int = 1000,
        page: str | None = None,
    ) -> dict:
        """
        Fetch URLs associated with an IP address (TCA-0406).

        POST /api/networking/ip/urls/v1/query/json

        Args:
            ip:    IP address to query.
            limit: Maximum number of URLs to return (default 1000).
            page:  Pagination token from a previous response's ``next_page``
                   field.

        Returns:
            Parsed JSON response from the SI API.
        """
        cache_key = ("tca_0406_ip_related_urls", ip, limit, page)
        if (cached := self._cache_get(cache_key)) is not None:
            logger.debug("Cache hit: tca_0406_ip_related_urls %s", ip)
            return cached
        query: dict = {"ip": ip, "response_format": "json", "limit": limit}
        if page is not None:
            query["page"] = page
        result = await self._post(
            "/api/networking/ip/urls/v1/query/json",
            {"rl": {"query": query}},
        )
        self._cache_set(cache_key, result)
        return result

    async def tca_0406_ip_resolutions(
        self,
        ip: str,
        *,
        limit: int = 1000,
        page: str | None = None,
    ) -> dict:
        """
        Fetch passive DNS resolutions for an IP address (TCA-0406).

        POST /api/networking/ip/resolutions/v1/query/json

        Returns historical DNS records mapping this IP to hostnames,
        including resolution timestamps and data providers.

        Args:
            ip:    IP address to query.
            limit: Maximum number of resolution records to return (default 1000).
            page:  Pagination token from a previous response's ``next_page``
                   field.

        Returns:
            Parsed JSON response from the SI API.
        """
        cache_key = ("tca_0406_ip_resolutions", ip, limit, page)
        if (cached := self._cache_get(cache_key)) is not None:
            logger.debug("Cache hit: tca_0406_ip_resolutions %s", ip)
            return cached
        query: dict = {"ip": ip, "response_format": "json", "limit": limit}
        if page is not None:
            query["page"] = page
        result = await self._post(
            "/api/networking/ip/resolutions/v1/query/json",
            {"rl": {"query": query}},
        )
        self._cache_set(cache_key, result)
        return result

    # ------------------------------------------------------------------ #
    # TCA-0407 – Bulk Network Reputation                                   #
    # ------------------------------------------------------------------ #

    async def tca_0407_bulk_network_reputation(
        self,
        network_locations: list[str],
    ) -> dict:
        """
        Fetch reputation for up to 100 URLs, domains, and/or IP addresses
        in a single request (TCA-0407).

        POST /api/networking/reputation/v1/query/json

        The type of each indicator (URL, domain, IP) is detected automatically
        by the API. Results are returned as a flat list of entries, each
        containing reputation data, classification (URLs only), categories,
        third-party reputations, and associated malware indicator.

        Args:
            network_locations: List of up to 100 URLs, domains, or IP
                               addresses to query.

        Returns:
            Parsed JSON response from the SI API.
        """
        if not network_locations:
            return {"rl": {"entries": []}}
        if len(network_locations) > 100:
            raise ValueError(
                f"TCA-0407 supports at most 100 network locations per request; "
                f"{len(network_locations)} were provided."
            )
        cache_key = ("tca_0407_bulk_network_reputation", tuple(sorted(network_locations)))
        if (cached := self._cache_get(cache_key)) is not None:
            logger.debug("Cache hit: tca_0407_bulk_network_reputation (%d locations)", len(network_locations))
            return cached
        body = {
            "rl": {
                "query": {
                    "network_locations": [
                        {"network_location": loc} for loc in network_locations
                    ],
                    "response_format": "json",
                }
            }
        }
        result = await self._post(
            "/api/networking/reputation/v1/query/json",
            body,
        )
        self._cache_set(cache_key, result)
        return result

    # ------------------------------------------------------------------ #
    # TCA-0405 – Domain Threat Intelligence                                #
    # ------------------------------------------------------------------ #

    async def tca_0405_domain_report(self, domain: str) -> dict:
        """
        Fetch the threat intelligence report for a domain (TCA-0405).

        POST /api/networking/domain/report/v1/query/json

        Returns third-party reputations, downloaded file statistics, DNS
        records, top threats, certificates, and first/last seen timestamps.

        Args:
            domain: Domain name to query.

        Returns:
            Parsed JSON response from the SI API.
        """
        cache_key = ("tca_0405_domain_report", domain)
        if (cached := self._cache_get(cache_key)) is not None:
            logger.debug("Cache hit: tca_0405_domain_report %s", domain)
            return cached
        body = {"rl": {"query": {"domain": domain, "response_format": "json"}}}
        result = await self._post("/api/networking/domain/report/v1/query/json", body)
        self._cache_set(cache_key, result)
        return result

    async def tca_0405_domain_downloaded_files(
        self,
        domain: str,
        *,
        limit: int = 1000,
        extended: bool = False,
        classification: str | None = None,
    ) -> dict:
        """
        Fetch files downloaded from a domain (TCA-0405).

        POST /api/networking/domain/downloaded_files/v1/query/json

        Args:
            domain:         Domain name to query.
            limit:          Maximum number of files to return (default 1000).
            extended:       When True, include extended file metadata.
            classification: Filter by classification. One of: ``KNOWN``,
                            ``SUSPICIOUS``, ``MALICIOUS``, ``UNKNOWN``.

        Returns:
            Parsed JSON response from the SI API.
        """
        cache_key = ("tca_0405_domain_downloaded_files", domain, limit, extended, classification)
        if (cached := self._cache_get(cache_key)) is not None:
            logger.debug("Cache hit: tca_0405_domain_downloaded_files %s", domain)
            return cached
        query: dict = {"domain": domain, "response_format": "json", "limit": limit}
        if extended:
            query["extended"] = True
        if classification is not None:
            query["classification"] = classification
        result = await self._post(
            "/api/networking/domain/downloaded_files/v1/query/json",
            {"rl": {"query": query}},
        )
        self._cache_set(cache_key, result)
        return result

    async def tca_0405_domain_related_domains(
        self,
        domain: str,
        *,
        limit: int = 1000,
    ) -> dict:
        """
        Fetch domains related to a given domain (TCA-0405).

        POST /api/networking/domain/related_domains/v1/query/json

        Args:
            domain: Domain name to query.
            limit:  Maximum number of related domains to return (default 1000).

        Returns:
            Parsed JSON response from the SI API.
        """
        cache_key = ("tca_0405_domain_related_domains", domain, limit)
        if (cached := self._cache_get(cache_key)) is not None:
            logger.debug("Cache hit: tca_0405_domain_related_domains %s", domain)
            return cached
        query: dict = {"domain": domain, "response_format": "json", "limit": limit}
        result = await self._post(
            "/api/networking/domain/related_domains/v1/query/json",
            {"rl": {"query": query}},
        )
        self._cache_set(cache_key, result)
        return result

    async def tca_0405_domain_related_urls(
        self,
        domain: str,
        *,
        limit: int = 1000,
    ) -> dict:
        """
        Fetch URLs associated with a domain (TCA-0405).

        POST /api/networking/domain/urls/v1/query/json

        Args:
            domain: Domain name to query.
            limit:  Maximum number of URLs to return (default 1000).

        Returns:
            Parsed JSON response from the SI API.
        """
        cache_key = ("tca_0405_domain_related_urls", domain, limit)
        if (cached := self._cache_get(cache_key)) is not None:
            logger.debug("Cache hit: tca_0405_domain_related_urls %s", domain)
            return cached
        query: dict = {"domain": domain, "response_format": "json", "limit": limit}
        result = await self._post(
            "/api/networking/domain/urls/v1/query/json",
            {"rl": {"query": query}},
        )
        self._cache_set(cache_key, result)
        return result

    async def tca_0405_domain_resolutions(
        self,
        domain: str,
        *,
        limit: int = 1000,
    ) -> dict:
        """
        Fetch passive DNS resolutions for a domain (TCA-0405).

        POST /api/networking/domain/resolutions/v1/query/json

        Returns historical DNS resolution records including record type,
        resolved answer (IP address), resolution timestamp, and provider.

        Args:
            domain: Domain name to query.
            limit:  Maximum number of resolution records to return (default 1000).

        Returns:
            Parsed JSON response from the SI API.
        """
        cache_key = ("tca_0405_domain_resolutions", domain, limit)
        if (cached := self._cache_get(cache_key)) is not None:
            logger.debug("Cache hit: tca_0405_domain_resolutions %s", domain)
            return cached
        query: dict = {"domain": domain, "response_format": "json", "limit": limit}
        result = await self._post(
            "/api/networking/domain/resolutions/v1/query/json",
            {"rl": {"query": query}},
        )
        self._cache_set(cache_key, result)
        return result

    # ------------------------------------------------------------------ #
    # TCA-0403 – URL Threat Intelligence                                   #
    # ------------------------------------------------------------------ #

    async def tca_0403_url_report(self, url: str, *, use_cache: bool = True) -> dict:
        """
        Fetch the threat intelligence report for a URL (TCA-0403).

        POST /api/networking/url/v1/report/query/json

        Returns classification, threat level, threat name, categories,
        analysis history, and third-party reputation data for the URL.

        Args:
            url:       Full URL including protocol (http:// or https://).
            use_cache: When False, bypass the response cache (useful when
                       polling for a newly submitted analysis).

        Returns:
            Parsed JSON response from the SI API.
        """
        cache_key = ("tca_0403_url_report", url)
        if use_cache and (cached := self._cache_get(cache_key)) is not None:
            logger.debug("Cache hit: tca_0403_url_report %s", url)
            return cached
        body = {"rl": {"query": {"url": url, "response_format": "json"}}}
        result = await self._post("/api/networking/url/v1/report/query/json", body)
        if use_cache:
            self._cache_set(cache_key, result)
        return result

    async def tca_0403_url_downloaded_files(
        self,
        url: str,
        *,
        analysis_id: str | None = None,
        last_analysis: bool = False,
        limit: int = 1000,
        extended: bool = False,
        classification: str | None = None,
    ) -> dict:
        """
        Fetch files downloaded from a URL during analysis (TCA-0403).

        POST /api/networking/url/v1/downloaded_files/query/json

        Args:
            url:           Full URL including protocol (http:// or https://).
            analysis_id:   Restrict results to a specific analysis run.
            last_analysis: When True, return only files from the most recent
                           analysis. Defaults to False.
            limit:         Maximum number of files to return (default 1000).
            extended:      When True, include extended file metadata.
            classification: Filter by classification. One of: ``KNOWN``,
                            ``SUSPICIOUS``, ``MALICIOUS``, ``UNKNOWN``.

        Returns:
            Parsed JSON response from the SI API.
        """
        cache_key = (
            "tca_0403_url_downloaded_files",
            url,
            analysis_id,
            last_analysis,
            limit,
            extended,
            classification,
        )
        if (cached := self._cache_get(cache_key)) is not None:
            logger.debug("Cache hit: tca_0403_url_downloaded_files %s", url)
            return cached
        query: dict = {
            "url": url,
            "response_format": "json",
            "limit": limit,
        }
        if analysis_id is not None:
            query["analysis_id"] = analysis_id
        if last_analysis:
            query["last_analysis"] = True
        if extended:
            query["extended"] = True
        if classification is not None:
            query["classification"] = classification
        body = {"rl": {"query": query}}
        result = await self._post(
            "/api/networking/url/v1/downloaded_files/query/json", body
        )
        self._cache_set(cache_key, result)
        return result

    # ------------------------------------------------------------------ #
    # TCA-0404 – URL Analysis Submission                                   #
    # ------------------------------------------------------------------ #

    _VALID_ANALYSIS_TYPES = frozenset({"light", "fileless"})

    async def tca_0404_analyze_url(
        self,
        url: str,
        *,
        analysis_type: str | None = None,
    ) -> dict:
        """
        Submit a URL for analysis (TCA-0404).

        POST /api/networking/url/v1/analyze/query/json

        The submitted URL and any downloaded files are treated as public data
        accessible to all Spectra Intelligence users. File classifications
        become available through TCA-0403 approximately 30 minutes after
        submission. Only one URL per request; a 403 is returned if analysis
        is already in progress for the same URL.

        Args:
            url:           Complete URL to analyse. The ``http://`` or
                           ``https://`` protocol prefix is auto-prepended if
                           missing.
            analysis_type: Controls download behaviour during analysis.
                           ``None`` / omitted — comprehensive analysis
                           (default); ``"light"`` — analyse the submitted URL
                           only, no followed links; ``"fileless"`` — analyse
                           without downloading files.

        Returns:
            Parsed JSON response containing ``requested_url``, ``status``
            (``"started"``), and ``analysis_id``.

        Raises:
            ValueError: If analysis_type is not one of the valid options.
        """
        if analysis_type is not None and analysis_type not in self._VALID_ANALYSIS_TYPES:
            logger.warning(
                "tca_0404: unrecognised analysis_type '%s' (known: %s) – proceeding anyway",
                analysis_type,
                ", ".join(sorted(self._VALID_ANALYSIS_TYPES)),
            )

        query: dict = {
            "url": url,
            "response_format": "json",
        }
        if analysis_type is not None:
            query["analysis_type"] = analysis_type

        return await self._post(
            "/api/networking/url/v1/analyze/query/json",
            {"rl": {"query": query}},
        )
