"""
Shared error helpers for MCP tools.

Centralises the structured error dicts returned to MCP clients so every tool
produces the same ``{status, error, message, next_steps}`` shape, and so that
HTTP errors from the Spectra Intelligence API are translated in one place.
"""

import functools
import ipaddress
import json
from collections.abc import Iterable
from typing import Any

import httpx

_HEX_CHARS = frozenset("0123456789abcdefABCDEF")

# Hash type by hex-string length, mirroring core.si_client._HASH_TYPES.
_HASH_TYPE_BY_LEN: dict[int, str] = {32: "md5", 40: "sha1", 64: "sha256"}
_HASH_LEN_BY_TYPE: dict[str, int] = {v: k for k, v in _HASH_TYPE_BY_LEN.items()}
_HASH_LABELS: dict[str, str] = {"md5": "MD5", "sha1": "SHA-1", "sha256": "SHA-256"}


def _hash_spec(allowed: tuple[str, ...]) -> str:
    """Human-readable list of accepted hash types"""
    parts = [f"{_HASH_LABELS[t]} ({_HASH_LEN_BY_TYPE[t]} hex chars)" for t in allowed]
    if len(parts) == 1:
        return parts[0]
    return ", ".join(parts[:-1]) + (", or " if len(parts) > 2 else " or ") + parts[-1]


# ------------------------------------------------------------------ #
# Canonical error builders                                             #
# ------------------------------------------------------------------ #

def invalid_input_error(param: str, message: str, next_steps: str = "") -> dict:
    """Structured error dict for invalid caller input."""
    result: dict = {
        "status": "error",
        "error": f"invalid_{param}",
        "message": message,
    }
    if next_steps:
        result["next_steps"] = next_steps
    return result


def unexpected_error(action: str, exc: Exception) -> dict:
    """Structured, generic error dict for an unexpected failure.

    Surfaces a descriptive message to the caller instead of an opaque
    traceback. The underlying exception is logged separately for debugging.
    """
    return {
        "status": "error",
        "error": "unexpected_error",
        "message": (
            f"An unexpected error occurred while performing {action}: "
            f"{type(exc).__name__}: {exc}"
        ),
        "next_steps": (
            "Retry the request. If the problem persists, the Spectra "
            "Intelligence service may be temporarily unavailable or the "
            "request arguments may be malformed."
        ),
    }


def not_found_error(target: str, context: str, next_steps: str) -> dict:
    """Standard error dict for a 404 / not-found response from the API."""
    return {
        "status": "error",
        "error": "not_found",
        "target": target,
        "message": f"No {context} data found for '{target}'. "
                   "The indicator may not exist in Spectra Intelligence, or "
                   "analysis has not been run for it yet.",
        "next_steps": next_steps,
    }


# ------------------------------------------------------------------ #
# Input validators                                                   #
# ------------------------------------------------------------------ #

def describe_hash_defect(
    hash_value: object,
    allowed: tuple[str, ...] = ("md5", "sha1", "sha256"),
) -> str | None:
    """Return a short phrase describing why hash_value is not an accepted hash."""
    h = str(hash_value or "").strip()
    if not h:
        return "empty or blank"
    non_hex = sorted(set(c for c in h if c not in _HEX_CHARS))
    if non_hex:
        return f"not hexadecimal (contains {non_hex!r})"
    hash_type = _HASH_TYPE_BY_LEN.get(len(h))
    if hash_type is None:
        return f"{len(h)} hex characters, which is not a valid hash length"
    if hash_type not in allowed:
        return f"{'an' if hash_type == 'md5' else 'a'} {_HASH_LABELS[hash_type]} hash ({len(h)} hex characters)"
    return None


def hash_type_of(hash_value: object) -> str | None:
    """Return "md5"/"sha1"/"sha256" for a well-formed hash, else None."""
    h = str(hash_value or "").strip()
    if not h or any(c not in _HEX_CHARS for c in h):
        return None
    return _HASH_TYPE_BY_LEN.get(len(h))


def validate_hash(
    hash_value: str,
    param: str = "hash_value",
    allowed: tuple[str, ...] = ("md5", "sha1", "sha256"),
    noun: str = "hash",
) -> dict | None:
    """Return a structured error dict if hash_value is invalid; None if valid.

    ``allowed`` restricts which hash types are accepted (default: all three).
    ``noun`` names the value in the guidance text, e.g. ``"certificate thumbprint"``.
    """
    defect = describe_hash_defect(hash_value, allowed)
    if defect is None:
        return None
    spec = _hash_spec(allowed)
    if defect == "empty or blank":
        return invalid_input_error(
            param,
            f"'{param}' is required and cannot be empty.",
            f"Provide {'an' if allowed[0] == 'md5' else 'a'} {spec} {noun}.",
        )
    return invalid_input_error(
        param,
        f"'{param}' is {defect}.",
        f"Provide a valid {noun} of an accepted type: {spec}.",
    )


# Cap on how many offending entries validate_hash_list names individually.
_MAX_LISTED_DEFECTS = 10


def validate_hash_list(
    hashes: object,
    param: str = "hashes",
    allowed: tuple[str, ...] = ("md5", "sha1", "sha256"),
    extra_next_steps: str = "",
    noun: str = "hash",
    max_entries: int | None = None,
    uniform: bool = False,
) -> dict | None:
    """Validate every entry of a hash list; return one aggregated error dict or None.

    Rejects the whole list if it is empty, longer than ``max_entries``, or if any
    entry is missing, non-hex, or not one of the ``allowed`` hash types — naming
    each offending position (up to :data:`_MAX_LISTED_DEFECTS`) so the caller can
    fix the input and resubmit.
    """
    spec = _hash_spec(allowed)

    def _error(message: str, next_steps: str) -> dict:
        if extra_next_steps:
            next_steps += " " + extra_next_steps
        return invalid_input_error(param, message, next_steps)

    if not hashes:
        return _error(
            f"'{param}' cannot be empty.",
            f"Provide a list of one or more {spec} {noun}s.",
        )
    if not isinstance(hashes, list):
        return _error(
            f"'{param}' must be a list, got {type(hashes).__name__}.",
            f"Provide a list of {spec} {noun}s.",
        )
    if max_entries is not None and len(hashes) > max_entries:
        return _error(
            f"'{param}' contains {len(hashes)} entries but the maximum is {max_entries}.",
            f"Split the {noun}s into batches of up to {max_entries} and call this tool "
            "multiple times.",
        )

    bad = [
        f"position {i}: {raw!r} is {defect}"
        for i, raw in enumerate(hashes)
        if (defect := describe_hash_defect(raw, allowed)) is not None
    ]
    if not bad:
        if uniform:
            by_type: dict[str, list[int]] = {}
            for i, raw in enumerate(hashes):
                by_type.setdefault(hash_type_of(raw), []).append(i)
            if len(by_type) > 1:
                majority = max(by_type, key=lambda t: len(by_type[t]))
                mixed = "; ".join(
                    f"{_HASH_LABELS[t]} at position{'s' if len(idx) > 1 else ''} "
                    + ", ".join(str(i) for i in idx[:_MAX_LISTED_DEFECTS])
                    + (f", ... and {len(idx) - _MAX_LISTED_DEFECTS} more" if len(idx) > _MAX_LISTED_DEFECTS else "")
                    for t, idx in by_type.items()
                    if t != majority
                )
                return _error(
                    f"'{param}' mixes hash types: most entries are "
                    f"{_HASH_LABELS[majority]}, but {mixed}.",
                    f"Every {noun} in one call must be of the same hash type "
                    f"({spec}). Convert the listed entries to "
                    f"{_HASH_LABELS[majority]}, or split them into a separate call.",
                )
        return None

    listed = "; ".join(bad[:_MAX_LISTED_DEFECTS])
    if len(bad) > _MAX_LISTED_DEFECTS:
        listed += f"; ... and {len(bad) - _MAX_LISTED_DEFECTS} more"
    return _error(
        f"{len(bad)} of {len(hashes)} entries are not valid: {listed}.",
        f"Every entry must be a {noun} of an accepted type: {spec}. "
        "Correct or remove the listed entries and call the tool again.",
    )


def validate_url(url: str, param: str = "url") -> dict | None:
    """Return a structured error dict if url is structurally invalid; None if valid."""
    if not url or not url.strip():
        return invalid_input_error(
            param,
            f"'{param}' is required and cannot be empty.",
            "Provide a full URL (https://example.com/path) or a bare domain (example.com).",
        )
    u = url.strip()
    has_scheme = "://" in u
    has_dot = "." in u
    has_alpha = any(c.isalpha() for c in u)
    if not (has_scheme or has_dot) or not has_alpha:
        return invalid_input_error(
            param,
            f"'{param}' does not look like a valid URL or domain: {u!r}.",
            "Provide a full URL (https://example.com/path) or a bare domain/hostname (example.com).",
        )
    return None


def validate_indicator(indicator: str, param: str = "indicator") -> dict | None:
    """Return a structured error dict if the network indicator is invalid; None if valid.

    Accepts what :func:`validate_url` accepts plus bare IPv4/IPv6 addresses.
    """
    if not indicator or not indicator.strip():
        return invalid_input_error(
            param,
            f"'{param}' is required and cannot be empty.",
            "Provide a domain (example.com), IPv4/IPv6 address, or full URL (https://example.com/path).",
        )
    u = indicator.strip()
    try:
        ipaddress.ip_address(u)
        return None
    except ValueError:
        pass
    has_scheme = "://" in u
    has_dot = "." in u
    has_alpha = any(c.isalpha() for c in u)
    if not (has_scheme or has_dot) or not has_alpha:
        return invalid_input_error(
            param,
            f"'{param}' does not look like a valid URL, domain, or IP address: {u!r}.",
            "Provide a domain (example.com), IPv4/IPv6 address, or full URL (https://example.com/path).",
        )
    return None


# ------------------------------------------------------------------ #
# HTTP error translation                                               #
# ------------------------------------------------------------------ #

def is_http_404(exc: BaseException) -> bool:
    """Return True if exc is an httpx 404 response error."""
    return isinstance(exc, httpx.HTTPStatusError) and exc.response.status_code == 404


def _extract_api_detail(response: httpx.Response) -> str:
    """Pull the most useful human-readable detail out of an API error response.

    Prefers a JSON body's ``message``/``error`` field, falling back to the raw
    response text. Returns an empty string if nothing useful is present.
    """
    try:
        payload = response.json()
    except Exception:
        payload = None
    if isinstance(payload, dict):
        detail = payload.get("message") or payload.get("error")
        if isinstance(detail, str) and detail.strip():
            return detail.strip()
    return (response.text or "").strip()


def suspect_hints(candidates: dict[str, tuple[Any, Iterable[Any]]]) -> list[str]:
    """Build non-blocking "likely culprit" hints for an API rejection.
    """
    hints: list[str] = []
    for name, (value, allowed) in candidates.items():
        allowed = list(allowed)
        if value is not None and value not in allowed:
            hints.append(
                f"{name}={value!r} (values known to be supported: "
                f"{', '.join(sorted(map(str, allowed)))})"
            )
    return hints


def translate_http_error(
    exc: httpx.HTTPStatusError,
    *,
    action: str,
    hints: list[str] | None = None,
    next_steps: str = "",
    error: str = "request_rejected",
) -> dict:
    """Translate an ``httpx.HTTPStatusError`` into a structured MCP error dict.
    Args:
        action:     Short description of what was attempted, e.g. ``"URL analysis"``
                    or ``"dynamic analysis"``. Used in the message.
        hints:      Optional list from :func:`suspect_hints` naming arguments
                    that are not among the known-supported values.
        next_steps: Overrides the default guidance line.
        error:      Machine-readable error code (default ``"request_rejected"``).
    """
    status = exc.response.status_code
    detail = _extract_api_detail(exc.response)
    hint_text = ""
    if hints:
        hint_text = (
            " The following argument(s) are not among the values currently known "
            "to be supported and may be the cause: " + "; ".join(hints) + "."
        )
    if not next_steps:
        next_steps = (
            "Verify the request arguments are valid and supported, then try again."
        )
    if hints:
        next_steps += (
            " Retrying with one of the known-supported values listed above "
            "is a good first step."
        )
    return {
        "status": "error",
        "error": error,
        "http_status": status,
        "message": (
            f"Spectra Intelligence rejected the {action} request (HTTP {status})."
            + (f" Details: {detail}" if detail else "")
            + hint_text
        ),
        "next_steps": next_steps,
    }


# ------------------------------------------------------------------ #
# MCP error surfacing                                                  #
# ------------------------------------------------------------------ #

class ToolExecutionError(Exception):
    """Raised so the MCP layer marks a call as failed (``isError=true``)."""


def guard_tool_errors(fn):
    """Wrap an async tool so an error-status return becomes an MCP failure."""
    @functools.wraps(fn)
    async def wrapper(*args, **kwargs):
        result = await fn(*args, **kwargs)
        if isinstance(result, dict) and result.get("status") == "error":
            raise ToolExecutionError(json.dumps(result))
        return result

    return wrapper
