"""Rank the file paths and registry keys from dynamic analysis.

WHAT PROBLEM THIS SOLVES
------------------------
One malware sample can touch tens of thousands of files and registry keys
while it runs. Almost all of that is ordinary operating-system activity --
loading libraries, reading fonts, checking the clock. The sandbox report has
limited room, so we assign every observed item a tier, and truncation then
drops entire tiers starting from the least interesting. The thing we must
avoid is cutting the two or three items that show what the malware actually
did in order to keep three hundred font reads.

TERMS USED THROUGHOUT
---------------------
target        One observed thing: a file path or a registry key, after
              normalisation. Example: "c:\\users\\v\\appdata\\local\\temp\\a.exe".
pattern       A lowercase fragment we search for inside a target. Example:
              "\\appdata\\" or "/tmp/".
tier          How badly we want to keep a target. TIER_ALWAYS is never
              dropped; TIER_LOW is dropped first. See the tier constants.
high signal   Worth keeping: the location is one malware commonly abuses, or
              one where malware leaves traces.
low signal    Safe to drop: routine OS or application activity that shows up
              in essentially every run, malicious or not.
persistence   Any change that makes a program start again by itself -- after
              a reboot, a login, or when another program launches. Malware
              needs this to survive, so persistence locations are the single
              highest-value thing in the report.
credential    A file or registry key holding passwords, tokens, or private
store         keys. Malware reads these to steal them.

HOW A TIER IS CHOSEN (see resolve_tier)
---------------------------------------
  0. If the matched pattern is in HIGH_SIGNAL_PATHS_ON_WRITE (file paths)
     or REGISTRY_WRITE_GATED (registry keys), the operation decides. A write
     returns that pattern's tier immediately; a read makes the pattern
     abstain, so the target is ranked by whatever else matches (usually
     nothing, giving TIER_MIDDLE). This exists because system directories
     are read constantly during normal operation -- loading a library from
     /usr/lib/ or reading a service key are both noise -- but a WRITE to the
     same location is almost always significant.
  1. The target matches a NEVER_DROP_PATHS / NEVER_DROP_REGISTRY pattern
     -> TIER_ALWAYS, and we stop looking.
  2. Otherwise, of every pattern that matches -- high-signal and low-signal
     alike -- the LONGEST one decides the tier. Equal lengths resolve toward
     keeping.
  3. Nothing matched -> TIER_MIDDLE.
  4. Finally, a file with an executable extension (.exe, .dll, .so, ...) is
     bumped from TIER_MIDDLE up to TIER_HIGH. This bump never applies to
     something already ranked TIER_LOW, because low-signal directories are
     full of legitimate executables -- Windows keeps thousands of DLLs under
     \\WinSxS\\, and promoting all of them would defeat the whole filter.

WHY THE LONGEST PATTERN WINS
----------------------------
A target normally matches several patterns at once, because paths are nested.
The longest match is the one that actually describes the target; a shorter
match is usually just the directory it happens to sit inside. Two real cases,
which point in opposite directions:

  c:\\users\\v\\appdata\\local\\microsoft\\windows\\caches\\cversions.2.db
      matches "\\appdata\\" (9 chars, high signal -- user-writable area)
      matches "\\microsoft\\windows\\caches\\" (26 chars, low signal)
      The longer one wins, so this is dropped. Correct: it is an Explorer
      cache file that appears in every single Windows run.

  /proc/sys/kernel/modules_disabled
      matches "/proc/" (6 chars, low signal -- kernel status files)
      matches "/proc/sys/kernel/" (17 chars, high signal)
      The longer one wins, so this is kept. Correct: writing here changes
      kernel settings, which is tampering, not status reading.

Notice that ranking by which list a pattern came from could not get both of
these right, since the high-signal pattern is the shorter one in the first
case and the longer one in the second.

(/dev/shm/ looks like a third example but is not one -- it is in
NEVER_DROP_PATHS, so step 1 returns before any length comparison happens.)

WHERE LENGTH BREAKS DOWN
------------------------
Length is only a stand-in for specificity, and it fails when a pattern is
very specific but very short. ".env" is exactly four characters yet names one
of the most-stolen files in existence, so it loses to every long low-signal
pattern. Same for the per-process files under /proc/. Those cases live in
HIGH_SIGNAL_REGEXES and the basename matcher further down, both of which
carry an explicit weight that competes with pattern lengths.

RULES THE PATTERNS RELY ON
--------------------------
  * Targets are normalised before matching (see normalise_path and
    normalise_registry): lowercased, environment variables expanded, and
    various Windows spellings of the same location collapsed to one form.
    Patterns are therefore always written in lowercase.
  * For the registry we match against "key\\value_name", not the key alone.
    A registry key is a folder-like container; a value is a named setting
    inside it. Some of the strongest signals here are value names rather than
    keys -- appinit_dlls, enablelua, autoconfigurl -- so leaving the value
    name out would miss them.
  * A pattern matches if it appears anywhere in the target, OR if the target
    ends with it once its trailing slash is removed. The second rule matters
    because a key can end at the interesting name: "\\run\\" needs to match
    "...\\currentversion\\run" with nothing after it.
  * TRAILING SLASHES ARE DELIBERATE, NOT UNTIDY. "\\system32\\drivers\\" has a
    trailing backslash so that it does NOT match the unrelated directory
    "\\windows\\system32\\driverstore\\filerepository\\" -- without the slash,
    "drivers" would match inside "driverstore". Removing trailing slashes to
    make the lists look uniform will silently reclassify things. The unit
    tests will catch it if you do.

THE PATH IS PARTLY ATTACKER-CONTROLLED
--------------------------------------
Worth holding onto, because it is easy to forget while editing pattern lists:
malware chooses where it writes and what it names directories. So a low-signal
pattern that can match anywhere in a path is a way for the attacker to ASK for
a low tier -- "mkdir -p /tmp/etc/fonts", drop the payload inside, and a naive
matcher files it under font noise. Two rules limit that:

  Anchoring     LOW_SIGNAL_PATH_ROOTS only match at the start of a path, since
                that is the only place they legitimately occur.
  Write-floor   Some low-signal patterns genuinely appear mid-path and cannot
                be anchored (per-user caches, node_modules). For those,
                resolve_tier refuses to put the WRITE of an executable file in
                the bottom tier, whatever directory it claims to be in.

Neither rule applies to high-signal patterns: an attacker making a path look
MORE suspicious than it is costs us nothing.
"""

from __future__ import annotations

import os
import re

# ------------------------------------------------------------------ #
# Tiers                                                              #
# ------------------------------------------------------------------ #
# Truncation removes items starting at TIER_LOW and works upward, so a lower
# number means "keep this for longer".
TIER_ALWAYS = 0   # kept no matter how little room is left
TIER_HIGH = 1     # kept unless the report is already down to essentials
TIER_MIDDLE = 2   # nothing matched, so we have no opinion either way
TIER_LOW = 3      # thrown away first

# ------------------------------------------------------------------ #
# 1. Absolute never-drop                                             #
# ------------------------------------------------------------------ #
# These patterns skip the length comparison entirely and return TIER_ALWAYS.
#
# The test for adding something here is NOT "is this important?" -- most
# high-signal patterns are important. It is: "is this pattern short enough,
# or buried deep enough, that some longer low-signal pattern could outrank
# it?" If yes, it needs the guarantee. If it is already the longest thing
# matching its targets, HIGH_SIGNAL_PATHS is the right home.
#
# Files and registry keys are two separate lists because resolve_tier only
# consults the one matching the event type -- a pattern in NEVER_DROP_REGISTRY
# is never compared against a file path, and a pattern in NEVER_DROP_PATHS is
# never compared against a registry key. So a pattern added to the wrong list
# has no effect whatsoever, and nothing warns you about it.
#
# Do not reason about this from what the strings look like. A file can legally
# be named "hkey_local_machine\foo", and a registry value name can contain
# "/etc/shadow"; the separation is enforced by which pool gets searched, not by
# the two kinds of pattern being distinguishable.
#
# When you add coverage for a capability, check whether it has BOTH a file
# form and a registry form. Windows password hashes are the example: they sit
# in a file at \system32\config\sam, and the same data is reachable live
# through the registry key hkey_local_machine\sam\. Covering one does not
# cover the other, but a single entry in one list can make it look covered.
NEVER_DROP_PATHS: tuple[str, ...] = (
    # --- Linux: things that make a program start by itself ---
    "/dev/shm/",              # RAM-backed scratch dir; favourite drop spot
                              # because files there leave no disk trace
    "/etc/ld.so.preload",     # every program on the box loads the libraries
                              # listed here -- the classic Linux rootkit trick
    "/etc/systemd/",          # systemd = the Linux service manager. A unit
    "/lib/systemd/system/",   # file in any of these dirs is a service that
    "/usr/lib/systemd/system/",   # starts at boot.
    "/.config/systemd/user/",     # same, but starts at user login
    "/.config/autostart/",    # desktop-session autostart entries
    "/etc/xdg/autostart/",    # same, applied to every user on the box
    "/var/spool/cron",        # per-user scheduled jobs ("crontabs")
    "/etc/shadow",            # password hashes for every Linux account
    "/etc/sudoers",           # who may run commands as root

    # --- Windows: where account passwords and secrets live on disk ---
    # These are "hive" files: the on-disk backing files for parts of the
    # Windows registry. Copying them off the machine is how attackers crack
    # or replay account passwords offline.
    "\\system32\\config\\sam",       # local account password hashes
    "\\system32\\config\\system",    # holds the key needed to decrypt SAM
    "\\system32\\config\\security",  # cached domain creds, service secrets
    "\\ntds.dit",                   # the whole Active Directory database
                                    # (only present on domain controllers)
    "\\ntuser.dat",                 # one user's registry hive
    "\\usrclass.dat",               # the rest of that user's hive
    "harddiskvolumeshadowcopy",     # a snapshot of the disk. Attackers read
                                    # the hives above out of a snapshot
                                    # because Windows locks the live files.

    # --- Windows: things that make a program start by itself ---
    "\\start menu\\programs\\startup\\",   # anything here runs at login.
                              # Spelled out in full rather than as "startup"
                              # so it outranks longer low-signal patterns.
    "\\system32\\tasks\\",       # scheduled tasks are stored as files here
    "\\syswow64\\tasks\\",       # 32-bit programs see this path instead
    "\\windows\\tasks\\",        # older scheduled-task location
    "\\system32\\drivers\\",     # a file dropped here can load into the
                              # kernel, which is as deep as access gets
    "\\drivers\\etc\\hosts",     # Windows' hosts file: editing it silently
                              # redirects domain names, e.g. to block
                              # antivirus updates
)

NEVER_DROP_REGISTRY: tuple[str, ...] = (
    # --- Registry locations that start a program automatically ---
    # Every entry here answers "what does Windows launch without being
    # asked?", which is exactly what malware needs to survive a reboot.
    "\\user shell folders",       # tells Windows where the Startup folder
                                  # IS. Repoint it and you get persistence
                                  # without touching the folder itself.
    "appinit_dlls",               # a library listed here is loaded into
                                  # almost every process that starts
    "appcertdlls",                # similar, triggered whenever a process
                                  # creates another process
    "userinit",                   # the program Windows runs immediately
                                  # after you log in
    "\\winlogon\\shell",          # which program acts as the desktop
                                  # (normally explorer.exe)

    # --- COM hijacking ---
    # COM is the Windows mechanism that lets one program ask for a component
    # by ID and get a library loaded on its behalf. \treatas says "when asked
    # for component A, use B instead", which is rarely set legitimately and
    # rarely read, so it stays here. Its siblings inprocserver32 and
    # localserver32 name the file to load and ARE read on every single COM
    # activation, so they are write-gated instead -- see REGISTRY_WRITE_GATED.
    "\\treatas",

    # --- Reading secrets straight out of the live registry ---
    # The file patterns in NEVER_DROP_PATHS cover copying the hive files.
    # These cover reading the same secrets from the running system, which
    # touches no file at all and would otherwise go unnoticed.
    "hkey_local_machine\\sam\\",   # local account password hashes
    "hkey_local_machine\\security\\policy\\secrets\\",   # "LSA secrets":
    "\\policy\\secrets\\",        # service account passwords, cached domain
    "\\policy\\pollegacy",        # credentials, VPN keys, stored in plaintext
                                  # once decrypted

    # --- Turning off Windows' own protections ---
    # Both are setting names rather than keys, and both are short, so they
    # need the guarantee. Setting either to 0 removes the prompt that
    # normally appears before a program gains administrator rights.
    "enablelua",                  # switches User Account Control off entirely
    "consentpromptbehavioradmin", # controls whether admins get prompted
)

# ------------------------------------------------------------------ #
# 2. File paths: high signal                                         #
# ------------------------------------------------------------------ #
# Locations worth keeping. Unlike the never-drop lists, these DO take part in
# the length comparison, so a longer low-signal pattern can still outrank one.
HIGH_SIGNAL_PATHS: tuple[str, ...] = (
    # --- Directories any user can write to ---
    # Malware has to put its files somewhere, and it usually cannot write to
    # protected system directories. These are the places it can, so this is
    # where dropped payloads show up.
    "/tmp/", "/var/tmp/", "/run/shm/", "/run/user/",
    "/root/", "/home/",
    "\\appdata\\", "\\users\\", "\\programdata\\",
    "\\windows\\temp\\", "\\perflogs\\", "\\$recycle.bin\\", "\\recycler\\",
    # A handful of directories inside C:\Windows are writable by ordinary
    # users, which is unusual and therefore interesting. Attackers use them
    # to get a file into a "trusted" location -- some Windows security checks
    # treat anything under C:\Windows as more trustworthy.
    "\\windows\\tracing\\", "\\windows\\debug\\wia\\",
    "\\windows\\registration\\", "\\windows\\system32\\spool\\drivers\\",

    # --- Persistence: files that cause something to run later ---
    "startup", "autorun", "autostart",
    "/etc/cron", "/var/spool/at/",
    "/etc/init", "/etc/rc.",
    "/etc/modules-load.d/", "/etc/modprobe.d/", "/etc/ld.so.conf",
    "/etc/profile", "/.bashrc", "/.bash_profile", "/.profile", "/.zshrc",
    "/.bash_logout",
    "\\system32\\wbem\\",     # WMI: a Windows management system that can be
                              # told "run this program when X happens". A file
                              # dropped here can register such a trigger.
    # Office documents can carry macros, and these locations make a macro run
    # every time the application opens -- persistence without any executable.
    "\\xlstart\\",           # anything here opens with Excel
    "normal.dotm",            # Word's default template, loaded every time
    "\\word\\startup\\",     # Word's equivalent of xlstart

    # macOS equivalents of the above. A .plist
    # file in one of these directories is a job the OS starts for you.
    "/library/launchagents/",     # starts at user login
    "/library/launchdaemons/",    # starts at boot, runs as root
    "/library/startupitems/", "/library/scriptingadditions/",

    # --- Credential stores: files malware reads to steal secrets ---
    # A hit here means the sample was looking for something to exfiltrate,
    # which tells you what kind of malware it is (infostealer vs ransomware
    # vs loader) more clearly than almost anything else in the report.
    "/etc/passwd", "/etc/gshadow",
    "/.ssh/", "\\.ssh\\", "/.aws/", "/.kube/config", "/.docker/config.json",
    "/.netrc", "/.git-credentials", "/.bash_history",
    # Browser credential databases. "Login Data" and "Web Data" are Chrome's
    # saved-password and autofill stores; the .json/.db ones are Firefox's.
    # "Local State" holds the key that decrypts Chrome's saved passwords.
    "\\login data", "\\logins.json", "\\key4.db", "\\key3.db",
    "\\cookies.sqlite", "\\local state", "\\web data",
    "wallet.dat", "\\wallets\\",     # cryptocurrency wallet files

    # --- Developer and AI-agent credential stores ---
    # Cloud CLIs, package managers and AI coding tools all cache access
    # tokens in predictable places in the user's home directory, usually in
    # plaintext. A stolen token here is often worth more than a password,
    # because it already bypasses multi-factor authentication.
    #
    # Two things to know about this group. First, most of these paths sit
    # under /home/ or \users\, which are already high-signal, so these
    # patterns rarely change the tier -- their value is telling the analyst
    # WHICH store was touched. Second, coverage is unavoidably patchy: some
    # tools store tokens in the OS keyring instead of a file, leaving nothing
    # on disk for us to match.
    "/.mcp-auth/", "\\.mcp-auth\\",   # tokens for remote MCP servers. The
                                      # MCP_REMOTE_CONFIG_DIR environment
                                      # variable can move this elsewhere.
    ".credentials.json",              # Claude Code's token file on Linux
    "/.codex/auth.json",
    "/.config/gh/hosts.yml", "/.config/gcloud/", "/.azure/",
    "/.config/rclone/rclone.conf",
    "/.terraform.d/credentials",
    "/.npmrc", "/.pypirc", "/.gem/credentials",
    "/.gnupg/", "\\.gnupg\\",
    "/.config/hub", "/.subversion/auth/",

    # --- Changing how the machine behaves ---
    # Writes here reroute name lookups or weaken login security. A common
    # pattern is editing the hosts file so antivirus update servers resolve
    # to nowhere.
    "/etc/hosts", "/etc/resolv.conf", "/etc/nsswitch.conf",
    "/etc/pam.d/",            # PAM decides how Linux authenticates logins
    "/etc/ssh/sshd_config",   # remote-access settings, e.g. allowing root
    "/etc/security/",

    # --- Directories served to the internet by a web server ---
    # A script written here is reachable from a browser, which is how a
    # "webshell" works: the attacker gets a command prompt over HTTP.
    "/var/www/", "\\inetpub\\wwwroot\\", "/wp-content/uploads/",
    "\\tomcat\\webapps\\",

    # --- Interesting paths inside otherwise-noisy virtual directories ---
    # /proc/ and /dev/ are not real disks; they are interfaces the kernel
    # exposes as files. Reading them is so routine that both are low-signal
    # overall, but a few specific paths inside them are not. Each pattern
    # below is longer than "/proc/" (6 chars) or "/dev/" (5), so the length
    # rule keeps them.
    #
    # Note what CANNOT go here: the per-process files at /proc/<pid>/mem and
    # /proc/<pid>/maps, which are how one process reads or rewrites another
    # process's memory. The process ID varies, so the only fixed part is
    # "/mem" -- four characters, which loses to "/proc/". Those are handled
    # by HIGH_SIGNAL_REGEXES instead.
    "/proc/sys/kernel/", "/proc/sys/net/",   # writes here change kernel
                                             # settings rather than read them
    "/proc/self/exe",         # points at the running program's own file
    "/proc/kcore",            # a view of all physical memory
    "/dev/mqueue/",           # another RAM-backed, writable location
)

# An escape hatch for targets that a plain fragment cannot describe.
#
# Each entry is (regular expression, weight). The weight stands in for pattern
# length in the comparison, so a 20 here beats any matching fragment shorter
# than 20 characters. Use this list only when a fragment genuinely cannot do
# the job -- it is slower and harder to read than the plain lists.
HIGH_SIGNAL_REGEXES: tuple[tuple[str, int], ...] = (
    # One process reading or writing another process's memory, which is how
    # code injection works. The path contains a process ID that changes every
    # run, so no fixed fragment can capture it: the only constant part is
    # "/mem" or "/maps", too short to outrank the low-signal "/proc/".
    (r"/proc/(?:\d+|self)/(?:mem|maps|environ|cmdline|syscall|stack|fd/)", 20),

    # Alternate Data Streams. On Windows, a file can carry extra hidden
    # contents addressed as "visible.txt:hidden.exe" -- the part after the
    # second colon does not appear in a normal directory listing, so malware
    # uses it to hide payloads. The character classes exclude a drive letter
    # ("c:\...") and network paths so those do not match.
    (r"[^\\/:]:[^\\/:]+:\$?\w+", 20),
)

# Directories where the SAME path means opposite things depending on what was
# done to it. These are where the operating system keeps its own programs and
# libraries, so:
#   reading  -> completely routine. Every process that starts reads dozens of
#               files here just to load. Treated as TIER_LOW.
#   writing  -> serious. It means something replaced or added a system binary
#               or library, which usually requires administrator rights and is
#               almost never legitimate mid-run. Treated as TIER_HIGH.
# resolve_tier() picks between the two using the event's operation, so the
# sandbox's operation names must be mapped into WRITE_OPERATIONS below or this
# whole list silently resolves to TIER_LOW.
HIGH_SIGNAL_PATHS_ON_WRITE: tuple[str, ...] = (
    # Linux program directories
    "/usr/bin/", "/usr/sbin/", "/bin/", "/sbin/", "/usr/local/bin/",
    "/opt/", "/etc/",
    # Linux shared-library directories. Replacing a library here means every
    # program that uses it runs attacker code.
    "/usr/lib/", "/lib/", "/lib64/",
    # Windows equivalents. syswow64 holds the 32-bit copies of system files.
    "\\windows\\system32\\", "\\windows\\syswow64\\",
    "\\program files\\", "\\program files (x86)\\",
)

# ------------------------------------------------------------------ #
# 3. File paths: low signal                                          #
# ------------------------------------------------------------------ #
# Low-signal patterns come in two kinds, and the difference is a security
# property rather than a stylistic one.
#
# LOW_SIGNAL_PATH_ROOTS are only meaningful at the start of a path. A genuine
# read of /etc/fonts/ always appears at the beginning of the path, so these are
# matched ANCHORED: at position 0, or just after a drive letter. Matching them
# anywhere in the path would let an attacker pick the tier, because the path is
# partly attacker-controlled -- "mkdir -p /tmp/etc/fonts" and a payload written
# inside it would otherwise be classified as font noise and dropped.
#
# LOW_SIGNAL_PATHS are the ones that legitimately appear part-way through a
# path and therefore cannot be anchored. These remain spoofable by directory
# naming; the write-floor rule in resolve_tier is the partial mitigation.
LOW_SIGNAL_PATH_ROOTS: tuple[str, ...] = (
    # --- Linux: shared data, config and kernel status files ---
    # Fonts, locale data, timezone tables, certificate bundles. Programs read
    # these while starting up and nothing about that is informative.
    "/usr/share/", "/usr/include/", "/usr/lib/locale/",
    "/usr/lib/python", "/usr/lib/jvm/",
    "/etc/fonts/", "/etc/dconf/", "/etc/terminfo/", "/etc/ssl/certs/",
    "/etc/alternatives/", "/etc/localtime", "/etc/ld.so.cache",

    # /sys/, /dev/ and /proc/ are not real disks -- the kernel presents
    # information as files there. Reading them is how a program finds out how
    # much memory exists or which CPU it is on, so it is ubiquitous. The few
    # paths inside them that DO matter are listed in HIGH_SIGNAL_PATHS and
    # HIGH_SIGNAL_REGEXES, and win because they are longer.
    "/sys/",
    "/dev/",
    "/proc/",
    "/proc/self/task/", "/proc/loadavg", "/proc/meminfo", "/proc/stat",
    "/proc/uptime", "/proc/cpuinfo", "/proc/filesystems",

    # --- Windows: bundled resources under C:\Windows ---
    # Note these are written out from "\windows\" onward, not from the
    # subdirectory, precisely so they can be anchored.
    "\\windows\\winsxs\\",       # Windows' store of every version of every
                                  # system library it has ever installed
    "\\windows\\assembly\\", "\\windows\\microsoft.net\\assembly\\",   # .NET
    "\\windows\\fonts\\", "\\windows\\globalization\\",       # fonts, locales
    "\\windows\\system32\\driverstore\\filerepository\\",   # driver packages.
                                  # A DIFFERENT directory from
                                  # \system32\drivers\ in NEVER_DROP_PATHS.
    "\\windows\\inf\\",          # driver installation instructions
    "\\windows\\system32\\en-us\\", "\\windows\\system32\\migration\\",
    "\\windows\\webcache\\",
)

# Patterns that legitimately occur mid-path, so they cannot be anchored.
LOW_SIGNAL_PATHS: tuple[str, ...] = (
    # --- Windows: per-user caches ---
    # This group is the single biggest source of volume in an unfiltered
    # Windows report, which is the main reason this filter exists. All of these
    # sit inside a user profile, so they cannot be anchored to the path root.
    "\\microsoft\\windows\\caches\\",   # Explorer cache. At 26 characters
                                  # this deliberately outranks the 9-character
                                  # "\appdata\", which these paths also match.
    "\\explorer\\thumbcache", "\\explorer\\iconcache",   # thumbnails, icons
    "\\cryptneturlcache\\", "\\inetcache\\counters",
    "\\microsoft\\windows\\history\\",

    # --- Installed dependency trees ---
    # Thousands of files belonging to npm/pip packages. Interesting only if
    # something writes an executable or a secret into them, which the
    # extension and basename rules handle separately.
    "\\node_modules\\", "\\site-packages\\",
    "/node_modules/", "/site-packages/", "/__pycache__/",
)

# ------------------------------------------------------------------ #
# 4. Registry: high signal                                           #
# ------------------------------------------------------------------ #
# Background, if you have not worked with the Windows registry: it is a
# hierarchical settings database. Keys are like folders; values are named
# settings inside a key. Top-level "hives" have names like HKEY_LOCAL_MACHINE
# (machine-wide, abbreviated HKLM) and HKEY_CURRENT_USER (one user, HKCU).
# Malware cares about it because a huge amount of "what does Windows run, and
# when" is configured there, and changing a setting needs no file on disk.
#
# Remember that we match against "key\value_name", so entries below without a
# leading backslash (cor_profiler, autoconfigurl) are value names.
HIGH_SIGNAL_REGISTRY: tuple[str, ...] = (
    # --- Locations that cause a program to run ---
    # Variants of the Run key: all mean "launch this at login/boot". The two
    # highest-traffic spellings (\run\ and \runonce\) are write-gated in
    # REGISTRY_WRITE_GATED; these rarer variants are not read often enough to
    # need it.
    "\\runonceex\\",
    "\\runservices\\", "\\runserviceonce\\",
    "\\policies\\explorer\\run\\",   # same idea, applied via group policy
    "\\winlogon\\",                 # settings for the login process itself
    "\\windows nt\\currentversion\\windows\\",   # holds "Load" and "Run"
                                      # values, an old autostart mechanism
    "\\silentprocessexit\\",        # "when process X exits, run Y"
    "\\browser helper objects\\",   # libraries Internet Explorer loads
    "\\active setup\\",             # runs once per user at first login

    # Windows Explorer (the desktop and file manager) loads libraries listed
    # in these keys at startup or when drawing the UI. Adding an entry gets
    # attacker code loaded inside a trusted process.
    "\\shellserviceobjectdelayload\\", "\\shelliconoverlayidentifiers\\",
    "\\shell extensions\\approved", "\\contextmenuhandlers\\", "\\shellex\\",

    "\\command processor\\", "\\autorun",   # a command run every time
                                            # cmd.exe opens
    "\\session manager\\",   # very early boot settings. Includes
                              # BootExecute (programs run before Windows
                              # fully starts) and KnownDLLs (a trusted list
                              # of library names).
    "\\safeboot\\",          # what still runs in Safe Mode, i.e. surviving
                              # a common cleanup step
    "\\control panel\\desktop\\scrnsave",   # the screensaver program: runs
                              # unattended after an idle timeout
    "\\environment\\",       # environment variables. Two abuses live here:
                              # a logon-script value, and the .NET profiler
                              # variables below.
    # .NET can be told to load a "profiler" library into managed processes.
    # Attackers set these to get their library loaded automatically.
    "cor_profiler", "cor_enable_profiling", "\\.netframework\\",
    # Application-compatibility shims: a legitimate mechanism for patching old
    # programs, which can also inject a library into a chosen program.
    "\\appcompatflags\\installedsdb", "\\appcompatflags\\custom\\",
    "\\print\\monitors\\", "\\print\\providers\\",   # the print spooler
                              # loads libraries registered here, as SYSTEM
    "\\netsh\\",             # helper libraries loaded by the netsh
                              # networking tool
    # Windows sockets layers: a library registered here sees all network
    # traffic for the machine.
    "\\winsock2\\parameters\\protocol_catalog9",
    "\\winsock2\\parameters\\namespace_catalog5",

    # --- How Windows authenticates users ---
    # LSA is the component that handles logins and holds credentials in
    # memory. Libraries registered in these keys are loaded into it, which is
    # both a persistence trick and a way to capture passwords as users type
    # them.
    "\\lsa\\", "\\securityproviders\\",
    "\\authentication\\credential provider",   # the login UI itself
    "\\notification packages",    # notified whenever a password changes
    "\\security packages",
    "\\wdigest\\", "\\credssp\\",   # older protocols that can be re-enabled
                                    # to make passwords recoverable in memory
    # Installing a root certificate makes the machine trust certificates the
    # attacker issued, which enables silent interception of HTTPS traffic.
    "\\systemcertificates\\", "\\certificates\\root\\",

    # --- Weakening or blinding the machine's defences ---
    # (\policies\ itself is write-gated: applications read policy settings
    # constantly to find out what they are allowed to do.)
    "\\windows defender\\", "\\mpengine\\",   # antivirus settings, e.g.
                       # adding an exclusion so a directory is never scanned
    "\\sharedaccess\\parameters\\firewallpolicy\\",   # firewall rules
    "filesystemredirection",
    "\\winevt\\channels\\", "\\eventlog\\",   # event logging, i.e. the
                       # record of what happened. Disabling it hides tracks.
    # Microsoft Office macro security. Turning warnings off, or marking a
    # directory as "trusted", lets a malicious document run without prompting.
    "vbawarnings", "\\trusted locations\\", "\\resiliency\\",
    "\\terminal server\\", "\\wds\\rdpwd\\",   # remote desktop settings

    # --- Hijacking what happens when a file or link is opened ---
    # These keys hold the command line Windows runs for a given file type or
    # URL type. Repointing one means an ordinary double-click, or a link a
    # trusted Windows tool follows, launches attacker code instead. Several
    # published privilege-escalation tricks are exactly this.
    # (\shell\open\command is write-gated -- it is read whenever anything
    # opens a file by type.)
    "\\shell\\runas\\command",
    "\\ms-settings\\", "\\mscfile\\", "\\exefile\\",

    # --- Network redirection ---
    # Proxy settings. Pointing the machine at an attacker-controlled proxy
    # (or a config script it fetches) exposes all browser traffic.
    "autoconfigurl", "proxyserver", "proxyenable",
    "\\internet settings\\zonemap\\domains\\",   # per-site trust levels
)

# ------------------------------------------------------------------ #
# 4b. Registry: high signal ON WRITE ONLY                            #
# ------------------------------------------------------------------ #
# The registry counterpart of HIGH_SIGNAL_PATHS_ON_WRITE, and it exists for the
# same reason: for these locations, reading and writing mean opposite things.
#
#   Writing  -> the machine's behaviour just changed. This could be persistence,
#               hijacking, or policy tampering.
#   Reading  -> almost always Windows doing its job. Every process launch reads
#               Image File Execution Options; every COM activation reads
#               InprocServer32; every service query reads CurrentControlSet\
#               Services. Before this table existed, all of that landed in
#               TIER_ALWAYS and crowded out real findings.
#
# The value is the tier a WRITE gets. Reads make the pattern abstain entirely:
# it contributes nothing, and the target is ranked by whatever else matches --
# usually nothing, so a read lands in TIER_MIDDLE. Note the file-side
# equivalent resolves reads to TIER_LOW instead. The difference is deliberate:
# a read here is recon, which is worth more than a font load, and registry
# targets are not eligible for the executable-extension promotion that made
# TIER_MIDDLE dangerous on the file side.
#
# WHAT DOES *NOT* BELONG HERE: anything where the READ is itself the attack.
# Password hives and LSA secrets (hkey_local_machine\sam\, \policy\secrets\)
# are read to steal them, so they stay in NEVER_DROP_REGISTRY and stay
# operation-insensitive. Gating those would hide credential theft.
REGISTRY_WRITE_GATED: dict[str, int] = {
    # Writes here are persistence, so they keep the never-drop guarantee.
    "\\currentversion\\run": TIER_ALWAYS,
    "\\currentversion\\runonce": TIER_ALWAYS,
    "\\currentcontrolset\\services\\": TIER_ALWAYS,
    "\\image file execution options\\": TIER_ALWAYS,
    "\\schedule\\taskcache\\": TIER_ALWAYS,
    "inprocserver32": TIER_ALWAYS,
    "localserver32": TIER_ALWAYS,

    # Writes here are suspicious but not by themselves conclusive.
    "\\run\\": TIER_HIGH,
    "\\runonce\\": TIER_HIGH,
    "\\policies\\": TIER_HIGH,
    "\\shell\\open\\command": TIER_HIGH,
}

# ------------------------------------------------------------------ #
# 5. Registry: low signal                                            #
# ------------------------------------------------------------------ #
LOW_SIGNAL_REGISTRY: tuple[str, ...] = (
    # Keys describing which program opens which file type. Any program that
    # opens a file reads these, so the volume is enormous.
    "hkey_classes_root\\.",          # keys literally named ".txt", ".exe"...
    "\\software\\classes\\.",        # the per-user version of the same thing

    # COM component registration. Listing installed components is routine
    # bookkeeping. The specific values that redirect a component to a
    # different file (inprocserver32 and friends) are in NEVER_DROP_REGISTRY
    # and win despite this being the longer pattern, because never-drop is
    # checked before any length comparison.
    "hkey_classes_root\\clsid\\",
    "\\typelib\\", "\\interface\\",

    # Hardware and device enumeration -- reading what is plugged in.
    "hkey_local_machine\\hardware\\devicemap\\",
    "\\currentcontrolset\\enum\\",

    # Explorer's own bookkeeping: recently used names, per-folder view
    # settings, typed paths.
    "\\muicache\\", "\\explorer\\fileexts\\",
    "\\explorer\\streams\\",
    "\\explorer\\shell folders\\",   # the trailing backslash is required.
                              # Without it this also matches the neighbouring
                              # "User Shell Folders" key, which IS a
                              # persistence location and is in the never-drop
                              # list.
    "\\explorer\\usersettings\\", "\\explorer\\typedpaths\\",

    # Fonts, locales, timezone, graphics and performance-counter settings.
    "\\perflib\\", "\\nls\\", "\\fontsubstitutes", "\\fontdpi",
    "\\timezoneinformation", "\\directx\\",
    # Browser cache bookkeeping. Note this is deliberately narrower than
    # "\internet settings\": the proxy values under that key ARE high-signal
    # and are listed above.
    "\\internet settings\\5.0\\cache\\", "\\internet settings\\cache\\",
    "\\control panel\\international\\", "\\control panel\\accessibility\\",
    "\\uninstall\\",   # the installed-programs list. Malware reads it to see
                       # what antivirus is present, so this is reconnaissance
                       # at best -- worth keeping only if nothing better fits.
)

# ------------------------------------------------------------------ #
# 6. Extension promotion                                             #
# ------------------------------------------------------------------ #
# File types that can execute code. A file with one of these extensions is
# lifted from TIER_MIDDLE to TIER_HIGH, on the reasoning that an unclassified
# location holding something runnable is more interesting than an
# unclassified location holding a document.
#
# The promotion deliberately does NOT apply to TIER_LOW. Low-signal
# directories are full of perfectly legitimate executables -- Windows keeps
# thousands of DLLs under \WinSxS\ -- so promoting those would undo the
# filtering we just did.
EXECUTABLE_EXTENSIONS: frozenset[str] = frozenset({
    ".exe", ".dll", ".sys", ".scr", ".cpl", ".ocx", ".drv",
    ".ps1", ".psm1", ".bat", ".cmd", ".vbs", ".vbe", ".js", ".jse",
    ".wsf", ".wsh", ".hta", ".lnk", ".pif", ".msi", ".msp", ".jar",
    ".so", ".ko", ".dylib", ".elf", ".sh", ".py", ".pl",
})

# ------------------------------------------------------------------ #
# 6b. Credential files matched by filename                           #
# ------------------------------------------------------------------ #
# Some credential files cannot be described by a path fragment at all, so
# these rules look at the last component of the path (the filename) instead.
#
# ".env" is the motivating example. It holds application secrets and is one of
# the most-stolen files there is, but as a fragment it fails twice over: it
# would match unrelated names like ".envrc" or "config.environment", and at
# four characters it loses every length comparison anyway.
#
# BASENAME_WEIGHT is the length this rule claims when competing with ordinary
# patterns. It must stay above the longest low-signal pattern, otherwise a
# secret sitting inside a noisy directory -- node_modules/some-package/.env is
# a real case -- gets dropped along with the directory. Unit tests assert this,
# so raising it is safe and lowering it will fail loudly.
BASENAME_WEIGHT = 64

# Filenames that must match exactly.
BASENAME_HIGH_EXACT: frozenset[str] = frozenset({
    ".env", ".envrc",             # application secrets and shell environment
    # SSH private keys. The naming is conventional: "id_" plus the algorithm.
    # The matching ".pub" files are public halves and are excluded below.
    "id_rsa", "id_dsa", "id_ecdsa", "id_ed25519", "id_ed25519_sk",
    "authorized_keys",            # which keys may log in -- appending grants
                                  # the attacker permanent access
    "known_hosts",                # a list of machines this host connects to,
                                  # useful for spreading further
    ".credentials.json", "credentials", "credentials.json",
    "secrets.json", "secrets.yaml", "secrets.yml",
    ".pgpass", ".my.cnf",         # database passwords, stored in plaintext
    ".dbeaver-data-sources.json",
    "shadow", "sam", "ntds.dit",  # the password stores named earlier, caught
                                  # here too in case they are copied elsewhere
                                  # under their original name
    # Windows deployment files. They routinely contain an administrator
    # password in plaintext, and are often left readable on a network share.
    "unattend.xml", "sysprep.inf", "groups.xml",
})

# Filenames that START with one of these. Covers the common convention of
# per-environment secret files: ".env.local", ".env.production".
BASENAME_HIGH_PREFIXES: tuple[str, ...] = (".env.",)

# File extensions that indicate a key, certificate or password database,
# whatever the filename in front of them happens to be.
BASENAME_HIGH_EXTENSIONS: frozenset[str] = frozenset({
    ".pem", ".pfx", ".p12", ".pk8", ".key", ".keystore", ".jks",
    ".ppk", ".ovpn", ".kdbx", ".kdb", ".psafe3", ".agilekeychain",
})

# Checked before everything above, and wins outright.
#
# These are the harmless lookalikes: template files that ship in source
# repositories with no real secret in them, and the public halves of key
# pairs, which are meant to be shared. Any sample that unpacks a source
# repository touches dozens of them, and without this list they would flood
# the high tier and push out the findings that matter.
BASENAME_EXCLUDE: frozenset[str] = frozenset({
    ".env.example", ".env.sample", ".env.template", ".env.dist",
    ".env.defaults", ".env.test", ".env.schema",
    "id_rsa.pub", "id_dsa.pub", "id_ecdsa.pub", "id_ed25519.pub",
    "credentials.example", "secrets.example.json",
})


def _basename(path: str) -> str:
    """Return the last path component, splitting on either separator.

    os.path.basename is not used because it only understands the separator of
    the platform this code happens to run on, and we classify Windows paths
    from a Linux host and vice versa.
    """
    return re.split(r"[\\/]", path)[-1]


def _basename_is_credential(path: str) -> bool:
    """True if the filename identifies a credential file."""
    base = _basename(path)
    if not base or base in BASENAME_EXCLUDE:
        return False
    if base in BASENAME_HIGH_EXACT:
        return True
    if base.startswith(BASENAME_HIGH_PREFIXES):
        return True
    return os.path.splitext(base)[1] in BASENAME_HIGH_EXTENSIONS


# Operation names that count as modifying a file, used to resolve
# HIGH_SIGNAL_PATHS_ON_WRITE. 
WRITE_OPERATIONS: frozenset[str] = frozenset({
    "file_written", "file_created", "file_deleted", "file_moved",
    "key_created", "key_deleted", "key_value_created", "key_value_deleted", "key_value_modified"
})

# ------------------------------------------------------------------ #
# Normalisation                                                      #
# ------------------------------------------------------------------ #
# Windows can spell the same location many different ways, and the sandbox
# reports whichever spelling the program used. Without normalisation, a
# pattern matches one spelling and misses the rest -- which is a silent
# failure, not an error. The four cases handled below:
#
#   Device paths     "\??\C:\Windows\..." and
#                    "\Device\HarddiskVolume2\Windows\..." are both
#                    C:\Windows. Low-level code uses these forms.
#   Hive names       "HKLM\..." and "HKEY_LOCAL_MACHINE\..." are the same
#                    key. So is "\REGISTRY\MACHINE\...", used by kernel-level
#                    reporting.
#   Wow6432Node      When a 32-bit program on 64-bit Windows writes to
#                    HKLM\Software\X, Windows silently stores it at
#                    HKLM\Software\Wow6432Node\X. Same setting, extra path
#                    component, so we remove the component.
#   User SIDs        A user's own settings appear either as HKEY_CURRENT_USER
#                    or as HKEY_USERS\S-1-5-21-<long number>, where the number
#                    identifies the account. We collapse the second form into
#                    the first so patterns need only one spelling.
_NT_DEVICE_RE = re.compile(r"^\\\?\?\\|^\\device\\harddiskvolume\d+|^\\\\\?\\")
_GLOBALROOT_RE = re.compile(r"\\\\\?\\globalroot")

_HIVE_ALIASES = (
    ("hkey_local_machine", "hkey_local_machine"),
    ("hklm", "hkey_local_machine"),
    ("hkey_current_user", "hkey_current_user"),
    ("hkcu", "hkey_current_user"),
    ("hkey_classes_root", "hkey_classes_root"),
    ("hkcr", "hkey_classes_root"),
    ("hkey_current_config", "hkey_current_config"),
    ("hkcc", "hkey_current_config"),
    ("hkey_users", "hkey_users"),
    ("hku", "hkey_users"),
    ("\\registry\\machine", "hkey_local_machine"),
    ("\\registry\\user", "hkey_users"),
)

_USER_SID_RE = re.compile(r"hkey_users\\s-1-5-21-[\d-]+(?:_classes)?")

# Windows environment variables, expanded by hand.
#
# os.path.expandvars only understands %VAR% syntax when Python is running ON
# Windows. Sandboxes routinely report paths in the %TEMP%\x.exe form, and the
# analysis host is usually Linux, so relying on expandvars means those paths
# silently fail to match any pattern -- \appdata\ never matches "%temp%".
#
# The expansions below use a placeholder username, because the real one is
# irrelevant: every pattern in this file matches on the directory structure
# (\users\, \appdata\, \windows\temp\), never on who owns it.
_WINDOWS_ENV_EXPANSIONS: tuple[tuple[str, str], ...] = (
    ("%localappdata%", "c:\\users\\_user_\\appdata\\local"),
    ("%appdata%", "c:\\users\\_user_\\appdata\\roaming"),
    ("%userprofile%", "c:\\users\\_user_"),
    ("%homepath%", "\\users\\_user_"),
    ("%temp%", "c:\\users\\_user_\\appdata\\local\\temp"),
    ("%tmp%", "c:\\users\\_user_\\appdata\\local\\temp"),
    ("%programdata%", "c:\\programdata"),
    ("%allusersprofile%", "c:\\programdata"),
    ("%public%", "c:\\users\\public"),
    ("%systemroot%", "c:\\windows"),
    ("%windir%", "c:\\windows"),
    ("%system32%", "c:\\windows\\system32"),
    ("%programfiles(x86)%", "c:\\program files (x86)"),
    ("%programfiles%", "c:\\program files"),
    ("%systemdrive%", "c:"),
)

def normalise_path(path: str) -> str:
    """Convert one observed file path into the form the patterns expect.

    Lowercases, expands environment variables (%TEMP% and friends), removes
    the Windows device prefixes described above, and collapses doubled
    separators. Mixed separators are unified only when a backslash is present,
    so genuine Linux paths are left alone.
    """
    p = os.path.expandvars(path).lower()
    # Windows-style variables, which expandvars leaves alone on a Linux host.
    # Longest keys first, so %localappdata% is not mangled by %appdata%.
    if "%" in p:
        for name, expansion in _WINDOWS_ENV_EXPANSIONS:
            p = p.replace(name, expansion)
    p = _GLOBALROOT_RE.sub("", p)
    p = _NT_DEVICE_RE.sub("", p)
    if "\\" in p:                     # Windows path with mixed separators
        p = p.replace("/", "\\")
    p = re.sub(r"\\{2,}", "\\\\", p)
    p = re.sub(r"/{2,}", "/", p)
    return p


def normalise_registry(key: str, value_name: str | None = None) -> str:
    """Convert one observed registry key into the form the patterns expect.

    Pass value_name whenever the sandbox reports one. It is appended to the
    key so that "key\value_name" is what gets matched -- several patterns are
    value names rather than keys, and omitting it makes them unmatchable.
    """
    k = key.lower().replace("/", "\\")
    for alias, full in _HIVE_ALIASES:
        if k.startswith(alias) and not k.startswith(full):
            k = full + k[len(alias):]
            break
    k = k.replace("\\wow6432node", "")
    # Per-user hives resolve to HKCU so patterns need only one form.
    k = _USER_SID_RE.sub("hkey_current_user", k)
    k = re.sub(r"\\{2,}", "\\\\", k)
    if value_name:
        k = k.rstrip("\\") + "\\" + value_name.lower()
    return k


# ------------------------------------------------------------------ #
# Matching                                                           #
# ------------------------------------------------------------------ #
_COMPILED_HIGH_REGEXES = tuple(
    (re.compile(rx), weight) for rx, weight in HIGH_SIGNAL_REGEXES
)


def _matches(target: str, pattern: str) -> bool:
    """True if pattern applies to target.

    Two ways to match. Normally the pattern just has to appear anywhere in the
    target. The second way exists for patterns written with a trailing
    separator: "\\run\\" should also match a key that ENDS at "...\\run", where
    there is no following backslash for the pattern to match against. So if
    the pattern ends in a separator, we also accept the target ending with the
    pattern minus that separator.
    """
    if pattern in target:
        return True
    if pattern[-1:] in ("\\", "/"):
        return target.endswith(pattern[:-1])
    return False


def _root_views(target: str) -> tuple[str, ...]:
    """The positions an anchored pattern is allowed to match at.

    Just the whole string for a POSIX path, plus the string with a leading
    drive letter removed so that "\\windows\\winsxs\\" anchors against
    "c:\\windows\\winsxs\\...".
    """
    if len(target) > 2 and target[1] == ":":
        return (target, target[2:])
    return (target,)


def _matches_anchored(target: str, pattern: str) -> bool:
    """True if pattern appears at the START of target, not merely inside it.

    Used for LOW_SIGNAL_PATH_ROOTS. The point is that an attacker controls
    part of every path we classify -- they choose where to write and what to
    name directories -- so a low-signal pattern that matches anywhere is a way
    for them to request a low tier. Anchoring removes that.
    """
    for base in _root_views(target):
        if base.startswith(pattern):
            return True
        if pattern[-1:] in ("\\", "/") and base == pattern[:-1]:
            return True
    return False


def _resolve_pattern_tier(pattern: str, *, is_registry: bool,
                          operation: str) -> int:
    """Look up which tier a single matched pattern argues for.
 
    The write-only list is checked first, since those patterns are the only
    ones whose tier depends on the event rather than the pattern.
 
    Note that a READ of a write-only path resolves to TIER_LOW, not
    TIER_MIDDLE, and the difference matters for two reasons:
 
      * TIER_MIDDLE is the only tier eligible for executable-extension
        promotion, so returning it here would lift every kernel32.dll and
        ntdll.dll load to TIER_HIGH. Process startup reads dozens of those,
        so the report would fill with library loads.
      * TIER_MIDDLE means "no pattern matched, no opinion". Here a pattern did
        match and we have a firm opinion: system-library reads are the largest
        single source of noise in a trace.
 
    An unrecognised file in a system directory is a different case, and it
    already falls through to TIER_MIDDLE at the end of this function.
    """
    if pattern in HIGH_SIGNAL_PATHS_ON_WRITE:
        return TIER_HIGH if operation in WRITE_OPERATIONS else TIER_LOW
    if is_registry:
        if pattern in REGISTRY_WRITE_GATED:
            # Reads are filtered out before this point, in resolve_tier.
            return REGISTRY_WRITE_GATED[pattern]
        if pattern in HIGH_SIGNAL_REGISTRY:
            return TIER_HIGH
        if pattern in LOW_SIGNAL_REGISTRY:
            return TIER_LOW
    else:
        if pattern in HIGH_SIGNAL_PATHS:
            return TIER_HIGH
        if pattern in LOW_SIGNAL_PATHS or pattern in _LOW_ROOTS_SET:
            return TIER_LOW
    return TIER_MIDDLE


def _never_drop(is_registry: bool) -> tuple[str, ...]:
    return NEVER_DROP_REGISTRY if is_registry else NEVER_DROP_PATHS


# Membership test for "must this pattern be matched at the start of the path?"
_LOW_ROOTS_SET = frozenset(LOW_SIGNAL_PATH_ROOTS)


def _pattern_pool(is_registry: bool) -> tuple[str, ...]:
    """Every pattern that could apply, high and low signal together.

    They are pooled deliberately: the comparison in resolve_tier ranks by
    length across both, so it must see them as one set rather than consulting
    the high list first.
    """
    if is_registry:
        return (NEVER_DROP_REGISTRY + tuple(REGISTRY_WRITE_GATED)
                + HIGH_SIGNAL_REGISTRY + LOW_SIGNAL_REGISTRY)
    return (NEVER_DROP_PATHS + HIGH_SIGNAL_PATHS + LOW_SIGNAL_PATHS
            + LOW_SIGNAL_PATH_ROOTS + HIGH_SIGNAL_PATHS_ON_WRITE)


def resolve_tier(
    target: str,
    *,
    is_registry: bool = False,
    operation: str = "read",
    already_normalised: bool = False,
) -> int:
    """Return the tier for one observed file path or registry key.

    Args:
        target: the path or key as the sandbox reported it.
        is_registry: True for registry keys, False for file paths. Selects
            which set of lists to consult; they never share patterns.
        operation: what the event did ("read", "write", ...). Only affects
            paths in HIGH_SIGNAL_PATHS_ON_WRITE; see WRITE_OPERATIONS.
        already_normalised: set True if you have already called
            normalise_path/normalise_registry, which you must do if you need
            to append a registry value name.

    Returns one of the TIER_* constants.
    """
    t = target if already_normalised else (
        normalise_registry(target) if is_registry else normalise_path(target)
    )

    # Walk every pattern and keep the longest match. best_len holds the length
    # of the winner so far, which lets us skip shorter patterns outright.
    never_drop = _never_drop(is_registry)
    best_tier = TIER_MIDDLE
    best_len = -1
    for pattern in _pattern_pool(is_registry):
        if len(pattern) < best_len:
            continue
        matcher = _matches_anchored if pattern in _LOW_ROOTS_SET else _matches
        if not matcher(t, pattern):
            continue
        if is_registry and pattern in REGISTRY_WRITE_GATED:
            if operation not in WRITE_OPERATIONS:
                continue            # read: this pattern abstains entirely
            # Write: short-circuit like never-drop, so that a longer
            # low-signal pattern cannot outrank it. This is what keeps a COM
            # hijack write from being buried by hkey_classes_root\clsid\.
            return REGISTRY_WRITE_GATED[pattern]
        if pattern in never_drop:
            return TIER_ALWAYS          # step 1: no comparison needed
        tier = _resolve_pattern_tier(
            pattern, is_registry=is_registry, operation=operation
        )
        # Longer pattern wins. On a tie, the lower tier number wins, which
        # means an even contest resolves toward keeping the item.
        if len(pattern) > best_len or tier < best_tier:
            best_tier, best_len = tier, len(pattern)

    # The two rules that use a declared weight instead of a pattern length.
    # Both are file-only: neither concept applies to registry keys.
    if not is_registry:
        for regex, weight in _COMPILED_HIGH_REGEXES:
            if weight >= best_len and regex.search(t):
                if weight > best_len or TIER_HIGH < best_tier:
                    best_tier, best_len = TIER_HIGH, weight

        if BASENAME_WEIGHT >= best_len and _basename_is_credential(t):
            best_tier, best_len = TIER_HIGH, BASENAME_WEIGHT

    # Last two adjustments, both about executables, and both file-only.
    if not is_registry:
        is_executable = os.path.splitext(t)[1] in EXECUTABLE_EXTENSIONS

        # An executable in an unclassified location is worth more than a
        # document there. Only TIER_MIDDLE is eligible -- see
        # EXECUTABLE_EXTENSIONS for why this must not rescue TIER_LOW.
        if is_executable and best_tier == TIER_MIDDLE:
            return TIER_HIGH

        # Write-floor. Anchoring stops an attacker claiming a low tier by
        # naming a directory at the path root, but the patterns in
        # LOW_SIGNAL_PATHS genuinely occur mid-path and so cannot be anchored:
        # creating "...\appdata\roaming\microsoft\windows\caches\" or a
        # "node_modules" directory and writing a payload inside it still lands
        # in TIER_LOW. So refuse to drop the WRITE of an executable to the
        # bottom tier no matter which directory it claims to be in. Reads are
        # untouched, which is what keeps the cost down -- loading a library out
        # of node_modules stays low-signal.
        if is_executable and best_tier == TIER_LOW:
            if operation in WRITE_OPERATIONS:
                return TIER_MIDDLE

    return best_tier


# ------------------------------------------------------------------ #
# Maintenance helper: find pattern pairs where length decides the outcome  #
# ------------------------------------------------------------------ #
def overlapping_pattern_pairs(
    is_registry: bool = False,
) -> list[tuple[str, str]]:
    """List pattern pairs where one pattern contains the other.

    Run this after adding patterns. Each pair returned is a place where the
    length rule quietly picks a winner for any target that matches both, so
    each one is worth an eyeball: if the longer member of a pair belongs to the
    tier you did not intend, you have either just started dropping something
    real or just started keeping noise. That is the failure mode this whole
    file is arranged to prevent, and it produces no error when it happens.

    Returns (shorter, longer) tuples, longest first.
    """
    pool = _pattern_pool(is_registry)
    out = set()
    for a in pool:
        for b in pool:
            if a != b and a in b:
                out.add((a, b))
    return sorted(out, key=lambda p: (-len(p[1]), p[0]))

 
_TIER_KEY_NAMES: dict[int, str] = {
    TIER_ALWAYS: "highest_priority",
    TIER_HIGH:   "high_priority",
    TIER_MIDDLE: "medium_priority",
    TIER_LOW:    "low_priority",
}


def tier_and_cap(
    items: list[tuple[str, str]],
    indicator_type: str,
    limit: int,
) -> dict[str, list[str]]:
    """Tier a list of (indicator, operation) pairs and return up to ``limit`` items.

    Fills greedily: all TIER_ALWAYS items first, then TIER_HIGH, TIER_MIDDLE,
    TIER_LOW — stopping as soon as ``limit`` is reached. Returns items nested
    under their priority key so callers can see which tier each item belongs to.

    Args:
        items: (indicator, operation) pairs as the sandbox reported them. For
            registry entries that have a value name, the indicator should
            already be the combined "key\\\\value_name" string.
        indicator_type: "file_path" or "registry".
        limit: maximum total number of indicators to return across all tiers.

    Returns a dict with keys ``highest_priority``, ``high_priority``,
    ``medium_priority``, ``low_priority``, each a list of normalised
    indicators. All four keys are always present. The total count across all
    lists is at most ``limit``.
    """
    FILE_PATH = "file_path"
    REGISTRY = "registry"
    if indicator_type not in (FILE_PATH, REGISTRY):
        raise ValueError(
            f"indicator_type must be {FILE_PATH!r} or {REGISTRY!r}, "
            f"got {indicator_type!r}"
        )

    is_registry = indicator_type == REGISTRY
    normalise = normalise_registry if is_registry else normalise_path

    tiers: dict[int, list[str]] = {
        TIER_ALWAYS: [],
        TIER_HIGH: [],
        TIER_MIDDLE: [],
        TIER_LOW: [],
    }
    seen: set[str] = set()

    for indicator, operation in items:
        normalised = normalise(indicator)
        if normalised in seen:
            continue
        seen.add(normalised)
        tier = resolve_tier(
            normalised,
            is_registry=is_registry,
            operation=operation,
            already_normalised=True,
        )
        tiers[tier].append(normalised)

    result: dict[str, list[str]] = {name: [] for name in _TIER_KEY_NAMES.values()}
    remaining = limit
    for tier in (TIER_ALWAYS, TIER_HIGH, TIER_MIDDLE, TIER_LOW):
        if remaining <= 0:
            break
        bucket = tiers[tier][:remaining]
        result[_TIER_KEY_NAMES[tier]] = bucket
        remaining -= len(bucket)
    return result


