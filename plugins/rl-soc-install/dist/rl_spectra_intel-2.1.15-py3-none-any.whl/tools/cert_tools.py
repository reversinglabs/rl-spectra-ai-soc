"""
Certificate Threat Intelligence MCP Tools

Tools for querying certificate reputation, analytics, and thumbprint search
from the Spectra Intelligence API.
"""

import logging

import httpx
from core.errors import (
    invalid_input_error as _invalid_input_error,
    translate_http_error,
    unexpected_error as _unexpected_error,
    validate_hash as _validate_hash,
    validate_hash_list as _validate_hash_list,
)
from core.si_client import SpectraIntelligenceClient
from core.user_authorization import require_authorization

logger = logging.getLogger(__name__)

_VALID_CLASSIFICATIONS = frozenset({"KNOWN", "SUSPICIOUS", "MALICIOUS", "UNKNOWN"})
_MAX_THUMBPRINTS = 100


def _validate_thumbprint(value: str, param: str = "thumbprint") -> dict | None:
    """Return a structured error dict if a certificate thumbprint is invalid; None if valid."""
    return _validate_hash(value, param, noun="certificate thumbprint")


@require_authorization
async def get_certificate_index(
    thumbprint: str,
    *,
    classification: str | None = None,
    extended: bool = False,
    page: str | None = None,
    limit: int = 100,
) -> dict:
    """
    Return a list of samples signed with a specific certificate.

    Args:
        thumbprint:     MD5 (32 hex chars), SHA-1 (40) or SHA-256 (64)
                        thumbprint of the certificate, as plain text — no
                        quotes or brackets needed.
        classification: Optional filter. One of: ``KNOWN``, ``SUSPICIOUS``,
                        ``MALICIOUS``, ``UNKNOWN``.
        extended:       When True, include extended sample metadata (threat
                        level, malware family, first/last seen, file size, etc.).
        page:           Pagination token from a previous response's
                        ``next_page`` field.
        limit:          Number of samples to return (1–100, default 100).

    Returns:
        A dict with:
        - ``samples``: list of sample objects, each containing hashes,
          classification, and threat data.
        - ``next_page``: pagination token (present only when more results exist).
    """
    thumbprint = (thumbprint or "").strip().strip("\"'")
    if err := _validate_thumbprint(thumbprint):
        return err
    if classification is not None and classification not in _VALID_CLASSIFICATIONS:
        return _invalid_input_error(
            "classification",
            f"'{classification}' is not a valid classification.",
            f"Valid values are: {', '.join(sorted(_VALID_CLASSIFICATIONS))}. Omit to return all.",
        )
    if not 1 <= limit <= 100:
        return _invalid_input_error(
            "limit",
            f"'limit' must be between 1 and 100, got {limit}.",
            "Use a value between 1 and 100.",
        )

    try:
        client = SpectraIntelligenceClient()
        response = await client.tca_0501_certificate_index(
            thumbprint,
            page=page,
            limit=limit,
            extended=extended,
            classification=classification,
        )
        rl = response.get("rl")
        if rl is None:
            logger.warning("get_certificate_index: response missing 'rl'")
            return {}
        result: dict = {}
        if (samples := rl.get("samples")) is not None:
            result["samples"] = samples
        if (next_page := rl.get("next_page")) is not None:
            result["next_page"] = next_page
        return result
    except httpx.HTTPStatusError as exc:
        if exc.response.status_code == 400:
            logger.warning(
                "get_certificate_index: API rejected request for thumbprint '%s' (HTTP 400)",
                thumbprint,
            )
            return translate_http_error(
                exc,
                action="certificate index",
                error="request_rejected",
                next_steps=(
                    "Verify the thumbprint and, if paginating, that 'page' is an "
                    "unmodified token from a previous response's 'next_page'."
                ),
            )
        logger.exception(
            "get_certificate_index: HTTP %s for thumbprint '%s'",
            exc.response.status_code, thumbprint,
        )
        return translate_http_error(
            exc,
            action="certificate index",
            next_steps=(
                "Retry the request. If the error persists, Spectra Intelligence "
                "may be temporarily unavailable."
            ),
        )
    except Exception as exc:
        logger.exception(
            "get_certificate_index: unexpected error for thumbprint '%s'", thumbprint
        )
        return _unexpected_error("certificate index lookup", exc)


def _parse_thumbprints(value: str | list[str]) -> list[str]:
    """Normalise the ``thumbprints`` argument into a list of thumbprint strings."""
    if not isinstance(value, str):
        return [str(t).strip() for t in value]

    text = value.strip()
    if text.startswith("[") and text.endswith("]"):
        text = text[1:-1]
    parts = [
        p.strip().strip("\"'")
        for p in text.replace(",", " ").replace(";", " ").split()
    ]
    return [p for p in parts if p]


@require_authorization
async def get_certificate_analytics(thumbprints: str) -> dict | list:
    """
    Return analytics for one or more certificate thumbprints.

    For a single thumbprint, returns a dict. For multiple thumbprints (up to
    100 per call), returns a dict whose ``certificate_analytics`` is a list.
    Invalid thumbprints are reported in the ``invalid_thumbprints`` key of the
    response.

    Args:
        thumbprints: A single certificate thumbprint (MD5, SHA-1, or SHA-256)
                     or a list of up to 100 thumbprints. When passing multiple
                     thumbprints pass them as comma separated. 

    Returns:
        For a **single thumbprint**: a dict containing ``certificate_analytics``
        with ``statistics`` (counts by classification), ``classification``
        (status, threat_level, trust_factor), ``certificate_first_seen``, and
        the certificate chain of trust.

        For a **list**: a dict containing:
        - ``certificate_analytics``: list of analytics objects (one per thumbprint).
        - ``invalid_thumbprints``: list of thumbprints rejected by the API.
    """
    parsed = _parse_thumbprints(thumbprints)

    if len(parsed) == 1:
        if err := _validate_thumbprint(parsed[0], "thumbprints"):
            return err
    elif err := _validate_hash_list(
        parsed,
        "thumbprints",
        noun="certificate thumbprint",
        max_entries=_MAX_THUMBPRINTS,
        extra_next_steps="Pass them as plain text, separated by commas or spaces.",
    ):
        return err

    try:
        client = SpectraIntelligenceClient()

        if len(parsed) == 1:
            response = await client.tca_0502_certificate_analytics(parsed[0])
            rl = response.get("rl")
            if rl is None:
                logger.warning("get_certificate_analytics: single response missing 'rl'")
                return {}
            return rl.get("certificate_analytics", {})

        # Bulk path
        response = await client.tca_0502_certificate_analytics_bulk(parsed)
        rl = response.get("rl")
        if rl is None:
            logger.warning("get_certificate_analytics: bulk response missing 'rl'")
            return {}
        result: dict = {
            "certificate_analytics": rl.get("certificate_analytics", []),
        }
        if invalid := rl.get("invalid_thumbprints"):
            result["invalid_thumbprints"] = invalid
        return result

    except httpx.HTTPStatusError as exc:
        logger.exception(
            "get_certificate_analytics: HTTP %s", exc.response.status_code
        )
        return translate_http_error(
            exc,
            action="certificate analytics",
            next_steps=(
                "Verify the thumbprint(s) are valid MD5/SHA-1/SHA-256 values. "
                "If the error persists, Spectra Intelligence may be temporarily "
                "unavailable."
            ),
        )
    except Exception as exc:
        logger.exception("get_certificate_analytics: unexpected error")
        return _unexpected_error("certificate analytics lookup", exc)


@require_authorization
async def search_certificate_thumbprints(
    common_name: str,
    *,
    limit: int = 100,
    page_common_name: str | None = None,
    page_thumbprint: str | None = None,
) -> dict:
    """
    Search for certificate thumbprints by common name.

    Supports wildcard ``*`` to match variable character sequences — for
    example, ``"Microsoft*"`` returns all certificates whose common name
    begins with "Microsoft".

    Args:
        common_name:        Certificate common name or partial name.
                            Use ``*`` as a wildcard (e.g. ``"*Symantec*"``).
        limit:              Number of results to return (1–100, default 100).
        page_common_name:   Pagination token from a previous response's
                            ``next_page_common_name`` field.
        page_thumbprint:    Pagination token from a previous response's
                            ``next_page_thumbprint`` field.

    Returns:
        A dict with:
        - ``search``: list of objects, each with a ``common_name`` and
          ``thumbprints`` (MD5, SHA-1, SHA-256 values).
        - ``next_page_common_name`` / ``next_page_thumbprint``: pagination
          tokens (present only when more results exist).
    """
    if not common_name or not common_name.strip():
        return _invalid_input_error(
            "common_name",
            "'common_name' is required and cannot be empty.",
            "Provide a certificate common name or partial name. Use '*' as a wildcard (e.g. 'Microsoft*').",
        )
    if not 1 <= limit <= 100:
        return _invalid_input_error(
            "limit",
            f"'limit' must be between 1 and 100, got {limit}.",
            "Use a value between 1 and 100.",
        )
    if page_common_name is not None and page_thumbprint is not None:
        return _invalid_input_error(
            "page",
            "'page_common_name' and 'page_thumbprint' cannot both be set.",
            "Pass only the pagination token(s) from the previous response's "
            "'next_page_common_name' / 'next_page_thumbprint' as returned — do not set both yourself.",
        )

    try:
        client = SpectraIntelligenceClient()
        response = await client.tca_0503_certificate_search(
            common_name,
            limit=limit,
            page_common_name=page_common_name,
            page_thumbprint=page_thumbprint,
        )
        rl = response.get("rl")
        if rl is None:
            logger.warning("search_certificate_thumbprints: response missing 'rl'")
            return {}
        result: dict = {
            "search": rl.get("search", []),
        }
        if (npn := rl.get("next_page_common_name")) is not None:
            result["next_page_common_name"] = npn
        if (npt := rl.get("next_page_thumbprint")) is not None:
            result["next_page_thumbprint"] = npt
        return result
    except httpx.HTTPStatusError as exc:
        if exc.response.status_code == 400:
            logger.warning(
                "search_certificate_thumbprints: API rejected request for common_name %r (HTTP 400)",
                common_name,
            )
            return translate_http_error(
                exc,
                action="certificate thumbprint search",
                error="request_rejected",
                next_steps=(
                    "Verify the common_name (use '*' as a wildcard, e.g. 'Microsoft*') "
                    "and that any pagination token is an unmodified value from a "
                    "previous response."
                ),
            )
        logger.exception(
            "search_certificate_thumbprints: HTTP %s for common_name '%s'",
            exc.response.status_code, common_name,
        )
        return translate_http_error(
            exc,
            action="certificate thumbprint search",
            next_steps=(
                "Retry the request. If the error persists, Spectra Intelligence "
                "may be temporarily unavailable."
            ),
        )
    except Exception as exc:
        logger.exception(
            "search_certificate_thumbprints: unexpected error for common_name '%s'",
            common_name,
        )
        return _unexpected_error("certificate thumbprint search", exc)
