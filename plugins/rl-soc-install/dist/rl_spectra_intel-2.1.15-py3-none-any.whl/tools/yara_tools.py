"""
YARA MCP Tools

Tools for managing YARA rulesets and hunting in Spectra Intelligence.
"""

import asyncio
import logging
import time

import httpx

from core.errors import translate_http_error
from core.si_client import SpectraIntelligenceClient
from core.user_authorization import require_authorization

logger = logging.getLogger(__name__)


@require_authorization
async def yara_hunt_start(
    ruleset_name: str,
    ruleset_content: str,
    retro: bool = False,
) -> dict:
    """
    Create a YARA ruleset and start a live hunt, optionally also starting a retro hunt.

    Creating the ruleset automatically starts a live hunt against new files as
    they are ingested. If ``retro`` is True, a retro hunt is also launched to
    scan files already in the Spectra Intelligence corpus.

    Args:
        ruleset_name:    Name of the ruleset to create.
        ruleset_content: YARA rule content.
        retro:           When True, also start a retro hunt after creating the ruleset.

    Returns:
        A dict with ``started_at`` (Unix epoch seconds, captured before the hunt
        begins — pass this to ``yara_hunt_get_matches`` as ``since``),
        ``live_hunt`` containing the creation result, and optionally ``retro_hunt``
        containing the retro hunt start result if ``retro`` is True.
    """
    if not ruleset_name or not ruleset_name.strip():
        raise ValueError("'ruleset_name' is required and cannot be empty.")
    if not ruleset_content or not ruleset_content.strip():
        raise ValueError("'ruleset_content' is required and cannot be empty.")
    try:
        ruleset_name = ruleset_name.lower()
        started_at = int(time.time())
        client = SpectraIntelligenceClient()

        try:
            live_result = await client.tca_0303_create_or_update_ruleset(ruleset_name, ruleset_content)
        except httpx.HTTPStatusError as exc:
            if exc.response.status_code == 400:
                return translate_http_error(
                    exc,
                    action="YARA ruleset create/update",
                    error="ruleset_rejected",
                    next_steps="Check the ruleset syntax and name, then resubmit.",
                )
            raise

        output: dict = {"started_at": started_at, "live_hunt": live_result}

        if retro:
            try:
                retro_result = await client.tca_0319_start_retro_hunt(ruleset_name)
                output["retro_hunt"] = retro_result
            except httpx.HTTPStatusError as exc:
                if exc.response.status_code == 400:
                    output["retro_hunt"] = translate_http_error(
                        exc,
                        action="YARA retro hunt start",
                        error="retro_hunt_rejected",
                    )
                else:
                    raise

        return output
    except Exception:
        logger.exception("yara_hunt_start: unexpected error for ruleset '%s'", ruleset_name)
        raise


@require_authorization
async def yara_hunt_status_and_matches(
    ruleset_name: str,
    since_live: int,
    since_retro: int,
) -> dict:
    """
    Get hunt status and retrieve matches for a YARA ruleset.

    Fetches live hunt status (TCA-0303), retro hunt status (TCA-0319), live
    hunt matches (TCA-0303 feed), and retro hunt matches (TCA-0319 feed) all
    in parallel. Match entries are enriched with classification and threat name
    via TCA-0320 and grouped by classification.

    Args:
        ruleset_name: Name of the ruleset to check.
        since_live:   Start of the time range for live hunt matches, as a Unix
                      epoch timestamp in seconds. Use the ``started_at`` value
                      returned by ``yara_hunt_start`` for the first call, then
                      use the ``last_timestamp`` from the previous response.
        since_retro:  Start of the time range for retro hunt matches, as a Unix
                      epoch timestamp in seconds. Use the ``started_at`` value
                      returned by ``yara_hunt_start`` for the first call, then
                      use the ``last_timestamp`` from the previous response.

    Returns:
        A dict with ``live_hunt`` and ``retro_hunt``, each containing:

        - ``status`` — ruleset/hunt status.
        - ``last_timestamp`` — use as ``since_*`` on the next call.
        - ``classifications`` — matched samples grouped by classification
          (``ruleset_name``, ``ruleset_sha1``, and ``sample_available`` removed;
          ``first_seen`` included from the extended feed response).
        - ``warning`` — present if results were truncated to 500 entries.
    """
    if not ruleset_name or not ruleset_name.strip():
        raise ValueError("'ruleset_name' is required and cannot be empty.")
    try:
        ruleset_name = ruleset_name.lower()
        client = SpectraIntelligenceClient()

        status_live, status_retro, matches_live, matches_retro = await asyncio.gather(
            client.tca_0303_get_ruleset(ruleset_name),
            client.tca_0319_get_retro_hunt_status(ruleset_name),
            client.tca_0303_get_matches("timestamp", str(since_live), extended=True),
            client.tca_0319_get_retro_matches("timestamp", str(since_retro), extended=True),
            return_exceptions=True,
        )

        _REMOVE_ENTRY = {"ruleset_name", "ruleset_sha1", "sample_available"}

        def _clean_entry(e: dict) -> dict:
            cleaned = {k: v for k, v in e.items() if k not in _REMOVE_ENTRY}
            rules = e.get("rule")
            if isinstance(rules, list) and rules:
                first = rules[0]
                cleaned["rule"] = first.get("identifier") if isinstance(first, dict) else first
            return cleaned

        def _process_status(result, hunt_label: str):
            if isinstance(result, httpx.HTTPStatusError):
                if result.response.status_code == 400:
                    return translate_http_error(result, action=f"{hunt_label} status", error="hunt_status_rejected")
                return {"error": str(result)}
            if isinstance(result, Exception):
                return {"error": str(result)}
            return result

        def _process_matches(result, hunt_label: str) -> dict:
            if isinstance(result, httpx.HTTPStatusError):
                if result.response.status_code == 400:
                    return translate_http_error(result, action=f"{hunt_label} matches", error="hunt_matches_rejected")
                return {"error": str(result)}
            if isinstance(result, Exception):
                return {"error": str(result)}
            feed = result.get("rl", {}).get("feed", {})
            entries = feed.get("entries")
            if entries is None:
                logger.warning("yara_hunt_status_and_matches: missing 'entries' in %s feed response", hunt_label)
                entries = []
            filtered = [
                _clean_entry(e)
                for e in entries
                if e.get("ruleset_name") == ruleset_name
            ]
            out: dict = {"last_timestamp": feed.get("last_timestamp"), "entries": filtered[:500]}
            if len(filtered) > 500:
                out["warning"] = "More than 500 files were matched; results truncated to 500."
            return out

        live_out  = _process_matches(matches_live,  "live")
        retro_out = _process_matches(matches_retro, "retro")

        # Collect all unique sha1s for TCA-0320 enrichment
        all_entries = (
            live_out.get("entries", []) if isinstance(live_out.get("entries"), list) else []
        ) + (
            retro_out.get("entries", []) if isinstance(retro_out.get("entries"), list) else []
        )
        sha1s = list({e["sha1"] for e in all_entries if isinstance(e.get("sha1"), str)})

        classification_lookup: dict[str, dict] = {}
        if sha1s:
            batches = [sha1s[i:i + 1000] for i in range(0, len(sha1s), 1000)]
            batch_results = await asyncio.gather(
                *[client.tca_0320_expression_search(" ".join(batch)) for batch in batches],
                return_exceptions=True,
            )
            for batch_result in batch_results:
                if isinstance(batch_result, Exception):
                    logger.warning("yara_hunt_status_and_matches: TCA-0320 batch lookup failed: %s", batch_result)
                    continue
                for entry in batch_result.get("rl", {}).get("web_search_api", {}).get("entries", []):
                    sha1 = entry.get("sha1")
                    if sha1:
                        classification_lookup[sha1] = {
                            "classification": entry.get("classification"),
                            "threatname": entry.get("threatname"),
                        }

        def _enrich_and_group(out: dict) -> dict:
            entries = out.pop("entries", [])
            if not isinstance(entries, list):
                return out
            groups: dict[str, list] = {}
            for e in entries:
                sha1 = e.get("sha1")
                if sha1 and sha1 in classification_lookup:
                    info = classification_lookup[sha1]
                    e["classification"] = info["classification"]
                    if info["threatname"]:
                        e["threatname"] = info["threatname"]
                classification = e.get("classification") or "UNKNOWN"
                groups.setdefault(classification, []).append(e)
            out["classifications"] = groups
            return out

        live_matches  = _enrich_and_group(live_out)
        retro_matches = _enrich_and_group(retro_out)

        return {
            "live_hunt": {
                "status": _process_status(status_live, "live"),
                **live_matches,
            },
            "retro_hunt": {
                "status": _process_status(status_retro, "retro"),
                **retro_matches,
            },
        }
    except Exception:
        logger.exception("yara_hunt_status_and_matches: unexpected error for ruleset '%s'", ruleset_name)
        raise


@require_authorization
async def yara_hunt_delete(ruleset_name: str) -> dict:
    """
    Cancel any active retro hunt, stop the live hunt, and delete a YARA ruleset.

    Attempts to cancel the retro hunt first, then deletes the ruleset.
    Deleting the ruleset stops the live hunt — there is no separate disable
    endpoint; deletion is the mechanism. The retro hunt
    cancellation is best-effort — if there is no active retro hunt the error
    is noted but deletion still proceeds.

    Args:
        ruleset_name: Name of the ruleset to delete.

    Returns:
        A dict with ``deleted`` confirming the ruleset name, and optionally
        ``retro_hunt_cancel`` with the cancel result or error.
    """
    if not ruleset_name or not ruleset_name.strip():
        raise ValueError("'ruleset_name' is required and cannot be empty.")
    try:
        ruleset_name = ruleset_name.lower()
        client = SpectraIntelligenceClient()

        output: dict = {}

        try:
            cancel_result = await client.tca_0319_cancel_retro_hunt(ruleset_name)
            output["retro_hunt_cancel"] = cancel_result
        except httpx.HTTPStatusError as exc:
            output["retro_hunt_cancel"] = translate_http_error(
                exc, action="YARA retro hunt cancel", error="retro_hunt_cancel_failed",
            )

        try:
            await client.tca_0303_delete_ruleset(ruleset_name)
            output["deleted"] = ruleset_name
        except httpx.HTTPStatusError as exc:
            if exc.response.status_code == 400:
                output["delete_error"] = translate_http_error(
                    exc, action="YARA ruleset delete", error="delete_rejected",
                )
            else:
                raise

        return output
    except Exception:
        logger.exception("yara_hunt_delete: unexpected error for ruleset '%s'", ruleset_name)
        raise
