"""
User Authorization and Quota Enforcement

Provides the :func:`require_authorization` decorator for MCP tool functions.
When OAuth is enabled, the decorator:

1. Extracts the ``preferred_username`` from the request's access token.
2. Calls the ReversingLabs quota service to verify the user is authorised and
   has not exceeded their usage quota.
3. Raises an appropriate error if either check fails.

When OAuth is disabled the decorator is a transparent pass-through.
"""

import logging
from functools import wraps
from typing import Optional

import httpx

from config import get_settings

logger = logging.getLogger(__name__)

# Internal quota service endpoint
# TCA-0050: quota/authorization check, called before every tool invocation when OAuth is enabled.
_QUOTA_URL = "https://alt-internal-api01.rl.lan/api/mcp/quota/v1/update"


class AuthorizationError(Exception):
    """Raised when the user is not authorised to use the service (HTTP 403)."""


class QuotaExceededError(Exception):
    """Raised when the user has exceeded their usage quota (HTTP 429)."""


async def check_user_authorization(username: str) -> None:
    """
    Verify that *username* is authorised and has remaining quota.

    Sends a POST request to the internal ReversingLabs quota service.

    Args:
        username: The username extracted from the JWT ``preferred_username`` claim.

    Raises:
        AuthorizationError: The quota service returned HTTP 403.
        QuotaExceededError: The quota service returned HTTP 429.
        httpx.HTTPError: For any other HTTP-level failure.
    """
    logger.debug("Checking authorization for user '%s' at %s", username, _QUOTA_URL)

    try:
        async with httpx.AsyncClient(timeout=10.0, verify=False) as client:
            response = await client.post(_QUOTA_URL, json={"username": username})

        logger.debug(
            "Quota service response – status=%s, body=%.200s",
            response.status_code,
            response.text,
        )

        if response.status_code == 403:
            logger.warning("User '%s' is not authorised", username)
            raise AuthorizationError(
                f"User '{username}' is not authorised to use this service"
            )

        if response.status_code == 429:
            logger.warning("User '%s' has exceeded their quota", username)
            raise QuotaExceededError(f"User '{username}' has exceeded their quota")

        if response.status_code != 200:
            logger.warning(
                "Quota service returned unexpected status %s for user '%s'",
                response.status_code,
                username,
            )

        response.raise_for_status()
        logger.debug("Authorization check passed for user '%s'", username)

    except (AuthorizationError, QuotaExceededError):
        raise
    except httpx.HTTPError as exc:
        logger.error(
            "HTTP error while checking authorization for user '%s': %s",
            username,
            exc,
        )
        raise


def require_authorization(func):
    """
    Decorator that enforces user authorisation and quota checks on MCP tools.

    When ``MCP_OAUTH_ENABLED`` is falsy the decorator is a no-op so that
    unauthenticated development/test deployments work without modification.

    Usage::

        from core.user_authorization import require_authorization

        @require_authorization
        async def my_tool(arg: str) -> dict:
            ...
    """

    @wraps(func)
    async def wrapper(*args, **kwargs):
        oauth_enabled = get_settings().mcp_oauth_enabled

        if not oauth_enabled:
            logger.debug(
                "OAuth disabled – skipping authorization for tool '%s'",
                func.__name__,
            )
            return await func(*args, **kwargs)

        logger.debug("Authorization check for tool '%s'", func.__name__)

        from mcp.server.auth.middleware.auth_context import get_access_token
        from mcp.server.auth.provider import AccessToken

        try:
            access_token: Optional[AccessToken] = get_access_token()

            if access_token is None:
                logger.error(
                    "No access token in context for tool '%s'", func.__name__
                )
                raise AuthorizationError("Authentication required")

            username: str = access_token.client_id or ""

            if not username or username == "unknown":
                logger.error(
                    "Invalid username in access token for tool '%s'", func.__name__
                )
                raise AuthorizationError("Invalid user credentials")

            await check_user_authorization(username)

            logger.info(
                "User '%s' authorised for tool '%s'", username, func.__name__
            )

        except (AuthorizationError, QuotaExceededError) as exc:
            logger.error(
                "Authorization failed for tool '%s': %s", func.__name__, exc
            )
            raise
        except Exception as exc:
            logger.exception(
                "Unexpected error during authorization for tool '%s'", func.__name__
            )
            raise AuthorizationError(
                f"Authorization check failed: {exc}"
            ) from exc

        return await func(*args, **kwargs)

    return wrapper
