"""
OAuth Configuration

Loads MCP_OAUTH_* environment variables into a validated Pydantic model.
The result is cached so the configuration is only resolved once per process.
"""

import logging
from functools import lru_cache
from typing import List, Optional

from pydantic import BaseModel, Field, ValidationError

from config import get_settings

logger = logging.getLogger(__name__)


class OAuthConfig(BaseModel):
    """
    Configuration for validating OAuth2 / OIDC JWT access tokens.

    Environment variables (all prefixed with ``MCP_OAUTH_``):

    ========================  =========  =======================================
    Variable                  Required   Description
    ========================  =========  =======================================
    MCP_OAUTH_ISSUER          yes        OIDC issuer URL
    MCP_OAUTH_AUDIENCE        yes        Expected JWT ``aud`` claim
    MCP_OAUTH_AUTH_PROVIDER   yes        Expected JWT ``azp`` claim
    MCP_OAUTH_JWKS_URL        no         Override for the JWKS endpoint URL
    MCP_OAUTH_REQUIRED_SCOPE  no         Scope that must be present in the token
    ========================  =========  =======================================
    """

    issuer: str = Field(
        ...,
        description="OIDC issuer URL, e.g. https://auth.reversinglabs.com/realms/mcp",
    )
    jwks_url: Optional[str] = Field(
        None,
        description=(
            "JWKS endpoint URL. When absent, "
            "'/protocol/openid-connect/certs' is appended to the issuer "
            "(standard Keycloak layout)."
        ),
    )
    audience: str = Field(
        ...,
        description="Expected audience (aud) claim, e.g. https://mcp.reversinglabs.com/mcp",
    )
    auth_provider: str = Field(
        ...,
        description="Expected authorised party (azp) claim, e.g. ai-assistant",
    )
    algorithms: List[str] = Field(
        default_factory=lambda: ["RS256"],
        description="Allowed JWT signing algorithms",
    )
    required_scope: Optional[str] = Field(
        None,
        description=(
            "Optional scope required for access. "
            "The JWT 'scope' claim must contain this value when set."
        ),
    )


@lru_cache(maxsize=1)
def get_oauth_config() -> OAuthConfig:
    """
    Build and cache an :class:`OAuthConfig` from environment variables.

    Raises:
        RuntimeError: If required variables are missing or the config is invalid.
    """
    s = get_settings()
    env = {
        "issuer": s.mcp_oauth_issuer,
        "audience": s.mcp_oauth_audience,
        "auth_provider": s.mcp_oauth_auth_provider,
        "jwks_url": s.mcp_oauth_jwks_url,
        "required_scope": s.mcp_oauth_required_scope,
    }

    try:
        cfg = OAuthConfig(**env)
    except ValidationError as exc:
        raise RuntimeError(f"Invalid MCP OAuth configuration: {exc}") from exc

    # Derive the standard Keycloak JWKS URL if not explicitly configured
    if not cfg.jwks_url:
        cfg.jwks_url = (
            cfg.issuer.rstrip("/") + "/protocol/openid-connect/certs"
        )
        logger.debug("Derived JWKS URL: %s", cfg.jwks_url)

    logger.info(
        "OAuth config loaded – issuer=%s, audience=%s, auth_provider=%s",
        cfg.issuer,
        cfg.audience,
        cfg.auth_provider,
    )
    return cfg
