"""OAuth support package for the MCP server."""
