"""
Keycloak JWT Token Verifier for FastMCP

Implements FastMCP's ``TokenVerifier`` interface using RS256 JWTs issued by
Keycloak.  Instantiate and pass to ``FastMCP`` when ``MCP_OAUTH_ENABLED=true``.

JWKS keys are cached for five minutes to handle key rotation gracefully without
hammering the identity provider on every request.
"""

import logging
import time
from typing import Optional

import httpx
import jwt
from jwt import PyJWKClient

from mcp.server.auth.provider import AccessToken, TokenVerifier

from .oauth_config import get_oauth_config

logger = logging.getLogger(__name__)

_JWKS_CACHE_TTL_SECONDS = 300  # 5 minutes


class KeycloakTokenVerifier(TokenVerifier):
    """
    Concrete :class:`TokenVerifier` that validates RS256 JWTs from Keycloak.

    Validation steps:

    1. Decode the token without signature verification to log basic claims for
       debugging.
    2. Fetch (and cache) the JWKS from the identity provider.
    3. Verify signature, expiry, issuer, and audience.
    4. Enforce the ``azp`` (authorised party) claim.
    5. Optionally enforce a required scope.
    6. Return an :class:`AccessToken` whose ``client_id`` is set to the
       ``preferred_username`` from the token.
    """

    def __init__(self) -> None:
        self._cfg = get_oauth_config()
        self._discovery_url = f"{self._cfg.issuer}/.well-known/openid-configuration"
        self._jwks_uri: Optional[str] = None
        self._jwks: Optional[dict] = None
        self._jwks_fetched_at: float = 0.0
        self._jwks_client = PyJWKClient(self._cfg.jwks_url)
        logger.debug(
            "KeycloakTokenVerifier initialised – issuer=%s, jwks_url=%s",
            self._cfg.issuer,
            self._cfg.jwks_url,
        )

    # ------------------------------------------------------------------ #
    # Private helpers                                                       #
    # ------------------------------------------------------------------ #

    async def _load_jwks(self) -> dict:
        """Return cached JWKS, refreshing if the cache has expired."""
        now = time.time()
        if self._jwks and (now - self._jwks_fetched_at) < _JWKS_CACHE_TTL_SECONDS:
            return self._jwks

        async with httpx.AsyncClient(timeout=5.0) as client:
            if not self._jwks_uri:
                logger.debug("Fetching OIDC discovery document: %s", self._discovery_url)
                discovery_resp = await client.get(self._discovery_url)
                discovery_resp.raise_for_status()
                self._jwks_uri = discovery_resp.json()["jwks_uri"]
                logger.debug("Resolved JWKS URI: %s", self._jwks_uri)

            logger.debug("Refreshing JWKS from %s", self._jwks_uri)
            jwks_resp = await client.get(self._jwks_uri)
            jwks_resp.raise_for_status()
            self._jwks = jwks_resp.json()
            self._jwks_fetched_at = now

        return self._jwks

    # ------------------------------------------------------------------ #
    # TokenVerifier interface                                               #
    # ------------------------------------------------------------------ #

    async def verify_token(self, token: str) -> Optional[AccessToken]:
        """
        Validate *token* and return an :class:`AccessToken` on success.

        Returns ``None`` on any validation failure; FastMCP interprets this as
        an unauthenticated request.
        """
        try:
            # ---- Step 1: peek at claims without signature check (debug only) ----
            unverified = jwt.decode(token, options={"verify_signature": False})
            logger.debug(
                "Unverified token claims – iss=%s, aud=%s, azp=%s, exp=%s (now=%s)",
                unverified.get("iss"),
                unverified.get("aud"),
                unverified.get("azp"),
                unverified.get("exp"),
                int(time.time()),
            )

            # ---- Step 2: ensure JWKS is available ----
            await self._load_jwks()

            # ---- Step 3: full verification ----
            logger.debug(
                "Verifying token – expected issuer=%s, audience=%s, auth_provider=%s",
                self._cfg.issuer,
                self._cfg.audience,
                self._cfg.auth_provider,
            )
            signing_key = self._jwks_client.get_signing_key_from_jwt(token).key
            claims = jwt.decode(
                token,
                signing_key,
                algorithms=self._cfg.algorithms,
                issuer=self._cfg.issuer,
                audience=self._cfg.audience,
                leeway=60,  # tolerate up to 60 s of clock skew
                options={
                    "verify_signature": True,
                    "verify_exp": True,
                    "verify_iss": True,
                    "verify_aud": True,
                },
            )

            logger.debug(
                "Verified token claims – iss=%s, aud=%s, azp=%s, scope=%s, "
                "preferred_username=%s",
                claims.get("iss"),
                claims.get("aud"),
                claims.get("azp"),
                claims.get("scope"),
                claims.get("preferred_username"),
            )

            # ---- Step 4: authorised party check ----
            if claims.get("azp") != self._cfg.auth_provider:
                logger.error(
                    "Token azp '%s' does not match expected '%s'",
                    claims.get("azp"),
                    self._cfg.auth_provider,
                )
                return None

            # ---- Step 5: optional scope check ----
            scopes: list[str] = []
            scope_str = claims.get("scope")
            if isinstance(scope_str, str):
                scopes = scope_str.split()

            if self._cfg.required_scope and self._cfg.required_scope not in scopes:
                logger.error(
                    "Token missing required scope '%s'",
                    self._cfg.required_scope,
                )
                return None

            # ---- Step 6: build AccessToken ----
            subject = claims.get("preferred_username") or "unknown"
            exp = claims.get("exp")
            expires_at = int(exp) if isinstance(exp, int) else int(time.time()) + 300

            logger.info("Token verified for user '%s'", subject)
            return AccessToken(
                token=token,
                client_id=subject,
                scopes=scopes,
                expires_at=expires_at,
            )

        except Exception:
            logger.exception("JWT verification failed")
            return None
