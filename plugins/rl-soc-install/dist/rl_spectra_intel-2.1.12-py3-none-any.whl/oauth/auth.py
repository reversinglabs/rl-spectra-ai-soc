"""
FastAPI OAuth Utilities

Provides reusable FastAPI dependencies for token validation and per-endpoint
scope enforcement.  These are useful for any additional HTTP endpoints exposed
alongside the main MCP server (e.g. admin or webhook routes).

For MCP tool-level authorisation see :mod:`core.user_authorization`.
"""

from __future__ import annotations

import logging
from typing import Any, Callable, Dict, Optional

from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
import jwt
from jwt import PyJWKClient

from .config import OAuthConfig, get_oauth_config

logger = logging.getLogger(__name__)

_security = HTTPBearer(auto_error=True)

# Module-level JWKS client cache – one instance per process is sufficient for
# typical single-threaded / async FastAPI usage.
_jwks_client: Optional[PyJWKClient] = None


def _get_jwks_client(config: OAuthConfig) -> PyJWKClient:
    global _jwks_client
    if _jwks_client is None:
        logger.debug("Creating JWKS client for %s", config.jwks_url)
        _jwks_client = PyJWKClient(str(config.jwks_url))
    return _jwks_client


class Principal(Dict[str, Any]):
    """
    Thin wrapper around the decoded JWT claims dictionary.

    Replace with a Pydantic model if stricter typing is required.
    """


def _check_scope(claims: Dict[str, Any], required_scope: Optional[str]) -> None:
    """Raise HTTP 403 when *required_scope* is not present in the token."""
    if not required_scope:
        return

    scopes_val = claims.get("scope")
    if not scopes_val:
        logger.warning("Token is missing 'scope' claim; required: %s", required_scope)
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Missing 'scope' claim in token",
        )

    scopes = scopes_val.split() if isinstance(scopes_val, str) else list(scopes_val)

    if required_scope not in scopes:
        logger.warning(
            "Required scope '%s' not in token scopes: %s",
            required_scope,
            scopes,
        )
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=f"Required scope '{required_scope}' not granted",
        )


def get_current_principal(
    credentials: HTTPAuthorizationCredentials = Depends(_security),
) -> Principal:
    """
    FastAPI dependency that validates a Bearer token and returns its claims.

    Usage::

        from fastapi import Depends
        from oauth.auth import get_current_principal, Principal

        @app.get("/protected")
        def protected(principal: Principal = Depends(get_current_principal)):
            return {"user": principal.get("preferred_username")}

    Raises:
        HTTPException: 401 if the token is invalid or expired.
        HTTPException: 403 if the required scope (if configured) is absent.
    """
    cfg = get_oauth_config()
    token = credentials.credentials
    jwks_client = _get_jwks_client(cfg)

    try:
        signing_key = jwks_client.get_signing_key_from_jwt(token).key
        claims = jwt.decode(
            token,
            signing_key,
            algorithms=cfg.algorithms,
            audience=cfg.audience,
            issuer=cfg.issuer,
        )
    except Exception as exc:
        logger.warning("Bearer token validation failed: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=f"Invalid or expired token: {exc}",
        ) from exc

    _check_scope(claims, cfg.required_scope)

    logger.debug(
        "Authenticated principal: %s", claims.get("preferred_username", "unknown")
    )
    return Principal(claims)


def auth_required_with_scope(scope: str) -> Callable[..., Principal]:
    """
    Return a FastAPI dependency that enforces a specific *scope*.

    Usage::

        from oauth.auth import auth_required_with_scope

        @app.post("/admin/reload")
        def reload(principal = Depends(auth_required_with_scope("mcp.admin"))):
            ...

    Raises:
        HTTPException: 401 if the token is invalid or expired.
        HTTPException: 403 if *scope* is absent from the token.
    """

    def _dependency(
        credentials: HTTPAuthorizationCredentials = Depends(_security),
    ) -> Principal:
        cfg = get_oauth_config()
        token = credentials.credentials
        jwks_client = _get_jwks_client(cfg)

        try:
            signing_key = jwks_client.get_signing_key_from_jwt(token).key
            claims = jwt.decode(
                token,
                signing_key,
                algorithms=cfg.algorithms,
                audience=cfg.audience,
                issuer=cfg.issuer,
            )
        except Exception as exc:
            logger.warning("Bearer token validation failed: %s", exc)
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail=f"Invalid or expired token: {exc}",
            ) from exc

        _check_scope(claims, scope)
        logger.debug(
            "Scope '%s' verified for principal: %s",
            scope,
            claims.get("preferred_username", "unknown"),
        )
        return Principal(claims)

    return _dependency
