"""
Application Configuration

Reads configuration from a .env file and environment variables.
Environment variables always take precedence over .env values.
Credentials are loaded from vault-mounted files first, then from the environment.
The application aborts immediately if credentials are not found.
"""

import logging
import os
import sys
from functools import lru_cache
from pathlib import Path
from typing import Optional

from dotenv import load_dotenv

# Bootstrap logging at DEBUG so early init messages are captured.
# The level is reconfigured once Settings is fully constructed.
logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    stream=sys.stderr,
)

logger = logging.getLogger(__name__)


def _load_dotenv() -> None:
    """Load .env from the current working directory.  System env vars always take precedence."""
    env_file = Path.cwd() / ".env"
    if env_file.exists():
        # override=False ensures existing env vars are not overwritten
        load_dotenv(env_file, override=False)
        logger.debug("Loaded environment from %s", env_file)
    else:
        logger.debug(".env not found at %s – using environment variables only", env_file)


def _read_vault_secret(path: str) -> Optional[str]:
    """Return the contents of a vault-mounted secret file, or None if absent."""
    p = Path(path)
    if p.exists():
        try:
            value = p.read_text().strip()
            if value:
                logger.info("Loaded secret from vault file: %s", path)
                return value
        except Exception as exc:  # pragma: no cover
            logger.warning("Failed to read vault secret %s: %s", path, exc)
    return None


def configure_logging(level: str) -> None:
    """Reconfigure the root logger level after settings are loaded."""
    numeric = getattr(logging, level.upper(), None)
    if not isinstance(numeric, int):
        logger.warning("Invalid LOG_LEVEL '%s'; defaulting to INFO", level)
        level = "INFO"
        numeric = logging.INFO
    logging.getLogger().setLevel(numeric)
    logger.debug("Log level set to %s", level.upper())


def get_logger(name: str) -> logging.Logger:
    """Return a module-level logger."""
    return logging.getLogger(name)


class Settings:
    """
    Centralised application settings.

    Load order:
      1. .env file (lowest priority – only applied when env var is absent)
      2. Environment variables (always win)
      3. Vault-mounted secret files (highest priority for credentials only)

    The application calls ``sys.exit(1)`` immediately if ReversingLabs
    credentials cannot be resolved.
    """

    def __init__(self) -> None:
        _load_dotenv()

        # ------------------------------------------------------------------ #
        # ReversingLabs API settings                                           #
        # ------------------------------------------------------------------ #
        self.reversinglabs_host: str = os.getenv(
            "REVERSINGLABS_HOST", "data.reversinglabs.com"
        )
        self.reversinglabs_verify_ssl: bool = os.getenv(
            "REVERSINGLABS_VERIFY_SSL", "false"
        ).strip().lower() not in {"false", "0", "no"}
        self.reversinglabs_internal: bool = os.getenv(
            "REVERSINGLABS_INTERNAL", "false"
        ).strip().lower() not in {"false", "0", "no"}

        # ------------------------------------------------------------------ #
        # OAuth settings                                                       #
        # ------------------------------------------------------------------ #
        self.mcp_oauth_enabled: bool = os.getenv(
            "MCP_OAUTH_ENABLED", "True"
        ).strip().lower() not in {"false", "0", "no"}

        self.mcp_oauth_issuer: str = os.getenv(
            "MCP_OAUTH_ISSUER",
            "https://auth.reversinglabs.com/realms/mcp-spectraintelligence",
        )
        self.mcp_oauth_audience: str = os.getenv(
            "MCP_OAUTH_AUDIENCE",
            "https://mcp.reversinglabs.com/mcp",
        )
        self.mcp_oauth_auth_provider: str = os.getenv(
            "MCP_OAUTH_AUTH_PROVIDER",
            "ai-assistant",
        )
        self.mcp_oauth_resource_url: str = os.getenv(
            "MCP_OAUTH_RESOURCE_URL",
            "http://localhost:3002/mcp",
        )
        self.mcp_oauth_jwks_url: Optional[str] = os.getenv("MCP_OAUTH_JWKS_URL")
        self.mcp_oauth_required_scope: Optional[str] = os.getenv(
            "MCP_OAUTH_REQUIRED_SCOPE"
        )

        # ------------------------------------------------------------------ #
        # MCP server settings                                                  #
        # ------------------------------------------------------------------ #
        self.mcp_host: str = os.getenv("MCP_HOST", "0.0.0.0")
        self.mcp_http_port: int = int(os.getenv("MCP_HTTP_PORT", "3002"))
        self.mcp_path: str = os.getenv("MCP_PATH", "/mcp")
        self.mcp_transport: str = os.getenv("MCP_TRANSPORT", "streamable-http")
        self.mcp_health_port: int = int(os.getenv("MCP_HEALTH_PORT", "8000"))
        self.mcp_secure_host: str = os.getenv("MCP_SECURE_HOST", self.mcp_host)
        self.mcp_secure_http_port: int = int(
            os.getenv("MCP_SECURE_HTTP_PORT", str(self.mcp_http_port))
        )
        self.mcp_secure_path: str = os.getenv("MCP_SECURE_PATH", self.mcp_path)
        _allowed_hosts_raw = os.getenv(
            "MCP_ALLOWED_HOSTS", "mcp.reversinglabs.com,localhost:*"
        )
        self.mcp_allowed_hosts: list[str] = [
            h.strip() for h in _allowed_hosts_raw.split(",") if h.strip()
        ]

        # ------------------------------------------------------------------ #
        # SI client settings                                                   #
        # ------------------------------------------------------------------ #
        self.si_cache_ttl: int = int(os.getenv("SI_CACHE_TTL", "60"))
        self.si_max_sample_size_mb: int = int(os.getenv("SI_MAX_SAMPLE_SIZE_MB", "100"))

        # ------------------------------------------------------------------ #
        # GeoIP settings                                                       #
        # ------------------------------------------------------------------ #
        self.geoip_data_dir: str = os.getenv(
            "GEOIP_DATA_DIR",
            os.path.join(os.path.dirname(__file__), "data"),
        )

        # ------------------------------------------------------------------ #
        # OpenAI OAuth                                                         #
        # ------------------------------------------------------------------ #
        self.openai_domain_challenge_token: Optional[str] = os.getenv(
            "OPENAI_DOMAIN_CHALLENGE_TOKEN"
        )

        # ------------------------------------------------------------------ #
        # Logging                                                              #
        # ------------------------------------------------------------------ #
        self.log_level: str = os.getenv("LOG_LEVEL", "INFO").strip().upper()
        configure_logging(self.log_level)

        # ------------------------------------------------------------------ #
        # Credentials – vault files take precedence over environment vars     #
        # ------------------------------------------------------------------ #
        self.reversinglabs_username: Optional[str] = (
            _read_vault_secret("/vault/secrets/u_rlapi")
            or os.getenv("REVERSINGLABS_USERNAME")
        )
        self.reversinglabs_password: Optional[str] = (
            _read_vault_secret("/vault/secrets/p_rlapi")
            or os.getenv("REVERSINGLABS_PASSWORD")
        )

        self._abort_on_missing_credentials()

        logger.info(
            "Settings loaded – host=%s, verify_ssl=%s, oauth_enabled=%s, log_level=%s",
            self.reversinglabs_host,
            self.reversinglabs_verify_ssl,
            self.mcp_oauth_enabled,
            self.log_level,
        )

    def _abort_on_missing_credentials(self) -> None:
        """Exit immediately if required credentials are unavailable."""
        missing: list[str] = []
        if not self.reversinglabs_username:
            missing.append(
                "REVERSINGLABS_USERNAME  "
                "(also checked /vault/secrets/u_rlapi)"
            )
        if not self.reversinglabs_password:
            missing.append(
                "REVERSINGLABS_PASSWORD  "
                "(also checked /vault/secrets/p_rlapi)"
            )
        if missing:
            for item in missing:
                logger.critical("Missing required credential: %s", item)
            logger.critical(
                "Application cannot start without ReversingLabs credentials. Exiting."
            )
            sys.exit(1)


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """Return the application-wide Settings singleton."""
    return Settings()
