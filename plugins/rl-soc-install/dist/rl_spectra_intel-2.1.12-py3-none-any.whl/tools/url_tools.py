"""
URL / Network MCP Tools

Tools that submit URLs for analysis and return network threat intelligence
from the Spectra Intelligence API.
"""

import asyncio
import logging

from core.si_client import SpectraIntelligenceClient
from core.user_authorization import require_authorization

logger = logging.getLogger(__name__)

_POLL_INTERVAL = 5    # seconds between TCA-0403 polls
_POLL_TIMEOUT  = 600  # seconds before giving up (10 minutes)


@require_authorization
async def submit_url(
    url: str,
    analysis_type: str | None = None,
    wait_for_results: bool = False,
) -> dict:
    """
    Submit a URL to Spectra Intelligence for analysis.

    The URL is crawled one level deep. Up to 50 downloaded files (max 100 MB
    each) are classified, with updated classifications available approximately
    30 minutes after submission.

    All submitted URLs and downloaded files are treated as **public data**
    accessible to all Spectra Intelligence users.

    Submitting the same URL while a previous analysis is still in progress
    will be rejected by the API (HTTP 403 "Analysis in progress").

    Args:
        url:               The URL to analyse. The ``http://`` protocol prefix is
                           added automatically if omitted.
        analysis_type:     Controls download behaviour during analysis.
                           Omit for comprehensive analysis (default);
                           ``"light"`` to analyse only the submitted URL without
                           following links; ``"fileless"`` to analyse without
                           downloading any files.
        wait_for_results:  When ``True``, poll until the analysis completes
                           and return the full URL report (same structure as
                           ``get_network_intelligence`` for a URL). When
                           ``False`` (default), return immediately after
                           submission with ``status``, ``requested_url``, and
                           ``analysis_id``.

    Returns:
        When ``wait_for_results`` is ``False``:
            A dict with ``requested_url``, ``status``, and ``analysis_id``.

        When ``wait_for_results`` is ``True``:
            The URL report dict once the analysis completes.

    Raises:
        RuntimeError: If ``wait_for_results`` is True and the analysis does not
                      complete within ``_POLL_TIMEOUT`` seconds.
    """
    try:
        client = SpectraIntelligenceClient()
        response = await client.tca_0404_analyze_url(url, analysis_type=analysis_type)
        rl = response.get("rl")
        if rl is None:
            logger.warning("TCA-0404: missing expected attribute 'rl' in response")
            return response

        if not wait_for_results:
            return rl

        analysis_id = rl.get("analysis_id")
        if not analysis_id:
            logger.warning("submit_url: TCA-0404 missing 'rl.analysis_id' — cannot poll for results")
            raise RuntimeError("TCA-0404 did not return an analysis_id for the submitted URL.")

        logger.info(
            "submit_url: submitted '%s', analysis_id=%s — polling TCA-0403",
            url, analysis_id,
        )

        elapsed = 0
        while elapsed < _POLL_TIMEOUT:
            await asyncio.sleep(_POLL_INTERVAL)
            elapsed += _POLL_INTERVAL

            report_resp = await client.tca_0403_url_report(url, use_cache=False)
            report_rl = report_resp.get("rl")
            if report_rl is None:
                logger.warning("submit_url: TCA-0403 missing 'rl' (elapsed=%ds)", elapsed)
                continue

            for entry in (report_rl.get("analysis") or {}).get("analysis_history") or []:
                if entry.get("analysis_id") == analysis_id:
                    logger.info(
                        "submit_url: analysis_id=%s found after %ds",
                        analysis_id, elapsed,
                    )
                    return report_rl

        raise RuntimeError(
            f"URL analysis for '{url}' (analysis_id={analysis_id}) did not complete "
            f"within {_POLL_TIMEOUT} seconds."
        )
    except Exception:
        logger.exception("submit_url: unexpected error for url '%s'", url)
        raise
