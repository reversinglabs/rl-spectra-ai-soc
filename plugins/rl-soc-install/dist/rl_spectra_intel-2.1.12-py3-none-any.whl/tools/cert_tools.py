"""
Certificate Threat Intelligence MCP Tools

Tools for querying certificate reputation, analytics, and thumbprint search
from the Spectra Intelligence API.
"""

import logging

from core.si_client import SpectraIntelligenceClient
from core.user_authorization import require_authorization

logger = logging.getLogger(__name__)


@require_authorization
async def get_certificate_index(
    thumbprint: str,
    *,
    classification: str | None = None,
    extended: bool = False,
    page: str | None = None,
    limit: int = 100,
) -> dict:
    """
    Return a list of samples signed with a specific certificate.

    Args:
        thumbprint:     MD5, SHA-1, or SHA-256 thumbprint of the certificate.
        classification: Optional filter. One of: ``KNOWN``, ``SUSPICIOUS``,
                        ``MALICIOUS``, ``UNKNOWN``.
        extended:       When True, include extended sample metadata (threat
                        level, malware family, first/last seen, file size, etc.).
        page:           Pagination token from a previous response's
                        ``next_page`` field.
        limit:          Number of samples to return (1–100, default 100).

    Returns:
        A dict with:
        - ``samples``: list of sample objects, each containing hashes,
          classification, and threat data.
        - ``next_page``: pagination token (present only when more results exist).
    """
    try:
        client = SpectraIntelligenceClient()
        response = await client.tca_0501_certificate_index(
            thumbprint,
            page=page,
            limit=limit,
            extended=extended,
            classification=classification,
        )
        rl = response.get("rl")
        if rl is None:
            logger.warning("get_certificate_index: response missing 'rl'")
            return {}
        result: dict = {}
        if (samples := rl.get("samples")) is not None:
            result["samples"] = samples
        if (next_page := rl.get("next_page")) is not None:
            result["next_page"] = next_page
        return result
    except Exception:
        logger.exception(
            "get_certificate_index: unexpected error for thumbprint '%s'", thumbprint
        )
        raise


@require_authorization
async def get_certificate_analytics(thumbprints: str | list[str]) -> dict | list:
    """
    Return analytics for one or more certificate thumbprints.

    For a single thumbprint, returns a dict. For a list, returns a list of
    dicts (up to 100 thumbprints per call). Invalid thumbprints are reported
    in the ``invalid_thumbprints`` key of the response.

    Args:
        thumbprints: A single certificate thumbprint (MD5, SHA-1, or SHA-256)
                     or a list of up to 100 thumbprints.

    Returns:
        For a **single thumbprint**: a dict containing ``certificate_analytics``
        with ``statistics`` (counts by classification), ``classification``
        (status, threat_level, trust_factor), ``certificate_first_seen``, and
        the certificate chain of trust.

        For a **list**: a dict containing:
        - ``certificate_analytics``: list of analytics objects (one per thumbprint).
        - ``invalid_thumbprints``: list of thumbprints rejected by the API.

    Raises:
        ValueError: If more than 100 thumbprints are provided.
    """
    try:
        client = SpectraIntelligenceClient()

        if isinstance(thumbprints, str):
            response = await client.tca_0502_certificate_analytics(thumbprints)
            rl = response.get("rl")
            if rl is None:
                logger.warning("get_certificate_analytics: single response missing 'rl'")
                return {}
            return rl.get("certificate_analytics", {})

        # Bulk path
        response = await client.tca_0502_certificate_analytics_bulk(thumbprints)
        rl = response.get("rl")
        if rl is None:
            logger.warning("get_certificate_analytics: bulk response missing 'rl'")
            return {}
        result: dict = {
            "certificate_analytics": rl.get("certificate_analytics", []),
        }
        if invalid := rl.get("invalid_thumbprints"):
            result["invalid_thumbprints"] = invalid
        return result

    except Exception:
        logger.exception("get_certificate_analytics: unexpected error")
        raise


@require_authorization
async def search_certificate_thumbprints(
    common_name: str,
    *,
    limit: int = 100,
    page_common_name: str | None = None,
    page_thumbprint: str | None = None,
) -> dict:
    """
    Search for certificate thumbprints by common name.

    Supports wildcard ``*`` to match variable character sequences — for
    example, ``"Microsoft*"`` returns all certificates whose common name
    begins with "Microsoft".

    Args:
        common_name:        Certificate common name or partial name.
                            Use ``*`` as a wildcard (e.g. ``"*Symantec*"``).
        limit:              Number of results to return (1–100, default 100).
        page_common_name:   Pagination token from a previous response's
                            ``next_page_common_name`` field.
        page_thumbprint:    Pagination token from a previous response's
                            ``next_page_thumbprint`` field.

    Returns:
        A dict with:
        - ``search``: list of objects, each with a ``common_name`` and
          ``thumbprints`` (MD5, SHA-1, SHA-256 values).
        - ``next_page_common_name`` / ``next_page_thumbprint``: pagination
          tokens (present only when more results exist).
    """
    try:
        client = SpectraIntelligenceClient()
        response = await client.tca_0503_certificate_search(
            common_name,
            limit=limit,
            page_common_name=page_common_name,
            page_thumbprint=page_thumbprint,
        )
        rl = response.get("rl")
        if rl is None:
            logger.warning("search_certificate_thumbprints: response missing 'rl'")
            return {}
        result: dict = {
            "search": rl.get("search", []),
        }
        if (npn := rl.get("next_page_common_name")) is not None:
            result["next_page_common_name"] = npn
        if (npt := rl.get("next_page_thumbprint")) is not None:
            result["next_page_thumbprint"] = npt
        return result
    except Exception:
        logger.exception(
            "search_certificate_thumbprints: unexpected error for common_name '%s'",
            common_name,
        )
        raise
