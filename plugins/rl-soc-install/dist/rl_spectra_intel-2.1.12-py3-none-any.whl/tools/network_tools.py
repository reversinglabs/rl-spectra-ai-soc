"""
Network Threat Intelligence MCP Tools

Tools for querying URL, domain, and IP threat intelligence from the
Spectra Intelligence API.
"""

import asyncio
import ipaddress
import logging
import socket
import ssl
from datetime import datetime, timezone

from cryptography import x509
from cryptography.x509.oid import NameOID

from core.si_client import SpectraIntelligenceClient
from core.user_authorization import require_authorization

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Domain trust / exclusion sets (used by get_network_reputation)
# ---------------------------------------------------------------------------
_TRUSTED_DOMAINS = {
    "google.com", "cdn.jsdelivr.net", "cloudflare.com", "microsoft.com",
    "github.com", "akamai.net", "fastly.net",
}
_URL_SHORTENERS = {
    "bit.ly", "t.co", "tinyurl.com", "goo.gl", "ow.ly", "is.gd", "buff.ly",
}
_FILE_SHARING = {
    "drive.google.com", "docs.google.com", "dropbox.com", "sharefile.com",
    "we.tl", "mega.nz", "mediafire.com",
}
_COMMERCIAL_CAS = {
    "DigiCert Inc", "Sectigo Limited", "GlobalSign", "Amazon",
    "Baltimore CyberTrust Root", "Google Trust Services LLC", "GTS CA 1P5",
}
_FREE_CAS = {"Let's Encrypt", "Cloudflare Inc ECC CA-3"}
_TRUSTED_DNS_IPS = {
    "8.8.8.8", "8.8.4.4",           # Google
    "1.1.1.1", "1.0.0.1",           # Cloudflare
    "9.9.9.9", "149.112.112.112",   # Quad9
}


def _fetch_cert_info(hostname: str, timeout: int = 5) -> dict:
    """Retrieve TLS certificate metadata for a host. Returns {} on any failure.

    Uses CERT_NONE so the connection succeeds regardless of chain validity
    (e.g. TLS-inspecting proxies, self-signed certs on suspicious hosts).
    The raw DER bytes are parsed directly with the cryptography library.
    """
    try:
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        with socket.create_connection((hostname, 443), timeout=timeout) as sock:
            with ctx.wrap_socket(sock, server_hostname=hostname) as ssock:
                der = ssock.getpeercert(binary_form=True)
        if not der:
            return {}
        cert = x509.load_der_x509_certificate(der)

        def _cn(name: x509.Name) -> str | None:
            attrs = name.get_attributes_for_oid(NameOID.COMMON_NAME)
            return attrs[0].value if attrs else None

        def _ou(name: x509.Name) -> str:
            attrs = name.get_attributes_for_oid(NameOID.ORGANIZATIONAL_UNIT_NAME)
            return " ".join(a.value for a in attrs)

        issuer_cn  = _cn(cert.issuer)
        subject_cn = _cn(cert.subject)
        valid_to   = cert.not_valid_after_utc
        return {
            "valid_from":          cert.not_valid_before_utc.isoformat(),
            "valid_to":            valid_to.isoformat(),
            "issuer_common_name":  issuer_cn,
            "subject_common_name": subject_cn,
            "is_self_signed":      issuer_cn == subject_cn,
            "is_expired":          datetime.now(timezone.utc) > valid_to,
            "is_ev":               any(k in _ou(cert.subject).lower() for k in ("ev", "extended")),
        }
    except Exception as exc:
        logger.debug("_fetch_cert_info: failed for %s: %s", hostname, exc)
        return {}



def _classify_indicator(indicator: str) -> str:
    """Return 'url', 'ip', or 'domain' for the given network indicator."""
    if "://" in indicator:
        return "url"
    try:
        ipaddress.ip_address(indicator)
        return "ip"
    except ValueError:
        return "domain"


def _transform_url_report(rl: dict) -> None:
    """Apply field removals and renames to a TCA-0403 URL report in-place."""
    if isinstance(analysis := rl.get("analysis"), dict):
        analysis.pop("analysis_history", None)
        analysis.pop("first_analysis", None)
        analysis.pop("analysis_count", None)
        if "statistics" in analysis:
            analysis["downloaded_file_classifications"] = analysis.pop("statistics")
    if isinstance(dynamic := rl.get("dynamic_analysis"), dict):
        dynamic.pop("analysis_history", None)
    if isinstance(rep := rl.get("third_party_reputation"), dict):
        if "statistics" in rep:
            rep["reputations"] = rep.pop("statistics")


@require_authorization
async def get_network_reputation(indicator: str) -> dict:
    """
    NETWORK REPUTATION ANALYSIS
    ----------------------------
    Assess a network indicator (domain, IP, or URL) using third-party reputation
    data, GeoIP context, and live TLS certificate metadata.  Returns a compact,
    LLM-friendly result with an automated risk score.

    Analytical guidance for the model
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    1. BUSINESS CONTEXT – map ASN/org from GeoIP; spot CDN/SaaS/hosting providers.
    2. SPAM vs MALWARE – low detection-rate (<20 %) with marketing ASN → likely
       benign tracking; detection-rate >50 % or malware association → probable threat.
    3. FALSE-POSITIVE INDICATORS – legitimate large ASN, long domain age, consistent
       benign history, spam blocklist without malware samples.
    4. VERDICT CALIBRATION
       - Legitimate platform + no malware samples → BENIGN / Marketing
       - Low detections + no samples            → SUSPICIOUS / Needs verification
       - Otherwise                              → MALICIOUS / Threat infrastructure
    5. CERTIFICATE RISK – self-signed or expired raises risk; EV/commercial CA lowers
       it modestly; issuer/subject mismatch is suspicious.
    6. GEO/ASN RISK – small regional ISPs in high-risk geographies carry higher risk
       than major cloud/CDN providers.

    Args:
        indicator: Domain (``example.com``), IPv4/IPv6, or full URL
                   (``https://example.com/path``).

    Returns:
        Dict with keys: ``indicator``, ``type``, ``risk``
        (``risk_score`` 0-100, ``risk_category``, ``verdict``),
        ``third_party_reputations``, ``associated_malware``, ``first_seen``,
        ``last_seen``, ``business_context``, ``geoip`` (with DB-IP attribution),
        ``certificate``, ``llm_prompt``.
    """
    if not indicator:
        return {"error": "indicator is required"}

    indicator_type = _classify_indicator(indicator)
    domain_only = indicator.lower().split("://")[-1].split("/")[0]

    from geoip import lookup_ip as _geo_lookup

    # ------------------------------------------------------------------
    # Fan out: TCA-0407, GeoIP, and TLS cert are all independent —
    # run them concurrently.  GeoIP and cert use asyncio.to_thread so
    # their blocking I/O doesn't stall the event loop.
    # ------------------------------------------------------------------
    reputation_task = client_tca0407 = None
    client_tca0407 = SpectraIntelligenceClient()

    rep_resp, geo, cert_info = await asyncio.gather(
        client_tca0407.tca_0407_bulk_network_reputation([indicator]),
        asyncio.to_thread(_geo_lookup, indicator),
        asyncio.to_thread(_fetch_cert_info, domain_only),
        return_exceptions=True,
    )

    # ------------------------------------------------------------------
    # TCA-0407 result
    # ------------------------------------------------------------------
    entry: dict = {}
    if isinstance(rep_resp, Exception):
        logger.exception("get_network_reputation: TCA-0407 failed for '%s'", indicator, exc_info=rep_resp)
    else:
        entries = rep_resp.get("rl", {}).get("entries")
        if entries is None:
            logger.warning("get_network_reputation: missing expected attribute 'entries' in TCA-0407 response")
        elif entries:
            entry = entries[0]
        else:
            logger.debug("get_network_reputation: TCA-0407 returned empty entries for '%s'", indicator)

    # ------------------------------------------------------------------
    # GeoIP result
    # ------------------------------------------------------------------
    geoip_data: dict = {"attribution": {"name": "IP Geolocation by DB-IP", "url": "https://db-ip.com"}}
    business_context: dict = {}
    if isinstance(geo, Exception):
        logger.exception("get_network_reputation: GeoIP failed for '%s'", indicator, exc_info=geo)
    elif isinstance(geo, dict) and geo:
        geo.setdefault("attribution", {"name": "IP Geolocation by DB-IP", "url": "https://db-ip.com"})
        geoip_data = geo
        bc = {
            "owner_organization": geo.get("as_org"),
            "country_iso":        geo.get("country_iso"),
            "country_name":       geo.get("country_name"),
            "hosting_provider":   geo.get("as_org"),
        }
        business_context = {k: v for k, v in bc.items() if v}

    # ------------------------------------------------------------------
    # TLS cert result
    # ------------------------------------------------------------------
    if isinstance(cert_info, Exception):
        logger.debug("get_network_reputation: cert fetch failed for '%s': %s", domain_only, cert_info)
        cert_info = {}

    # ------------------------------------------------------------------
    # Risk score computation
    # ------------------------------------------------------------------
    rep             = entry.get("third_party_reputations") or {}
    total           = rep.get("total", 0) or 0
    malicious       = rep.get("malicious", 0) or 0
    suspicious_cnt  = rep.get("suspicious", 0) or 0
    clean_cnt       = rep.get("clean", 0) or 0
    associated_malware = bool(entry.get("associated_malware"))

    if total:
        raw_score  = (malicious * 1.0 + suspicious_cnt * 0.5 + clean_cnt * -0.2) / total
        risk_score = int(max(0.0, min(1.0, raw_score)) * 100)
    else:
        risk_score = 0

    if associated_malware and risk_score < 50:
        risk_score = min(100, risk_score + 15)

    if domain_only in _TRUSTED_DOMAINS:
        risk_score = min(risk_score, 10)
    if domain_only in _URL_SHORTENERS or domain_only in _FILE_SHARING:
        risk_score = max(risk_score, 40)
    if indicator in _TRUSTED_DNS_IPS:
        risk_score = 0
        associated_malware = False

    if cert_info:
        if cert_info.get("is_self_signed") or cert_info.get("is_expired"):
            risk_score = min(100, risk_score + 20)
        else:
            issuer_cn = cert_info.get("issuer_common_name")
            if issuer_cn in _COMMERCIAL_CAS and risk_score > 0:
                risk_score = max(0, risk_score - 5)
            elif issuer_cn in _FREE_CAS and risk_score > 0:
                risk_score = max(0, risk_score - 2)
            if cert_info.get("is_ev") and risk_score > 0:
                risk_score = max(0, risk_score - 10)

    if risk_score < 20:
        risk_category, verdict = "low",    "benign_or_marketing"
    elif risk_score < 50:
        risk_category, verdict = "medium", "suspicious"
    else:
        risk_category, verdict = "high",   "malicious"

    llm_prompt = (
        "Assess the network indicator using: certificate status (self-signed/expired, "
        "EV/commercial CA, issuer/subject anomalies); associated malware and URI statistics; "
        "geolocation/ASN and infrastructure ownership; and the third-party reputation ratio "
        "(malicious+suspicious)/total. Return a concise JSON-only conclusion with verdict, "
        "risk_score, risk_category, and top contributing factors. "
        "CRITICAL: Do NOT use VirusTotal (VT) or any VT-derived enrichment as a fallback. "
        "Exception: If the user explicitly provides a VirusTotal link/report/excerpt, you may "
        "reference it as user-provided external context only; do not perform any VT lookups. "
        "Use only fields from this response payload (no duplication): indicator, type, risk, "
        "third_party_reputations, associated_malware, first_seen, last_seen, business_context, "
        "geoip, certificate."
    )

    return {
        "indicator":               indicator,
        "type":                    indicator_type,
        "risk":                    {"risk_score": risk_score, "risk_category": risk_category, "verdict": verdict},
        "third_party_reputations": entry.get("third_party_reputations", {}),
        "associated_malware":      associated_malware,
        "first_seen":              entry.get("first_seen"),
        "last_seen":               entry.get("last_seen"),
        "business_context":        business_context,
        "geoip":                   geoip_data,
        "certificate":             cert_info,
        "llm_prompt":              llm_prompt,
    }


@require_authorization
async def get_network_intelligence(indicator: str) -> dict:
    """
    Return threat intelligence for a URL, domain, or IP address.

    The indicator type is detected automatically:
    - URLs contain ``://``
    - IP addresses (IPv4 or IPv6) are parsed via the standard library
    - Everything else is treated as a domain

    **URL**: classification, threat details, analysis history, and
    third-party reputation data.

    **Domain**: four concurrent calls returning a report (classification,
    reputation, DNS records, certificates), related domains, related URLs,
    and passive DNS resolutions.

    **IP**: three concurrent calls returning a report (classification,
    reputation, GeoIP, WHOIS), related URLs, and passive DNS resolutions.

    Args:
        indicator: A URL (``https://example.com/path``), domain
                   (``example.com``), or IP address (``1.2.3.4`` /
                   ``2001:db8::1``).

    Returns:
        For a **URL**: a dict containing ``requested_url``, ``classification``,
        ``reason``, ``threat_level``, ``threat_name``, ``categories``,
        ``last_seen``, ``analysis``, ``dynamic_analysis``, and
        ``third_party_reputations``.

        For a **domain**: a dict containing ``report``, ``related_domains``,
        ``related_urls``, and ``resolutions``.

        For an **IP**: a dict containing ``report``, ``geoip``, ``related_urls``,
        and ``resolutions``.
    """
    kind = _classify_indicator(indicator)
    client = SpectraIntelligenceClient()

    try:
        if kind == "url":
            response = await client.tca_0403_url_report(indicator)
            rl = response.get("rl")
            if rl is None:
                logger.warning("get_network_intelligence: TCA-0403 missing 'rl'")
                return {}
            _transform_url_report(rl)
            return rl

        if kind == "domain":
            report_resp, related_domains_resp, related_urls_resp, resolutions_resp = (
                await asyncio.gather(
                    client.tca_0405_domain_report(indicator),
                    client.tca_0405_domain_related_domains(indicator),
                    client.tca_0405_domain_related_urls(indicator),
                    client.tca_0405_domain_resolutions(indicator),
                    return_exceptions=True,
                )
            )

            result: dict = {}

            if isinstance(report_resp, Exception):
                logger.warning("get_network_intelligence: domain report failed for '%s': %s", indicator, report_resp)
            else:
                rl = report_resp.get("rl")
                if rl is None:
                    logger.warning("get_network_intelligence: TCA-0405 report missing 'rl'")
                else:
                    result["report"] = rl

            if isinstance(related_domains_resp, Exception):
                logger.warning("get_network_intelligence: related domains failed for '%s': %s", indicator, related_domains_resp)
            else:
                rl = related_domains_resp.get("rl")
                if rl is None:
                    logger.warning("get_network_intelligence: TCA-0405 related_domains missing 'rl'")
                else:
                    result["related_domains"] = [
                        d.get("domain") for d in rl.get("related_domains", [])
                        if d.get("domain")
                    ][:100]

            if isinstance(related_urls_resp, Exception):
                logger.warning("get_network_intelligence: related URLs failed for '%s': %s", indicator, related_urls_resp)
            else:
                rl = related_urls_resp.get("rl")
                if rl is None:
                    logger.warning("get_network_intelligence: TCA-0405 related_urls missing 'rl'")
                else:
                    result["related_urls"] = [
                        u.get("url") for u in rl.get("urls", [])
                        if u.get("url")
                    ][:500]

            if isinstance(resolutions_resp, Exception):
                logger.warning("get_network_intelligence: resolutions failed for '%s': %s", indicator, resolutions_resp)
            else:
                rl = resolutions_resp.get("rl")
                if rl is None:
                    logger.warning("get_network_intelligence: TCA-0405 resolutions missing 'rl'")
                else:
                    result["resolutions"] = rl.get("resolutions", [])[:100]

            if not result:
                raise RuntimeError(
                    f"All TCA-0405 calls failed for domain '{indicator}'. "
                    "The domain may not exist in Spectra Intelligence."
                )

            return result

        # kind == "ip"
        report_resp, related_urls_resp, resolutions_resp = await asyncio.gather(
            client.tca_0406_ip_report(indicator),
            client.tca_0406_ip_related_urls(indicator),
            client.tca_0406_ip_resolutions(indicator),
            return_exceptions=True,
        )

        result = {}

        if isinstance(report_resp, Exception):
            logger.warning("get_network_intelligence: IP report failed for '%s': %s", indicator, report_resp)
        else:
            rl = report_resp.get("rl")
            if rl is None:
                logger.warning("get_network_intelligence: TCA-0406 report missing 'rl'")
            else:
                result["report"] = rl
                if (geoip := rl.get("geoip")) is not None:
                    result["geoip"] = geoip
                else:
                    logger.warning("get_network_intelligence: TCA-0406 report missing 'rl.geoip'")

        if isinstance(related_urls_resp, Exception):
            logger.warning("get_network_intelligence: related URLs failed for '%s': %s", indicator, related_urls_resp)
        else:
            rl = related_urls_resp.get("rl")
            if rl is None:
                logger.warning("get_network_intelligence: TCA-0406 related_urls missing 'rl'")
            else:
                result["related_urls"] = [
                    u.get("url") for u in rl.get("urls", [])
                    if u.get("url")
                ][:500]

        if isinstance(resolutions_resp, Exception):
            logger.warning("get_network_intelligence: resolutions failed for '%s': %s", indicator, resolutions_resp)
        else:
            rl = resolutions_resp.get("rl")
            if rl is None:
                logger.warning("get_network_intelligence: TCA-0406 resolutions missing 'rl'")
            else:
                result["resolutions"] = rl.get("resolutions", [])[:100]

        if not result:
            raise RuntimeError(
                f"All TCA-0406 calls failed for IP '{indicator}'. "
                "The IP may not exist in Spectra Intelligence."
            )

        return result

    except Exception:
        logger.exception("get_network_intelligence: unexpected error for indicator '%s'", indicator)
        raise


@require_authorization
async def get_downloaded_files(indicator: str) -> dict:
    """
    Return SHA1 hashes of files downloaded from a URL, domain, or IP address,
    grouped by classification.

    The indicator type is detected automatically.

    - **URL**: files downloaded during URL analysis runs.
    - **Domain**: files downloaded from any URL on the domain.
    - **IP**: files downloaded from any URL hosted on the IP.

    Args:
        indicator: A URL, domain, or IP address.

    Returns:
        A dict keyed by classification (``MALICIOUS``, ``SUSPICIOUS``,
        ``KNOWN``, ``UNKNOWN``). Each value is a list of SHA1 hashes.
    """
    kind = _classify_indicator(indicator)

    try:
        client = SpectraIntelligenceClient()

        if kind == "url":
            response = await client.tca_0403_url_downloaded_files(indicator)
        elif kind == "domain":
            response = await client.tca_0405_domain_downloaded_files(indicator)
        else:
            response = await client.tca_0406_ip_downloaded_files(indicator)

        rl = response.get("rl")
        if rl is None:
            logger.warning("get_downloaded_files: response missing 'rl'")
            return {}

        files = rl.get("files")
        if files is None:
            files = rl.get("downloaded_files")  # some endpoints use 'downloaded_files' instead of 'files'
            if files is None:
                logger.warning("get_downloaded_files: response missing 'rl.files' or 'rl.downloaded_files'")
                return {}

        grouped: dict[str, list] = {}
        for file in files:
            sha1 = file.get("sha1")
            if sha1:
                classification = file.get("classification") or "UNKNOWN"
                grouped.setdefault(classification, []).append(sha1)

        return grouped
    except Exception:
        logger.exception("get_downloaded_files: unexpected error for indicator '%s'", indicator)
        raise


@require_authorization
async def bulk_network_reputation_lookup(indicators: list[str]) -> list:
    """
    Return reputation data for up to 100 URLs, domains, and/or IP addresses.
    Results are returned in the same order as the input list.

    Args:
        indicators: List of up to 100 URLs, domains, or IP addresses.
    """
    try:
        client = SpectraIntelligenceClient()
        response = await client.tca_0407_bulk_network_reputation(indicators)
        rl = response.get("rl")
        if rl is None:
            logger.warning("bulk_network_reputation_lookup: TCA-0407 missing 'rl'")
            return []

        entries = rl.get("entries")
        if not entries:
            logger.warning("bulk_network_reputation_lookup: TCA-0407 missing 'rl.entries'")
            return []

        result = []
        for entry in entries:
            item: dict = {
                "requested_network_location": entry.get("requested_network_location"),
                "first_seen": entry.get("first_seen"),
                "last_seen": entry.get("last_seen"),
                "third_party_reputations": entry.get("third_party_reputations"),
            }
            if (classification := entry.get("classification")) is not None:
                item["classification"] = classification
            result.append(item)

        return result
    except Exception:
        logger.exception("bulk_network_reputation_lookup: unexpected error")
        raise
