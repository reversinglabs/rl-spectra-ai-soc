"""MCP Prompts for ReversingLabs Spectra Intelligence."""
from typing import Dict, Any

from .prompt_registry import PROMPTS


def _get_template(name: str) -> str:
    for prompt in PROMPTS:
        if prompt["name"] == name:
            return prompt["template"]
    raise KeyError(f"Prompt template not found for {name}")


def register(mcp):
    @mcp.prompt()
    def investigate_hash(hash: str, context: str = "") -> str:
        """Start a comprehensive malware investigation for a file hash."""
        context_text = f"\n\nContext: {context}" if context else ""
        return _get_template("investigate_hash").format(hash=hash, context=context_text)

    @mcp.prompt()
    def triage_iocs(iocs: str, incident_type: str = "") -> str:
        """Triage and prioritize a list of indicators of compromise (IOCs)."""
        incident_context = f" related to a {incident_type} incident" if incident_type else ""
        return _get_template("triage_iocs").format(iocs=iocs, incident_type=incident_context)

    @mcp.prompt()
    def threat_hunt(hunt_hypothesis: str, threat_actor: str = "") -> str:
        """Start a proactive threat hunting session based on TTPs or threat intelligence."""
        actor_context = f"\n\nFocus on TTPs and IOCs associated with: {threat_actor}" if threat_actor else ""
        return _get_template("threat_hunt").format(hunt_hypothesis=hunt_hypothesis, threat_actor=actor_context)

    @mcp.prompt()
    def incident_response(incident_description: str, initial_iocs: str = "") -> str:
        """Guide through incident response workflow for a security event."""
        iocs_text = f"\n\nInitial IOCs discovered:\n{initial_iocs}" if initial_iocs else ""
        return _get_template("incident_response").format(incident_description=incident_description, initial_iocs=iocs_text)

    @mcp.prompt()
    def malware_family_analysis(malware_family: str, sample_hash: str = "") -> str:
        """Deep dive analysis of a specific malware family."""
        sample_text = f"\n\nSpecific sample to analyze: {sample_hash}" if sample_hash else ""
        return _get_template("malware_family_analysis").format(malware_family=malware_family, sample_hash=sample_text)

    @mcp.prompt()
    def campaign_tracking(campaign_name: str, known_iocs: str = "") -> str:
        """Track and analyze indicators related to a threat campaign."""
        iocs_text = f"\n\nKnown IOCs:\n{known_iocs}" if known_iocs else ""
        return _get_template("campaign_tracking").format(campaign_name=campaign_name, known_iocs=iocs_text)

    @mcp.prompt()
    def pivot_analysis(initial_indicator: str, pivot_strategy: str = "") -> str:
        """Pivot from an initial indicator to discover related threats."""
        strategy_text = f"\n\nPivot strategy: {pivot_strategy}" if pivot_strategy else ""
        return _get_template("pivot_analysis").format(initial_indicator=initial_indicator, pivot_strategy=strategy_text)

    @mcp.prompt()
    def threat_report(report_focus: str, iocs: str = "", audience: str = "technical") -> str:
        """Generate a comprehensive threat intelligence report."""
        iocs_text = f"\n\nIOCs to include:\n{iocs}" if iocs else ""
        return _get_template("threat_report").format(report_focus=report_focus, iocs=iocs_text, audience=audience)

    @mcp.prompt()
    def yara_hunt(hunt_objective: str, sample_hash: str = "") -> str:
        """Guide through YARA rule creation and retrohunt workflow for threat hunting."""
        sample_text = f"\n\nBase YARA rule on this sample: {sample_hash}" if sample_hash else ""
        return _get_template("yara_hunt").format(hunt_objective=hunt_objective, sample_hash=sample_text)
