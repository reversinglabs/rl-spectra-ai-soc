from __future__ import annotations

import ipaddress
import os
from dataclasses import asdict
from datetime import datetime, timedelta
from threading import Thread
from typing import Optional, Dict, Any

from .downloader import update_dbip_lite
from .models import EnrichmentResult
from .mmdb import MMDBChain


class GeoEnricher:
    @staticmethod
    def _default_data_dir() -> str:
        from config import get_settings
        return get_settings().geoip_data_dir

    def __init__(self, data_dir: Optional[str] = None, config: Optional[Dict[str, Any]] = None):
        if data_dir is None:
            data_dir = self._default_data_dir()
        import logging
        logger = logging.getLogger(__name__)
        
        self.data_dir = data_dir
        self.config = config or {}
        logger.info("GeoEnricher initializing with data_dir: %s", data_dir)
        
        self._check_and_update_dbs()
        
        mmdb = self.config.get("mmdb_paths", {
            "asn": ["dbip-asn-lite.mmdb"],
            "city": ["dbip-city-lite.mmdb"],
            "country": ["dbip-country-lite.mmdb"],
        })
        logger.info("Loading MMDB chains: asn=%s, city=%s, country=%s", mmdb.get("asn"), mmdb.get("city"), mmdb.get("country"))
        
        self.asn_chain = MMDBChain(self.data_dir, mmdb.get("asn", []), db_type="asn")
        self.city_chain = MMDBChain(self.data_dir, mmdb.get("city", []), db_type="city")
        self.country_chain = MMDBChain(self.data_dir, mmdb.get("country", []), db_type="country")
        
        logger.info("MMDB chains loaded: asn=%d readers, city=%d readers, country=%d readers", 
                   len(self.asn_chain.readers), len(self.city_chain.readers), len(self.country_chain.readers))

    def _check_and_update_dbs(self, age_days: int = 2):
        import logging
        logger = logging.getLogger(__name__)
        
        auto_update = str(os.environ.get("GEOIP_AUTO_UPDATE", "1")).strip()
        if auto_update in {"0", "false", "False", "no", "No"}:
            logger.warning("GeoIP auto-update disabled (GEOIP_AUTO_UPDATE=%s)", auto_update)
            return
        
        # Check all required MMDB files, not just the primary one
        required_files = {
            "city": os.path.join(self.data_dir, "dbip-city-lite.mmdb"),
            "asn": os.path.join(self.data_dir, "dbip-asn-lite.mmdb"),
            "country": os.path.join(self.data_dir, "dbip-country-lite.mmdb")
        }
        
        needs_update = False
        missing_files = []
        
        # Check if any files are missing
        for db_type, path in required_files.items():
            if not os.path.exists(path):
                logger.info("MMDB file missing: %s (type=%s), triggering download", path, db_type)
                missing_files.append(db_type)
                needs_update = True
        
        # If all files exist, check age of the primary (city) file
        if not needs_update:
            primary_db = required_files["city"]
            mtime = datetime.fromtimestamp(os.path.getmtime(primary_db))
            age = datetime.now() - mtime
            logger.info("All MMDB files exist. Primary file age: %s days", age.days)
            if age > timedelta(days=age_days):
                logger.info("MMDB files are older than %d days, triggering update", age_days)
                needs_update = True
        
        if needs_update:
            if missing_files:
                logger.info("MMDB files missing: %s. Downloading synchronously to ensure availability...", missing_files)
                # Download synchronously if files are missing to ensure they're available for initialization
                update_dbip_lite(data_dir=self.data_dir)
                logger.info("MMDB download completed")
            else:
                # Files exist but are old - update in background
                logger.info("Starting background MMDB update for data_dir: %s", self.data_dir)
                t = Thread(target=update_dbip_lite, kwargs={"data_dir": self.data_dir}, daemon=True)
                t.start()
        else:
            logger.info("MMDB files are up to date, no download needed")

    @staticmethod
    def _get(d: Dict[str, Any], path: list[str]):
        node = d
        for p in path:
            if node is None:
                return None
            node = node.get(p)
        return node

    @staticmethod
    def _get_subdivision_name(city_data: Dict[str, Any]):
        subs = city_data.get("subdivisions")
        if isinstance(subs, list) and subs:
            sub = subs[0]
            return sub.get("names", {}).get("en") or sub.get("name")
        return None
    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    def lookup(self, indicator: str) -> Optional[Dict[str, Any]]:
        """
        Lookup geoip information for an IP address, domain, or URL.
        
        Args:
            indicator: IP address, domain name, or URL
            
        Returns:
            Dict with geoip information or None if lookup fails
        """
        try:
            # Handle URLs by extracting hostname
            if "://" in indicator:
                from urllib.parse import urlparse
                parsed = urlparse(indicator)
                if parsed.hostname:
                    indicator = parsed.hostname
                else:
                    return None
            
            # Handle domain names by resolving to IP
            if not self._is_ip_address(indicator):
                ip = self._resolve_domain(indicator)
                if not ip:
                    return None
                indicator = ip
            
            # Perform geoip lookup
            import logging
            logger = logging.getLogger(__name__)
            logger.debug("Performing geoip lookup for IP: %s", indicator)
            
            result = EnrichmentResult(ip=indicator)
            
            # Try city database first for detailed info
            city_data = self.city_chain.lookup(indicator)
            if city_data:
                logger.debug("City database lookup successful for %s", indicator)
                result.country_name = self._get(city_data, ["country", "names", "en"])
                result.country_iso = self._get(city_data, ["country", "iso_code"])
                result.region = self._get_subdivision_name(city_data)
                result.city = self._get(city_data, ["city", "names", "en"])
                result.latitude = self._get(city_data, ["location", "latitude"])
                result.longitude = self._get(city_data, ["location", "longitude"])
                result.source_paths.append("city")
            else:
                logger.debug("City database lookup returned no data for %s", indicator)
            
            # Try ASN database for network info
            asn_data = self.asn_chain.lookup(indicator)
            if asn_data:
                logger.debug("ASN database lookup successful for %s: ASN=%s, Org=%s", 
                           indicator, self._get(asn_data, ["autonomous_system_number"]), 
                           self._get(asn_data, ["autonomous_system_organization"]))
                result.asn = self._get(asn_data, ["autonomous_system_number"])
                result.as_org = self._get(asn_data, ["autonomous_system_organization"])
                result.source_paths.append("asn")
            else:
                logger.debug("ASN database lookup returned no data for %s", indicator)
            
            # Fallback to country database if no city data
            if not result.country_name:
                country_data = self.country_chain.lookup(indicator)
                if country_data:
                    logger.debug("Country database lookup successful for %s", indicator)
                    result.country_name = self._get(country_data, ["country", "names", "en"])
                    result.country_iso = self._get(country_data, ["country", "iso_code"])
                    result.source_paths.append("country")
                else:
                    logger.debug("Country database lookup returned no data for %s", indicator)
            
            if result.country_name or result.city or result.asn:
                result.used_api = "maxmind_geoip2"
                logger.debug("GeoIP enrichment complete for %s: country=%s, city=%s, asn=%s", 
                           indicator, result.country_name, result.city, result.asn)
                return asdict(result)
            
            logger.debug("No geoip data found for %s in any database", indicator)
            return None
            
        except Exception as exc:
            import logging
            logger = logging.getLogger(__name__)
            logger.warning("GeoIP lookup failed for %s: %s", indicator, exc)
            return None

    def _is_ip_address(self, indicator: str) -> bool:
        """Check if the indicator is an IP address."""
        try:
            ipaddress.ip_address(indicator)
            return True
        except ValueError:
            return False

    def _resolve_domain(self, domain: str) -> Optional[str]:
        """Resolve domain to IP address."""
        try:
            import socket
            return socket.gethostbyname(domain)
        except Exception:
            return None

    def close(self):
        """Close the enricher and clean up resources."""
        # MMDBChain objects don't need explicit closing in this implementation
        pass
