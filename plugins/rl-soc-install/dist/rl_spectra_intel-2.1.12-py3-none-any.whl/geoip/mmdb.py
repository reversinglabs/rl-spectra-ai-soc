from __future__ import annotations

import os
from typing import Optional, Dict, Any, List, Tuple

from geoip2.database import Reader as MMDBReader


class MMDBChain:
    def __init__(self, base_dir: str, rel_paths: List[str], db_type: str = "city"):
        import logging
        logger = logging.getLogger(__name__)
        
        self.readers: List[MMDBReader] = []
        self.paths: List[str] = []
        self.db_type = db_type

        logger.info("Initializing MMDBChain for db_type=%s with base_dir=%s, rel_paths=%s", db_type, base_dir, rel_paths)
        
        for rel in rel_paths:
            path = os.path.join(base_dir, rel)
            if os.path.exists(path):
                try:
                    reader = MMDBReader(path)
                    self.readers.append(reader)
                    self.paths.append(path)
                    logger.debug("Successfully loaded MMDB file: %s (type=%s)", path, db_type)
                except Exception as exc:
                    logger.error("Failed to load MMDB file %s: %s", path, exc)
            else:
                logger.warning("MMDB file not found: %s (type=%s)", path, db_type)
        
        if not self.readers:
            logger.warning("No MMDB readers loaded for db_type=%s", db_type)

    def lookup(self, ip: str) -> Optional[Dict[str, Any]]:
        import logging
        logger = logging.getLogger(__name__)
        
        if not self.readers:
            logger.warning("No MMDB readers available for lookup (db_type=%s)", self.db_type)
            return None

        for idx, reader in enumerate(self.readers):
            try:
                if self.db_type == "asn":
                    response = reader.asn(ip)
                elif self.db_type == "country":
                    response = reader.country(ip)
                else:
                    response = reader.city(ip)
                result = self._response_to_dict(response)
                logger.debug("MMDB lookup successful for %s using reader %d/%d (db_type=%s, path=%s)", 
                           ip, idx+1, len(self.readers), self.db_type, self.paths[idx] if idx < len(self.paths) else "unknown")
                return result
            except Exception as exc:
                logger.debug("MMDB lookup failed for %s using reader %d/%d (db_type=%s): %s", 
                            ip, idx+1, len(self.readers), self.db_type, exc)
                continue
        
        logger.debug("No MMDB data found for %s after trying %d readers (db_type=%s)", ip, len(self.readers), self.db_type)
        return None

    def _response_to_dict(self, response) -> Dict[str, Any]:
        result: Dict[str, Any] = {}
        try:
            if hasattr(response, 'autonomous_system_number'):
                result['autonomous_system_number'] = response.autonomous_system_number
                result['autonomous_system_organization'] = response.autonomous_system_organization
            if hasattr(response, 'country'):
                result['country'] = {
                    'iso_code': response.country.iso_code,
                    'names': {'en': response.country.name}
                }
            if hasattr(response, 'city') and response.city.name:
                result['city'] = {'names': {'en': response.city.name}}
            if hasattr(response, 'subdivisions') and response.subdivisions:
                result['subdivisions'] = [
                    {'names': {'en': sub.name}} for sub in response.subdivisions
                ]
            if hasattr(response, 'location'):
                result['location'] = {
                    'latitude': response.location.latitude,
                    'longitude': response.location.longitude
                }
        except Exception:
            pass
        return result

    def close(self):
        for reader in self.readers:
            try:
                reader.close()
            except Exception:
                pass

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
