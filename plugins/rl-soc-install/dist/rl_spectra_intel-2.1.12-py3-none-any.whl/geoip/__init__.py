from __future__ import annotations

import threading
from typing import Optional, Dict, Any
import ipaddress
import socket
import logging
from urllib.parse import urlparse

logger = logging.getLogger(__name__)
_enricher_lock = threading.Lock()
_enricher = None


def get_ip_from_domain(domain_name: str) -> Optional[str]:
    """Resolve a domain name to an IPv4 address string."""
    try:
        return socket.gethostbyname(domain_name)
    except socket.gaierror:
        return None
    except Exception as exc:
        logger.warning("Failed to resolve domain %s: %s", domain_name, exc)
        return None


def get_ip_from_url(url: str) -> Optional[str]:
    """Extract hostname from a URL and resolve it to an IPv4 address string."""
    try:
        hostname = urlparse(url).hostname
        if hostname:
            return get_ip_from_domain(hostname)
        logger.warning("Could not extract hostname from URL: %s", url)
        return None
    except Exception as exc:
        logger.warning("Failed to resolve URL %s to IP: %s", url, exc)
        return None


def lookup_ip(indicator: str) -> Optional[Dict[str, Any]]:
    """
    Lookup IP geolocation information for a network indicator.
    
    Args:
        indicator: IP address, domain name, or URL
        
    Returns:
        Dict with geoip information or None if lookup fails
    """
    try:
        logger.debug("GeoIP lookup starting for indicator: %s", indicator)
        enricher = get_enricher()
        if enricher:
            result = enricher.lookup(indicator)
            if result:
                logger.debug("GeoIP lookup successful for %s: found %d fields", indicator, len(result))
            else:
                logger.debug("GeoIP lookup returned no data for %s", indicator)
            return result
        logger.warning("GeoIP enricher not available")
        return None
    except Exception as exc:
        logger.warning("GeoIP lookup failed for %s: %s", indicator, exc)
        return None


def get_enricher(data_dir: Optional[str] = None, config: Optional[Dict[str, Any]] = None):
    global _enricher
    if _enricher is None:
        with _enricher_lock:
            if _enricher is None:
                # Lazy import to avoid requiring geoip2 until actually needed
                from .enricher import GeoEnricher  # type: ignore

                from config import get_settings
                final_data_dir = data_dir or get_settings().geoip_data_dir
                logger.info("Initializing GeoIP enricher with data_dir: %s", final_data_dir)
                _enricher = GeoEnricher(data_dir=final_data_dir, config=config)
                logger.info("GeoIP enricher initialized successfully")
    return _enricher