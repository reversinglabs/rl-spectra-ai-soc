from __future__ import annotations

import gzip
import os
import shutil
from datetime import datetime
from typing import Optional
import ssl
from urllib.request import urlopen, Request
import logging


def _default_data_dir() -> str:
    from config import get_settings
    return get_settings().geoip_data_dir

DBIP_URLS = {
    "city": "https://download.db-ip.com/free/dbip-city-lite-{year}-{month:02d}.mmdb.gz",
    "asn": "https://download.db-ip.com/free/dbip-asn-lite-{year}-{month:02d}.mmdb.gz",
    "country": "https://download.db-ip.com/free/dbip-country-lite-{year}-{month:02d}.mmdb.gz"
}

logger = logging.getLogger(__name__)


def _download(url: str, out_path: str, timeout: int = 30) -> str:
    req = Request(url, headers={"User-Agent": "geoip-enrich-updater/1.0"})
    context = ssl._create_unverified_context()
    with urlopen(req, timeout=timeout, context=context) as r:
        data = r.read()
    with open(out_path, "wb") as f:
        f.write(data)
    return out_path



def _extract_gzip(gz_path: str, out_path: str) -> str:
    with gzip.open(gz_path, "rb") as f_in:
        with open(out_path, "wb") as f_out:
            shutil.copyfileobj(f_in, f_out)
    return out_path


def update_dbip_lite(
    data_dir: Optional[str] = None,
    year: Optional[int] = None,
    month: Optional[int] = None,
    timeout: int = 30,
) -> bool:
    if data_dir is None:
        data_dir = _default_data_dir()
    now = datetime.utcnow()
    y = int(year or now.year)
    m = int(month or now.month)

    logger.info("Starting DB-IP Lite MMDB update for %s-%02d in data_dir: %s", y, m, data_dir)

    try:
        os.makedirs(data_dir, exist_ok=True)
        logger.debug("Data directory created/verified: %s", data_dir)
    except Exception as exc:
        logger.error("GeoIP data dir unavailable (%s): %s", data_dir, exc)
        return False

    updated_any = False
    for kind, url_tmpl in DBIP_URLS.items():
        url = url_tmpl.format(year=y, month=m)
        gz_name = f"dbip-{kind}-lite-{y}-{m:02d}.mmdb.gz"
        gz_path = os.path.join(data_dir, gz_name)
        tmp_mmdb = os.path.join(data_dir, f".{kind}.mmdb.tmp")
        final_mmdb = os.path.join(data_dir, f"dbip-{kind}-lite.mmdb")

        logger.debug("Attempting to download %s MMDB from: %s", kind, url)
        try:
            _download(url, gz_path, timeout=timeout)
            logger.debug("Downloaded %s MMDB to: %s", kind, gz_path)
            
            _extract_gzip(gz_path, tmp_mmdb)
            logger.debug("Extracted %s MMDB to: %s", kind, tmp_mmdb)
            
            os.replace(tmp_mmdb, final_mmdb)
            logger.debug("Successfully installed %s MMDB at: %s", kind, final_mmdb)
            updated_any = True
        except Exception as exc:
            try:
                if os.path.exists(tmp_mmdb):
                    os.remove(tmp_mmdb)
            except Exception:
                pass
            logger.error("GeoIP DB-IP Lite update failed for %s: %s", kind, exc)
        finally:
            try:
                if os.path.exists(gz_path):
                    os.remove(gz_path)
            except Exception:
                pass

    if updated_any:
        logger.info("DB-IP Lite MMDB update completed successfully")
    else:
        logger.warning("DB-IP Lite MMDB update completed with no files updated")
    
    return updated_any
