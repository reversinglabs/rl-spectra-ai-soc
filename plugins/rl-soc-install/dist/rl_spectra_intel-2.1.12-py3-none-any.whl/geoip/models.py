from __future__ import annotations

import json
from dataclasses import dataclass, asdict, field
from typing import Optional, List, Dict


@dataclass
class EnrichmentResult:
    ip: str
    country_name: Optional[str] = None
    country_iso: Optional[str] = None
    region: Optional[str] = None
    city: Optional[str] = None
    latitude: Optional[float] = None
    longitude: Optional[float] = None
    asn: Optional[int] = None
    as_org: Optional[str] = None
    source_paths: List[str] = field(default_factory=list)
    used_api: Optional[str] = None
    attribution: Dict[str, str] = field(default_factory=lambda: {"name": "IP Geolocation by DB-IP", "url": "https://db-ip.com"})
    attribution_notice: str = "DB-IP Lite requires attribution. Please include \"IP Geolocation by DB-IP\" with a link to https://db-ip.com in your product documentation or UI."