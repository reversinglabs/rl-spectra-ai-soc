"""
Spectra Intelligence MCP Server

Entry point for the MCP server.  Supports two authentication modes:

* **Unauthenticated** (default): suitable for local development or trusted
  internal deployments.  Start with ``MCP_OAUTH_ENABLED=false``.
* **OAuth** (``MCP_OAUTH_ENABLED=true``): validates RS256 JWTs issued by
  Keycloak before accepting any tool call.

Transport is controlled by ``MCP_TRANSPORT`` (default: ``streamable-http``).
A lightweight health-check HTTP server is also started on ``MCP_HEALTH_PORT``
(default: 8000) for Kubernetes / load-balancer probes.
"""

import asyncio
import logging
import pathlib
import sys

import urllib3
from mcp.server.fastmcp import FastMCP
from mcp.server.auth.settings import AuthSettings
from mcp.server.transport_security import TransportSecuritySettings
from mcp.types import ToolAnnotations

# Suppress InsecureRequestWarning when SSL verification is disabled
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Settings must be imported (and therefore initialised) before anything else so
# that logging is configured and credentials are validated up front.
from config import get_settings, get_logger  # noqa: E402
from oauth.oauth_config import get_oauth_config  # noqa: E402
from oauth.verifier import KeycloakTokenVerifier  # noqa: E402

logger = get_logger(__name__)

def _read_version() -> str:
    try:
        try:
            import tomllib
        except ImportError:
            try:
                import tomli as tomllib  # type: ignore[no-reuse]
            except ImportError:
                return "unknown"
        pyproject = pathlib.Path(__file__).parent / "pyproject.toml"
        with pyproject.open("rb") as f:
            return tomllib.load(f)["project"]["version"]
    except Exception:
        return "unknown"

__version__ = _read_version()

# Elevate MCP framework log verbosity to aid debugging transport/auth issues
for _mcp_logger in ("mcp", "mcp.server", "mcp.server.streamable_http_manager"):
    try:
        logging.getLogger(_mcp_logger).setLevel(logging.DEBUG)
    except Exception:
        pass

# ------------------------------------------------------------------ #
# Server factory                                                        #
# ------------------------------------------------------------------ #

def create_mcp_server(
    *,
    token_verifier=None,
    auth: AuthSettings | None = None,
) -> FastMCP:
    """Create and configure the :class:`FastMCP` server with all tools."""
    settings = get_settings()

    mcp = FastMCP(
        "spectra-intelligence-mcp",
        token_verifier=token_verifier,
        auth=auth,
    )

    # mcp SDK 1.27 has no public API for server version;
    # version is on the underlying low-level Server object.
    # If this breaks on upgrade, check FastMCP._mcp_server.version
    mcp._mcp_server.version = __version__

    logger.info(
        "MCP server created – name=spectra-intelligence-mcp, "
        "host=%s, oauth=%s",
        settings.reversinglabs_host,
        settings.mcp_oauth_enabled,
    )

    # ------------------------------------------------------------------ #
    # Tool registration                                                     #
    # ------------------------------------------------------------------ #
    from tools.file_tools import (
        get_sample_overview,
        get_sample_indicators,
        get_sample_detection_rules,
        get_sample_ttps,
        get_sample_similarity,
        start_auxiliary_analysis,
        start_dynamic_analysis,
        get_dynamic_analysis_status,
        get_sample_behavior,
        get_sample_strings,
        get_sample_content,
        submit_file,
        advanced_search,
        bulk_file_reputation_lookup,
    )
    from tools.url_tools import (
        submit_url,
    )
    from tools.network_tools import (
        get_network_reputation,
        get_network_intelligence,
        get_downloaded_files,
        bulk_network_reputation_lookup,
    )
    from tools.yara_tools import (
        yara_hunt_start,
        yara_hunt_status_and_matches,
        yara_hunt_delete,
    )
    from mcp_extras.intelligence_tools import (
        enhanced_threat_analysis,
    )
    from tools.cert_tools import (
        get_certificate_index,
        get_certificate_analytics,
        search_certificate_thumbprints,
    )
    _read   = ToolAnnotations(readOnlyHint=True, idempotentHint=True, openWorldHint=True)
    _action = ToolAnnotations(readOnlyHint=False, destructiveHint=False, openWorldHint=True)
    _mutate = ToolAnnotations(readOnlyHint=False, destructiveHint=True, openWorldHint=True)

    # File / sample tools
    mcp.tool(annotations=_read)(get_sample_overview)
    mcp.tool(annotations=_read)(get_sample_indicators)
    mcp.tool(annotations=_read)(get_sample_detection_rules)
    mcp.tool(annotations=_read)(get_sample_ttps)
    mcp.tool(annotations=_read)(get_sample_similarity)
    mcp.tool(annotations=_action)(start_auxiliary_analysis)
    mcp.tool(annotations=_action)(start_dynamic_analysis)
    mcp.tool(annotations=_read)(get_dynamic_analysis_status)
    mcp.tool(annotations=_read)(get_sample_behavior)
    mcp.tool(annotations=_read)(get_sample_strings)
    mcp.tool(annotations=_read)(get_sample_content)
    mcp.tool(annotations=_action)(submit_file)
    mcp.tool(annotations=_read)(advanced_search)
    mcp.tool(annotations=_read)(bulk_file_reputation_lookup)

    # URL tools
    mcp.tool(annotations=_action)(submit_url)

    # Network tools
    mcp.tool(annotations=_read)(get_network_reputation)
    mcp.tool(annotations=_read)(get_network_intelligence)
    mcp.tool(annotations=_read)(get_downloaded_files)
    mcp.tool(annotations=_read)(bulk_network_reputation_lookup)

    # YARA tools
    mcp.tool(annotations=_mutate)(yara_hunt_start)
    mcp.tool(annotations=_read)(yara_hunt_status_and_matches)
    mcp.tool(annotations=_mutate)(yara_hunt_delete)

    # Intelligence tools
    mcp.tool(annotations=_read)(enhanced_threat_analysis)

    # Certificate tools
    mcp.tool(annotations=_read)(get_certificate_index)
    mcp.tool(annotations=_read)(get_certificate_analytics)
    mcp.tool(annotations=_read)(search_certificate_thumbprints)

    # Prompt templates
    from prompts.mcp_prompts import register as register_prompts
    register_prompts(mcp)

    return mcp


# ------------------------------------------------------------------ #
# Health-check server                                                   #
# ------------------------------------------------------------------ #

async def _run_health_server() -> None:
    """Run a standalone health-check HTTP server on ``MCP_HEALTH_PORT``."""
    from starlette.applications import Starlette
    from starlette.responses import JSONResponse, PlainTextResponse, Response
    from starlette.routing import Route
    import uvicorn

    async def health(request):
        return JSONResponse(
            {
                "status": "ok",
                "server": "spectra-intelligence-mcp",
            }
        )

    async def health_legacy(request):
        return PlainTextResponse("OK")

    async def openai_challenge(request):
        token = get_settings().openai_domain_challenge_token
        if not token:
            return Response(status_code=404)
        return PlainTextResponse(token)

    app = Starlette(
        routes=[
            Route("/health", health, methods=["GET"]),
            Route("/healthz", health_legacy, methods=["GET"]),
            Route("/.well-known/openai-apps-challenge", openai_challenge, methods=["GET"]),
        ]
    )

    health_port = get_settings().mcp_health_port
    logger.info("Starting health-check server on port %s", health_port)

    config = uvicorn.Config(app, host="0.0.0.0", port=health_port, log_level="warning")
    server = uvicorn.Server(config)
    await server.serve()


async def _suppress_uvicorn_access_log() -> None:
    """Quieten the uvicorn access logger after it has been initialised."""
    await asyncio.sleep(0.5)
    logging.getLogger("uvicorn.access").setLevel(logging.WARNING)


# ------------------------------------------------------------------ #
# Transport helpers                                                     #
# ------------------------------------------------------------------ #


def _apply_http_settings(srv: FastMCP, host: str, port: int, path: str) -> None:
    srv.settings.host = host
    srv.settings.port = port
    srv.settings.streamable_http_path = path


async def _run_with_health(mcp: FastMCP) -> None:
    """Start the MCP server and the health-check server concurrently."""
    s = get_settings()
    if s.mcp_transport == "stdio":
        logger.warning("STDIO transport – health-check server will not start")
        await mcp.run_stdio_async()
        return

    logger.info(
        "Starting MCP server (streamable-http) on %s:%s%s",
        s.mcp_host,
        s.mcp_http_port,
        s.mcp_path,
    )
    await asyncio.gather(
        _run_health_server(),
        mcp.run_streamable_http_async(),
        _suppress_uvicorn_access_log(),
    )


# ------------------------------------------------------------------ #
# Main entry point                                                      #
# ------------------------------------------------------------------ #

def main() -> None:
    """Configure and launch the MCP server."""
    settings = get_settings()

    logger.info(
        "Starting Spectra Intelligence MCP Server – oauth_enabled=%s, transport=%s",
        settings.mcp_oauth_enabled,
        settings.mcp_transport,
    )

    if not settings.mcp_oauth_enabled:
        # ---- Unauthenticated mode ----
        logger.warning("OAuth is DISABLED – server will accept unauthenticated requests")
        mcp = create_mcp_server()
        _apply_http_settings(mcp, settings.mcp_host, settings.mcp_http_port, settings.mcp_path)
        mcp.settings.transport_security = TransportSecuritySettings(
            enable_dns_rebinding_protection=True,
            allowed_hosts=settings.mcp_allowed_hosts,
            allowed_origins=[],
        )
        asyncio.run(_run_with_health(mcp))
        return

    # ---- OAuth mode ----
    oauth_config = get_oauth_config()

    auth_settings = AuthSettings(
        issuer_url=oauth_config.issuer,
        resource_server_url=settings.mcp_oauth_resource_url,
        required_scopes=(
            [oauth_config.required_scope] if oauth_config.required_scope else []
        ),
    )

    transport_security = TransportSecuritySettings(
        enable_dns_rebinding_protection=True,
        allowed_hosts=settings.mcp_allowed_hosts,
        allowed_origins=[],
    )

    verifier = KeycloakTokenVerifier()
    mcp = create_mcp_server(token_verifier=verifier, auth=auth_settings)
    _apply_http_settings(mcp, settings.mcp_secure_host, settings.mcp_secure_http_port, settings.mcp_secure_path)
    mcp.settings.transport_security = transport_security

    logger.info(
        "OAuth enabled – issuer=%s, secure_port=%s",
        oauth_config.issuer,
        settings.mcp_secure_http_port,
    )

    async def _run() -> None:
        await asyncio.gather(
            _run_health_server(),
            mcp.run_streamable_http_async(),
            _suppress_uvicorn_access_log(),
        )

    asyncio.run(_run())


if __name__ == "__main__":
    main()
