from __future__ import annotations

import logging
import os
from typing import Optional, Dict, Any, List, Tuple

from geoip2.database import Reader as MMDBReader

logger = logging.getLogger(__name__)


class MMDBChain:
    def __init__(self, paths: List[str], db_type: str = "city"):
        self.readers: List[MMDBReader] = []
        self.paths: List[str] = []
        self.db_type = db_type

        for path in paths:
            if not os.path.isfile(path):
                continue
            try:
                self.readers.append(MMDBReader(path))
                self.paths.append(path)
            except Exception as exc:
                logger.warning("Failed to open %s MMDB %s: %s", db_type, path, exc)

    @property
    def available(self) -> bool:
        return bool(self.readers)

    def lookup(self, ip: str) -> Tuple[Optional[Dict[str, Any]], Optional[str]]:
        for reader, path in zip(self.readers, self.paths):
            try:
                if self.db_type == "asn":
                    response = reader.asn(ip)
                elif self.db_type == "country":
                    response = reader.country(ip)
                else:
                    response = reader.city(ip)
                if response:
                    return self._response_to_dict(response), path
            except Exception:
                continue
        return None, None

    def _response_to_dict(self, response) -> Dict[str, Any]:
        result: Dict[str, Any] = {}
        try:
            if hasattr(response, 'autonomous_system_number'):
                result['autonomous_system_number'] = response.autonomous_system_number
                result['autonomous_system_organization'] = response.autonomous_system_organization
            if hasattr(response, 'country'):
                result['country'] = {
                    'iso_code': response.country.iso_code,
                    'names': {'en': response.country.name}
                }
            if hasattr(response, 'city') and response.city.name:
                result['city'] = {'names': {'en': response.city.name}}
            if hasattr(response, 'subdivisions') and response.subdivisions:
                result['subdivisions'] = [
                    {'names': {'en': sub.name}} for sub in response.subdivisions
                ]
            if hasattr(response, 'location'):
                result['location'] = {
                    'latitude': response.location.latitude,
                    'longitude': response.location.longitude
                }
        except Exception:
            pass
        return result

    def close(self):
        for reader in self.readers:
            try:
                reader.close()
            except Exception:
                pass

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
