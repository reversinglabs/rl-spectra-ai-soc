from __future__ import annotations

import ipaddress
import logging
from typing import Optional, Dict, Any

from .models import EnrichmentResult
from .mmdb import MMDBChain
from .paths import DEFAULT_FILENAMES, candidate_dirs, find_mmdb_files

logger = logging.getLogger(__name__)


class GeoEnricher:
    """Loads the DB-IP/GeoLite MMDB databases from disk and enriches IPs.

    MMDB files are searched for in these directories in this order:
      1. /usr/share/dbip-databases-free/ #where data should be on appliance
      2. /usr/share/GeoIP/ # a fall back that is being removed soon
      3. mcp_server_analyze/data/ #developer directory for where data goes 

    This is done so we do not force a user to download the mmdb files themselves and instead rely on files from the appliance or
    a developer downloads the files themselves.
    """

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        self.config = config or {}

        mmdb = self.config.get("mmdb_paths", DEFAULT_FILENAMES)

        self.asn_chain = self._open_chain("asn", mmdb.get("asn", []))
        self.city_chain = self._open_chain("city", mmdb.get("city", []))
        self.country_chain = self._open_chain("country", mmdb.get("country", []))

        missing = [
            db_type
            for db_type, chain in (
                ("asn", self.asn_chain),
                ("city", self.city_chain),
                ("country", self.country_chain),
            )
            if not chain.available
        ]
        if missing:
            logger.warning(
                "GeoIP MMDB files not found for %s (searched %s); "
                "the corresponding enrichment fields will be left empty",
                ", ".join(missing), ", ".join(candidate_dirs()),
            )

    @property
    def available(self) -> bool:
        """True when at least one MMDB database was found on disk."""
        return any(
            chain.available
            for chain in (self.asn_chain, self.city_chain, self.country_chain)
        )

    def _open_chain(self, db_type: str, filenames) -> MMDBChain:
        paths = find_mmdb_files(list(filenames or []))
        if paths:
            logger.debug("Using %s GeoIP database(s): %s", db_type, ", ".join(paths))
        return MMDBChain(paths, db_type=db_type)

    def enrich_ip(self, ip: str) -> EnrichmentResult:
        try:
            ipaddress.ip_address(ip)
        except ValueError:
            return EnrichmentResult(ip=ip)

        result = EnrichmentResult(ip=ip, source_paths=[])

        asn_data, asn_path = self.asn_chain.lookup(ip)
        if asn_data:
            result.asn = self._get(asn_data, ["autonomous_system_number"]) or self._get(asn_data, ["asn"])
            result.as_org = self._get(asn_data, ["autonomous_system_organization"]) or self._get(asn_data, ["organization"]) 
            if asn_path:
                result.source_paths.append(asn_path)

        city_data, city_path = self.city_chain.lookup(ip)
        if city_data:
            result.country_iso = self._get(city_data, ["country", "iso_code"])
            result.country_name = self._get(city_data, ["country", "names", "en"]) or self._get(city_data, ["country", "name"])
            result.region = self._get_subdivision_name(city_data)
            result.city = self._get(city_data, ["city", "names", "en"]) or self._get(city_data, ["city", "name"]) 
            loc = self._get(city_data, ["location"]) 
            if loc:
                result.latitude = loc.get("latitude")
                result.longitude = loc.get("longitude")
            if city_path:
                result.source_paths.append(city_path)

        if not result.country_iso or not result.country_name:
            ctry_data, ctry_path = self.country_chain.lookup(ip)
            if ctry_data:
                result.country_iso = result.country_iso or self._get(ctry_data, ["country", "iso_code"]) 
                result.country_name = result.country_name or self._get(ctry_data, ["country", "names", "en"]) or self._get(ctry_data, ["country", "name"]) 
                if ctry_path:
                    result.source_paths.append(ctry_path)

        return result

    @staticmethod
    def _get(d: Dict[str, Any], path: list[str]):
        node = d
        for p in path:
            if node is None:
                return None
            node = node.get(p)
        return node

    @staticmethod
    def _get_subdivision_name(city_data: Dict[str, Any]):
        subs = city_data.get("subdivisions")
        if isinstance(subs, list) and subs:
            sub = subs[0]
            return sub.get("names", {}).get("en") or sub.get("name")
        return None

    def close(self):
        self.asn_chain.close()
        self.city_chain.close()
        self.country_chain.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
