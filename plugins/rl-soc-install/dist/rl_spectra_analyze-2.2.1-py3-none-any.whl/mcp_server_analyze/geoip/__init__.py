from __future__ import annotations

import os
import threading
from typing import Optional, Dict, Any
import ipaddress
import socket
import logging
from urllib.parse import urlparse

logger = logging.getLogger(__name__)
_enricher_lock = threading.Lock()
_enricher = None


def get_ip_from_domain(domain_name: str) -> Optional[str]:
    """Resolve a domain name to an IPv4 address string."""
    try:
        return socket.gethostbyname(domain_name)
    except socket.gaierror as exc:
        logger.warning("Failed to resolve domain %s: %s", domain_name, exc)
        return None
    except Exception as exc:
        logger.warning("Failed to resolve domain %s: %s", domain_name, exc)
        return None


def get_ip_from_url(url: str) -> Optional[str]:
    """Extract hostname from a URL and resolve it to an IPv4 address string."""
    try:
        hostname = urlparse(url).hostname
        if hostname:
            return get_ip_from_domain(hostname)
        logger.warning("Could not extract hostname from URL: %s", url)
        return None
    except Exception as exc:
        logger.warning("Failed to resolve URL %s to IP: %s", url, exc)
        return None

def get_enricher(config: Optional[Dict[str, Any]] = None):
    global _enricher
    if _enricher is None:
        with _enricher_lock:
            if _enricher is None:
                # Lazy import to avoid requiring geoip2 until actually needed
                from .enricher import GeoEnricher  # type: ignore

                _enricher = GeoEnricher(config=config)
    return _enricher


def lookup_ip(ip: str) -> Dict[str, Any]:
    """
    Return GeoIP enrichment for **any network indicator**: IP address, domain name or full URL.

    Behaviour:
    1. If the input is a valid IPv4/IPv6 address it is enriched directly.
    2. If the input looks like a domain, we resolve it to an IP with
       ``socket.gethostbyname``.
    3. If the input contains a URL scheme (e.g. ``https://example.com/path``),
       we extract the hostname and resolve that to an IP.

    Invalid or unresolvable inputs return an **empty dict** so that callers
    can fall back gracefully.
    """
    try:
        enr = get_enricher()
        if not enr.available:
            logger.warning("No GeoIP databases available; skipping lookup for %s", ip)
            return {}

        ip_candidate = ip
        try:
            # Validate the IP address. Keep the canonical string representation.
            ip_candidate = str(ipaddress.ip_address(ip_candidate))
        except ValueError as err:
            logger.info("Value %s is not a direct IP address: %s", ip, err)
            resolved = get_ip_from_domain(ip_candidate) or get_ip_from_url(ip_candidate)
            if not resolved:
                return {}
            ip_candidate = resolved

        res = enr.enrich_ip(ip_candidate)
        data = res.to_dict() if hasattr(res, "to_dict") else res

        if isinstance(data, dict):
            ip_value = data.get("ip")
            if isinstance(ip_value, (ipaddress.IPv4Address, ipaddress.IPv6Address)):
                data["ip"] = str(ip_value)
        return data
    except Exception as exc:
        logger.error("lookup ip error: %s", exc)
        return {}
