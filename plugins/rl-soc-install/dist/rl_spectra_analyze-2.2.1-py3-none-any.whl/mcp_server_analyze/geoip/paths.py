from __future__ import annotations

import logging
import os
from typing import Dict, List

logger = logging.getLogger(__name__)

PACKAGE_DATA_DIR = os.path.normpath(
    os.path.join(os.path.dirname(__file__), "..", "data")
)

SYSTEM_DATA_DIR = "/usr/share/GeoIP/"
#other name for data field location 
DBIP_DATA_DIR = "/usr/share/dbip-databases-free/"
DEFAULT_FILENAMES: Dict[str, List[str]] = {
    "asn": ["dbip-asn-lite.mmdb", "GeoLite2-ASN.mmdb"],
    "country": ["dbip-country-lite.mmdb", "GeoLite2-Country.mmdb"],
    "city": ["dbip-city-lite.mmdb", "GeoLite2-City.mmdb"],
}


def candidate_dirs() -> List[str]:
    """Return the directories searched for MMDB files, in priority order."""
    dirs = [
        DBIP_DATA_DIR,
        SYSTEM_DATA_DIR,
        PACKAGE_DATA_DIR,
    ]

    seen = set()
    result = []
    for d in dirs:
        if not d:
            continue
        d = os.path.normpath(os.path.expanduser(d))
        if d not in seen:
            seen.add(d)
            result.append(d)
    return result


def find_mmdb_files(filenames: List[str]) -> List[str]:
    """Return absolute paths of the ``filenames`` that exist on disk.

    Each name is looked up across all candidate directories; the first hit
    wins. Names given as absolute paths are used as-is. Missing files are
    silently skipped so lookups degrade to empty results.
    """
    found = []
    for name in filenames:
        if os.path.isabs(name):
            if os.path.isfile(name):
                found.append(name)
            continue

        for directory in candidate_dirs():
            path = os.path.join(directory, name)
            if os.path.isfile(path):
                found.append(path)
                break
    return found
