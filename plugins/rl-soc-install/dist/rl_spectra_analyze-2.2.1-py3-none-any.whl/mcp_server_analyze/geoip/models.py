from __future__ import annotations

import json
from dataclasses import dataclass, asdict, field
from typing import Optional, List, Dict


@dataclass
class EnrichmentResult:
    ip: str
    country_name: Optional[str] = None
    country_iso: Optional[str] = None
    region: Optional[str] = None
    city: Optional[str] = None
    latitude: Optional[float] = None
    longitude: Optional[float] = None
    asn: Optional[int] = None
    as_org: Optional[str] = None
    source_paths: List[str] = field(default_factory=list)
    used_api: Optional[str] = None
    attribution: Dict[str, str] = field(default_factory=lambda: {"name": "IP Geolocation by DB-IP", "url": "https://db-ip.com"})
    attribution_notice: str = "DB-IP Lite requires attribution. Please include \"IP Geolocation by DB-IP\" with a link to https://db-ip.com in your product documentation or UI."

    def to_json(self) -> str:
        return json.dumps(asdict(self), ensure_ascii=False)

    def to_dict(self) -> dict:
        return asdict(self)

    def to_row(self) -> List[str]:
        return [
            self.ip or "",
            self.country_name or "",
            self.country_iso or "",
            self.region or "",
            self.city or "",
            "" if self.latitude is None else str(self.latitude),
            "" if self.longitude is None else str(self.longitude),
            "" if self.asn is None else str(self.asn),
            self.as_org or "",
            ";".join(self.source_paths or []),
            self.used_api or "",
            (self.attribution or {}).get("name", ""),
            (self.attribution or {}).get("url", ""),
            self.attribution_notice or ""
        ]

    @staticmethod
    def csv_headers() -> List[str]:
        return [
            "ip", "country_name", "country_iso", "region", "city",
            "latitude", "longitude", "asn", "as_org", "source_paths", "used_api",
            "attribution_name", "attribution_url", "attribution_notice"
        ]
