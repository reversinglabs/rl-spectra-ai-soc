PROMPTS = [
    {
        "name": "investigate_hash",
        "description": "Start a comprehensive malware investigation for a file hash.",
        "arguments": [
            {
                "name": "hash",
                "description": "The file hash to investigate",
                "required": True
            },
            {
                "name": "context",
                "description": "Additional context about the hash (optional)",
                "required": False
            }
        ],
        "template": "I need to investigate this file hash: {hash}{context}\n\nPlease help me conduct a comprehensive malware investigation by:\n\n1. First, get the file analysis to understand the threat level and basic classification\n2. Analyze the file's behavior, capabilities, and potential impact\n3. Identify any network IOCs (domains, IPs, URLs) associated with this file\n4. Look for similar files or variants that might be related\n5. Provide a summary of the threat including:\n   - Malware family/classification\n   - Key behaviors and capabilities\n   - Risk assessment\n   - Recommended actions\n\nUse the available ReversingLabs Spectra Analyze tools to gather this intelligence.",
    },
    {
        "name": "triage_iocs",
        "description": "Triage and prioritize a list of indicators of compromise (IOCs).",
        "arguments": [
            {
                "name": "iocs",
                "description": "The list of IOCs to triage",
                "required": True
            },
            {
                "name": "incident_type",
                "description": "The type of incident (optional)",
                "required": False
            }
        ],
        "template": "I need to triage these indicators of compromise:\n\n{iocs}{incident_type}\n\nPlease help me prioritize and analyze these IOCs by:\n\n1. Checking the reputation and threat level of each indicator using ReversingLabs Spectra Analyze\n2. Identifying which IOCs are most critical (active threats, high confidence)\n3. Grouping related IOCs (same campaign, malware family, infrastructure)\n4. For the highest priority IOCs, provide detailed threat intelligence\n5. Recommend which IOCs should be investigated first and why\n\nProvide a prioritized action plan for the security team.",
    },
    {
        "name": "threat_hunt",
        "description": "Start a proactive threat hunting session based on TTPs or threat intelligence.",
        "arguments": [
            {
                "name": "hunt_hypothesis",
                "description": "The threat hunting hypothesis",
                "required": True
            },
            {
                "name": "threat_actor",
                "description": "The threat actor (optional)",
                "required": False
            }
        ],
        "template": "I want to conduct a proactive threat hunt for: {hunt_hypothesis}{threat_actor}\n\nPlease help me design and execute this threat hunt by:\n\n1. Suggesting specific search queries to find relevant threats in the ReversingLabs database\n2. Identifying key indicators and patterns to look for\n3. Analyzing any discovered samples or IOCs\n4. Correlating findings to known threat actors or campaigns\n5. Providing actionable intelligence for detection and response\n\nGuide me through the hunting process step by step.",
    },
    {
        "name": "incident_response",
        "description": "Guide through incident response workflow for a security event.",
        "arguments": [
            {
                "name": "incident_description",
                "description": "Brief description of the security incident",
                "required": True
            },
            {
                "name": "initial_iocs",
                "description": "Any initial IOCs discovered (optional)",
                "required": False
            }
        ],
        "template": "I'm responding to a security incident: {incident_description}{initial_iocs}\n\nPlease guide me through the incident response process:\n\n1. **Triage**: Assess the severity and scope of the incident\n2. **Investigation**: Analyze any IOCs to understand the threat\n3. **Containment**: Identify what needs to be blocked or isolated\n4. **Intelligence**: Gather threat intelligence about the attack\n5. **Remediation**: Provide recommendations for cleanup and recovery\n6. **Lessons Learned**: Suggest improvements to prevent similar incidents\n\nUse ReversingLabs Spectra Analyze tools and walk me through each phase.",
    },
    {
        "name": "malware_family_analysis",
        "description": "Deep dive analysis of a specific malware family.",
        "arguments": [
            {
                "name": "malware_family",
                "description": "The name of the malware family to analyze",
                "required": True
            },
            {
                "name": "sample_hash",
                "description": "A specific sample hash to analyze (optional)",
                "required": False
            }
        ],
        "template": "I need a deep analysis of the {malware_family} malware family.{sample_hash}\n\nPlease provide comprehensive intelligence including:\n\n1. **Overview**: What is {malware_family} and what does it do?\n2. **TTPs**: Key tactics, techniques, and procedures\n3. **Samples**: Find and analyze representative samples\n4. **Network IOCs**: Associated domains, IPs, and URLs\n5. **Variants**: Different versions or variants of this family\n6. **Attribution**: Known threat actors using this malware\n7. **Detection**: How to detect and defend against {malware_family}\n8. **Trends**: Recent activity and evolution of this threat\n\nUse search and analysis tools to gather this intelligence.\n\nUse ReversingLabs Spectra Analyze tools to gather this information.",
    },
    {
        "name": "campaign_tracking",
        "description": "Track and analyze indicators related to a threat campaign.",
        "arguments": [
            {
                "name": "campaign_name",
                "description": "The name of the threat campaign to track",
                "required": True
            },
            {
                "name": "known_iocs",
                "description": "Known indicators of compromise for this campaign (optional)",
                "required": False
            }
        ],
        "template": "I'm tracking the threat campaign: {campaign_name}{known_iocs}\n\nHelp me monitor and analyze this campaign by:\n\n1. Analyzing all known IOCs associated with this campaign\n2. Searching for additional related indicators and samples\n3. Identifying the malware families and tools being used\n4. Mapping the attack infrastructure (domains, IPs, hosting)\n5. Tracking campaign evolution and new variants\n6. Assessing the current threat level and activity\n7. Providing recommendations for detection and blocking\n\nUse ReversingLabs Spectra Analyze tools to gather this information and give me a comprehensive view of this campaign's current state.",
    },
    {
        "name": "pivot_analysis",
        "description": "Pivot from an initial indicator to discover related threats.",
        "arguments": [
            {
                "name": "initial_indicator",
                "description": "The initial indicator to pivot from",
                "required": True
            },
            {
                "name": "pivot_strategy",
                "description": "The pivot strategy to use (optional)",
                "required": False
            }
        ],
        "template": "Starting from this indicator: {initial_indicator}{pivot_strategy}\n\nHelp me pivot and discover related threats by:\n\n1. Analyzing the initial indicator to understand what we're dealing with\n2. Finding similar files or related samples\n3. Identifying shared infrastructure (domains, IPs, URLs)\n4. Looking for behavioral patterns and common TTPs\n5. Discovering other indicators in the same campaign or family\n6. Building a complete picture of the threat landscape\n7. Prioritizing which pivots provide the most valuable intelligence\n\nUse ReversingLabs Spectra Analyze tools to gather this information and guide me through the pivoting process to maximize threat discovery.",
    },
    {
        "name": "threat_report",
        "description": "Generate a comprehensive threat intelligence report.",
        "arguments": [
            {
                "name": "report_focus",
                "description": "The focus of the threat report",
                "required": True
            },
            {
                "name": "iocs",
                "description": "Known IOCs to include in the report (optional)",
                "required": False
            },
            {
                "name": "audience",
                "description": "The audience for the report (optional, default: technical)",
                "required": False
            }
        ],
        "template": "I need to create a threat intelligence report focused on: {report_focus}\n\nTarget audience: {audience}{iocs}\n\nPlease help me create a comprehensive report including:\n\n1. **Executive Summary**: High-level overview of the threat\n2. **Threat Analysis**: Detailed technical analysis\n3. **IOCs**: Complete list of indicators with context\n4. **TTPs**: Tactics, techniques, and procedures observed\n5. **Impact Assessment**: Potential impact and risk level\n6. **Recommendations**: Detection, prevention, and response guidance\n7. **Attribution**: Known threat actors or campaigns (if applicable)\n8. **Timeline**: Activity timeline and trends\n\nUse ReversingLabs Spectra Analyze to gather all necessary intelligence and structure it appropriately.",
    },
    {
        "name": "yara_hunt",
        "description": "Guide through YARA rule creation and retrohunt workflow for threat hunting.",
        "arguments": [
            {
                "name": "hunt_objective",
                "description": "The objective of the YARA hunt (e.g., malware family, threat actor, specific behavior)",
                "required": True
            },
            {
                "name": "sample_hash",
                "description": "A sample hash to base the YARA rule on (optional)",
                "required": False
            }
        ],
        "template": "I want to conduct a YARA hunt for: {hunt_objective}{sample_hash}\n\nPlease guide me through the YARA hunting workflow:\n\n1. **Rule Development**:\n   - If I provided a sample hash, analyze it to identify unique characteristics\n   - Help me create effective YARA rules targeting the specific threat\n   - Ensure rules are specific enough to avoid false positives but broad enough to catch variants\n\n2. **Rule Management**:\n   - Create or update the YARA ruleset on Spectra Analyze\n   - Enable the ruleset for continuous matching\n   - Validate the rule syntax and effectiveness\n\n3. **Retrohunt Execution**:\n   - Start a local retrohunt to scan existing samples on the appliance\n   - If connected to Spectra Intelligence, consider starting a cloud retrohunt for broader coverage\n   - Monitor the retrohunt progress and status\n\n4. **Results Analysis**:\n   - Retrieve and analyze samples that matched the YARA rules\n   - Identify patterns, variants, and related threats\n   - Assess the quality of matches (true positives vs false positives)\n\n5. **Rule Refinement**:\n   - Based on results, suggest improvements to the YARA rules\n   - Iterate on the rules to improve detection accuracy\n\n6. **Actionable Intelligence**:\n   - Summarize findings and provide threat intelligence\n   - Recommend detection and response actions\n   - Suggest additional pivots or investigations\n\nUse the YARA ruleset management, retrohunt, and match retrieval tools to execute this workflow efficiently.",
    },
]
