"""MCP prompts for ReversingLabs Spectra Analyze."""

from . import mcp_prompts

__all__ = ['mcp_prompts']
