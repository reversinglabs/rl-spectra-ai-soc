# Advanced Search Extended Reference

Extended reference for tag names and file type subtypes. Consult this when a query requires a specific tag value or precise file type subtype.

## Supported Tags

**IMPORTANT**: The `tag` keyword only accepts the exact predefined values listed below. No wildcards. Do NOT invent or guess tag names.

### Generic Tags
`access-control-information`, `anonymous-email`, `cert-appendix`, `cert-bad-timestamp`, `cert-expired`, `cert-impersonate`, `cert-invalid`, `cert-malformed`, `cert-revoked`, `cert-revoked-aa-compromise`, `cert-revoked-affiliation-changed`, `cert-revoked-ca-compromise`, `cert-revoked-cert-hold`, `cert-revoked-cessation-of-operation`, `cert-revoked-key-compromise`, `cert-revoked-privilege-withdrawn`, `cert-revoked-remove-from-crl`, `cert-revoked-superseded`, `cert-revoked-unspecified`, `cert-self-signed`, `cert-signed`, `cert-signed-after-expiration`, `cert-signed-after-revocation`, `cert-untrusted`, `cert-weak-crypto`, `contains-archive`, `contains-document`, `contains-elf`, `contains-macho`, `contains-pe`, `contains-script`, `cryptocurrency`, `dde`, `desktop`, `email-outlook`, `email-pattern`, `email-thunderbird`, `encrypted`, `entropy-high`, `entropy-zero`, `exif`, `geotagging`, `guid-activex-killbit`, `im-skype`, `image-corrupt`, `image-malformed`, `image-segment-duplicate`, `image-segment-unexpected-location`, `image-segment-unknown`, `linguist`, `machine-learning`, `nsis-table-invalid-offset`, `nsis-table-invalid-size`, `ntfs-alternate-data-stream`, `obfuscated`, `probably-packed`, `overlay`, `password`, `ransomware-artifact`, `ransomware-encrypted`, `script`, `sql-query`, `ssh-key`, `stego`, `stego-compressed`, `stego-embedded`, `stego-encoded`, `stego-encrypted`, `uri-banking-website`, `uri-credentials`, `uri-deceptive-file`, `uri-domain-blacklisted`, `uri-domain-homoglyph`, `uri-domain-punycode`, `uri-domain-spoofed`, `uri-domain-typosquat`, `uri-dynamic-dns`, `uri-hostname-length`, `uri-interesting-file`, `uri-ip-address`, `uri-malicious-redirect`, `uri-malware-regex`, `uri-onion-website`, `uri-open-redirect`, `uri-path-length`, `uri-path-spoofed`, `uri-security-website`, `uri-shortened`, `uri-subdomain-count`, `uri-suspicious-path`, `uri-suspicious-port`, `uri-suspicious-query`, `uri-suspicious-tld`

### Behavior Tags
`account-settings-tamper`, `autorun`, `av-disable`, `av-impersonate`, `av-service-detect`, `av-tamper`, `backup-tamper`, `bitlocker-tamper`, `data-exfiltration`, `dns-tamper`, `dns-use`, `file-download`, `file-upload`, `firewall-tamper`, `ftp-use`, `hosts-modifier`, `impersonate-native`, `irc-use`, `log-tamper`, `netntlm-hash-leak`, `network-settings-tamper`, `nfs-tamper`, `privacy-intrusion`, `privilege-escalation`, `process-injection`, `process-termination`, `proxy`, `registry-tamper`, `security-settings-tamper`, `service-disable`, `smb-tamper`, `startup-tamper`, `storage-settings-tamper`, `storage-tamper`, `uac-bypass`, `update-disable`, `virtualization-settings-tamper`, `vpn-tamper`, `vpn-use`, `web-request`, `wmi-use`

### Application Tags
`arch-mips`, `arch-powerpc`, `arch-sparc`, `arch-x86`, `arch-x86-64`, `arch-arm-64`, `arch-arm`, `codeview`, `cui`, `gui`, `installer`, `library-ad`, `library-analytics`, `library-audio`, `library-browser`, `library-cloud`, `library-compression`, `library-crypto`, `library-database`, `library-development`, `library-driver`, `library-educational`, `library-email`, `library-entertainment`, `library-gaming`, `library-graphics`, `library-messaging`, `library-multimedia`, `library-networking`, `library-productivity`, `library-security`, `library-social`, `library-utility`, `library-virtualization`, `lolbin`, `plugin`, `protection-aslr`, `protection-dep`, `protection-ehc`, `protection-cfg`, `protection-ret`, `protection-rfg`, `protection-mpx`, `protection-xfg`, `protection-cet`, `protection-sdl`, `protection-seh`, `protection-stack`, `force-integrity`, `packed`, `rich-header`, `reproducible-build`, `sfx`, `taggant`, `tool-hacktool`, `tool-steganography`, `uefi`, `uninstaller`, `unsupported-application`, `updater`, `version-info`, `vulnerable-with-cve`, `vulnerable-without-cve`, `xbox`

### Mobile Tags
`android-cupcake`, `android-donut`, `android-eclair`, `android-froyo`, `android-gingerbread`, `android-honeycomb`, `android-ice-cream-sandwich`, `android-jelly-bean`, `android-kitkat`, `android-lollipop`, `android-marshmallow`, `android-nougat`, `android-oreo`, `android-pie`, `android-10`, `android-11`, `mobile`, `mobile-custom-permissions`, `mobile-data-access`, `mobile-deprecated`, `mobile-gps`, `mobile-infostealer`, `mobile-logging`, `mobile-settings`, `mobile-sms`, `mobile-telco`, `mobile-voicemail`

### Malware Tags
`backdoor`, `c2`, `custom-packed`, `downloader`, `keylogger`, `pos`, `ransomware`

### Packer Tags
`antidebugging`, `antidumping`, `antiemulation`, `antisandbox`, `antitracing`, `fake-signature`, `import-elimination`, `import-redirection`, `pe-compression`, `pe-encryption`, `pe-encryption-rc4`, `pe-encryption-tea`, `polymorphic`, `remove-ep`, `remove-header`, `tamper-protection`

### Browser Tags
`chrome-reference`, `chrome-tamper`, `chromium-reference`, `chromium-tamper`, `firefox-reference`, `firefox-tamper`, `internet-explorer-reference`, `internet-explorer-tamper`, `netscape-reference`, `netscape-tamper`, `opera-reference`, `opera-tamper`, `safari-reference`, `safari-tamper`

### Classification Tags
`cert-blacklisted`, `cert-whitelisted`, `cloud`, `exploit`, `graylisting`, `hierarchy-analyzer`, `image-analyzer`, `ricc`, `signature`, `antivirus`, `ng-antivirus`, `yara`

### Capability Tags
`capability-advertising`, `capability-bluetooth`, `capability-camera`, `capability-cryptography`, `capability-deprecated`, `capability-embeds`, `capability-execution`, `capability-filesystem`, `capability-identification`, `capability-microphone`, `capability-networking`, `capability-nfc`, `capability-scripting`, `capability-security`, `capability-social`, `capability-undocumented`, `capability-vpn`, `capability-wallet`

### Indicator Tags
`indicator-anomaly`, `indicator-autostart`, `indicator-behavior`, `indicator-disable`, `indicator-document`, `indicator-evasion`, `indicator-execution`, `indicator-exploit`, `indicator-family`, `indicator-file`, `indicator-flow`, `indicator-macro`, `indicator-memory`, `indicator-monitor`, `indicator-network`, `indicator-packer`, `indicator-payload`, `indicator-permissions`, `indicator-registry`, `indicator-search`, `indicator-settings`, `indicator-signature`, `indicator-steal`, `indicator-stealth`

### String Tags
`string-file`, `string-scp`, `string-callto`, `string-h323`, `string-webcal`, `string-ftp`, `string-http`, `string-https`, `string-mailto`, `string-sftp`, `string-sip`, `string-ssh`, `string-telnet`

### Compression & Crypto Tags
`compression-brotli`, `compression-bzip2`, `compression-deflate`, `compression-dicky`, `compression-gipfeli`, `compression-gzip`, `compression-inflate`, `compression-lz4`, `compression-lzfse`, `compression-lzhuf`, `compression-lzma`, `compression-ncompress42`, `compression-pithy`, `compression-pkzip`, `compression-pucrunch`, `compression-snappy`, `compression-unlzx`, `compression-unrarlib`, `compression-zip`, `compression-zlib`, `compression-zstd`, `crypto-acss`, `crypto-adler-crc32`, `crypto-base32`, `crypto-base64`, `crypto-base64url`, `crypto-bcrypt`, `crypto-bhencode`, `crypto-blake`, `crypto-blowfish`, `crypto-bmw512`, `crypto-botan`, `crypto-camellia`, `crypto-cast`, `crypto-cast256`, `crypto-clefia`, `crypto-collision`, `crypto-crc32`, `crypto-cryptlib`, `crypto-cryptopp`, `crypto-des`, `crypto-desx`, `crypto-dsa`, `crypto-ecc`, `crypto-frog`, `crypto-gnupg`, `crypto-gnutls`, `crypto-gost`, `crypto-haval`, `crypto-hmac`, `crypto-ike`, `crypto-kasumi`, `crypto-keccak`, `crypto-mars`, `crypto-md2`, `crypto-md4`, `crypto-md5`, `crypto-md5mac`, `crypto-misty1`, `crypto-misty2`, `crypto-nacl`, `crypto-nettle`, `crypto-noekeon`, `crypto-nss`, `crypto-nush`, `crypto-openbsd-base64`, `crypto-openssl`, `crypto-pbkdf2`, `crypto-pkcs`, `crypto-rawdes`, `crypto-rc2`, `crypto-rijndael`, `crypto-ripemd128`, `crypto-ripemd160`, `crypto-ripemd256`, `crypto-ripemd320`, `crypto-rsa`, `crypto-rtss`, `crypto-safer`, `crypto-salsa20`, `crypto-seed`, `crypto-serpent`, `crypto-sha1`, `crypto-sha224`, `crypto-sha256`, `crypto-sha384`, `crypto-sha512`, `crypto-shark`, `crypto-siphash`, `crypto-skein`, `crypto-skipjack`, `crypto-sms4`, `crypto-sosemanuk`, `crypto-square`, `crypto-tiger`, `crypto-tripledes`, `crypto-turing`, `crypto-twofish`, `crypto-unicorn`, `crypto-uuencode`, `crypto-wake`, `crypto-whirlpool`, `crypto-x509`, `crypto-xxencode`

### Email Tags
`email-deceptive-sender`, `email-returnpath-mismatch`, `email-replyto-mismatch`, `email-sender-mismatch`, `email-envelopefrom-mismatch`, `email-receivedtime-mismatch`, `email-spf-fail`, `email-dkim-fail`, `email-dmarc-fail`, `email-pgp`, `email-smime`, `email-attachment`, `email-deceptive-extension`, `email-body-plain`, `email-body-rtf`, `email-body-html`, `email-impersonation`, `email-signature-impersonation`, `email-urgency`, `email-sensitive-topic`, `email-hidden-text`, `email-subject-spam`, `email-subject-phishing`, `email-anonymous-provider`

### Format-Specific Tags
`html-frame`, `html-form`, `html-input`, `html-password`, `html-image`, `html-canvas`, `html-object`, `html-download`, `html-local-link`, `html-tracking`, `html-popup`, `html-wsffile`, `font-embedded`, `deceptive-link`, `platform-unix`, `platform-windows`, `quarantine-manual`, `quarantine-malicious-content`, `quarantine-threat-metadata`

### Common Tag Query Examples

```
tag:packed AND classification:malicious
tag:ransomware
tag:antisandbox AND tag:antidebugging
tag:cryptocurrency
tag:capability-execution AND tag:capability-networking
tag:email-attachment AND tag:email-subject-phishing
tag:obfuscated AND tag:script
tag:cert-expired AND tag:cert-signed
```

## Supported File Types and Subtypes

The `sampletype` keyword accepts hierarchical `Type/Subtype` values.

| **File Type** | **Subtypes** | **Example Query** |
|---------------|--------------|-------------------|
| **Binary** | None | `sampletype:Binary/None` |
| **Archive** | None | `sampletype:Archive` |
| **Text** | None, Acrobat JavaScript, ActionScript, Batch, CCPP, CoffeeScript, Common Lisp, CSS, Dart, Erlang, EBM, Groovy, Haskell, HTML, JavaScript, JScript, JSON, Lua, Makefile, OCaml, PHP, Pascal, Perl, Perl6, PowerShell, Prolog, Python, R, Ruby, Scala, Scheme, Shell, Tcl, VBA, VBS, WebExtensions JavaScript, XML | `sampletype:Text/Python` |
| **Script** | ActionScript, Ada, Assembly, AutoIt, Batch, CCPP, CSharp, Clojure, CMake, CoffeeScript, Common Lisp, CSS, D, Dart, Eiffel, Emacs Lisp, Erlang, FSharp, Factor, FORTRAN, Go, Groovy, Haskell, HTML, Java, JavaScript, LLVM, Lua, Makefile, Matlab, Nix, Objective-C, Objective-J, OCaml, Pascal, Perl, Perl6, PHP, PowerShell, Prolog, Puppet, Python, R, Ruby, Rust, Scala, Scheme, Shell, Smalltalk, Swift, Tcl, TeX, TypeScript, VBA, VBS, Verilog, VHDL, VimL, Visual Basic | `sampletype:Script/PowerShell` |
| **MZ** | None, DOS, PE16 | `sampletype:MZ/DOS` |
| **DOS** | None | `sampletype:DOS/None` |
| **PE16** | None, Exe, Dll | `sampletype:PE16/Exe` |
| **PE** | None, Exe, Dll, .Net Exe, .Net Dll, Sys, UEFI, VXD, Xbox, AutoIt, AutoHotkey | `sampletype:PE/Exe` |
| **PE+** | None, Exe, Dll, .Net Exe, .Net Dll, Sys, UEFI, VXD, Xbox, AutoIt, AutoHotkey | `sampletype:PE+/Dll` |
| **ELF32 Little** | None, Exe, SO, Relocatable, Core, Bundle | `sampletype:ELF32 Little/Exe` |
| **ELF32 Big** | None, Exe, SO, Relocatable, Core, Bundle | `sampletype:ELF32 Big/Exe` |
| **ELF64 Little** | None, Exe, SO, Relocatable, Core, Bundle | `sampletype:ELF64 Little/SO` |
| **ELF64 Big** | None, Exe, SO, Relocatable, Core, Bundle | `sampletype:ELF64 Big/Exe` |
| **MachO32 Little** | None, Exe, SO, Relocatable, Core, Bundle | `sampletype:MachO32 Little/Exe` |
| **MachO32 Big** | None, Exe, SO, Relocatable, Core, Bundle | `sampletype:MachO32 Big/Exe` |
| **MachO64 Little** | None, Exe, SO, Relocatable, Core, Bundle | `sampletype:MachO64 Little/Exe` |
| **MachO64 Big** | None, Exe, SO, Relocatable, Core, Bundle | `sampletype:MachO64 Big/Exe` |
| **DEX** | None, Exe | `sampletype:DEX/Exe` |
| **ODEX** | None, Exe | `sampletype:ODEX/Exe` |
| **Document** | None, Excel 4 | `sampletype:Document/None` |
| **Email** | None, OutlookMSG, OutlookEmbeddedMSG, MIME | `sampletype:Email/OutlookMSG` |
| **Package** | None, Docker, NuGet, Composer | `sampletype:Package/Docker` |

### Common File Type Queries

```
# Windows executables
sampletype:[PE,PE+]

# Windows DLLs
sampletype:[*Dll]

# Linux executables
sampletype:[ELF32 Little,ELF64 Little]

# macOS executables
sampletype:[MachO64 Little,MachO32 Little]

# Android
sampletype:[DEX,ODEX]

# Scripts
sampletype:[PowerShell,Python,Shell,JavaScript,VBS,Batch]

# Documents
sampletype:Document

# Archives and packages
sampletype:Archive
sampletype:Package/Docker
```
