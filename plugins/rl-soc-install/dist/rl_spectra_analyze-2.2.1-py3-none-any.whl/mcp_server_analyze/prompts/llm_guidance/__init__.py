import logging
import os

logger = logging.getLogger(__name__)

def get_llm_guidance(tool_name: str):
    """
    Get LLM guidance for a specific tool.
    
    Args:
        tool_name: Name of the tool to get guidance for
        
    Returns:
        str: The guidance text, or empty string if not found
    """
    mydir = os.path.dirname(os.path.abspath(__file__))
    
    try:
        with open(os.path.join(mydir, f'{tool_name}.md')) as f:
            guidance = f.read()
        return guidance
    except FileNotFoundError:
        logger.warning('No LLM guidance file found for tool: %s', tool_name)
        return ''
    except Exception as e:
        logger.error('Error reading LLM guidance for tool %s: %s', tool_name, e)
        return ''
