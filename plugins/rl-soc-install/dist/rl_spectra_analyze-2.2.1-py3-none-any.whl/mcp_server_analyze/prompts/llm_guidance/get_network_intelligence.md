When interpreting network threat intelligence for a URL, domain, or IP,
work through these stages:

1. CLASSIFICATION & REPUTATION
• Start with the top-level ``classification`` (URL) and the
  ``third_party_reputations`` statistics (total / malicious / undetected /
  clean) for every indicator type.
• A single malicious source among many undetected ones is weak evidence;
  multiple independent malicious sources is strong evidence.

2. THREAT ATTRIBUTION
• Review ``top_threats`` (threat_name, files_count, risk_score) to understand
  what malware families are associated with the indicator.
• ``downloaded_files_statistics`` (domain / IP) and ``analysis.statistics``
  (URL) show how many hosted/served files were malicious — a strong signal of
  active malware distribution.

3. INFRASTRUCTURE CONTEXT
• For domains, inspect ``last_dns_records`` for the resolving IPs/providers.
• For IPs, use ``resolutions`` (IP-to-domain mappings) and ``urls`` (hosted
  URLs) to pivot and understand co-hosted infrastructure. Shared hosting on a
  large provider is not itself malicious.

4. VERDICT CALIBRATION
• Malicious third-party consensus + malicious downloaded files => MALICIOUS.
• Low/isolated detections and no malicious samples => likely benign or needs
  verification.
• Consider recency: ``modified_time`` / ``analysis_time`` / ``update_time``
  indicate how fresh the intelligence is.

Do NOT use VirusTotal or any VT-derived enrichment as a fallback. Use only the
fields returned in this response payload.
