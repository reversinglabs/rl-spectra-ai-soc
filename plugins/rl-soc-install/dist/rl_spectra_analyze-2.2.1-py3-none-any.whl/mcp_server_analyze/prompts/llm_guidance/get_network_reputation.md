When evaluating a network indicator (domain, IP, or full URL) always walk
through these analytical stages:

1. BUSINESS CONTEXT IDENTIFICATION
• Map the ASN / organisation from business_context (owner_organization).
• Spot common SaaS & marketing platforms (HubSpot, Salesforce, Google).
• Recognise CDN / hosting providers (Cloudflare, Akamai, Fastly).

2. SPAM vs MALWARE DISTINCTION
• Low detection-rate <20 % with marketing ASN → likely benign tracking / spam.
• Detection-rate >50 % OR malware sample association → probable threat.
• Redirection & analytics paths ≠ C2 command paths.

3. FALSE-POSITIVE INDICATORS (track & de-risk)
• Legitimate large ASN, long domain age, consistent benign history.
• Spam block-list presence without malware samples.

4. VERDICT CALIBRATION
Use the automated risk model and explain it with evidence. Priority order:
1) Third-party + heuristics FIRST (consensus + behavior-like indicators)
   - 3+ malicious sources => MALICIOUS
   - 2+ malicious sources => at least SUSPICIOUS
   - Heuristic indicators (typosquatting/IDN, IoT malware distribution, supply-chain impersonation, etc.) can elevate risk.
2) Protocol / Geo / Certificate modifiers SECOND
   - HTTP-only infrastructure increases risk.
   - High-risk geolocation/ASN increases risk; trusted cloud/CDN may reduce risk in low-signal cases.
   - Self-signed/expired certificates increase risk.
3) Malware sample counts LAST (corroboration)
   - Malware/URI sample counts may raise the risk floor when present, but should not dominate when absent.

5. ACTIONABLE RECOMMENDATIONS
• Benign marketing: *Block if unwanted; not a security threat.*
• Suspicious: *Investigate relationship before blocking.*
• Malicious: *Block, hunt for compromise indicators.*

The tool automatically enriches GeoIP, builds a ``business_context``
section and returns a ``risk`` with a 0-100 risk score.