## Query Syntax Rules

### Basic Structure
- Use explicit `field:value` syntax for all queries
- Combine terms with Boolean operators: `AND`, `OR`, `NOT`
- Default operator between terms is `AND` if not specified
- Use parentheses for complex logic: `(A OR B) AND C`

### Wildcards
- `*` matches zero or more characters: `filename:*.exe`
- `?` matches exactly one character: `filename:test?.dll`
- **Restrictions**: Cannot use wildcards with exact-match fields (md5, sha1, sha256, imphash, tag, attack-technique, attack-tactic)

### Ranges
- Syntax: `field:[FROM TO TO]`
- Open-ended: `av-count:[5 TO *]` or `size:[* TO 1000000]`
- Dates: `firstseen:[2026-01-01T00:00:00Z TO 2026-12-31T23:59:59Z]`
- **Important**: Use `TO` (uppercase) as separator

### Quotation Marks
- Required for values with spaces: `threatname:"Win32.Trojan.Agent"`
- Required for URIs with schemes: `uri-static:"http://example.com/*"`
- Required for special characters: `mutex:"--((Mutex))--"`

## User-Friendly Modifiers

### Numbers (trailing +/-)
- `5+` means "five or more"
- `42-` means "forty-two or less"
- Supported fields: `av-count`, `filecount`, `size`, `pe-section-count`, `submissions`, `threatlevel`, `trustfactor`
- Example: `av-count:10+` (10 or more AV detections)

### Dates (period abbreviations + trailing +/-)
- Abbreviations: `h` (hours), `d` (days), `w` (weeks), `m` (months), `y` (years)
- `+` means "from N units ago to now" → equivalent to `[<N_units_ago> TO *]`
- `-` means "older than N units ago" → equivalent to `[* TO <N_units_ago>]`
- `7d+` = within the last 7 days → `[2026-03-17T... TO *]`
- `7d-` = older than 7 days → `[* TO 2026-03-17T...]`
- `1y+` = within the last year (recent); `1y-` = older than 1 year
- Supported fields: `firstseen`, `lastseen`, `lastanalysis`, `pe-timestamp`, `signer-valid-from`, `signer-valid-to`, `taggant-valid-from`, `taggant-valid-to`
- Example: `firstseen:30d+` (last 30 days), `firstseen:1y-` (older than 1 year)

### Sizes (unit abbreviations + trailing +/-)
- Units: `KB`, `MB`, `GB`, `KiB`, `MiB`, `GiB` (case-insensitive)
- `5MB+` means "five megabytes or larger"
- `13kib-` means "thirteen kibibytes or smaller"
- Only applies to `size` field
- Example: `size:[1MB TO 10MB]`

## Most Common Search Keywords

### File Identification
- **`sha1`**, **`sha256`**, **`md5`**: Exact hash lookups (no wildcards)
- **`hashes`**: Mixed hash search (bulk search)
- **`imphash`**: Import hash (PE files, no wildcards)
- **`filename`** (alias: `name`): File name with wildcards
- **`size`**: File size in bytes (supports units and ranges)

### Classification & Threat
- **`classification`** (alias: `class`): Values: `malicious`, `suspicious`, `known` (NOT `goodware`)
- **`threatname`**: ReversingLabs threat name (wildcards OK)
- **`threatlevel`**: Threat level 0-5 (higher = more dangerous)
- **`trustfactor`**: Trust factor 0-5 (higher = more trusted)
- **`av-count`** (alias: `positives`, `p`): Number of AV detections
- **`av-detection`** (alias: `engines`): AV detection name (wildcards OK)
- **`av-<vendor>`**: Specific AV vendor detection (e.g., `av-microsoft:*wannacry*`)

### Time-based
- **`firstseen`** (alias: `fs`): First seen timestamp
- **`lastseen`** (alias: `ls`): Last seen timestamp
- **`lastanalysis`** (alias: `la`): Last analysis timestamp
- **`pe-timestamp`** (alias: `pets`): PE compilation timestamp

### File Type & Format
- **`sampletype`** (alias: `filetype`, `type`, `format`): File type (e.g., `PE`, `PE+`, `ELF`, `Mach-O`, `PDF`, `APK`). For full subtype hierarchy see extended reference.
- **`filecount`**: Number of extracted files

### PE-Specific (Windows Executables)
- **`pe-company-name`**: Company name from version info
- **`pe-product-name`**: Product name from version info
- **`pe-description`**: File description
- **`pe-original-name`**: Original filename
- **`pe-import`** (alias: `imports`): Imported DLLs
- **`pe-export`** (alias: `exports`): Exported functions
- **`pe-function`**: Imported functions
- **`pe-section-name`**: Section names (e.g., `.text`, `.data`)
- **`pe-section-count`**: Number of sections
- **`pe-resource`**: Resource names
- **`pe-language`**: PE language (e.g., `english`, `russian`)
- **`pdb-path`** (alias: `pdb`): PDB debug path

### Network Indicators
- **`domain`**: Domain names (wildcards OK)
- **`ipv4`** (alias: `ip`): IPv4 addresses (wildcards OK)
- **`ipv4-static`**: Static IPv4 from file
- **`ipv4-dynamic`**: Dynamic IPv4 from sandbox
- **`ipv6`**, **`ipv6-static`**: IPv6 addresses
- **`uri`**: URLs (group keyword for uri-source, uri-static, uri-config, uri-dynamic)
- **`uri-static`**: Static URLs from file
- **`uri-dynamic`**: Dynamic URLs from sandbox
- **`uri-source`** (alias: `itw`): In-the-wild download source
- **`uri-config`** (alias: `c2`): C2 URLs from config

### Behavioral Indicators
- **`mutex`**: Mutex names (group for mutex-config, mutex-dynamic)
- **`mutex-dynamic`**: Mutexes from sandbox
- **`mutex-config`**: Mutexes from config extraction
- **`attack-technique`**: MITRE ATT&CK technique ID (e.g., `T1059.001`, no wildcards)
- **`attack-tactic`**: MITRE ATT&CK tactic ID (e.g., `TA0002`, no wildcards)
- **`indicators`**: ReversingLabs indicator IDs

### Certificate & Signing
- **`certificate`**: Group keyword for all cert fields
- **`cert-issuer-name`**: Certificate issuer name
- **`cert-issuer-org`**: Certificate issuer organization
- **`cert-subject-name`**: Certificate subject name
- **`cert-subject-org`**: Certificate subject organization
- **`cert-serial`**: Certificate serial number
- **`cert-thumbprint`**: Certificate thumbprint
- **`signer-valid-from`**, **`signer-valid-to`**: Certificate validity dates

### Document-Specific
- **`document`**: Group keyword for document metadata
- **`document-author`**: Document author
- **`document-title`**: Document title
- **`document-subject`**: Document subject
- **`document-pages`**: Number of pages
- **`document-language`**: Document language

### Android-Specific
- **`android-package`**: Android package name
- **`android-app-name`**: Android app name
- **`android-permission`**: Android permissions
- **`android-features`**: Android features

### .NET-Specific
- **`dotnet-assembly`**: .NET assembly names
- **`dotnet-module-name`**: .NET module names
- **`dotnet-type-name`**: .NET type names
- **`dotnet-method-name`**: .NET method names

### Tags & Attribution
- **`tag`**: ReversingLabs behavioral/capability tags — exact match only, no wildcards. These describe *how* a sample behaves, NOT *what* it is. Common values: `packed`, `ransomware`, `antisandbox`, `antidebugging`, `obfuscated`, `cryptocurrency`, `capability-execution`, `capability-networking`. **Do NOT use `tag:` for threat type names** (trojan, worm, spyware, etc.) — use `threatname:*trojan*` instead. For the full tag list see extended reference.
- **`tag-yara`**: YARA-based tags
- **`actor`**: Threat actor attribution
- **`vertical`**: Threat vertical (e.g., `ransomware`, `apt`, `financial`)
- **`exploit`**: CVE identifiers (e.g., `cve-2026-*`)

### Other
- **`submissions`**: Number of submissions
- **`available`** (alias: `in`, `shareable`): Sample availability (TRUE/FALSE)
- **`similar-to`**: Find similar samples by SHA1
- **`submission-analyzer`** *(local only)*: `0` = top-container (directly submitted), `1` = URL analysis result
- **`dropped-files-containers`** *(local only)*: Matches samples dropped by another sample. Use `*` to match any dropper

## Local-Only Keywords

The following keywords only work with `instance=local`. They cause errors or empty results with `instance=cloud`.

| Keyword | Description |
|---------|-------------|
| **`submission-analyzer`** | `0` = top-container (directly submitted), `1` = URL analysis result |
| **`dropped-files-containers`** | Matches samples dropped by another sample. Use `*` to match any dropper |
| **`filecount`** | Number of files extracted from the sample |
| **`processing-status`** | Current processing state on the appliance |
| **`submission-time`** | Timestamp when the sample was submitted |
| **`submission-user`** | Username who submitted the sample |
| **`tag-user`** | User-defined tags applied manually on the appliance |
| **`upload-source`** | Source from which the sample was uploaded |
| **`upload-source-tag`** | Tag associated with the upload source |
| **`upload-data`** | Additional metadata attached at upload time |

### Sample Origin Intent Mapping

| User intent | Query to use |
|-------------|--------------|
| top container / directly submitted samples | `submission-analyzer:0` |
| URL analysis samples | `submission-analyzer:1` |
| extracted files (from archives/packages) | `submissions:0` |
| dropped files (dropped by another sample) | `dropped-files-containers:*` |

## Common Pitfalls to Avoid

1. **Wrong classification value**: Use `classification:known` NOT `classification:goodware`
2. **`tag:` is not for threat types**: `tag:trojan`, `tag:worm`, `tag:spyware` are invalid — use `threatname:*trojan*` instead. `tag:` is for behavioral/capability labels only.
3. **Wildcards on exact fields**: Don't use `sha1:*dead*` (exact match only)
4. **Missing quotes**: Use `uri-static:"http://example.com"` not `uri-static:http://example.com`
5. **Wrong range syntax**: Use `[5 TO 10]` not `[5-10]` or `[5..10]`
6. **Spaces in modifiers**: Use `5+` not `5 +`
7. **NOW in dates**: `NOW` and `NOW-30DAYS` are NOT supported — use `firstseen:30d+` (last 30 days) instead
8. **Local-only keywords with cloud**: `submission-analyzer`, `dropped-files-containers`, `submission-time`, `submission-user`, `tag-user`, `upload-source`, `upload-source-tag`, `upload-data`, `processing-status` only work with `instance=local`

## Field Restrictions

### Exact-match only (no wildcards)
- `md5`, `sha1`, `sha256`, `imphash`
- `tag`, `attack-technique`, `attack-tactic`
- All `*-sha1` fields (e.g., `pe-section-sha1`)

### Wildcards allowed
- Most string fields: `filename`, `domain`, `threatname`, `pe-*`, `document-*`, etc.

### Numeric fields (support +/- modifiers and ranges)
- `av-count`, `filecount`, `size`, `pe-section-count`, `submissions`, `threatlevel`, `trustfactor`

### Date fields (support period abbreviations and +/- modifiers)
- `firstseen`, `lastseen`, `lastanalysis`, `pe-timestamp`, `signer-valid-from`, `signer-valid-to`

## Bulk Search

For searching multiple hashes at once:
```
hashes:[<sha1>, <sha256>, <md5>, ...]
```
- Maximum 10,000 unique hashes per request
- Supports only `OR` operator (no `AND` or `NOT`)

## Common Query Patterns

```
# High-confidence malware
classification:malicious AND av-count:10+

# Specific threat family
threatname:*emotet* OR threatname:*trickbot*

# Recent malware (last 30 days)
classification:malicious AND firstseen:30d+

# MITRE ATT&CK technique
attack-technique:T1059.001 AND classification:malicious

# Network infrastructure pivot
uri-config:*pastebin.com* AND classification:malicious
```

## Example Hunting Queries

```
# Ransomware (last 30 days, high detections)
vertical:ransomware AND firstseen:30d+ AND av-count:5+

# Detect obfuscated .NET malware
sampletype:PE AND dotnet-assembly:* AND tag:obfuscated

# Find dropped files from sandboxing
dropped-files-containers:* AND classification:malicious
```
