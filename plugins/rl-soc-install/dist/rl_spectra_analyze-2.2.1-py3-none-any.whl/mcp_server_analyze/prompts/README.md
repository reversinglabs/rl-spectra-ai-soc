# Prompt Engineering

This document aims to clarify the different types of prompts used (and not used) in this project. The goal is to store all prompts within this directory structure so they are easier to review and maintain. 

## About the "System Prompt" and Context Files

Every AI assistant should be provided context about its role and how to use the tools provided by the MCP Server. This is typically done via a system prompt, though it could also be done via a context file.  

The system prompt, and/or a context file, is expected to provide additional instructions that define the role & purpose of the AI assistant relative to the MCP server. These instructions can also define global behavior rules, provide high-level tool usage strategies, and specify output-format guarantees that should never be broken. It's generally acceptable to provide much more context and information in the context files than in the system prompt. The exact syntax of a context file varies by platform - for example, in Claude Desktop they are specified in Skills files; in Gemini CLI they are specified in the file GEMINI.md. 

### Roles
As mentioned, the AI assistant needs to be told what role it is expected to play. The Spectra Analyze MCP server should be able to interact with user of various roles: **threat analyst**, **incident responder**, **reverse engineer**, etc... While all of these roles have some overlap, they also have their own set of domain knowledge and expectations when it comes to tool usage, and each is expected to interact with the MCP server in their own unique way. Each role is defined in its own file, which is intended to be configured as a context file in the AI assistant. 

<div style="background-color: #e6ffe6; padding: 15px; border-left: 5px solid #4CAF50; border-radius: 5px;">
    Currently, we only support a single role - theat analyst. The context for this role is defined in roles/threat_analyst.md. Additional roles will be defined in the future.
</div>




### Configuring System Prompt and Context in the AI Assistant
Refer to the [README](../README.md) for details on configuring different clients.

## MCP Prompts
MCP prompts are a component of the MCP standard, and all MCP servers must provide a `/prompts/list` endpoint that exposes them. The official docs state:

> Prompts are designed to be **user-controlled**, meaning they are exposed from servers to clients with the intention of the user being able to explicitly select them for use.

At present, this project does not use any MCP prompts. In the future, we may use this as a mechanism to provide suggested workflows to the user and/or LLM.

## Tool Descriptions
Tool descriptions are documentation about each tool that is provided to the AI client.  The current project extracts the doc string for each tool's function and transmits that to the client as the tool's description. Even though the AI assistant will read these tool descriptions, it is also recommended that tool documentation be include in the system prompt or context files so that the LLM has full knowledge about them throughout the chat session.


## LLM Guidance

LLM Guidance here refers to instructions embedded directly in the response from the MCP tool. The guidance can vary depending on the user's role, even for tool output that is otherwise identical. For general purpose AI assistants, (e.g. Claude Desktop and Gemini cli), LLM guidance needs be included directly in the MCP tool output. For custom-built applications (e.g. a chatbot on Analyze), an intermediary such as an orchestration layer can inject the LLM guidance into the response before sending it to the LLM. To keep things flexible, we separate the LLM guidance from the code that creates MCP tool output, and store them in the llm_guidance directory. In the actual MCP tool output, this guidance (when present) can be found in the `llm_prompt` attribute.

