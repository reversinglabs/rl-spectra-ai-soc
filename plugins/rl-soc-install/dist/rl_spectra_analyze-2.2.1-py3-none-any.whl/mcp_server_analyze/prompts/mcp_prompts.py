"""MCP Prompts for ReversingLabs Spectra Analyze.

Prompts are defined in :mod:`prompt_registry` and consumed here so that
the MCP server and Claude Desktop manifest share a single source of truth.
"""
import logging
from typing import Dict, Any

from .prompt_registry import PROMPTS

logger = logging.getLogger(__name__)


def register(mcp):
    def _text_from_result(result: Dict[str, Any]) -> str:
        if result and "messages" in result and len(result["messages"]) > 0:
            return result["messages"][0]["content"]["text"]
        return ""

    @mcp.prompt()
    def investigate_hash(hash: str, context: str = "") -> str:
        """Start a comprehensive malware investigation for a file hash."""
        return _text_from_result(_generate_investigate_hash_prompt({"hash": hash, "context": context}))

    @mcp.prompt()
    def triage_iocs(iocs: str, incident_type: str = "") -> str:
        """Triage and prioritize a list of indicators of compromise (IOCs)."""
        return _text_from_result(_generate_triage_iocs_prompt({"iocs": iocs, "incident_type": incident_type}))

    @mcp.prompt()
    def threat_hunt(hunt_hypothesis: str, threat_actor: str = "") -> str:
        """Start a proactive threat hunting session based on TTPs or threat intelligence."""
        return _text_from_result(_generate_threat_hunt_prompt({"hunt_hypothesis": hunt_hypothesis, "threat_actor": threat_actor}))

    @mcp.prompt()
    def incident_response(incident_description: str, initial_iocs: str = "") -> str:
        """Guide through incident response workflow for a security event."""
        return _text_from_result(
            _generate_incident_response_prompt({"incident_description": incident_description, "initial_iocs": initial_iocs})
        )

    @mcp.prompt()
    def malware_family_analysis(malware_family: str, sample_hash: str = "") -> str:
        """Deep dive analysis of a specific malware family."""
        return _text_from_result(
            _generate_malware_family_prompt({"malware_family": malware_family, "sample_hash": sample_hash})
        )

    @mcp.prompt()
    def campaign_tracking(campaign_name: str, known_iocs: str = "") -> str:
        """Track and analyze indicators related to a threat campaign."""
        return _text_from_result(_generate_campaign_tracking_prompt({"campaign_name": campaign_name, "known_iocs": known_iocs}))

    @mcp.prompt()
    def pivot_analysis(initial_indicator: str, pivot_strategy: str = "") -> str:
        """Pivot from an initial indicator to discover related threats."""
        return _text_from_result(
            _generate_pivot_analysis_prompt({"initial_indicator": initial_indicator, "pivot_strategy": pivot_strategy})
        )

    @mcp.prompt()
    def threat_report(report_focus: str, iocs: str = "", audience: str = "technical") -> str:
        """Generate a comprehensive threat intelligence report."""
        return _text_from_result(_generate_threat_report_prompt({"report_focus": report_focus, "iocs": iocs, "audience": audience}))

    @mcp.prompt()
    def yara_hunt(hunt_objective: str, sample_hash: str = "") -> str:
        """Guide through YARA rule creation and retrohunt workflow for threat hunting."""
        return _text_from_result(_generate_yara_hunt_prompt({"hunt_objective": hunt_objective, "sample_hash": sample_hash}))


# Prompt generators for each prompt type

def _get_template(name: str) -> str:
    for prompt in PROMPTS:
        if prompt["name"] == name:
            return prompt["template"]
    raise KeyError(f"Prompt template not found for {name}")


def _generate_investigate_hash_prompt(args: Dict[str, str]) -> Dict[str, Any]:
    """Generate investigation prompt for a file hash."""
    hash_value = args["hash"]
    context = args.get("context", "")
    context_text = f"\n\nContext: {context}" if context else ""

    template = _get_template("investigate_hash")
    text = template.format(hash=hash_value, context=context_text)

    return {
        "description": f"Comprehensive investigation of hash {hash_value}",
        "messages": [
            {
                "role": "user",
                "content": {
                    "type": "text",
                    "text": text
                }
            }
        ]
    }


def _generate_triage_iocs_prompt(args: Dict[str, str]) -> Dict[str, Any]:
    """Generate triage prompt for multiple IOCs."""
    iocs = args["iocs"]
    incident_type = args.get("incident_type", "")
    incident_context = f" related to a {incident_type} incident" if incident_type else ""
    template = _get_template("triage_iocs")
    text = template.format(iocs=iocs, incident_type=incident_context)

    return {
        "description": "Triage and prioritization of multiple IOCs",
        "messages": [
            {
                "role": "user",
                "content": {
                    "type": "text",
                    "text": text
                }
            }
        ]
    }


def _generate_threat_hunt_prompt(args: Dict[str, str]) -> Dict[str, Any]:
    """Generate threat hunting prompt."""
    hypothesis = args["hunt_hypothesis"]
    threat_actor = args.get("threat_actor", "")
    actor_context = f"\n\nFocus on TTPs and IOCs associated with: {threat_actor}" if threat_actor else ""
    
    template = _get_template("threat_hunt")
    text = template.format(hunt_hypothesis=hypothesis, threat_actor=actor_context)

    return {
        "description": f"Threat hunting for: {hypothesis}",
        "messages": [
            {
                "role": "user",
                "content": {
                    "type": "text",
                    "text": text
                }
            }
        ]
    }


def _generate_incident_response_prompt(args: Dict[str, str]) -> Dict[str, Any]:
    """Generate incident response workflow prompt."""
    print(args)
    description = args["incident_description"]
    initial_iocs = args.get("initial_iocs", "")
    iocs_text = f"\n\nInitial IOCs discovered:\n{initial_iocs}" if initial_iocs else ""
    template = _get_template("incident_response")
    text = template.format(incident_description=description, initial_iocs=iocs_text)

    return {
        "description": "Incident response workflow",
        "messages": [
            {
                "role": "user",
                "content": {
                    "type": "text",
                    "text": text
                }
            }
        ]
    }


def _generate_malware_family_prompt(args: Dict[str, str]) -> Dict[str, Any]:
    """Generate malware family analysis prompt."""
    family = args["malware_family"]
    sample_hash = args.get("sample_hash", "")
    sample_text = f"\n\nSpecific sample to analyze: {sample_hash}" if sample_hash else ""

    template = _get_template("malware_family_analysis")
    text = template.format(malware_family=family, sample_hash=sample_text)

    return {
        "description": f"Deep dive analysis of {family} malware",
        "messages": [
            {
                "role": "user",
                "content": {
                    "type": "text",
                    "text": text
                }
            }
        ]
    }


def _generate_campaign_tracking_prompt(args: Dict[str, str]) -> Dict[str, Any]:
    """Generate campaign tracking prompt."""
    campaign = args["campaign_name"]
    known_iocs = args.get("known_iocs", "")
    iocs_text = f"\n\nKnown IOCs:\n{known_iocs}" if known_iocs else ""
    
    template = _get_template("campaign_tracking")
    text = template.format(campaign_name=campaign, known_iocs=iocs_text)

    return {
        "description": f"Campaign tracking for {campaign}",
        "messages": [
            {
                "role": "user",
                "content": {
                    "type": "text",
                    "text": text
                }
            }
        ]
    }


def _generate_pivot_analysis_prompt(args: Dict[str, str]) -> Dict[str, Any]:
    """Generate pivot analysis prompt."""
    indicator = args["initial_indicator"]
    strategy = args.get("pivot_strategy", "")
    strategy_text = f"\n\nPivot strategy: {strategy}" if strategy else ""
    
    template = _get_template("pivot_analysis")
    text = template.format(initial_indicator=indicator, pivot_strategy=strategy_text)

    return {
        "description": f"Pivot analysis from {indicator}",
        "messages": [
            {
                "role": "user",
                "content": {
                    "type": "text",
                    "text": text
                }
            }
        ]
    }


def _generate_threat_report_prompt(args: Dict[str, str]) -> Dict[str, Any]:
    """Generate threat intelligence report prompt."""
    focus = args["report_focus"]
    iocs = args.get("iocs", "")
    audience = args.get("audience", "technical")

    iocs_text = f"\n\nIOCs to include:\n{iocs}" if iocs else ""
    
    template = _get_template("threat_report")
    text = template.format(report_focus=focus, iocs=iocs_text, audience=audience)

    return {
        "description": f"Threat intelligence report on {focus}",
        "messages": [
            {
                "role": "user",
                "content": {
                    "type": "text",
                    "text": text
                }
            }
        ]
    }


def _generate_yara_hunt_prompt(args: Dict[str, str]) -> Dict[str, Any]:
    """Generate YARA hunt workflow prompt."""
    objective = args["hunt_objective"]
    sample_hash = args.get("sample_hash", "")
    sample_text = f"\n\nBase YARA rule on this sample: {sample_hash}" if sample_hash else ""
    
    template = _get_template("yara_hunt")
    text = template.format(hunt_objective=objective, sample_hash=sample_text)

    return {
        "description": f"YARA hunt workflow for {objective}",
        "messages": [
            {
                "role": "user",
                "content": {
                    "type": "text",
                    "text": text
                }
            }
        ]
    }
