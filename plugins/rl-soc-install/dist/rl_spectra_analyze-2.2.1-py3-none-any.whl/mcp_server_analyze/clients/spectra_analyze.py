"""Spectra Analyze API client."""

import ipaddress
import logging
import requests
from typing import Optional, Dict, Any, List

from mcp_server_analyze.core import get_auth_headers
from mcp_server_analyze.clients.utils import determine_hash_type, is_sha1, get_year_ago, utc_now

logger = logging.getLogger(__name__)


def _is_html_response(text: str) -> bool:
    """Check if response text is HTML.
    
    Args:
        text: Response text to check
        
    Returns:
        True if text appears to be HTML
    """
    if not text:
        return False
    text_lower = text.strip().lower()
    return (text_lower.startswith('<!doctype html') or
            text_lower.startswith('<html') or
            '<html>' in text_lower)


def _sanitize_error_response(error_body: str, status_code: int) -> str:
    """Sanitize error response, removing HTML content.
    
    Args:
        error_body: Raw error response body
        status_code: HTTP status code
        
    Returns:
        Sanitized error message suitable for display
    """
    if _is_html_response(error_body):
        return f"HTTP {status_code} error - Server returned HTML error page (check server logs for details)"
    return error_body


def classification_to_string(classification: int, riskscore: int = 0) -> str:
    """Convert classification integer to human-readable string.
    
    Args:
        classification: Classification integer from API
        riskscore: Risk score (0-100), used to distinguish classification 1 subtypes
        
    Returns:
        Human-readable classification string
        
    Classification mapping:
        3 = MALICIOUS
        2 = SUSPICIOUS
        1 = LIKELY BENIGN (if riskscore <= 3)
        1 = NO KNOWN THREATS (if riskscore > 3)
        0 = UNKNOWN
    """
    if classification == 3:
        return "MALICIOUS"
    elif classification == 2:
        return "SUSPICIOUS"
    elif classification == 1:
        if riskscore <= 3:
            return "LIKELY BENIGN"
        else:
            return "NO KNOWN THREATS"
    else:
        return "UNKNOWN"


DEFAULT_FILE_REPUTATION_FIELDS = [
    'id', 'sha1', 'sha256', 'md5', 'classification', 'classification_result',
    'classification_reason', 'riskscore', 'file_type', 'file_subtype', 'file_size',
    'local_first_seen', 'local_last_seen', 'tags',
]

DEFAULT_FILE_ANALYSIS_FIELDS = [
    'classification',
    'ticore',
    'sample_summary',
    'rl_cloud_sandbox',
    'rl_auxiliary_analysis',
    'av_scanners',
]


class SpectraAnalyzeClient:
    """Client for Spectra Analyze API interactions."""

    rha1_url = '/api/spectra-intelligence/rha1/{rha_type}/{hash_value}/'
    rha1_bulk_url = '/api/spectra-intelligence/rha1/'

    malware_url = '/api/spectra-intelligence/malware-presence/{hash_type}/{hash_value}/'
    malware_bulk_url = '/api/spectra-intelligence/malware-presence/'

    cloud_search_url = '/api/spectra-intelligence/search/'

    network_reputations_url = '/api/spectra-intelligence/network/reputations/'
    network_url_report = '/api/network-threat-intel/url/?url={url}'
    network_domain_report = '/api/network-threat-intel/domain/{domain}/'
    network_ip_report = '/api/network-threat-intel/ip/{ip}/report/'
    network_url_intel = '/api/network-threat-intel/url/'
    network_ip_resolutions = '/api/network-threat-intel/ip/{ip}/resolutions/'
    network_ip_urls = '/api/network-threat-intel/ip/{ip}/urls/'
    network_ip_downloaded_files = '/api/network-threat-intel/ip/{ip}/downloaded_files/'
    network_domain_downloaded_files = '/api/network-threat-intel/domain/{domain}/downloaded_files/'
    network_url_downloaded_files = '/api/network-threat-intel/url/?url={url}/downloaded_files/'

    rca2_url = '/api/spectra-intelligence/rca2/{hash_type}/{hash_value}/'
    rca2_bulk_url = '/api/spectra-intelligence/rca2/'

    rldata_url = '/api/spectra-intelligence/rldata/{hash_type}/{hash_value}/'
    rldata_bulk_url = '/api/spectra-intelligence/rldata/'

    cloud_sandbox_url = '/api/spectra-intelligence/reports/sandbox/{hash_value}/'
    dynamic_analysis_status_url = '/api/rl_dynamic_analysis/status'
    sample_classification_url = '/api/samples/v3/{hash_value}/classification/'

    samples_details_url = '/api/samples/v2/list/details/'
    samples_list_url = '/api/samples/v2/list/'
    sample_extracted_files = '/api/samples/v2/{hash_value}/extracted-files/'
    search_url = '/api/samples/v3/search/'
    search_count_url = '/api/samples/v3/search/total-count'

    ticore_url = '/api/v2/samples/{hash_value}/ticore/'

    yara_rulesets_url = '/api/yara/v2/rulesets/'
    yara_ruleset_content_url = '/api/yara/ruleset/content/'
    yara_ruleset_url = '/api/yara/ruleset/'
    yara_ruleset_enable_url = '/api/yara/ruleset/enable/'
    yara_ruleset_disable_url = '/api/yara/ruleset/disable/'
    yara_ruleset_matches_url = '/api/yara/v2/ruleset/matches/'
    yara_local_retrohunt_url = '/api/uploads/local-retro-hunt/'
    yara_cloud_retrohunt_url = '/api/yara/ruleset/{ruleset_name}/cloud-retro-hunt/'
    submit_url_url = '/api/submit/url/'
    reanalyze_bulk_url = '/api/samples/v2/analyze_bulk/'

    def __init__(self, base_url: str, verify_ssl: bool = True, timeout=30):
        """Initialize the Spectra Analyze client.

        Args:
            base_url: Base URL for Spectra Analyze appliance
            verify_ssl: Whether to verify SSL certificates
        """
        self.base_url = base_url.rstrip('/')
        self.verify_ssl = verify_ssl
        self.timeout = timeout
        self.headers = get_auth_headers()
        logger.debug('Headers: %s', self.headers)
        logger.debug('Initialized SpectraAnalyzeClient with base_url: %s, verify_ssl: %s', self.base_url, self.verify_ssl)

    def request(self, method: str, path: str, **kwargs):
        endpoint = f'{self.base_url}{path}'
        response = requests.request(method, endpoint, headers=get_auth_headers(), verify=self.verify_ssl, timeout=self.timeout, **kwargs)
        response.raise_for_status()
        return response.json()

    def get(self, path: str, params: Optional[Dict[str, Any]] = None):
        return self.request('get', path, params=params)

    def post(self, path: str, payload: Dict[str, Any]):
        return self.request('post', path, json=payload)

    def stream_sample(self, hash_value: str, chunk_size: int = 65536):
        """Stream a file sample in chunks without saving to disk.

        GET /api/samples/{hash}/download/?fetch

        This is a generator. At most one chunk is held in memory at a time;
        the file is never written to disk.

        Args:
            hash_value: MD5, SHA-1, or SHA-256 hash of the file to download.
            chunk_size: Bytes per chunk (default 64 KB).

        Yields:
            Raw bytes chunks.
        """
        url = f'{self.base_url}/api/samples/{hash_value}/download/?fetch'
        logger.debug('SA API GET (stream) %s', url)
        response = requests.get(
            url,
            headers=get_auth_headers(),
            verify=self.verify_ssl,
            timeout=300,
            stream=True,
        )
        response.raise_for_status()
        for chunk in response.iter_content(chunk_size=chunk_size):
            if chunk:
                yield chunk

    def get_file_analysis(self, hash_value: str) -> Optional[Dict[str, Any]]:
        """Get file analysis from Spectra Analyze.

        Args:
            hash_value: File hash (SHA1, SHA256, or MD5)

        Returns:
            Analysis data dictionary or None if not found
        """
        try:
            payload = {'hash_values': [hash_value], 'fields': DEFAULT_FILE_ANALYSIS_FIELDS}
            logger.info('Fetching file analysis from Spectra Analyze: %s', hash_value)

            data = self.post(path=self.samples_details_url, payload=payload)

            if data.get('count', 0) == 0:
                logger.info('File not found in Spectra Analyze: %s', hash_value)
                return None

            if data.get('count') > 1:
                logger.error('API returned unexpected result count for %s', hash_value)
                return None

            # Return the first result
            result = data['results'][0]
            logger.debug('Successfully retrieved file analysis for %s', hash_value)
            return result

        except requests.exceptions.HTTPError as e:
            if e.response and e.response.status_code == 404:
                logger.info('File not found in Spectra Analyze: %s', hash_value)
            else:
                logger.error('HTTP error fetching file analysis: %s', e)
            return None
        except requests.exceptions.RequestException as e:
            logger.error('Request error fetching file analysis: %s', e)
            return None
        except Exception as e:
            logger.error('Unexpected error fetching file analysis: %s', e)
            return None

    def get_file_reputation(self, hash_value: str, fields: Optional[List[str]] = None) -> Dict[str, Any]:
        """Get file reputation data from Spectra Analyze.

        This wraps the `/api/samples/v2/list/` endpoint that returns basic
        reputation metadata for one or more hashes.

        Args:
            hash_value: File hash (SHA1, SHA256, or MD5)
            fields: Optional list of fields to request. If not provided, the
                server default is used.

        Returns:
            Raw JSON response from the API as a dictionary.

        Raises:
            requests.exceptions.HTTPError: If the HTTP request returned an
                unsuccessful status code.
            requests.exceptions.RequestException: For other request-related
                errors.
        """
        payload = {'hash_values': [hash_value], 'fields': fields or DEFAULT_FILE_REPUTATION_FIELDS}
        logger.info('Fetching file reputation from Spectra Analyze: %s', hash_value)
        return self.post(path=self.samples_list_url, payload=payload)

    def advanced_search(self, query: str, sort: Optional[str] = None, limit: int = 100,
                        ticloud=False, page: int = 1, start_search_date: Optional[str] = None,
                        end_search_date: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """Perform advanced search in Spectra Analyze.

        Args:
            query: Search query string
            sort: Optional sort parameter
            limit: Results per page (default: 100, max 100 enforced by the API)
            ticloud: Query the Spectra Intelligence cloud index when True
            page: 1-based page number for paginating large result sets
            start_search_date: Cloud-only lower bound (YYYY-MM-DD). Defaults to one year ago.
            end_search_date: Cloud-only upper bound (YYYY-MM-DD). Defaults to now. 

        Returns:
            Search results dictionary with entries, total_count, and meta, or None if error
        """
        try:
            payload = {
                'query': query,
                'records_per_page': limit,
                'ticloud': ticloud,
                'page': page,
            }

            if ticloud:
                payload['start_search_date'] = start_search_date or get_year_ago().strftime('%Y-%m-%d')
                payload['end_search_date'] = end_search_date or utc_now().strftime('%Y-%m-%d')

            if sort:
                payload['sort'] = sort

            logger.info('Searching Spectra Analyze: %s', query)

            data = self.post(self.search_url, payload=payload)

            # Parse response matching original implementation
            ws = data.get('rl', {}).get('web_search_api', {})
            entries = ws.get('entries', [])

            # For the cloud index the per-page response has no total_count, so
            # fetch it from the dedicated count API — but only once (page 1),
            count_data = None
            if ticloud and page == 1:
                try:
                    count_data = self.post(self.search_count_url, payload={
                        'query': payload.get('query'),
                        'start_search_date': payload.get('start_search_date'),
                        'end_search_date': payload.get('end_search_date'),
                    })
                except requests.exceptions.RequestException as e:
                    logger.warning('Search total-count unavailable for query %r: %s',
                                   payload.get('query'), e)

            # extract total count from search count api if ticloud
            total_count = count_data.get('total_count') if count_data else ws.get('total_count')

            result = {
                'search_api': {
                    'entries': entries,
                    'total_count': total_count if isinstance(total_count, int) else None
                }
            }

            if ticloud:
                for meta_key in ('last_search_date', 'next_page', 'more_pages', 'end_of_dataset'):
                    if meta_key in ws:
                        result['search_api'][meta_key] = ws[meta_key]

            logger.debug('Search returned %d results', len(entries))
            return result

        except requests.exceptions.RequestException as e:
            logger.error('Error searching Spectra Analyze: %s', e)
            return None
        except Exception as e:
            logger.error('Unexpected error searching Spectra Analyze: %s', e)
            return None

    def _get_indicator_type_and_path(self, location: str) -> tuple[str, str]:
        """Return (indicator_type, api_path) for a network location."""
        if "://" in location:
            return 'url', self.network_url_report.format(url=location)

        # remove port if present, network threat intelligence API does not support ports
        clean_location = location.split(":")[0] if location.count(":") == 1 else location

        try:
            ipaddress.ip_address(clean_location)
            return 'ip', self.network_ip_report.format(ip=clean_location)
        except ValueError:
            return 'domain', self.network_domain_report.format(domain=clean_location)

    def _lookup_single_indicator(self, location: str) -> Optional[Dict[str, Any]]:
        """Lookup a single indicator."""
        indicator_type, path = self._get_indicator_type_and_path(location)

        logger.debug('Looking up %s: %s', indicator_type, location)

        data = self.get(path=path)

        # entry = data.get('rl', {}).get('network_threat_intel', {})

        if not data:
            return None

        # Add the location to the entry for consistency
        data['network_location'] = location
        data['indicator_type'] = indicator_type
        return data

    def get_network_reputation(self, locations: List[str]) -> Optional[Dict[str, Any]]:
        """Get network reputation from Spectra Analyze.

        Note: Spectra Analyze API does not support bulk lookups, so each indicator
        is looked up individually. Limited to 10 indicators maximum.

        Args:
            locations: List of URLs, domains, or IP addresses

        Returns:
            Network reputation data dictionary or None if error
        """

        MAXIMUM_NUMBER_OF_LOCATIONS = 10

        try:
            if not locations:
                logger.debug('No network locations provided for reputation lookup')
                return None

            if len(locations) > MAXIMUM_NUMBER_OF_LOCATIONS:
                logger.warning('Received %d indicators for network reputation lookup. Limiting to first %s.', len(locations), MAXIMUM_NUMBER_OF_LOCATIONS)
                locations = locations[:MAXIMUM_NUMBER_OF_LOCATIONS]

            logger.info('Fetching network reputation for %d location(s) from Spectra Analyze', len(locations))

            all_entries = []

            for location in locations:
                try:
                    entry = self._lookup_single_indicator(location)
                    if entry:
                        all_entries.append(entry)

                except requests.exceptions.HTTPError as e:
                    logger.error('HTTP error looking up %s: %s', location, e)
                    continue
                except Exception as e:
                    logger.error('Error looking up %s: %s', location, e)
                    continue

            if all_entries:
                logger.info('Successfully retrieved network reputation for %d location(s)', len(all_entries))
                return {
                    'rl': {
                        'entries': all_entries
                    }
                }
            else:
                logger.warning('No entries returned from network reputation lookup')
                return None

        except Exception as e:
            logger.error('Unexpected error fetching network reputation: %s', e)
            return None

    def get_network_reputations_bulk(self, locations: List[str], max_locations: int = 100) -> Optional[Dict[str, Any]]:
        """Get network reputation for multiple Domains, URLs, and IP addresses.

        Args:
            locations: List of URLs, domains, or IP addresses
            max_locations: Maximum number of locations to look up

        Returns:
            Network reputation data dictionary ({'rl': {'entries': [...]}}) or None if error
        """
        try:
            if not locations:
                logger.debug('No network locations provided for bulk reputation lookup')
                return None

            if len(locations) > max_locations:
                logger.warning('Received %d indicators for bulk network reputation lookup. Limiting to first %d.', len(locations), max_locations)
                locations = locations[:max_locations]

            batch_size = 100
            batches = [locations[i:i + batch_size] for i in range(0, len(locations), batch_size)]

            logger.info('Fetching bulk network reputation for %d location(s) in %d batch(es) from Spectra Analyze', len(locations), len(batches))

            all_entries = []

            for batch_num, batch in enumerate(batches, 1):
                payload = {
                    'response_format': 'json',
                    'network_locations': list(batch),
                }

                try:
                    logger.debug('Processing bulk network reputation batch %d/%d with %d location(s)', batch_num, len(batches), len(batch))
                    data = self.post(path=self.network_reputations_url, payload=payload)
                    entries = data.get('entries') or data.get('rl', {}).get('entries', [])
                    all_entries.extend(entries)

                except requests.exceptions.HTTPError as e:
                    logger.error('HTTP error on bulk network reputation batch %d/%d: %s', batch_num, len(batches), e)
                    continue
                except Exception as e:
                    logger.error('Error on bulk network reputation batch %d/%d: %s', batch_num, len(batches), e)
                    continue

            if all_entries:
                logger.info('Successfully retrieved bulk network reputation for %d location(s)', len(all_entries))
                return {
                    'rl': {
                        'entries': all_entries
                    }
                }

            logger.warning('No entries returned from bulk network reputation lookup')
            return None

        except Exception as e:
            logger.error('Unexpected error fetching bulk network reputation: %s', e)
            return None

    def get_network_url_intel(self, url: str) -> Optional[Dict[str, Any]]:
        """Get Network Threat Intelligence for a URL.

        GET /api/network-threat-intel/url/?url={url}

        Args:
            url: The requested URL (URI-encoding is handled here).

        Returns:
            Network threat intelligence report dictionary or None if not found.
        """
        logger.info('Fetching network URL intelligence from Spectra Analyze: %s', url)
        try:
            return self.get(path=self.network_url_intel, params={'url': url})
        except requests.exceptions.HTTPError as e:
            if e.response is not None and e.response.status_code == 404:
                logger.info('URL not found in network threat intelligence: %s', url)
            else:
                logger.error('HTTP error fetching network URL intelligence: %s', e)
            return None
        except requests.exceptions.RequestException as e:
            logger.error('Request error fetching network URL intelligence: %s', e)
            return None
        except Exception as e:
            logger.error('Unexpected error fetching network URL intelligence: %s', e)
            return None

    def get_network_domain_intel(self, domain: str) -> Optional[Dict[str, Any]]:
        """Get Network Threat Intelligence for a domain.

        GET /api/network-threat-intel/domain/{domain}/

        Args:
            domain: The requested domain.

        Returns:
            Network threat intelligence report dictionary or None if not found.
        """
        logger.info('Fetching network domain intelligence from Spectra Analyze: %s', domain)
        try:
            return self.get(path=self.network_domain_report.format(domain=domain))
        except requests.exceptions.HTTPError as e:
            if e.response is not None and e.response.status_code == 404:
                logger.info('Domain not found in network threat intelligence: %s', domain)
            else:
                logger.error('HTTP error fetching network domain intelligence: %s', e)
            return None
        except requests.exceptions.RequestException as e:
            logger.error('Request error fetching network domain intelligence: %s', e)
            return None
        except Exception as e:
            logger.error('Unexpected error fetching network domain intelligence: %s', e)
            return None

    def get_network_ip_intel(self, ip: str) -> Optional[Dict[str, Any]]:
        """Get the Network Threat Intelligence report for an IP address.

        GET /api/network-threat-intel/ip/{ip}/report/

        Args:
            ip: The requested IP address.

        Returns:
            Network threat intelligence report dictionary or None if not found.
        """
        logger.info('Fetching network IP intelligence report from Spectra Analyze: %s', ip)
        try:
            return self.get(path=self.network_ip_report.format(ip=ip))
        except requests.exceptions.HTTPError as e:
            if e.response is not None and e.response.status_code == 404:
                logger.info('IP not found in network threat intelligence: %s', ip)
            else:
                logger.error('HTTP error fetching network IP intelligence report: %s', e)
            return None
        except requests.exceptions.RequestException as e:
            logger.error('Request error fetching network IP intelligence report: %s', e)
            return None
        except Exception as e:
            logger.error('Unexpected error fetching network IP intelligence report: %s', e)
            return None

    def get_network_ip_resolutions(self, ip: str, page: Optional[str] = None,
                                   page_size: Optional[int] = None) -> Optional[Dict[str, Any]]:
        """Get IP-to-domain resolutions for an IP address.

        GET /api/network-threat-intel/ip/{ip}/resolutions/

        Args:
            ip: The requested IP address.
            page: SHA1 hash of the next page (for pagination).
            page_size: Number of records to return.

        Returns:
            Resolutions dictionary or None if not found.
        """
        logger.info('Fetching network IP resolutions from Spectra Analyze: %s', ip)
        params: Dict[str, Any] = {}
        if page:
            params['page'] = page
        if page_size:
            params['page_size'] = page_size
        try:
            return self.get(path=self.network_ip_resolutions.format(ip=ip), params=params or None)
        except requests.exceptions.HTTPError as e:
            if e.response is not None and e.response.status_code == 404:
                logger.info('No resolutions found for IP: %s', ip)
            else:
                logger.error('HTTP error fetching network IP resolutions: %s', e)
            return None
        except requests.exceptions.RequestException as e:
            logger.error('Request error fetching network IP resolutions: %s', e)
            return None
        except Exception as e:
            logger.error('Unexpected error fetching network IP resolutions: %s', e)
            return None

    def get_network_ip_urls(self, ip: str, page: Optional[str] = None,
                            page_size: Optional[int] = None) -> Optional[Dict[str, Any]]:
        """Get URLs hosted on an IP address.

        GET /api/network-threat-intel/ip/{ip}/urls/

        Args:
            ip: The requested IP address.
            page: SHA1 hash of the next page (for pagination).
            page_size: Number of records to return.

        Returns:
            URLs dictionary or None if not found.
        """
        logger.info('Fetching network IP URLs from Spectra Analyze: %s', ip)
        params: Dict[str, Any] = {}
        if page:
            params['page'] = page
        if page_size:
            params['page_size'] = page_size
        try:
            return self.get(path=self.network_ip_urls.format(ip=ip), params=params or None)
        except requests.exceptions.HTTPError as e:
            if e.response is not None and e.response.status_code == 404:
                logger.info('No URLs found for IP: %s', ip)
            else:
                logger.error('HTTP error fetching network IP URLs: %s', e)
            return None
        except requests.exceptions.RequestException as e:
            logger.error('Request error fetching network IP URLs: %s', e)
            return None
        except Exception as e:
            logger.error('Unexpected error fetching network IP URLs: %s', e)
            return None

    def _network_downloaded_files(self, path: str, label: str, value: str,
                                  page: Optional[str] = None,
                                  page_size: Optional[int] = None,
                                  extended: bool = False,
                                  classification: Optional[str] = None,
                                  ) -> Optional[Dict[str, Any]]:
        """Shared implementation for the network downloaded-files endpoints.

        Args:
            path: Fully-formatted endpoint path.
            label: Indicator type label for logging (``URL``/``domain``/``IP``).
            value: The indicator value for logging.
            page: SHA1 hash of the next page (for pagination).
            page_size: Number of records to return.
            extended: When True, include additional file metadata.
            classification: Filter by classification (MALICIOUS, SUSPICIOUS,
                GOODWARE, UNKNOWN).

        Returns:
            Downloaded-files dictionary or None if not found.
        """
        logger.info('Fetching network downloaded files (%s) from Spectra Analyze: %s', label, value)
        params: Dict[str, Any] = {}
        if page:
            params['page'] = page
        if page_size:
            params['page_size'] = page_size
        if extended:
            params['extended'] = 'true'
        if classification:
            params['classification'] = classification
        try:
            return self.get(path=path, params=params or None)
        except requests.exceptions.HTTPError as e:
            if e.response is not None and e.response.status_code == 404:
                logger.info('No downloaded files found for %s: %s', label, value)
            else:
                logger.error('HTTP error fetching network downloaded files (%s): %s', label, e)
            return None
        except requests.exceptions.RequestException as e:
            logger.error('Request error fetching network downloaded files (%s): %s', label, e)
            return None
        except Exception as e:
            logger.error('Unexpected error fetching network downloaded files (%s): %s', label, e)
            return None

    def get_network_ip_downloaded_files(self, ip: str, page: Optional[str] = None,
                                        page_size: Optional[int] = None, extended: bool = False,
                                        classification: Optional[str] = None,
                                        ) -> Optional[Dict[str, Any]]:
        """Get files downloaded from an IP address.

        GET /api/network-threat-intel/ip/{ip}/downloaded_files/
        """
        return self._network_downloaded_files(
            self.network_ip_downloaded_files.format(ip=ip),
            'IP', ip, page, page_size, extended, classification,
        )

    def get_network_domain_downloaded_files(self, domain: str, page: Optional[str] = None,
                                            page_size: Optional[int] = None, extended: bool = False,
                                            classification: Optional[str] = None,
                                            ) -> Optional[Dict[str, Any]]:
        """Get files downloaded from URLs on a domain.

        GET /api/network-threat-intel/domain/{domain}/downloaded_files/
        """
        return self._network_downloaded_files(
            self.network_domain_downloaded_files.format(domain=domain),
            'domain', domain, page, page_size, extended, classification,
        )

    def get_network_url_downloaded_files(self, url: str, page: Optional[str] = None,
                                         page_size: Optional[int] = None, extended: bool = False,
                                         classification: Optional[str] = None,
                                         ) -> Optional[Dict[str, Any]]:
        """Get files downloaded from a URL.

        GET /api/network-threat-intel/url/?url={url}/downloaded_files/

        The URL is embedded raw in the query string via string formatting
        (matching ``network_url_report``), not percent-encoded, with the
        ``downloaded_files/`` segment appended after the URL value.
        """
        return self._network_downloaded_files(
            self.network_url_downloaded_files.format(url=url),
            'URL', url, page, page_size, extended, classification,
        )

    def get_extracted_files(self, hash_value: str) -> List[Dict[str, Any]]:
        """Get extracted files for a given hash.

        Args:
            hash_value: File hash (SHA1, SHA256, or MD5)

        Returns:
            List of extracted file dictionaries
        """
        extracted_files = []
        try:
            logger.info('Fetching extracted files from Spectra Analyze: %s', hash_value)

            data = self.get(path=self.sample_extracted_files.format(hash_value=hash_value))
            items = data.get('results', [])

            for item in items:
                sample = item.get('sample', {})
                extracted_files.append({
                    'sha1': sample.get('sha1', ''),
                    'sha256': sample.get('sha256', ''),
                    'md5': sample.get('md5', ''),
                    'classification': sample.get('classification', ''),
                    'threat_name': sample.get('classification_result', '')
                })

            logger.debug('Retrieved %d extracted files for %s', len(extracted_files), hash_value)

        except requests.exceptions.HTTPError as e:
            logger.error('HTTP error retrieving extracted files: %s', e)
        except Exception as e:
            logger.error('Failed to retrieve extracted files: %s', e)

        return extracted_files

    def get_malware_presence(self, hash_value: str) -> Optional[Dict[str, Any]]:
        """Get malware presence from TICloud (TCA-0101).

        Args:
            hash_value: File hash (SHA1, SHA256, or MD5)

        Returns:
            Reputation data dictionary or None if not found
        """
        try:
            logger.info('Fetching file reputation from Spectra Intelligence: %s', hash_value)
            hash_type = determine_hash_type(hash_value=hash_value)
            data = self.get(path=self.malware_url.format(hash_value=hash_value, hash_type=hash_type))
            logger.debug('Successfully retrieved file reputation for %s', hash_value)
            return data

        except requests.exceptions.HTTPError as e:
            if e.response and e.response.status_code == 404:
                logger.info('File not found in Spectra Intelligence: %s', hash_value)
            else:
                logger.error('HTTP error fetching file reputation: %s', e)
            return None
        except requests.exceptions.RequestException as e:
            logger.error('Request error fetching file reputation: %s', e)
            return None
        except Exception as e:
            logger.error('Unexpected error fetching file reputation: %s', e)
            return None

    def get_ticore(self, hash_value: str) -> Optional[Dict[str, Any]]:
        """Get the TitaniumCore (ticore) static analysis report for a sample.

        GET /api/v2/samples/{hash_value}/ticore/

        Args:
            hash_value: File hash (MD5, SHA1, or SHA256)

        Returns:
            Ticore report dictionary or None if not found
        """
        logger.info('Fetching ticore report from Spectra Analyze: %s', hash_value)
        try:
            return self.get(path=self.ticore_url.format(hash_value=hash_value))

        except requests.exceptions.HTTPError as e:
            if e.response and e.response.status_code == 404:
                logger.info('Ticore report not found in Spectra Analyze: %s', hash_value)
            else:
                logger.error('HTTP error fetching ticore report: %s', e)
            return None
        except requests.exceptions.RequestException as e:
            logger.error('Request error fetching ticore report: %s', e)
            return None
        except Exception as e:
            logger.error('Unexpected error fetching ticore report: %s', e)
            return None

    def get_rldata(self, hash_value: str) -> Optional[Dict[str, Any]]:
        """Get file rldata from Spectra Analyze proxy API.

        Args:
            hash_value: File hash (MD5, SHA1, or SHA256)

        Returns:
            File analysis data dictionary or None if not found
        """
        logger.info('Fetching file analysis from Spectra Analyze rldata proxy API: %s', hash_value)
        try:
            hash_type = determine_hash_type(hash_value=hash_value)
            data = self.get(path=self.rldata_url.format(hash_value=hash_value, hash_type=hash_type))
            logger.debug('Successfully retrieved file analysis for %s', hash_value)
            return data

        except requests.exceptions.HTTPError as e:
            if e.response and e.response.status_code == 404:
                logger.info('File not found in Spectra Analyze rldata proxy API: %s', hash_value)
            else:
                logger.error('HTTP error fetching file analysis: %s', e)
            return None
        except requests.exceptions.RequestException as e:
            logger.error('Request error fetching file analysis: %s', e)
            return None
        except Exception as e:
            logger.error('Unexpected error fetching file analysis: %s', e)
            return None

    def get_rca2(self, hash_value: str) -> Optional[Dict[str, Any]]:
        """Get RCA2 classification from TICloud (TCAI-0104).

        Args:
            hash_value: File hash (MD5, SHA1, or SHA256)

        Returns:
            RCA2 classification data dictionary or None if not found
        """
        logger.info('Fetching RCA2 classification from Spectra Intelligence: %s', hash_value)
        try:
            # Determine hash algorithm based on length
            hash_type = determine_hash_type(hash_value=hash_value)
            return self.get(path=self.rca2_url.format(hash_type=hash_type, hash_value=hash_value))

        except requests.exceptions.HTTPError as e:
            if e.response and e.response.status_code == 404:
                logger.info('File not found in Spectra Intelligence RCA2: %s', hash_value)
            else:
                logger.error('HTTP error fetching RCA2 classification: %s', e)
            return None
        except requests.exceptions.RequestException as e:
            logger.error('Request error fetching RCA2 classification: %s', e)
            return None
        except Exception as e:
            logger.error('Unexpected error fetching RCA2 classification: %s', e)
            return None

    def get_rca2_bulk(self, hash_values: List[str], hash_type: str, max_hashes: int = 100) -> Optional[Dict[str, Any]]:
        """Get RCA2 classification for many hashes for bulk querying for file reputation 

        Args:
            hash_values: List of hashes (max 100). All must be of ``hash_type``.
            hash_type: One of 'md5', 'sha1', or 'sha256'
            max_hashes: Maximum number of hashes to submit in one request

        Returns:
            RCA2 bulk data dictionary ({'rl': {'rca2': {'entries': [...]}}}) or None if error
        """
        try:
            if not hash_values:
                logger.debug('No hashes provided for bulk RCA2 lookup')
                return None

            if len(hash_values) > max_hashes:
                logger.warning('Received %d hashes for bulk RCA2 lookup. Limiting to first %d.', len(hash_values), max_hashes)
                hash_values = hash_values[:max_hashes]

            logger.info('Fetching bulk RCA2 classification for %d %s hash(es) from Spectra Intelligence', len(hash_values), hash_type)

            payload = {'hash_type': hash_type, 'hashes': hash_values}
            return self.request('post', self.rca2_bulk_url, json=payload, params={'extended': 'true'})

        except requests.exceptions.HTTPError as e:
            logger.error('HTTP error fetching bulk RCA2 classification: %s', e)
            return None
        except requests.exceptions.RequestException as e:
            logger.error('Request error fetching bulk RCA2 classification: %s', e)
            return None
        except Exception as e:
            logger.error('Unexpected error fetching bulk RCA2 classification: %s', e)
            return None

    def get_sample_classification(self, hash_value: str) -> Optional[Dict[str, Any]]:
        """Get classification and risk score for a sample (local or cloud-proxied).

        GET /api/samples/v3/{hash_value}/classification/

        Args:
            hash_value: File hash (MD5, SHA-1, or SHA-256)

        Returns:
            Classification data dictionary or None if not found
        """
        logger.info('Fetching sample classification: %s', hash_value)
        try:
            return self.get(path=self.sample_classification_url.format(hash_value=hash_value))
        except requests.exceptions.HTTPError as e:
            if e.response and e.response.status_code == 404:
                logger.info('Classification not found for: %s', hash_value)
            else:
                logger.error('HTTP error fetching sample classification: %s', e)
            return None
        except requests.exceptions.RequestException as e:
            logger.error('Request error fetching sample classification: %s', e)
            return None
        except Exception as e:
            logger.error('Unexpected error fetching sample classification: %s', e)
            return None

    def get_dynamic_analysis(self, hash_value: str) -> Optional[Dict[str, Any]]:
        """Get dynamic analysis from TICloud (TCA-0106).

        Args:
            hash_value: File hash (SHA1, SHA256, or MD5)

        Returns:
            Dynamic analysis data dictionary or None if not found
        """
        logger.info('Fetching dynamic analysis from Spectra Intelligence: %s', hash_value)

        try:
            return self.get(path=self.cloud_sandbox_url.format(hash_value=hash_value))

        except requests.exceptions.HTTPError as e:
            if e.response and e.response.status_code == 404:
                logger.info('Dynamic analysis not found in Spectra Intelligence: %s', hash_value)
            else:
                logger.error('HTTP error fetching dynamic analysis: %s', e)
            return None
        except requests.exceptions.RequestException as e:
            logger.error('Request error fetching dynamic analysis: %s', e)
            return None
        except Exception as e:
            logger.error('Unexpected error fetching dynamic analysis: %s', e)
            return None

    def get_dynamic_analysis_status(self, hash_value: str) -> Optional[Dict[str, Any]]:
        """Get the status of a dynamic (sandbox) analysis run.

        POST /api/rl_dynamic_analysis/status with body
        ``{"hash_values": [hash_value]}``.

        Args:
            hash_value: File hash (SHA1, SHA256, or MD5)

        Returns:
            Status data dictionary for the sample or None if not found
        """
        logger.info('Fetching dynamic analysis status: %s', hash_value)

        try:
            data = self.post(
                path=self.dynamic_analysis_status_url,
                payload={'hash_values': [hash_value]},
            )
            if isinstance(data, list):
                return data[0] if data else None
            return data

        except requests.exceptions.HTTPError as e:
            if e.response and e.response.status_code == 404:
                logger.info('Dynamic analysis status not found: %s', hash_value)
            else:
                logger.error('HTTP error fetching dynamic analysis status: %s', e)
            return None
        except requests.exceptions.RequestException as e:
            logger.error('Request error fetching dynamic analysis status: %s', e)
            return None
        except Exception as e:
            logger.error('Unexpected error fetching dynamic analysis status: %s', e)
            return None

    def get_rha1_analytics(self, hash_value: str, rha1_type: str) -> Optional[Dict[str, Any]]:
        """Get RHA1 analytics from TICloud (TCA-0321).

        Args:
            hash_value: SHA1, SHA256, or MD5 hash
            rha1_type: RHA1 precision level (pe01, pe02, elf01, macho01)

        Returns:
            RHA1 analytics data dictionary or None if not found
        """
        logger.info('Fetching RHA1 analytics from Spectra Intelligence: %s (type: %s)', hash_value, rha1_type)
        try:
            # Convert hash to SHA1 if needed
            sha1_hash = self._convert_hash_to_sha1(hash_value)
            if not sha1_hash:
                return None
            return self.get(path=self.rha1_url.format(hash_value=sha1_hash, rha_type=rha1_type))

        except requests.exceptions.HTTPError as e:
            if e.response and e.response.status_code == 404:
                logger.info('RHA1 analytics not found in Spectra Intelligence: %s', hash_value)
            else:
                logger.error('HTTP error fetching RHA1 analytics: %s', e)
            return None
        except requests.exceptions.RequestException as e:
            logger.error('Request error fetching RHA1 analytics: %s', e)
            return None
        except Exception as e:
            logger.error('Unexpected error fetching RHA1 analytics: %s', e)
            return None

    def _convert_hash_to_sha1(self, hash_value: str) -> Optional[str]:
        """Convert MD5 or SHA256 hash to SHA1 using file reputation API.

        Args:
            hash_value: Hash to convert (SHA1, SHA256, or MD5)

        Returns:
            SHA1 hash or None if conversion failed
        """
        hash_clean = hash_value.strip().lower()
        hash_len = len(hash_clean)

        if hash_len == 40:
            # Already SHA1
            return hash_clean
        elif hash_len == 64 or hash_len == 32:
            # SHA256 or MD5 - need to convert
            logger.info('Converting %s to SHA1', hash_value)

            try:
                query = f"hashes:{hash_value}"
                data = self.advanced_search(query, limit=1, ticloud=True)
                entries = data.get('search_api', {}).get('entries', [])
                if not entries:
                    logger.error('No entries found for hash: %s', hash_value)
                    return None

                entry = entries[0]
                if sha1 := (entry or {}).get('sha1'):
                    logger.debug('Converted %s to SHA1: %s', hash_value, sha1)
                    return sha1

                logger.error('Could not retrieve SHA1 for hash: %s', hash_value)
                return None

            except Exception as e:
                logger.error('Error converting hash to SHA1: %s', e)
                return None
        else:
            logger.error('Invalid hash format (expected SHA1, SHA256, or MD5): %s', hash_value)
            return None

    def yara_list_rulesets(self, ruleset_type: Optional[str] = None, status: Optional[str] = None,
                           source: Optional[str] = None, page: int = 1, page_size: int = 100) -> Optional[Dict[str, Any]]:
        """List YARA rulesets on the appliance.

        Args:
            ruleset_type: Filter by type ('my', 'user', 'system', 'all')
            status: Filter by status ('error', 'active', 'disabled', 'pending', 'invalid', 'capped', 'all')
            source: Filter by source ('local', 'cloud')
            page: Page number for pagination
            page_size: Number of results per page

        Returns:
            Dictionary with ruleset list or None if error
        """
        try:
            params = {'page': page, 'page_size': page_size}
            if ruleset_type:
                params['type'] = ruleset_type
            if status:
                params['status'] = status
            if source:
                params['source'] = source

            logger.info('Listing YARA rulesets from Spectra Analyze')
            data = self.get(self.yara_rulesets_url, params=params)
            logger.debug('Retrieved %d YARA rulesets', data.get('count', 0))
            return data

        except requests.exceptions.HTTPError as e:
            logger.error('HTTP error listing YARA rulesets: %s', e)
            error_detail = str(e)
            status_code = None
            if hasattr(e, 'response') and e.response is not None:
                status_code = e.response.status_code
                try:
                    error_body = e.response.text
                    logger.error('Response body: %s', error_body)
                    try:
                        error_json = e.response.json()
                        if isinstance(error_json, dict):
                            error_detail = error_json.get('message') or error_json.get('error') or _sanitize_error_response(error_body, status_code)
                        else:
                            error_detail = _sanitize_error_response(error_body, status_code)
                    except Exception:
                        error_detail = _sanitize_error_response(error_body, status_code)
                except Exception:
                    pass
            return {'success': False, 'error': error_detail, 'status_code': status_code}
        except requests.exceptions.RequestException as e:
            logger.error('Error listing YARA rulesets: %s', e)
            return {'success': False, 'error': str(e)}
        except Exception as e:
            logger.error('Unexpected error listing YARA rulesets: %s', e)
            return {'success': False, 'error': str(e)}

    def yara_create_or_update_ruleset(self, ruleset_name: str, content: str, ticloud: bool = False) -> Optional[Dict[str, Any]]:
        """Create or update a YARA ruleset.

        Args:
            ruleset_name: Name of the ruleset
            content: YARA rule content
            ticloud: Whether to synchronize with Spectra Intelligence cloud (default: False)

        Returns:
            Dictionary with operation result or None if error
        """
        try:
            payload = {'name': ruleset_name, 'content': content, 'ticloud': ticloud}
            logger.info('Creating/updating YARA ruleset: %s (ticloud=%s)', ruleset_name, ticloud)
            data = self.request('post', self.yara_ruleset_url, data=payload)
            logger.debug('Successfully created/updated YARA ruleset: %s', ruleset_name)
            return data

        except requests.exceptions.HTTPError as e:
            logger.error('HTTP error creating/updating YARA ruleset: %s', e)
            error_detail = str(e)
            status_code = None
            if hasattr(e, 'response') and e.response is not None:
                status_code = e.response.status_code
                try:
                    error_body = e.response.text
                    logger.error('Response body: %s', error_body)
                    try:
                        error_json = e.response.json()
                        if isinstance(error_json, dict):
                            # Check for detailed validation errors
                            if 'detail' in error_json and isinstance(error_json['detail'], dict):
                                if 'fields' in error_json['detail'] and isinstance(error_json['detail']['fields'], dict):
                                    # Extract field-specific errors (e.g., YARA syntax errors)
                                    field_errors = []
                                    for field, errors in error_json['detail']['fields'].items():
                                        if isinstance(errors, list):
                                            field_errors.extend(errors)
                                        else:
                                            field_errors.append(str(errors))
                                    if field_errors:
                                        base_msg = error_json.get('message', 'Validation error')
                                        error_detail = f"{base_msg}: {'; '.join(field_errors)}"
                                    else:
                                        error_detail = error_json.get('message') or error_json.get('error') or _sanitize_error_response(error_body, status_code)
                                else:
                                    error_detail = error_json.get('message') or error_json.get('error') or _sanitize_error_response(error_body, status_code)
                            else:
                                error_detail = error_json.get('message') or error_json.get('error') or _sanitize_error_response(error_body, status_code)
                        else:
                            error_detail = _sanitize_error_response(error_body, status_code)
                    except Exception:
                        error_detail = _sanitize_error_response(error_body, status_code)
                except Exception:
                    pass
            return {'success': False, 'error': error_detail, 'status_code': status_code}
        except requests.exceptions.RequestException as e:
            logger.error('Error creating/updating YARA ruleset: %s', e)
            return {'success': False, 'error': str(e)}
        except Exception as e:
            logger.error('Unexpected error creating/updating YARA ruleset: %s', e)
            return {'success': False, 'error': str(e)}

    def yara_delete_ruleset(self, ruleset_name: str) -> Optional[Dict[str, Any]]:
        """Delete a YARA ruleset and its matches.

        Args:
            ruleset_name: Name of the ruleset to delete

        Returns:
            Dictionary with operation result or None if error
        """
        try:
            payload = {'name': ruleset_name}
            logger.info('Deleting YARA ruleset: %s', ruleset_name)
            data = self.request('delete', self.yara_ruleset_url, data=payload)
            logger.debug('Successfully deleted YARA ruleset: %s', ruleset_name)
            return data

        except requests.exceptions.HTTPError as e:
            logger.error('HTTP error deleting YARA ruleset: %s', e)
            error_detail = str(e)
            status_code = None
            if hasattr(e, 'response') and e.response is not None:
                status_code = e.response.status_code
                try:
                    error_body = e.response.text
                    logger.error('Response body: %s', error_body)
                    try:
                        error_json = e.response.json()
                        if isinstance(error_json, dict):
                            error_detail = error_json.get('message') or error_json.get('error') or _sanitize_error_response(error_body, status_code)
                        else:
                            error_detail = _sanitize_error_response(error_body, status_code)
                    except Exception:
                        error_detail = _sanitize_error_response(error_body, status_code)
                except Exception:
                    pass
            return {'success': False, 'error': error_detail, 'status_code': status_code}
        except requests.exceptions.RequestException as e:
            logger.error('Error deleting YARA ruleset: %s', e)
            return {'success': False, 'error': str(e)}
        except Exception as e:
            logger.error('Unexpected error deleting YARA ruleset: %s', e)
            return {'success': False, 'error': str(e)}

    def yara_enable_ruleset(self, ruleset_name: str) -> Optional[Dict[str, Any]]:
        """Enable a YARA ruleset.

        Args:
            ruleset_name: Name of the ruleset to enable

        Returns:
            Dictionary with operation result or None if error
        """
        try:
            payload = {'name': ruleset_name}
            logger.info('Enabling YARA ruleset: %s', ruleset_name)
            data = self.request('post', self.yara_ruleset_enable_url, data=payload)
            logger.debug('Successfully enabled YARA ruleset: %s', ruleset_name)
            return data

        except requests.exceptions.HTTPError as e:
            logger.error('HTTP error enabling YARA ruleset: %s', e)
            error_detail = str(e)
            status_code = None
            if hasattr(e, 'response') and e.response is not None:
                status_code = e.response.status_code
                try:
                    error_body = e.response.text
                    logger.error('Response body: %s', error_body)
                    try:
                        error_json = e.response.json()
                        if isinstance(error_json, dict):
                            error_detail = error_json.get('message') or error_json.get('error') or _sanitize_error_response(error_body, status_code)
                        else:
                            error_detail = _sanitize_error_response(error_body, status_code)
                    except Exception:
                        error_detail = _sanitize_error_response(error_body, status_code)
                except Exception:
                    pass
            return {'success': False, 'error': error_detail, 'status_code': status_code}
        except requests.exceptions.RequestException as e:
            logger.error('Error enabling YARA ruleset: %s', e)
            return {'success': False, 'error': str(e)}
        except Exception as e:
            logger.error('Unexpected error enabling YARA ruleset: %s', e)
            return {'success': False, 'error': str(e)}

    def yara_disable_ruleset(self, ruleset_name: str) -> Optional[Dict[str, Any]]:
        """Disable a YARA ruleset.

        Args:
            ruleset_name: Name of the ruleset to disable

        Returns:
            Dictionary with operation result or None if error
        """
        try:
            payload = {'name': ruleset_name}
            logger.info('Disabling YARA ruleset: %s', ruleset_name)
            data = self.request('post', self.yara_ruleset_disable_url, data=payload)
            logger.debug('Successfully disabled YARA ruleset: %s', ruleset_name)
            return data

        except requests.exceptions.HTTPError as e:
            logger.error('HTTP error disabling YARA ruleset: %s', e)
            error_detail = str(e)
            status_code = None
            if hasattr(e, 'response') and e.response is not None:
                status_code = e.response.status_code
                try:
                    error_body = e.response.text
                    logger.error('Response body: %s', error_body)
                    try:
                        error_json = e.response.json()
                        if isinstance(error_json, dict):
                            error_detail = error_json.get('message') or error_json.get('error') or _sanitize_error_response(error_body, status_code)
                        else:
                            error_detail = _sanitize_error_response(error_body, status_code)
                    except Exception:
                        error_detail = _sanitize_error_response(error_body, status_code)
                except Exception:
                    pass
            return {'success': False, 'error': error_detail, 'status_code': status_code}
        except requests.exceptions.RequestException as e:
            logger.error('Error disabling YARA ruleset: %s', e)
            return {'success': False, 'error': str(e)}
        except Exception as e:
            logger.error('Unexpected error disabling YARA ruleset: %s', e)
            return {'success': False, 'error': str(e)}

    def yara_get_matches(self, ruleset_name: str, page: int = 1, page_size: int = 100) -> Optional[Dict[str, Any]]:
        """Get YARA matches for a ruleset.

        Args:
            ruleset_name: Name of the ruleset to get matches for
            page: Page number for pagination
            page_size: Number of results per page

        Returns:
            Dictionary with match results or None if error
        """
        try:
            params = {'page': page, 'page_size': page_size, 'name': ruleset_name}

            logger.info('Fetching YARA matches for ruleset: %s', ruleset_name)
            data = self.get(self.yara_ruleset_matches_url, params=params)
            logger.debug('Retrieved %d YARA matches', data.get('count', 0))
            
            # Convert classification integers to human-readable strings
            if 'results' in data:
                for match in data['results']:
                    if 'classification' in match and isinstance(match['classification'], int):
                        riskscore = match.get('riskscore', 0)
                        match['classification'] = classification_to_string(match['classification'], riskscore)
            
            return data

        except requests.exceptions.HTTPError as e:
            logger.error('HTTP error fetching YARA matches: %s', e)
            error_detail = str(e)
            status_code = None
            if hasattr(e, 'response') and e.response is not None:
                status_code = e.response.status_code
                try:
                    error_body = e.response.text
                    logger.error('Response body: %s', error_body)
                    try:
                        error_json = e.response.json()
                        if isinstance(error_json, dict):
                            error_detail = error_json.get('message') or error_json.get('error') or _sanitize_error_response(error_body, status_code)
                        else:
                            error_detail = _sanitize_error_response(error_body, status_code)
                    except Exception:
                        error_detail = _sanitize_error_response(error_body, status_code)
                except Exception:
                    pass
            return {'success': False, 'error': error_detail, 'status_code': status_code}
        except requests.exceptions.RequestException as e:
            logger.error('Error fetching YARA matches: %s', e)
            return {'success': False, 'error': str(e)}
        except Exception as e:
            logger.error('Unexpected error fetching YARA matches: %s', e)
            return {'success': False, 'error': str(e)}

    def _yara_retrohunt_control(self, path: str, operation: str, context: str) -> Optional[Dict[str, Any]]:
        """Shared helper for retrohunt control operations.

        Args:
            path: API endpoint path
            operation: Operation to perform ('START', 'STOP', or 'CLEAR')
            context: Context string for logging

        Returns:
            Dictionary with operation result or None if error
        """
        try:
            payload = {'operation': operation}
            logger.info('%s operation: %s', context, operation)
            data = self.request('post', path, data=payload)
            logger.debug('%s %s successful', context, operation)
            return data

        except requests.exceptions.HTTPError as e:
            logger.error('HTTP error with %s operation %s: %s', context.lower(), operation, e)
            error_detail = str(e)
            status_code = None
            if hasattr(e, 'response') and e.response is not None:
                status_code = e.response.status_code
                try:
                    error_body = e.response.text
                    logger.error('Response status code: %s', status_code)
                    logger.error('Response body: %s', error_body)
                    try:
                        error_json = e.response.json()
                        logger.error('Response JSON: %s', error_json)
                        # Use the API's error message if available
                        if isinstance(error_json, dict):
                            error_detail = error_json.get('message') or error_json.get('error') or error_body
                        else:
                            error_detail = error_body
                    except Exception:
                        error_detail = error_body
                except Exception as parse_error:
                    logger.error('Could not parse error response: %s', parse_error)
            return {
                'success': False,
                'error': error_detail,
                'status_code': status_code
            }
        except requests.exceptions.RequestException as e:
            logger.error('Request error with %s operation %s: %s', context.lower(), operation, e)
            error_detail = str(e)
            status_code = None
            if hasattr(e, 'response') and e.response is not None:
                status_code = e.response.status_code
                try:
                    logger.error('Response status code: %s', status_code)
                    error_body = e.response.text
                    logger.error('Response body: %s', error_body)
                    error_detail = error_body
                except Exception:
                    pass
            return {
                'success': False,
                'error': error_detail,
                'status_code': status_code
            }
        except Exception as e:
            logger.error('Unexpected error with %s operation %s: %s', context.lower(), operation, e)
            return {
                'success': False,
                'error': str(e)
            }

    def _yara_retrohunt_status(self, path: str, context: str) -> Optional[Dict[str, Any]]:
        """Shared helper for retrohunt status checks.

        Args:
            path: API endpoint path
            context: Context string for logging

        Returns:
            Dictionary with retrohunt status or None if error
        """
        try:
            logger.info('Checking %s status', context)
            data = self.get(path=path)
            logger.debug('Retrieved %s status', context)
            return data

        except requests.exceptions.HTTPError as e:
            status_code = e.response.status_code if e.response is not None else None
            if status_code == 428:
                logger.info('%s has not been started yet (428 Precondition Required)', context)
                return {
                    'success': True,
                    'status': {
                        'state': 'NOT_STARTED',
                        'message': 'Retrohunt has not been started yet'
                    }
                }
            elif status_code == 412:
                logger.info('%s precondition failed - feature may not be available (412)', context)
                return {
                    'success': False,
                    'error': 'Cloud retrohunt feature not available. Ensure appliance is connected to Spectra Intelligence cloud.'
                }
            else:
                logger.error('HTTP error checking %s status: %s', context, e)
                logger.error('Response status code: %s', status_code)
                error_detail = str(e)
                try:
                    error_body = e.response.text
                    logger.error('Response body: %s', error_body)
                    try:
                        error_json = e.response.json()
                        logger.error('Response JSON: %s', error_json)
                        if isinstance(error_json, dict):
                            error_detail = error_json.get('message') or error_json.get('error') or error_body
                        else:
                            error_detail = error_body
                    except Exception:
                        error_detail = error_body
                except Exception as parse_error:
                    logger.error('Could not parse error response: %s', parse_error)
                return {
                    'success': False,
                    'error': error_detail,
                    'status_code': status_code
                }
        except requests.exceptions.RequestException as e:
            logger.error('Request error checking %s status: %s', context, e)
            error_detail = str(e)
            status_code = None
            if hasattr(e, 'response') and e.response is not None:
                status_code = e.response.status_code
                try:
                    logger.error('Response status code: %s', status_code)
                    error_body = e.response.text
                    logger.error('Response body: %s', error_body)
                    error_detail = error_body
                except Exception:
                    pass
            return {
                'success': False,
                'error': error_detail,
                'status_code': status_code
            }
        except Exception as e:
            logger.error('Unexpected error checking %s status: %s', context, e)
            return {
                'success': False,
                'error': str(e)
            }

    def yara_local_retrohunt_control(self, operation: str) -> Optional[Dict[str, Any]]:
        """Start or stop a local YARA retrohunt.

        Args:
            operation: Operation to perform ('START' or 'STOP')

        Returns:
            Dictionary with operation result or None if error
        """
        return self._yara_retrohunt_control(self.yara_local_retrohunt_url, operation, 'Local retrohunt')

    def yara_local_retrohunt_status(self) -> Optional[Dict[str, Any]]:
        """Get the status of local YARA retrohunt.

        Returns:
            Dictionary with retrohunt status or None if error
        """
        return self._yara_retrohunt_status(self.yara_local_retrohunt_url, 'local retrohunt')

    def yara_cloud_retrohunt_control(self, ruleset_name: str, operation: str) -> Optional[Dict[str, Any]]:
        """Start, stop, or clear a cloud YARA retrohunt for a ruleset.

        Args:
            ruleset_name: Name of the ruleset
            operation: Operation to perform ('START', 'STOP', or 'CLEAR')

        Returns:
            Dictionary with operation result or None if error
        """
        path = self.yara_cloud_retrohunt_url.format(ruleset_name=ruleset_name)
        return self._yara_retrohunt_control(path, operation, f'Cloud retrohunt for {ruleset_name}')

    def yara_cloud_retrohunt_status(self, ruleset_name: str) -> Optional[Dict[str, Any]]:
        """Get the status of cloud YARA retrohunt for a ruleset.

        Args:
            ruleset_name: Name of the ruleset

        Returns:
            Dictionary with retrohunt status or None if error
        """
        path = self.yara_cloud_retrohunt_url.format(ruleset_name=ruleset_name)
        return self._yara_retrohunt_status(path, f'cloud retrohunt for {ruleset_name}')

    def submit_url(self, url_to_submit: str, crawler: str = 'local',
                   analysis: Optional[Dict[str, Any]] = None) -> Optional[Dict[str, Any]]:
        """Submit a URL for crawling and analysis.

        Args:
            url_to_submit: URL to submit for analysis
            crawler: Crawler type ('local' or 'cloud', default: 'local')
            analysis: Optional analysis configuration dictionary

        Returns:
            Dictionary with submission details or None if error
        """
        try:
            endpoint = f'{self.base_url}{self.submit_url_url}'
            data = {'url': url_to_submit, 'crawler': crawler}
            if analysis:
                import json
                data['analysis'] = json.dumps(analysis)

            logger.info('Submitting URL to Spectra Analyze: %s', url_to_submit)
            response = requests.post(endpoint, data=data, headers=self.headers,
                                     verify=self.verify_ssl, timeout=self.timeout)
            response.raise_for_status()
            result = response.json()
            logger.info('URL submitted successfully: %s', url_to_submit)
            return result

        except requests.exceptions.HTTPError as e:
            logger.error('HTTP error submitting URL: %s', e)
            error_detail = str(e)
            status_code = None
            if hasattr(e, 'response') and e.response is not None:
                status_code = e.response.status_code
                try:
                    error_body = e.response.text
                    logger.error('Response body: %s', error_body)
                    error_detail = error_body
                    try:
                        error_json = e.response.json()
                        if isinstance(error_json, dict):
                            error_detail = error_json.get('message') or error_json.get('error') or error_body
                    except Exception:
                        pass
                except Exception:
                    pass
            return {'success': False, 'error': error_detail, 'status_code': status_code}
        except requests.exceptions.RequestException as e:
            logger.error('Error submitting URL: %s', e)
            error_detail = str(e)
            if hasattr(e, 'response') and e.response is not None:
                try:
                    error_detail = e.response.text
                    logger.error('Response body: %s', error_detail)
                except Exception:
                    pass
            return {'success': False, 'error': error_detail}
        except Exception as e:
            logger.error('Unexpected error submitting URL: %s', e)
            return {'success': False, 'error': str(e)}

    def reanalyze_bulk(self, hash_values: List[str], analysis_services: List[str],
                       rl_cloud_sandbox_platform: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """Reanalyze samples with selected analysis services.

        Args:
            hash_values: List of hash values (SHA1, SHA256, or MD5) to reanalyze
            analysis_services: List of analysis services to use. Supported values:
                - rl_auxiliary_analysis: RL Auxiliary Analysis service
                - core: Spectra Core static analysis
                - cloud: AV engines in Spectra Intelligence cloud
                - rl_cloud_sandbox: ReversingLabs Cloud Sandbox
                - cape: CAPE dynamic analysis
                - cisco_secure_malware_analytics: Cisco Secure Malware Analytics
                - cuckoo: Cuckoo Sandbox
                - fireeye: FireEye dynamic analysis
                - joe: Joe Sandbox
                - vmray_tcbase: VMRay dynamic analysis
            rl_cloud_sandbox_platform: Platform for RL Cloud Sandbox (windows7, windows10, windows11, macos_11, ubuntu_20)

        Returns:
            Dictionary with reanalysis results or None if error
        """
        try:
            endpoint = f'{self.base_url}{self.reanalyze_bulk_url}'
            payload = {
                'hash_value': hash_values,
                'analysis': ','.join(analysis_services)
            }
            if rl_cloud_sandbox_platform:
                payload['rl_cloud_sandbox_platform'] = rl_cloud_sandbox_platform

            logger.info('Submitting %d sample(s) for reanalysis with services: %s',
                       len(hash_values), ', '.join(analysis_services))
            response = requests.post(endpoint, json=payload, headers=self.headers,
                                   verify=self.verify_ssl, timeout=self.timeout)
            response.raise_for_status()
            result = response.json()
            logger.info('Reanalysis request submitted successfully')
            return result

        except requests.exceptions.HTTPError as e:
            logger.error('HTTP error submitting reanalysis request: %s', e)
            error_detail = str(e)
            status_code = None
            if hasattr(e, 'response') and e.response is not None:
                status_code = e.response.status_code
                try:
                    error_body = e.response.text
                    logger.error('Response body: %s', error_body)
                    error_detail = error_body
                    try:
                        error_json = e.response.json()
                        if isinstance(error_json, dict):
                            error_detail = error_json.get('message') or error_json.get('error') or error_body
                    except Exception:
                        pass
                except Exception:
                    pass
            return {'success': False, 'error': error_detail, 'status_code': status_code}
        except requests.exceptions.RequestException as e:
            logger.error('Error submitting reanalysis request: %s', e)
            error_detail = str(e)
            if hasattr(e, 'response') and e.response is not None:
                try:
                    error_detail = e.response.text
                    logger.error('Response body: %s', error_detail)
                except Exception:
                    pass
            return {'success': False, 'error': error_detail}
        except Exception as e:
            logger.error('Unexpected error submitting reanalysis request: %s', e)
            return {'success': False, 'error': str(e)}
