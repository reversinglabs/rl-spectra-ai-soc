import datetime
from datetime import timezone


def determine_hash_type(hash_value: str) -> str:
    """
    Determine hash type based on hash length
    """
    hash_len = len(hash_value.strip())
    if hash_len == 32:
        return 'md5'
    elif hash_len == 40:
        return 'sha1'
    elif hash_len == 64:
        return 'sha256'
    else:
        raise ValueError(f'Invalid hash length {hash_len}. Expected MD5 (32), SHA1 (40), or SHA256 (64) characters')


def is_sha1(hash_value: str) -> bool:
    """
    Check if hash is SHA1 format.

    Args:
        hash_value: Hash string to check

    Returns:
        True if hash is SHA1 format, False otherwise
    """
    hash_len = len(hash_value.strip())
    return hash_len == 40


def utc_now():
    return datetime.datetime.now(timezone.utc)


def get_year_ago():
    return datetime.datetime.now(timezone.utc) - datetime.timedelta(days=365)
