"""Spectra Intelligence (TICloud) API client."""

import logging
import requests
from typing import Optional, Dict, Any, List

logger = logging.getLogger(__name__)


class SpectraIntelligenceClient:
    """Client for Spectra Intelligence (TICloud) API interactions."""
    
    def __init__(self, credentials: Dict[str, Optional[str]]):
        """Initialize the Spectra Intelligence client.
        
        Args:
            credentials: Dictionary with api_url, api_user, api_token
        """
        self.api_url = credentials.get('api_url', '').rstrip('/')
        self.api_user = credentials.get('api_user')
        self.api_token = credentials.get('api_token')
        self.timeout = 30
        
        if not all([self.api_url, self.api_user, self.api_token]):
            raise ValueError('Invalid TICloud credentials provided')
            
        logger.debug('Initialized SpectraIntelligenceClient with api_url: %s', self.api_url)
    
    def _determine_hash_type(self, hash_value: str) -> str:
        """Determine hash type based on hash length.
        
        Args:
            hash_value: Hash string
            
        Returns:
            Hash type ('md5', 'sha1', or 'sha256')
        """
        hash_len = len(hash_value.strip())
        if hash_len == 32:
            return 'md5'
        elif hash_len == 40:
            return 'sha1'
        elif hash_len == 64:
            return 'sha256'
        else:
            # Default to sha256 if unknown
            logger.warning('Unknown hash length %d, defaulting to sha256', hash_len)
            return 'sha256'
    
    def get_file_reputation(self, hash_value: str) -> Optional[Dict[str, Any]]:
        """Get file reputation from TICloud (TCA-0101).
        
        Args:
            hash_value: File hash (SHA1, SHA256, or MD5)
            
        Returns:
            Reputation data dictionary or None if not found
        """
        try:
            url = f'{self.api_url}/api/databrowser/malware_presence/query/{hash_value}?format=json'
            logger.info('Fetching file reputation from Spectra Intelligence: %s', hash_value)
            
            response = requests.get(
                url,
                auth=(self.api_user, self.api_token),
                verify=True,
                timeout=self.timeout
            )
            response.raise_for_status()
            data = response.json()
            
            logger.debug('Successfully retrieved file reputation for %s', hash_value)
            return data
            
        except requests.exceptions.HTTPError as e:
            if e.response and e.response.status_code == 404:
                logger.info('File not found in Spectra Intelligence: %s', hash_value)
            else:
                logger.error('HTTP error fetching file reputation: %s', e)
            return None
        except requests.exceptions.RequestException as e:
            logger.error('Request error fetching file reputation: %s', e)
            return None
        except Exception as e:
            logger.error('Unexpected error fetching file reputation: %s', e)
            return None
    
    def get_file_analysis(self, hash_value: str) -> Optional[Dict[str, Any]]:
        """Get file analysis from TICloud (TCA-0104).
        
        Args:
            hash_value: File hash (MD5, SHA1, or SHA256)
            
        Returns:
            File analysis data dictionary or None if not found
        """
        try:
            # Determine hash algorithm based on length
            hash_clean = hash_value.strip().lower()
            if len(hash_clean) == 32:
                algo = 'md5'
            elif len(hash_clean) == 40:
                algo = 'sha1'
            elif len(hash_clean) == 64:
                algo = 'sha256'
            else:
                logger.error('Invalid hash length: %d', len(hash_clean))
                return None
            
            url = f'{self.api_url}/api/databrowser/rldata/query/{algo}/{hash_clean}?format=json'
            logger.info('Fetching file analysis from Spectra Intelligence TCA-0104: %s (algo: %s)', hash_clean, algo)
            
            response = requests.get(
                url,
                auth=(self.api_user, self.api_token),
                verify=True,
                timeout=self.timeout
            )
            response.raise_for_status()
            data = response.json()
            
            logger.debug('Successfully retrieved file analysis for %s', hash_clean)
            return data
            
        except requests.exceptions.HTTPError as e:
            if e.response and e.response.status_code == 404:
                logger.info('File not found in Spectra Intelligence TCA-0104: %s', hash_value)
            else:
                logger.error('HTTP error fetching file analysis: %s', e)
            return None
        except requests.exceptions.RequestException as e:
            logger.error('Request error fetching file analysis: %s', e)
            return None
        except Exception as e:
            logger.error('Unexpected error fetching file analysis: %s', e)
            return None
    
    def get_rca2(self, hash_value: str) -> Optional[Dict[str, Any]]:
        """Get RCA2 classification from TICloud (TCAI-0104).
        
        Args:
            hash_value: File hash (MD5, SHA1, or SHA256)
            
        Returns:
            RCA2 classification data dictionary or None if not found
        """
        try:
            # Determine hash algorithm based on length
            hash_clean = hash_value.strip().lower()
            if len(hash_clean) == 32:
                algo = 'md5'
            elif len(hash_clean) == 40:
                algo = 'sha1'
            elif len(hash_clean) == 64:
                algo = 'sha256'
            else:
                logger.error('Invalid hash length: %d', len(hash_clean))
                return None
            
            url = f'{self.api_url}/api/rca2/v1/query/{algo}/{hash_clean}?format=json'
            logger.info('Fetching RCA2 classification from Spectra Intelligence: %s (algo: %s)', hash_clean, algo)
            
            response = requests.get(
                url,
                auth=(self.api_user, self.api_token),
                verify=True,
                timeout=self.timeout
            )
            response.raise_for_status()
            data = response.json()
            
            logger.debug('Successfully retrieved RCA2 classification for %s', hash_clean)
            return data
            
        except requests.exceptions.HTTPError as e:
            if e.response and e.response.status_code == 404:
                logger.info('File not found in Spectra Intelligence RCA2: %s', hash_value)
            else:
                logger.error('HTTP error fetching RCA2 classification: %s', e)
            return None
        except requests.exceptions.RequestException as e:
            logger.error('Request error fetching RCA2 classification: %s', e)
            return None
        except Exception as e:
            logger.error('Unexpected error fetching RCA2 classification: %s', e)
            return None
    
    def get_dynamic_analysis(self, hash_value: str) -> Optional[Dict[str, Any]]:
        """Get dynamic analysis from TICloud (TCA-0106).
        
        Args:
            hash_value: File hash (SHA1, SHA256, or MD5)
            
        Returns:
            Dynamic analysis data dictionary or None if not found
        """
        try:
            # Determine hash type based on length
            hash_type = self._determine_hash_type(hash_value)
            url = f'{self.api_url}/api/dynamic/analysis/report/v1/query/{hash_type}/{hash_value}?format=json'
            logger.info('Fetching dynamic analysis from Spectra Intelligence: %s', hash_value)
            
            response = requests.get(
                url,
                auth=(self.api_user, self.api_token),
                verify=True,
                timeout=self.timeout
            )
            response.raise_for_status()
            data = response.json()
            
            logger.debug('Successfully retrieved dynamic analysis for %s', hash_value)
            return data
            
        except requests.exceptions.HTTPError as e:
            if e.response and e.response.status_code == 404:
                logger.info('Dynamic analysis not found in Spectra Intelligence: %s', hash_value)
            else:
                logger.error('HTTP error fetching dynamic analysis: %s', e)
            return None
        except requests.exceptions.RequestException as e:
            logger.error('Request error fetching dynamic analysis: %s', e)
            return None
        except Exception as e:
            logger.error('Unexpected error fetching dynamic analysis: %s', e)
            return None
    
    def get_rha1_analytics(self, hash_value: str, rha1_type: str) -> Optional[Dict[str, Any]]:
        """Get RHA1 analytics from TICloud (TCA-0321).
        
        Args:
            hash_value: SHA1, SHA256, or MD5 hash
            rha1_type: RHA1 precision level (pe01, pe02, elf01, macho01)
            
        Returns:
            RHA1 analytics data dictionary or None if not found
        """
        try:
            # Convert hash to SHA1 if needed
            sha1_hash = self._convert_hash_to_sha1(hash_value)
            if not sha1_hash:
                return None
            
            url = f'{self.api_url}/api/rha1/analytics/v1/query/{rha1_type}/{sha1_hash}?format=json'
            logger.info('Fetching RHA1 analytics from Spectra Intelligence: %s (type: %s)', sha1_hash, rha1_type)
            
            response = requests.get(
                url,
                auth=(self.api_user, self.api_token),
                verify=True,
                timeout=self.timeout
            )
            response.raise_for_status()
            data = response.json()
            
            logger.debug('Successfully retrieved RHA1 analytics for %s', sha1_hash)
            return data
            
        except requests.exceptions.HTTPError as e:
            if e.response and e.response.status_code == 404:
                logger.info('RHA1 analytics not found in Spectra Intelligence: %s', hash_value)
            else:
                logger.error('HTTP error fetching RHA1 analytics: %s', e)
            return None
        except requests.exceptions.RequestException as e:
            logger.error('Request error fetching RHA1 analytics: %s', e)
            return None
        except Exception as e:
            logger.error('Unexpected error fetching RHA1 analytics: %s', e)
            return None
    
    def advanced_search(self, query: str, sort: Optional[str] = None, limit: int = 1000) -> Optional[Dict[str, Any]]:
        """Perform advanced search in Spectra Intelligence (TCA-0320).
        
        Args:
            query: Search query string
            sort: Optional sort parameter
            limit: Maximum number of results to return (default: 1000)
            
        Returns:
            Search results dictionary with entries, total_count, and meta, or None if error
        """
        try:
            url = f'{self.api_url}/api/search/v1/query'
            payload = {
                'query': query,
                'format': 'json',
                'records_per_page': limit
            }
            
            if sort:
                payload['sort'] = sort
            
            logger.info('Performing advanced search in Spectra Intelligence: %s', query)
            
            response = requests.post(
                url,
                auth=(self.api_user, self.api_token),
                json=payload,
                verify=True,
                timeout=self.timeout
            )
            response.raise_for_status()
            data = response.json()
            
            # Parse response matching original implementation
            ws = data.get('rl', {}).get('web_search_api', {})
            entries = ws.get('entries', [])
            total_count = ws.get('total_count')
            
            result = {
                'search_api': {
                    'entries': entries,
                    'total_count': total_count if isinstance(total_count, int) else None
                }
            }
            
            logger.debug('Search returned %d results', len(entries))
            return result
            
        except requests.exceptions.RequestException as e:
            logger.error('Error performing advanced search: %s', e)
            return None
        except Exception as e:
            logger.error('Unexpected error performing advanced search: %s', e)
            return None
    
    def get_network_reputation(self, locations: List[str]) -> Optional[Dict[str, Any]]:
        """Get network reputation from TICloud (TCA-0407).
        
        Automatically batches requests into groups of 100 locations.
        
        Args:
            locations: List of URLs, domains, or IP addresses
            
        Returns:
            Network reputation data dictionary or None if error
        """
        try:
            if not locations:
                logger.debug('No network locations provided for reputation lookup')
                return None
            
            # Batch locations into groups of 100
            batch_size = 100
            batches = [locations[i:i + batch_size] for i in range(0, len(locations), batch_size)]
            
            logger.info('Fetching network reputation for %d locations in %d batch(es)', len(locations), len(batches))
            
            all_entries = []
            
            for batch_num, batch in enumerate(batches, 1):
                try:
                    url = f'{self.api_url}/api/networking/reputation/v1/query/json'
                    payload = {
                        'rl': {
                            'query': {
                                'network_locations': [
                                    {'network_location': loc} for loc in batch
                                ],
                                'response_format': 'json'
                            }
                        }
                    }
                    
                    logger.debug('Processing batch %d/%d with %d locations', batch_num, len(batches), len(batch))
                    
                    response = requests.post(
                        url,
                        auth=(self.api_user, self.api_token),
                        json=payload,
                        verify=True,
                        timeout=self.timeout
                    )
                    response.raise_for_status()
                    data = response.json()
                    
                    entries = data.get('rl', {}).get('entries', [])
                    all_entries.extend(entries)
                    
                    logger.debug('Batch %d/%d returned %d entries', batch_num, len(batches), len(entries))
                    
                except requests.exceptions.HTTPError as e:
                    logger.error('HTTP error on batch %d/%d: %s', batch_num, len(batches), e)
                    continue
                except Exception as e:
                    logger.error('Error on batch %d/%d: %s', batch_num, len(batches), e)
                    continue
            
            if all_entries:
                logger.info('Successfully retrieved network reputation for %d locations', len(all_entries))
                return {
                    'rl': {
                        'entries': all_entries
                    }
                }
            else:
                logger.warning('No entries returned from network reputation lookup')
                return None
                
        except Exception as e:
            logger.error('Unexpected error fetching network reputation: %s', e)
            return None
    
    def _convert_hash_to_sha1(self, hash_value: str) -> Optional[str]:
        """Convert MD5 or SHA256 hash to SHA1 using file reputation API.
        
        Args:
            hash_value: Hash to convert (SHA1, SHA256, or MD5)
            
        Returns:
            SHA1 hash or None if conversion failed
        """
        hash_clean = hash_value.strip().lower()
        hash_len = len(hash_clean)
        
        if hash_len == 40:
            # Already SHA1
            return hash_clean
        elif hash_len == 64 or hash_len == 32:
            # SHA256 or MD5 - need to convert
            logger.info('Converting %s to SHA1', "SHA256" if hash_len == 64 else "MD5")
            
            try:
                data = self.get_file_reputation(hash_clean)
                if data:
                    sha1 = data.get('rl', {}).get('sample', {}).get('sha1')
                    if sha1:
                        logger.debug('Converted %s to SHA1: %s', hash_value, sha1)
                        return sha1
                
                logger.error('Could not retrieve SHA1 for hash: %s', hash_value)
                return None
                
            except Exception as e:
                logger.error('Error converting hash to SHA1: %s', e)
                return None
        else:
            logger.error('Invalid hash format (expected SHA1, SHA256, or MD5): %s', hash_value)
            return None

