"""Spectra Intelligence credentials singleton for managing API access."""

import logging
import os
import subprocess
from pathlib import Path
from typing import Optional, Dict
from .config import get_config

logger = logging.getLogger(__name__)


class SpectraIntelligenceCredentials:
    """Singleton class to manage Spectra Intelligence credentials.
    
    Credentials are loaded once and cached for the lifetime of the application.
    """
    
    _instance = None
    _cfg = get_config()
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialized = False
        return cls._instance
    
    def __init__(self):
        if self._initialized:
            return
            
        self.api_url: Optional[str] = None
        self.api_user: Optional[str] = None
        self.api_token: Optional[str] = None
        self.is_available: bool = False
        
        self._load_credentials()
        self._initialized = True
    
    def _load_credentials(self):
        """Load Spectra Intelligence credentials from config or environment."""
        try:            
            # Check if we should use environment variables
            base_url = self._cfg.analyze_base_url
            
            if 'localhost' not in base_url and '127.0.0.1' not in base_url:
                # Use environment variables for non-localhost
                logger.info('Using environment variables for Spectra Intelligence credentials')
                self.api_url = os.getenv('TICLOUD_API_URL', 'https://data.reversinglabs.com')
                self.api_user = os.getenv('TICLOUD_API_USER')
                self.api_token = os.getenv('TICLOUD_API_TOKEN')
            else:
                # Running on localhost - retrieve from Django settings via tcbase
                settings_map = {
                    'api_url': 'TICLOUD_API_URL',
                    'api_user': 'TICLOUD_API_USER',
                    'api_token': 'TICLOUD_API_TOKEN'
                }
                owner = Path("/etc/tcbase").owner()
                
                for key, setting_name in settings_map.items():
                    try:
                        # Set up environment variables required by tcbase
                        env = os.environ.copy()
                        env['TCBASE_TYPE'] = 'a1000'
                        
                        cmd = [
                            '/usr/bin/sudo',
                            '-u',
                            owner,
                            '/usr/bin/tcbase',
                            'manage',
                            'shell',
                            '-c',
                            f'from django.conf import settings; print(settings.{setting_name})'
                        ]
                        result = subprocess.run(cmd, capture_output=True, text=True, timeout=5, env=env)
                        
                        if result.returncode == 0:
                            value = result.stdout.strip()
                            if value and value != 'None':
                                if key == 'api_url':
                                    self.api_url = value
                                elif key == 'api_user':
                                    self.api_user = value
                                elif key == 'api_token':
                                    self.api_token = value
                                
                                if key != 'api_token':
                                    logger.debug('Retrieved Spectra Intelligence %s: %s', key, value)
                            else:
                                logger.warning('Spectra Intelligence %s is not set or is None', setting_name)
                        else:
                            logger.error('Failed to retrieve %s: %s', setting_name, result.stderr)
                    except subprocess.TimeoutExpired:
                        logger.error('Timeout retrieving %s', setting_name)
                    except Exception as e:
                        logger.error('Error retrieving %s: %s', setting_name, e)
            
            # Validate credentials
            if all([self.api_url, self.api_user, self.api_token]):
                self.is_available = True
                logger.info('Spectra Intelligence credentials loaded successfully')
            else:
                logger.info('Spectra Intelligence credentials not available')
                
        except Exception as e:
            logger.error('Error loading Spectra Intelligence credentials: %s', e)
            self.is_available = False
    
    def is_available_for_use(self) -> bool:
        """Check if Spectra Intelligence credentials are available."""
        return self.is_available
    
    def get_credentials(self) -> Dict[str, Optional[str]]:
        """Get credentials as a dictionary."""
        return {
            'api_url': self.api_url,
            'api_user': self.api_user,
            'api_token': self.api_token
        }
    
    @classmethod
    def reset(cls):
        """Reset the singleton instance (useful for testing)."""
        cls._instance = None
