"""Token management for Spectra Analyze authentication."""
import logging
from contextvars import ContextVar
from dataclasses import dataclass, field
from typing import Optional, Dict
from threading import Lock

logger = logging.getLogger(__name__)

# Context variable to store the current bearer token for the request
current_bearer_token: ContextVar[Optional[str]] = ContextVar('current_bearer_token', default=None)


@dataclass
class TokenManager:
    """Manages authentication tokens for Spectra Analyze API.
    
    This manager supports both legacy tokens and OAuth auth contexts.
    For OAuth, it stores the appliance token for downstream API calls.
    """
    
    _token: Optional[str] = None
    _auth_contexts: Dict[str, 'AuthContext'] = field(default_factory=dict)
    _lock: Lock = field(default_factory=Lock)

    def set_token(self, token: str) -> None:
        """Set the authentication token (legacy mode).
        
        Args:
            token: Authentication token string
        """
        with self._lock:
            self._token = token

    def get_token(self) -> str:
        """Get the current authentication token (legacy mode).
        
        Returns:
            Token string, or empty string if not set
        """
        with self._lock:
            return self._token or ''
    
    def set_auth_context(self, bearer_token: str, auth_context: 'AuthContext') -> None:
        """Store auth context for a bearer token.
        
        This is used for OAuth to map bearer tokens to their auth contexts
        which contain the appliance token.
        
        Args:
            bearer_token: Original bearer token from client
            auth_context: Authentication context with appliance token
        """
        with self._lock:
            self._auth_contexts[bearer_token] = auth_context
    
    def get_auth_context(self, bearer_token: str) -> Optional['AuthContext']:
        """Get auth context for a bearer token.
        
        Args:
            bearer_token: Original bearer token from client
            
        Returns:
            AuthContext if found, None otherwise
        """
        with self._lock:
            return self._auth_contexts.get(bearer_token)
    
    def clear_context(self, bearer_token: str) -> None:
        """Clear stored auth context for a bearer token.
        
        Args:
            bearer_token: Bearer token to clear
        """
        with self._lock:
            if bearer_token in self._auth_contexts:
                del self._auth_contexts[bearer_token]


# Global singleton
token_manager = TokenManager()


def get_auth_headers(bearer_token: Optional[str] = None) -> dict:
    """Get authentication headers with a valid token.

    For OAuth (SA temporary JWT tokens): uses Bearer scheme.
    For Legacy (permanent opaque tokens): uses Token scheme.

    Args:
        bearer_token: Original bearer token (for OAuth lookup)

    Returns:
        Dictionary with Authorization header
    """
    if not bearer_token:
        bearer_token = current_bearer_token.get()

    if bearer_token:
        context = token_manager.get_auth_context(bearer_token)
        if context and context.appliance_token:
            return {"Authorization": f"Bearer {context.appliance_token}"}

    token = token_manager.get_token()
    return {"Authorization": f"Token {token}"}
