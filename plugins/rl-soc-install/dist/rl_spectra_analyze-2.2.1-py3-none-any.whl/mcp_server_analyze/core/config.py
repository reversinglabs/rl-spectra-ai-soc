"""Configuration management for Spectra Analyze MCP Server.

This module provides a centralized configuration class that reads all settings
from the config.ini file.
"""
import configparser
import logging
import os
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


class Config:
    """Configuration manager for the MCP server."""
    
    def __init__(self, config_file: Optional[Path] = None):
        """Initialize configuration.
        
        Args:
            config_file: Path to config.ini file. If None, looks in current working directory.
        """
        if config_file is None:
            # Default to config.ini in the current working directory
            cwd_config = Path('config.ini')
            config_file = cwd_config if cwd_config.exists() else Path('/etc/mcp-server-analyze/config.ini')
        
        self.config_file = config_file
        self._parser = configparser.ConfigParser()
        self._load()
    
    def _load(self) -> None:
        """Load configuration from INI file."""
        if self.config_file.exists():
            try:
                self._parser.read(self.config_file)
            except Exception as e:
                raise RuntimeError(f"Failed to read configuration file {self.config_file}: {e}")
    
    def reload(self) -> None:
        """Reload configuration from INI file."""
        self._parser.clear()
        self._load()
    
    def _get_bool(self, section: str, key: str, default: bool = False) -> bool:
        """Get a boolean value from config, with fallback to default."""
        try:
            return self._parser.getboolean(section, key)
        except (configparser.NoSectionError, configparser.NoOptionError, ValueError):
            return default
    
    def _get_str(self, section: str, key: str, default: str = '') -> str:
        """Get a string value from config, with fallback to default."""
        try:
            return self._parser.get(section, key)
        except (configparser.NoSectionError, configparser.NoOptionError):
            return default
    
    def _get_int(self, section: str, key: str, default: int = 0) -> int:
        """Get an integer value from config, with fallback to default."""
        try:
            return self._parser.getint(section, key)
        except (configparser.NoSectionError, configparser.NoOptionError, ValueError):
            return default
    
    # Spectra Analyze Configuration
    @property
    def analyze_base_url(self) -> str:
        """Get base URL for Spectra Analyze appliance."""
        return self._get_str('analyze_host', 'base_url', 'https://localhost/')
    
    @property
    def analyze_verify_ssl(self) -> bool:
        """Get SSL verification setting for Spectra Analyze."""
        return self._get_bool('analyze_host', 'verify_ssl', False)
    
    # MCP Server Configuration
    @property
    def mcp_host(self) -> str:
        """Get MCP server bind address."""
        return self._get_str('mcp_server', 'bind_addr', '0.0.0.0')
    
    @property
    def mcp_port(self) -> int:
        """Get MCP server bind port."""
        return self._get_int('mcp_server', 'bind_port', 8000)
    
    @property
    def mcp_transport(self) -> str:
        """Get MCP server transport type."""
        return self._get_str('mcp_server', 'transport', 'streamable-http')
    
    @property
    def mcp_path(self) -> str:
        """Get MCP server path."""
        return self._get_str('mcp_server', 'path', '/mcp')
    
    @property
    def mcp_public_url(self) -> str:
        """Get MCP server public URL for OAuth.

        Resolution order:
        1. `oauth.public_url` from config.ini (explicit admin override)
        2. `MCP_SERVER_PUBLIC_URL` env var (populated by SA's installer from
           tcbase.domain_name + server.protocol via /etc/sysconfig/mcp-server-analyze)
        3. Empty string (OAuth validation will fail)
        """
        return self._get_str('oauth', 'public_url', '') or os.environ.get('MCP_SERVER_PUBLIC_URL', '')
    
    # Logging Configuration
    @property
    def log_level(self) -> str:
        """Get log level as uppercase string."""
        return self._get_str('logging', 'loglevel', 'info').upper()
    
    @property
    def log_level_int(self) -> int:
        """Get log level as integer for logging module."""
        return logging._nameToLevel.get(self.log_level, logging.INFO)
    
    @property
    def save_raw_responses(self) -> bool:
        """Get whether to save raw API responses."""
        return self._get_bool('logging', 'save_raw_responses', True)
    
    # Authentication Configuration
    @property
    def enable_legacy_auth(self) -> bool:
        """Get whether legacy token authentication is enabled."""
        return self._get_bool('authentication', 'enable_legacy_auth', True)
    
    @property
    def enable_oauth_auth(self) -> bool:
        """Get whether OAuth authentication is enabled."""
        return self._get_bool('authentication', 'enable_oauth_auth', False)
    
    @property
    def keycloak_server(self) -> str:
        """Get Keycloak server base URL."""
        return self._get_str('oauth', 'keycloak_server', '')
    
    @property
    def keycloak_realm(self) -> str:
        """Get Keycloak realm name."""
        return self._get_str('oauth', 'keycloak_realm', '')
    
    @property
    def keycloak_appliance_token_endpoint_path(self) -> str:
        """Get Keycloak appliance token endpoint path."""
        return self._get_str('oauth', 'keycloak_appliance_token_endpoint_path', '')
    
    @property
    def keycloak_issuer(self) -> str:
        """Get Keycloak issuer URL.
        
        Built from keycloak_server and keycloak_realm.
        Example: http://10.200.186.111:8080/realms/mcp-spectraanalyze
        """
        if not self.keycloak_server or not self.keycloak_realm:
            return ''
        server = self.keycloak_server.rstrip('/')
        return f"{server}/realms/{self.keycloak_realm}"
    
    @property
    def keycloak_jwks_url(self) -> str:
        """Get Keycloak JWKS URL.
        
        Built from keycloak_issuer.
        Example: http://10.200.186.111:8080/realms/mcp-spectraanalyze/protocol/openid-connect/certs
        """
        if not self.keycloak_issuer:
            return ''
        return f"{self.keycloak_issuer}/protocol/openid-connect/certs"
    
    @property
    def keycloak_appliance_token_endpoint(self) -> str:
        """Get Keycloak appliance token endpoint.
        
        Built from keycloak_issuer and keycloak_appliance_token_endpoint_path.
        Example: http://10.200.186.111:8080/realms/mcp-spectraanalyze/appliance-token
        """
        if not self.keycloak_issuer or not self.keycloak_appliance_token_endpoint_path:
            return ''
        path = self.keycloak_appliance_token_endpoint_path.lstrip('/')
        return f"{self.keycloak_issuer}/{path}"
    
    @property
    def appliance_id(self) -> str:
        """Get appliance ID for OAuth audience validation.
        
        Uses mcp_public_url as the appliance ID since the MCP server
        runs on the appliance itself.
        """
        return self.mcp_public_url or ''
    
    @property
    def appliance_url(self) -> str:
        """Get appliance URL for token exchange.
        
        Uses mcp_public_url as the appliance URL since the MCP server
        runs on the appliance itself.
        """
        return self.mcp_public_url or ''
    
    @property
    def oauth_required_scopes(self) -> list:
        """Get required OAuth scopes."""
        scopes_str = self._get_str('oauth', 'required_scopes', '')
        return [s.strip() for s in scopes_str.split(',') if s.strip()]
    
    @property
    def appliance_token_cache_ttl(self) -> int:
        """Get appliance token cache TTL in seconds."""
        return self._get_int('oauth', 'appliance_token_cache_ttl', 3600)
    
    @property
    def appliance_token_refresh_skew(self) -> int:
        """Get appliance token refresh skew in seconds (refresh before expiry)."""
        return self._get_int('oauth', 'appliance_token_refresh_skew', 300)
    
    # Validation
    def validate(self) -> bool:
        """Validate that required configuration is present.
        
        Returns:
            True if configuration is valid
        """
        if not self.analyze_base_url:
            return False
        
        # Validate OAuth config if OAuth is enabled
        if self.enable_oauth_auth:
            if not self.keycloak_issuer:
                logger.error('OAuth enabled but keycloak_issuer not configured')
                return False
            if not self.keycloak_jwks_url:
                logger.error('OAuth enabled but keycloak_jwks_url not configured')
                return False
            if not self.keycloak_appliance_token_endpoint:
                logger.error('OAuth enabled but keycloak_appliance_token_endpoint not configured')
                return False
            if not self.appliance_id:
                logger.error('OAuth enabled but appliance_id not configured')
                return False
        
        # At least one auth method must be enabled
        if not self.enable_legacy_auth and not self.enable_oauth_auth:
            logger.error('At least one authentication method must be enabled')
            return False
        
        return True
    
    def get_config_file_path(self) -> Path:
        """Get the path to the configuration file.
        
        Returns:
            Path to config.ini
        """
        return self.config_file


# Global configuration instance
_config: Optional[Config] = None


def get_config() -> Config:
    """Get the global configuration instance.
    
    Returns:
        Config instance
    """
    global _config
    if _config is None:
        _config = Config()
    return _config


def reload_config() -> None:
    """Reload the global configuration from file."""
    global _config
    if _config is not None:
        _config.reload()
    else:
        _config = Config()
