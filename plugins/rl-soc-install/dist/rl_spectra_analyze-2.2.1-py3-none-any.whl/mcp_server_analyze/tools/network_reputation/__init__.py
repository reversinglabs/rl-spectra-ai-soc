"""Network reputation tool."""

from mcp_server_analyze.tools.network_reputation.network_reputation import register

__all__ = ['register']
