"""Network reputation tool for Spectra Analyze MCP Server."""
import time
import logging
import ssl
from datetime import datetime
from typing import Any, Dict, List, Annotated
from pydantic import Field
from mcp.types import ToolAnnotations

from mcp_server_analyze.core import get_config
from mcp_server_analyze.tools.base_tool import BaseMCPTool
from mcp_server_analyze.tools.tool_utils import save_report_data, compress_and_encode_data, geoip_for

logger = logging.getLogger(__name__)
config = get_config()

# Domain trust / exclusion sets
TRUSTED_DOMAINS = {
    "google.com", "cdn.jsdelivr.net", "cloudflare.com", "microsoft.com",
    "github.com", "akamai.net", "fastly.net"
}
URL_SHORTENERS = {
    "bit.ly", "t.co", "tinyurl.com", "goo.gl", "ow.ly", "is.gd", "buff.ly"
}
FILE_SHARING = {
    "drive.google.com", "docs.google.com", "dropbox.com", "sharefile.com",
    "we.tl", "mega.nz", "mediafire.com"
}

# Commercial vs free CAs (commonName)
COMMERCIAL_CAS = {
    "DigiCert Inc", "Sectigo Limited", "GlobalSign", "Amazon", "Baltimore CyberTrust Root",
    "Google Trust Services LLC", "GTS CA 1P5"
}
FREE_CAS = {
    "Let's Encrypt", "Cloudflare Inc ECC CA-3"
}

logger = logging.getLogger(__name__)


class NetworkReputationTool(BaseMCPTool):
    """Network reputation tool with class-based architecture."""

    
    def execute(self, indicator: str) -> Dict[str, Any]:
        """Execute network reputation lookup.
        
        Args:
            indicator: URL, domain, or IP address
            
        Returns:
            Network reputation report
        """
        report = {
            'indicator': indicator,
            'type': '',
            'risk': {
                'risk_score': 0,
                'risk_category': '',
                'verdict': ''
            },
            'third_party_reputations': {
                'total': 0,
                'undetected': 0,
                'malicious': 0,
                'suspicious': 0,
                'clean': 0
            },
            'associated_malware': False,
            'first_seen': '',
            'last_seen': '',
            'business_context': {
                'owner_organization': '',
                'country_iso': '',
                'country_name': '',
                'hosting_provider': ''
            },
            'geoip': {},
            'certificate': {},
        }

        start_time = time.time()
        logger.info('Starting network reputation lookup for indicator: %s', indicator)
        
        if not indicator:
            return {"error": "indicator is required"}
        
        # Use SpectraAnalyzeClient to get network reputation
        try:
            result = self.sa_client.get_network_reputation([indicator])
            
            if not result or not result.get('rl', {}).get('entries'):
                logger.error("Network reputation lookup failed for %s: No data returned", indicator)
                return {"error": f"Network reputation lookup failed for {indicator}: No data returned"}
            
            # Extract the entry for this indicator
            entries = result.get('rl', {}).get('entries', [])
            if not entries:
                logger.error("Network reputation lookup failed for %s: No entries in response", indicator)
                return {"error": f"Network reputation lookup failed for {indicator}: No entries in response"}
            
            entry = entries[0]
            indicator_type = entry.get('indicator_type', '')

            report['type'] = indicator_type
            report['third_party_reputations'] = entry.get('third_party_reputations', {})
        
        except Exception as lookup_err:
            logger.error("Network reputation lookup failed for %s: %s", indicator, lookup_err, exc_info=True)
            return {"error": f"Network reputation lookup failed for {indicator}: {lookup_err}"}
        
        geo = geoip_for(indicator)
        if geo:
            report["geoip"] = geo
            business_context = {
                "owner_organization": geo.get("as_org"),
                "country_iso": geo.get("country_iso"),
                "country_name": geo.get("country_name"),
                "hosting_provider": geo.get("as_org"),
            }
            report["business_context"] = {k: v for k, v in business_context.items() if v}

        # Automated risk score & verdict
        try:
            risk_score = 0
            rep = report.get("third_party_reputations", {}).get('statistics')
            total = rep.get("total", 0)
            malicious = rep.get("malicious", 0)
            suspicious_cnt = rep.get("suspicious", 0)
            clean_cnt = rep.get("clean", 0)

            # Prepare certificate info
            cert_info = None
            domain_only = indicator.lower().split("://")[-1].split("/")[0]
            if indicator_type in ("domain", "ip"):
                cert_info = self._fetch_cert_info(domain_only)

            # Enhanced risk model
            weight_malicious = 1.0
            weight_suspicious = 0.5
            weight_clean = -0.2

            if total:
                raw_score = (
                    (malicious * weight_malicious) +
                    (suspicious_cnt * weight_suspicious) +
                    (clean_cnt * weight_clean)
                ) / total
                risk_score = int(max(0, min(1, raw_score)) * 100)
            else:
                risk_score = 0

            # Check if malware has been downloaded from this resource
            dl_stats = entry.get('downloaded_files_statistics', None) or entry.get('analysis', {}).get('statistics', {})
            associated_malware = dl_stats.get('malicious', 0) > 0

            # Adjust for associated malware
            if associated_malware and risk_score < 50:
                risk_score = min(100, risk_score + 15)

            # Known trusted public DNS servers
            trusted_dns = {
                "8.8.8.8", "8.8.4.4",  # Google
                "1.1.1.1", "1.0.0.1",  # Cloudflare
                "9.9.9.9", "149.112.112.112"  # Quad9
            }

            # Whitelist adjustment
            if domain_only in TRUSTED_DOMAINS:
                risk_score = min(risk_score, 10)
            # Exclusion categories never below medium
            if domain_only in URL_SHORTENERS or domain_only in FILE_SHARING:
                risk_score = max(risk_score, 40)
            if indicator in trusted_dns:
                risk_score = 0
                associated_malware = False

            classification = entry.get("classification", '').lower()

            if indicator_type in ("domain", "ip") or classification is None or classification == 'unknown':
                if risk_score < 20:
                    risk_category = "low"
                    verdict = "benign_or_marketing"
                elif risk_score < 50:
                    risk_category = "medium"
                    verdict = "suspicious"
                else:
                    risk_category = "high"
                    verdict = "malicious"
            else:
                verdict = classification
                if classification == 'malicious':
                    risk_score = max(risk_score + 50, 100)
                    risk_category = 'high'
                elif classification == 'suspicious':
                    risk_score = max(risk_score + 20, 49)
                    risk_category = 'medium'
                elif classification == 'goodware':
                    risk_score = min(risk_score, 19)
                    risk_category = 'low'

            risk = {
                "risk_score": risk_score / 10,
                "risk_category": risk_category,
                "verdict": verdict,
            }

        except Exception as verdict_err:
            logger.error("Automated verdict generation failed: %s", verdict_err, exc_info=True)
            risk = {"risk_score": 0, "risk_category": "unknown", "verdict": "error"}

        report["risk"] = risk
        report['associated_malware'] = associated_malware
        report["first_seen"] = entry.get("first_seen", '')
        report["last_seen"] = entry.get("last_seen", '')
        # Add LLM guidance if available
        try:
            from mcp_server_analyze.prompts.llm_guidance import get_llm_guidance
            report["llm_prompt"] = get_llm_guidance('get_network_reputation')
        except ImportError:
            pass

        end_time = time.time()
        logger.info('Network reputation lookup completed in %.2fs', end_time - start_time)

        # Save report data for debugging
        save_report_data('get_network_reputation', result, report)
        return compress_and_encode_data(report)


class BulkNetworkReputationTool(BaseMCPTool):
    """Bulk network reputation tool.

    Looks up many indicators in one call and returns the third-party reputation
    data (classification, per-source detections and statistics) as provided by
    the Spectra Analyze API for each one. Unlike ``get_network_reputation`` it
    skips the per-host GeoIP/SSL-certificate enrichment so bulk lookups stay fast.
    """

    # Upper bound on indicators accepted in a single call.
    MAXIMUM_NUMBER_OF_INDICATORS = 100

    @staticmethod
    def _statistics(entry: Dict[str, Any]) -> Dict[str, int]:
        """Normalize the third-party reputation statistics for an entry."""
        stats = entry.get('third_party_reputations') or {}
        return {
            'total': stats.get('total', 0),
            'undetected': stats.get('undetected', 0),
            'malicious': stats.get('malicious', 0),
            'suspicious': stats.get('suspicious', 0),
            'clean': stats.get('clean', 0),
        }

    def execute(self, indicators: List[str]) -> Dict[str, Any]:
        """Execute a bulk network reputation lookup.

        Each requested indicator gets its own result entry. A failed lookup does
        not prevent the others from being returned; the failing entry carries an
        ``error`` field instead of reputation data.

        Args:
            indicators: List of URLs, domains, or IP addresses

        Returns:
            Bulk network reputation report with one result per requested indicator
        """
        start_time = time.time()

        if not indicators:
            return {"error": "indicators is required"}

        if len(indicators) > self.MAXIMUM_NUMBER_OF_INDICATORS:
            logger.warning(
                'Received %d indicators for bulk network reputation lookup. Limiting to first %d.',
                len(indicators), self.MAXIMUM_NUMBER_OF_INDICATORS
            )
            indicators = indicators[:self.MAXIMUM_NUMBER_OF_INDICATORS]

        logger.info('Starting bulk network reputation lookup for %d indicator(s)', len(indicators))

        try:
            result = self.sa_client.get_network_reputations_bulk(indicators)
        except Exception as lookup_err:
            logger.error('Bulk network reputation lookup failed: %s', lookup_err, exc_info=True)
            result = None

        entries = (result or {}).get('rl', {}).get('entries', [])
        by_location = {entry.get('requested_network_location', ''): entry for entry in entries}

        reports = []
        for indicator in indicators:
            entry = by_location.get(indicator)
            if entry is None:
                reports.append({
                    'requested_network_location': indicator,
                    'error': 'No reputation data returned',
                })
                continue

            reports.append({
                'requested_network_location': indicator,
                'first_seen': entry.get('first_seen', ''),
                'last_seen': entry.get('last_seen', ''),
                'third_party_reputations': self._statistics(entry),
                'classification': entry.get('classification', ''),
            })

        report = {
            'requested': len(indicators),
            'returned': len(entries),
            'results': reports,
        }

        logger.info('Bulk network reputation lookup completed in %.2fs', time.time() - start_time)

        save_report_data('bulk_network_reputation_lookup', result, report)
        return report


def register(mcp):
    """Register the network reputation tool with the MCP server."""
    @mcp.tool(
        annotations=ToolAnnotations(
            title="Get Network Reputation for a URL, domain or IP address",
            readOnlyHint=True,
            destructiveHint=False,
            idempotentHint=True,
            openWorldHint=True,
        ),
    )
    def get_network_reputation(
            indicator: Annotated[
                str,
                Field(description="URL, domain, or IP address")
            ]
    ) -> Dict[str, Any]:
        """
        Get Network reputation for a URL, domain, or IP address
        """
        tool = NetworkReputationTool(
            sa_base_url=config.analyze_base_url,
            sa_verify_ssl=config.analyze_verify_ssl
        )
        return tool.execute(indicator)

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Bulk Network Reputation lookup for URLs, domains or IP addresses",
            readOnlyHint=True,
            destructiveHint=False,
            idempotentHint=True,
            openWorldHint=True,
        ),
    )
    def bulk_network_reputation_lookup(
            indicators: Annotated[
                List[str],
                Field(description="List of URLs, domains, or IP addresses (max 100)")
            ]
    ) -> Dict[str, Any]:
        """
        Get network reputation for multiple URLs, domains, or IP addresses in a single bulk lookup.
        """
        tool = BulkNetworkReputationTool(
            sa_base_url=config.analyze_base_url,
            sa_verify_ssl=config.analyze_verify_ssl
        )
        return tool.execute(indicators)
