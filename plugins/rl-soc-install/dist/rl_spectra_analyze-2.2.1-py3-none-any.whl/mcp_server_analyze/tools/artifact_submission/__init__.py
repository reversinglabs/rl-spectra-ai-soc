"""Artifact submission tools for files and URLs."""

from mcp_server_analyze.tools.artifact_submission.artifact_submission import register

__all__ = ['register']
