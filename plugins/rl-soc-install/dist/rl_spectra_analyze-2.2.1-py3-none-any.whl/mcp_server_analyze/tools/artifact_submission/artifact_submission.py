"""Artifact submission tools for Spectra Analyze MCP Server.

Supports submitting URLs for analysis and starting dynamic/auxiliary analysis.
"""
import logging
from typing import Any, Dict, Annotated, Optional
from pydantic import Field
from mcp.types import ToolAnnotations

from mcp_server_analyze.core import get_config
from mcp_server_analyze.tools.base_tool import BaseMCPTool

logger = logging.getLogger(__name__)

# Map Spectra Intelligence-facing platform names (the tool's public interface)
# to the values the Spectra Analyze reanalyze_bulk API accepts as input.
PLATFORM_MAP = {
    'windows7': 'windows7',
    'windows10': 'windows10',
    'windows11': 'windows11',
    'macos11': 'macos_11',
    'linux': 'linux',
}


class DynamicAnalysisTool(BaseMCPTool):
    """Tool for starting dynamic analysis on existing samples."""
    
    def execute(self, hash_values: list, sandbox: str = 'rl_cloud_sandbox',
               platform: str = 'windows11') -> Dict[str, Any]:
        """Start dynamic analysis on samples.
        
        Args:
            hash_values: List of hash values (SHA1, SHA256, or MD5) to analyze
            sandbox: Sandbox to use (rl_cloud_sandbox, cape, cuckoo, fireeye, joe, vmray_tcbase, cisco_secure_malware_analytics)
            platform: Platform for analysis (windows7, windows10, windows11, macos11, linux)
                     Note: Platform selection is only supported for rl_cloud_sandbox.
            
        Returns:
            Dictionary with analysis results
        """
        try:
            # Validate platform parameter - only supported for rl_cloud_sandbox
            if platform != 'windows11' and sandbox != 'rl_cloud_sandbox':
                return {
                    "success": False,
                    "error": f"Platform selection is only supported for rl_cloud_sandbox. Cannot use platform '{platform}' with sandbox '{sandbox}'."
                }

            # Verify the sample exists on the local appliance before submitting for
            # dynamic analysis. The reanalyze_bulk API silently returns empty results
            # for hashes that are not present locally.
            for hash_value in hash_values:
                reputation = self.sa_client.get_file_reputation(hash_value)
                if not reputation or reputation.get('count', 0) == 0:
                    return {
                        "success": False,
                        "error": (
                            f"Sample {hash_value} was not found on the local Spectra Analyze "
                            "appliance. Dynamic analysis requires the sample to be present locally."
                        )
                    }
            rl_cloud_sandbox_platform = None
            if sandbox == 'rl_cloud_sandbox':
                #map SI name to SA name and if not to the platform name given for new platforms 
                rl_cloud_sandbox_platform = PLATFORM_MAP.get(platform, platform)

            result = self.sa_client.reanalyze_bulk(
                hash_values=hash_values,
                analysis_services=[sandbox],
                rl_cloud_sandbox_platform=rl_cloud_sandbox_platform
            )
            
            if not result:
                return {
                    "success": False,
                    "error": "Failed to start dynamic analysis"
                }
            
            if result.get('success') is False or 'error' in result:
                return {
                    "success": False,
                    "error": result.get('error', 'Failed to start dynamic analysis'),
                    "status_code": result.get('status_code')
                }
            
            # Parse results
            results_list = result.get('results', [])
            return {
                "success": True,
                "message": f"Dynamic analysis started for {len(results_list)} sample(s)",
                "results": results_list
            }
            
        except Exception as e:
            logger.error('Error starting dynamic analysis: %s', e)
            return {
                "success": False,
                "error": str(e)
            }


class AuxiliaryAnalysisTool(BaseMCPTool):
    """Tool for starting auxiliary analysis on existing samples."""
    
    def execute(self, hash_values: list) -> Dict[str, Any]:
        """Start auxiliary analysis on samples.

        Args:
            hash_values: List of hash values (SHA1, SHA256, or MD5) to analyze

        Returns:
            Dictionary with analysis results
        """
        try:
            # Verify the sample exists on the local appliance before submitting for
            # auxiliary analysis. The reanalyze_bulk API silently returns empty results
            # for hashes that are not present locally.
            for hash_value in hash_values:
                reputation = self.sa_client.get_file_reputation(hash_value)
                if not reputation or reputation.get('count', 0) == 0:
                    return {
                        "success": False,
                        "error": (
                            f"Sample {hash_value} was not found on the local Spectra Analyze "
                            "appliance. Auxiliary analysis requires the sample to be present locally."
                        )
                    }

            result = self.sa_client.reanalyze_bulk(
                hash_values=hash_values,
                analysis_services=['rl_auxiliary_analysis']
            )
            
            if not result:
                return {
                    "success": False,
                    "error": "Failed to start auxiliary analysis"
                }
            
            if result.get('success') is False or 'error' in result:
                return {
                    "success": False,
                    "error": result.get('error', 'Failed to start auxiliary analysis'),
                    "status_code": result.get('status_code')
                }
            
            # Parse results
            results_list = result.get('results', [])
            return {
                "success": True,
                "message": f"Auxiliary analysis started for {len(results_list)} sample(s)",
                "results": results_list
            }
            
        except Exception as e:
            logger.error('Error starting auxiliary analysis: %s', e)
            return {
                "success": False,
                "error": str(e)
            }


class DynamicStatusTool(BaseMCPTool):
    """Tool for checking whether a sample's dynamic analysis has completed."""
    
    FINISHED_STATUS_CODE = 24000

    def execute(self, hash_value: str) -> Dict[str, Any]:
        """Check the status of a dynamic (sandbox) analysis run.

        Args:
            hash_value: Hash value (SHA1, SHA256, or MD5) of the sample

        Returns:
            Dictionary with ``status`` (``finished`` or ``not_ready``) 
        """
        try:
            logger.info('get_dynamic_analysis_status: checking dynamic analysis for %s', hash_value)

            data = self.sa_client.get_dynamic_analysis_status(hash_value)

            # No status record for a sample that may have never been submitted
            if not data:
                return {
                    "hash": hash_value,
                    "status": "not_ready/never_ran",
                    "message": (
                        "No dynamic analysis status is available yet. The run may "
                        "still be queued or in progress, or was never started."
                    ),
                }

            status_message = data.get('status_message')
            finished = data.get('status_code') == self.FINISHED_STATUS_CODE

            return {
                "hash": hash_value,
                "status": "finished" if finished else "not_ready",
                "message": (
                    "dynamic analysis report is ready"
                    if finished
                    else f"dynamic analysis is not ready yet (status: {status_message})"
                ),
                "last_analysis_id": data.get('last_analysis_id'),
                "created": data.get('created'),
                "changed": data.get('changed'),
            }

        except Exception as e:
            logger.error('Error checking dynamic analysis status: %s', e)
            return {
                "success": False,
                "error": str(e)
            }


class URLUploadTool(BaseMCPTool):
    """Tool for submitting URLs to Spectra Analyze."""
    
    def execute(self, url: str, crawler: str = 'local',
               start_dynamic_analysis: bool = False,
               dynamic_platform: Optional[str] = None) -> Dict[str, Any]:
        """Submit a URL for crawling and analysis.
        
        Args:
            url: URL to submit for analysis
            crawler: Crawler type ('local' or 'cloud')
            start_dynamic_analysis: Start ReversingLabs dynamic analysis
            dynamic_platform: Platform for dynamic analysis
            
        Returns:
            Dictionary with submission result
        """
        try:
            # Build analysis configuration
            analysis = None
            if start_dynamic_analysis:
                analysis = {
                    'rl_dynamic_analysis': {}
                }
                if dynamic_platform:
                    analysis['rl_dynamic_analysis']['platform'] = dynamic_platform
            
            result = self.sa_client.submit_url(
                url_to_submit=url,
                crawler=crawler,
                analysis=analysis
            )
            
            if not result:
                return {
                    "success": False,
                    "error": "Failed to submit URL for analysis"
                }
            
            if result.get('success') is False or 'error' in result:
                return {
                    "success": False,
                    "error": result.get('error', 'Failed to submit URL for analysis'),
                    "status_code": result.get('status_code')
                }
            
            detail = result.get('detail', {})
            return {
                "success": True,
                "message": result.get('message', 'URL submitted successfully'),
                "submission_id": detail.get('id'),
                "sha1": detail.get('sha1'),
                "filename": detail.get('filename'),
                "created": detail.get('created')
            }
            
        except Exception as e:
            logger.error('Error submitting URL: %s', e)
            return {
                "success": False,
                "error": str(e)
            }


def register(mcp):
    """Register artifact submission tools with the MCP server."""

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Submit URL",
            readOnlyHint=False,
            destructiveHint=False,
            idempotentHint=False,
            openWorldHint=True,
        ),
    )
    def submit_url(
            url: Annotated[
                str,
                Field(description="URL to submit for crawling and analysis", min_length=1)
            ],
            crawler: Annotated[
                str,
                Field(description="Crawler type: 'local' or 'cloud'")
            ] = 'local',
            start_dynamic_analysis: Annotated[
                bool,
                Field(description="Start ReversingLabs dynamic analysis for the downloaded content")
            ] = False,
            dynamic_platform: Annotated[
                Optional[str],
                Field(description="Platform for dynamic analysis: windows7, windows10, windows11, macos_11, linux")
            ] = None
    ) -> Dict[str, Any]:
        """
        Submit a URL to Spectra Analyze for crawling and analysis.
        
        The URL will be crawled and downloaded content will be analyzed as a ZIP archive.
        Optionally start dynamic analysis for the downloaded content.
        
        Crawler types:
        - local: Use appliance's local crawler
        - cloud: Use cloud-based crawler
        """
        config = get_config()
        tool = URLUploadTool(
            sa_base_url=config.analyze_base_url,
            sa_verify_ssl=config.analyze_verify_ssl
        )
        return tool.execute(
            url=url,
            crawler=crawler,
            start_dynamic_analysis=start_dynamic_analysis,
            dynamic_platform=dynamic_platform
        )
    
    @mcp.tool(
        annotations=ToolAnnotations(
            title="Start Dynamic Analysis",
            readOnlyHint=False,
            destructiveHint=False,
            idempotentHint=False,
            openWorldHint=True,
        ),
    )
    def start_dynamic_analysis(
            hash_value: Annotated[
                str,
                Field(description="Hash value (SHA1, SHA256, or MD5) of the sample to analyze")
            ],
            sandbox: Annotated[
                str,
                Field(description="Sandbox to use: rl_cloud_sandbox (default), cape, cuckoo, fireeye, joe, vmray_tcbase, cisco_secure_malware_analytics")
            ] = 'rl_cloud_sandbox',
            platform: Annotated[
                str,
                Field(description="Platform for analysis: windows7, windows10, windows11 (default), macos11, linux")
            ] = 'windows11'
    ) -> Dict[str, Any]:
        """
        Start dynamic analysis (sandbox execution) on an existing sample.
        
        Submits a sample that already exists on the Spectra Analyze appliance for dynamic analysis
        in the specified sandbox environment.
        
        **Default sandbox**: rl_cloud_sandbox (ReversingLabs Cloud Sandbox)
        **Default platform**: windows11
        
        **Supported sandboxes**:
        - rl_cloud_sandbox: ReversingLabs Cloud Sandbox (supports platform selection)
        - cape: CAPE Sandbox
        - cuckoo: Cuckoo Sandbox
        - fireeye: FireEye dynamic analysis
        - joe: Joe Sandbox
        - vmray_tcbase: VMRay dynamic analysis
        - cisco_secure_malware_analytics: Cisco Secure Malware Analytics
        
        **Note**: Third-party sandboxes (cape, cuckoo, fireeye, joe, vmray_tcbase, cisco_secure_malware_analytics)
        must be pre-configured on the Spectra Analyze instance before use.
        
        **Supported platforms** (for rl_cloud_sandbox):
            - windows11, windows10, windows7, macos11, linux
        
        Returns the analysis queue status for the submitted sample.
        """
        # Note supported platforms match what intelligence has and we do mapping to what
        # analyze actually accepts as input 
        config = get_config()
        tool = DynamicAnalysisTool(
            sa_base_url=config.analyze_base_url,
            sa_verify_ssl=config.analyze_verify_ssl
        )
        return tool.execute(
            hash_values=[hash_value],
            sandbox=sandbox,
            platform=platform
        )

    @mcp.tool(
        annotations=ToolAnnotations(
            title='Get Dynamic Analysis Status',
            readOnlyHint=True,
            destructiveHint=False,
            idempotentHint=True,
            openWorldHint=True,
        ),
    )
    def get_dynamic_analysis_status(
            hash_value: Annotated[
                str,
                Field(description="Hash value (SHA1, SHA256, or MD5) of the submitted sample")
            ]
    ) -> Dict[str, Any]:
        """
        Poll the status of a dynamic (sandbox) analysis run, e.g. after
        ``start_dynamic_analysis`` or submitting a file/URL with dynamic
        analysis enabled.

        Returns ``status``:
        - ``finished``: report ready (``status_code`` 24000 / ``reported``);
          fetch full behavioral data with ``get_sample_behavior``.
        - ``not_ready``: still queued/running (e.g. ``reanalyzing``), or never
          started.
        """
        config = get_config()
        tool = DynamicStatusTool(
            sa_base_url=config.analyze_base_url,
            sa_verify_ssl=config.analyze_verify_ssl
        )
        return tool.execute(hash_value=hash_value)

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Start Auxiliary Analysis",
            readOnlyHint=False,
            destructiveHint=False,
            idempotentHint=False,
            openWorldHint=True,
        ),
    )
    def start_auxiliary_analysis(
            hash_value: Annotated[
                str,
                Field(description="Hash value (SHA1, SHA256, or MD5) of the sample to analyze")
            ]
    ) -> Dict[str, Any]:
        """
        Start auxiliary analysis on an existing sample.
        
        Submits a sample that already exists on the Spectra Analyze appliance for ReversingLabs
        Auxiliary Analysis, which provides deep binary analysis and deobfuscation.
        
        **What is Auxiliary Analysis?**
        ReversingLabs Auxiliary Analysis performs advanced static analysis including:
        - Deep binary unpacking and deobfuscation
        - Advanced code analysis
        - Behavioral pattern detection
        - Additional threat intelligence extraction
        
        This analysis complements the standard static analysis and can reveal hidden threats
        or provide additional context about the sample's behavior and capabilities.
        
        Returns the analysis queue status for the submitted sample.
        """
        config = get_config()
        tool = AuxiliaryAnalysisTool(
            sa_base_url=config.analyze_base_url,
            sa_verify_ssl=config.analyze_verify_ssl
        )
        return tool.execute(hash_values=[hash_value])
