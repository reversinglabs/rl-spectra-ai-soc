"""Advanced search tool."""

from mcp_server_analyze.tools.search.search import register

__all__ = ['register']
