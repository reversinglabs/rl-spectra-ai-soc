"""Advanced search tool for Spectra Analyze MCP Server."""
import logging
import math
from typing import Any, Dict, Annotated, Literal, Optional
from pydantic import Field
from mcp.types import ToolAnnotations

from mcp_server_analyze.core import get_config
from mcp_server_analyze.tools.base_tool import BaseMCPTool
from mcp_server_analyze.tools.tool_utils import save_report_data, compress_and_encode_data
from mcp_server_analyze.prompts.llm_guidance import get_llm_guidance

logger = logging.getLogger(__name__)
config = get_config()


class AdvancedSearchTool(BaseMCPTool):
    """Advanced search tool with class-based architecture."""

    def execute(self, query: str, sort: str, instance = "local", limit: int = 10,
                page: Optional[int] = None,
                start_search_date: Optional[str] = None,
                end_search_date: Optional[str] = None) -> Dict[str, Any]:
        if not query:
            raise ValueError("query is required")

        if not page or page < 1:
            page = 1

        ticloud = instance == "cloud"

        try:
            logger.debug('Using Spectra Intelligence for advanced search')
            result = self.sa_client.advanced_search(
                query, sort=sort, limit=limit, ticloud=ticloud, page=page,
                start_search_date=start_search_date, end_search_date=end_search_date)
            if not (result or {}).get('search_api', {}).get('total_count'):
                logger.debug('Using Spectra Analyze for advanced search')
                result = self.sa_client.advanced_search(
                    query, sort=sort, limit=limit, ticloud=ticloud, page=page,
                    start_search_date=start_search_date, end_search_date=end_search_date)

            if not result:
                error_msg = f"Advanced Search API call failed: likely due to invalid query (query: {query})"
                logger.error(error_msg)
                error_result = {
                    "query": query,
                    "total_results": 0,
                    "error": error_msg,
                    # inject reference guidance upon empty response to prevent 
                    # unnecessary usage of tokens with large response
                    "llm_prompt": get_llm_guidance('advanced_search_reference')
                }
                save_report_data('advanced_search', error_result, error_result)
                return compress_and_encode_data(error_result)

            # Filter fields to save
            new_entries = []
            fields_to_save = [
                'sha1', 'sha256', 'md5', 'threatname', 'rca2_av_threat_name',
                'sample_type', 'sampletype', 'first_seen', 'firstseen',
                'imphash', 'rha1_pe01', 'sample_size', 'classification',
                'last_seen', 'lastseen'
            ]

            entries = result.get('search_api', {}).get('entries', None)

            if entries:
                for entry in entries:
                    new_entry = {}
                    for key, val in entry.items():
                        if key in fields_to_save:
                            new_entry[key] = val
                    new_entries.append(new_entry)

                result['search_api']['entries'] = new_entries

            search_api = result.get('search_api', {})
            total_count = search_api.get('total_count')
            search_api['current_page'] = page
            search_api['records_per_page'] = limit
            if isinstance(total_count, int) and limit > 0:
                search_api['total_pages'] = max(1, math.ceil(total_count / limit))
            else:
                search_api['total_pages'] = None
            result['search_api'] = search_api

            save_report_data('advanced_search', result, result)
            return compress_and_encode_data(result)

        except Exception as e:
            error_msg = f"Advanced Search API call failed: {str(e)} (query: {query})"
            logger.error(error_msg)
            error_result = {
                "query": query,
                "total_results": 0,
                "error": error_msg,
                "llm_prompt": get_llm_guidance('advanced_search_reference')
            }
            save_report_data('advanced_search', error_result, error_result)
            return compress_and_encode_data(error_result)


def register(mcp):
    tool = AdvancedSearchTool(sa_base_url=config.analyze_base_url, sa_verify_ssl=config.analyze_verify_ssl)

    tool_description = (
        "Search malware samples on the Spectra Analyze appliance using Solr query syntax. "
        "Use instance='local' for the on-prem appliance, instance='cloud' for Spectra Intelligence. "
        "Local-only fields: submission-analyzer, dropped-files-containers, submission-user, "
        "tag-user, upload-source, upload-source-tag, upload-data, filecount, processing-status."
    )

    date_preamble = (
        f"CRITICAL: Prefer shorthand for dates — it never goes stale. "
        f"`+` = from N units ago to now (recent); `-` = older than N units ago. "
        f"Examples: firstseen:30d+ (last 30 days), firstseen:7d+ (last 7 days), firstseen:1y- (older than 1 year).\n"
        f"Only use ISO 8601 exact ranges when the user specifies a precise date boundary.\n\n"
    )

    query_description = date_preamble + get_llm_guidance('advanced_search')

    @mcp.tool(
        description=tool_description,
        annotations=ToolAnnotations(
            title="Advanced Search",
            readOnlyHint=True,
            destructiveHint=False,
            idempotentHint=True,
            openWorldHint=True,
        ),
    )
    def advanced_search(
            query: Annotated[str, Field(description=query_description)],
            instance: Annotated[Optional[Literal["local", "cloud"]], Field(description=(
                "Search scope. 'local' queries the on-prem Spectra Analyze appliance. "
                "'cloud' queries Spectra Intelligence. Defaults to 'local' if omitted. "
            ))] = None,
            sort: Optional[str] = None,
            limit: Annotated[int, Field(description=(
                "Results per page (default: 10, max: 100). "
                "The response includes total_count, current_page and total_pages "
                "so you can page through the full result set."
            ))] = 10,
            page: Annotated[Optional[int], Field(description=(
                "Optional. 1-based page number for paginating large result sets "
                "(defaults to 1 if omitted). Use total_pages from the response to know "
                "how many pages exist, and increment page to fetch subsequent pages."
            ))] = None,
            start_search_date: Annotated[Optional[str], Field(description=(
                "Spectra Intelligence only (instance='cloud'). Lower bound of the search time range as "
                "YYYY-MM-DD. Defaults to one year ago if omitted."
            ))] = None,
            end_search_date: Annotated[Optional[str], Field(description=(
                "Spectra Intelligence only (instance='cloud'). Upper bound of the search time range as "
                "YYYY-MM-DD. Defaults to now if omitted."
            ))] = None
    ) -> Dict[str, Any]:
        """Perform an advanced search of malware samples."""
        return tool.execute(query=query, instance=instance, limit=limit, page=page, sort=sort,
                            start_search_date=start_search_date, end_search_date=end_search_date)
