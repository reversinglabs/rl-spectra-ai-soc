"""Utility functions for MCP tools."""
import json
import gzip
import base64
import logging

from pathlib import Path
from typing import Any, Dict, Optional
from mcp_server_analyze.core import get_config
from mcp_server_analyze.geoip import lookup_ip

logger = logging.getLogger(__name__)


def geoip_for(indicator: str, geoip: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Return the geoip block for a network indicator (IP, domain, or URL).
    """
    if geoip: #if geoip data already exists return that from the report 
        return geoip

    try:
        geo = lookup_ip(indicator)
    except Exception as geo_err:
        logger.error("GeoIP enrichment failed for %s: %s", indicator, geo_err, exc_info=True)
        return {}

    if isinstance(geo, dict) and geo:
        geo.setdefault("attribution", {"name": "IP Geolocation by DB-IP", "url": "https://db-ip.com"})
        return geo
    return {}


def save_tool_result(tool_name: str, result: Any, result_type: str) -> None:
    """Save tool result to debugging directory.
    
    Args:
        tool_name: Name of the tool
        result: Result data to save
        result_type: Type of result (e.g., 'analyze_api_response', 'mcp_output')
    """
    try:
        config = get_config()
        if not config.save_raw_responses:
            return
        
        # Create debug directory only when saving is enabled
        debugging_dir = Path(__file__).parent.parent / 'debugging'
        debugging_dir.mkdir(exist_ok=True)
        
        timestamp = __import__('datetime').datetime.utcnow().strftime('%Y%m%d_%H%M%S_%f')
        filename = f'{tool_name}-{result_type}-{timestamp}.json'
        filepath = debugging_dir / filename
        
        if isinstance(result, (dict, list, str, int, float, bool, type(None))):
            data = result
        else:
            data = str(result)
        
        with open(filepath, 'w') as f:
            json.dump({
                'tool': tool_name,
                'result_type': result_type,
                'timestamp': timestamp,
                'result': data
            }, f, indent=2)
        
        file_size_mb = filepath.stat().st_size / (1024 * 1024)
        logger.info('Saved %s %s result to %s (size: %.2f MB)', tool_name, result_type, filename, file_size_mb)
        
        if result_type == 'mcp_output' and file_size_mb > 1:
            logger.warning('Tool result for %s exceeds 1MB limit! Size: %.2f MB)', tool_name, file_size_mb)
    except Exception as e:
        logger.error('Failed to save %s tool result for %s: %s', result_type, tool_name, e)


def save_report_data(tool_name: str, analyze_api_response: Any, mcp_output: Any) -> None:
    """Save both API response and MCP output for a tool.
    
    Args:
        tool_name: Name of the tool
        analyze_api_response: Raw API response data
        mcp_output: Final MCP output data
    """
    save_tool_result(tool_name, analyze_api_response, 'analyze_api_response')
    save_tool_result(tool_name, mcp_output, 'mcp_output')


def compress_and_encode_data(data: Any, size_threshold_bytes: int = 850 * 1024) -> Dict[str, Any]:
    """Compress and base64-encode data if it exceeds size threshold.
    
    Args:
        data: Data to potentially compress
        size_threshold_bytes: Size threshold in bytes (default: 850KB)
        
    Returns:
        Dictionary with either uncompressed data or compressed data with metadata
    """
    try:
        json_str = json.dumps(data, separators=(',', ':'))
        original_size = len(json_str.encode('utf-8'))
        
        if original_size <= size_threshold_bytes:
            logger.info('Data size (%d bytes) under threshold, returning uncompressed', original_size)
            return {
                'data': data,
                'compression_info': {
                    'original_size_bytes': original_size,
                    'compression_applied': False,
                    'compression_threshold_bytes': size_threshold_bytes,
                    'reason': 'Size under threshold'
                }
            }
        
        logger.info('Data size (%d bytes) above threshold, Compressing...', original_size)
        compressed_bytes = gzip.compress(json_str.encode('utf-8'))
        compressed_size = len(compressed_bytes)
        base64_encoded = base64.b64encode(compressed_bytes).decode('utf-8')
        base64_size = len(base64_encoded)
        compression_ratio = (original_size - compressed_size) / original_size * 100 if original_size > 0 else 0
        
        logger.info('Compressed: %d bytes, Base64: %d bytes (original: %d bytes)', compressed_size, base64_size, original_size)
        
        return {
            'compressed_data': base64_encoded,
            'compression_info': {
                'original_size_bytes': original_size,
                'compressed_size_bytes': compressed_size,
                'base64_size_bytes': len(base64_encoded),
                'compression_ratio_percent': round(compression_ratio, 2),
                'compression_method': 'gzip',
                'compression_applied': True,
                'compression_threshold_bytes': size_threshold_bytes,
                'reason': 'Size exceeded threshold'
            },
            'format': {
                'encoding': 'base64',
                'compression': 'gzip',
                'original_format': 'json'
            }
        }
    except Exception as e:
        logger.error('Failed to compress data: %s', e)
        return {
            'error': f'Compression failed: {e}',
            'data': data,
            'compression_info': {
                'compression_attempted': True,
                'compression_successful': False,
                'original_size_bytes': len(json.dumps(data).encode('utf-8')) if data else 0
            }
        }


def get_llm_guidance(tool_name: str) -> str:
    """Get LLM guidance for a specific tool.
    
    Args:
        tool_name: Name of the tool to get guidance for
        
    Returns:
        str: The guidance text, or empty string if not found
    """
    prompts_dir = Path(__file__).parent.parent / 'prompts' / 'llm_guidance'
    
    try:
        guidance_file = prompts_dir / f'{tool_name}.md'
        with open(guidance_file, 'r') as f:
            guidance = f.read()
        return guidance
    except FileNotFoundError:
        logger.warning('No LLM guidance file found for tool: %s', tool_name)
        return ''
    except Exception as e:
        logger.error('Error reading LLM guidance for tool %s: %s', tool_name, e)
        return ''
