"""Streamlined YARA hunt tools for Spectra Analyze MCP Server."""
from mcp_server_analyze.tools.yara_hunt.yara_hunt import register

__all__ = ['register']
