"""Streamlined YARA hunt tools for Spectra Analyze MCP Server.

Provides three core tools:
- yara_hunt_start: Upload a ruleset and optionally start local/cloud live and retro hunts
- yara_hunt_status_and_matches: Get status and matches for all hunt types
- yara_hunt_delete: Stop cloud retro hunt, disable, and delete a ruleset
"""
import logging
import time
from typing import Any, Dict, Annotated
from pydantic import Field
from mcp.types import ToolAnnotations

from mcp_server_analyze.core import get_config
from mcp_server_analyze.tools.base_tool import BaseMCPTool

logger = logging.getLogger(__name__)
config = get_config()


class YaraHuntStartTool(BaseMCPTool):
    """Tool for starting YARA hunts (local/cloud, live/retro)."""
    
    def execute(self, ruleset_name: str, ruleset_content: str,
               local_live: bool = False, local_retro: bool = False,
               cloud_live: bool = False, cloud_retro: bool = False) -> Dict[str, Any]:
        """Start YARA hunt(s).
        
        Args:
            ruleset_name: Name of the ruleset
            ruleset_content: YARA rule content
            local_live: Start local live hunt
            local_retro: Start local retro hunt
            cloud_live: Start cloud live hunt (auto-starts when ticloud=True)
            cloud_retro: Start cloud retro hunt

        If no hunt type is enabled, the ruleset is only created/updated (uploaded)
        without starting any hunt.

        Returns:
            Dictionary with operation results
        """
        results = {
            "success": True,
            "ruleset_name": ruleset_name,
            "operations": {}
        }

        try:
            # Step 1: Always create/update the ruleset.
            # ticloud=True is required for any cloud operation (live or retro).
            ticloud = cloud_live or cloud_retro
            logger.info('Creating/updating YARA ruleset: %s (ticloud=%s)', ruleset_name, ticloud)
            create_result = self.sa_client.yara_create_or_update_ruleset(
                ruleset_name=ruleset_name,
                content=ruleset_content,
                ticloud=ticloud
            )

            if not create_result or create_result.get('success') is False:
                error_msg = create_result.get('error', 'Failed to create/update ruleset') if create_result else 'No response from API'
                results["success"] = False
                results["error"] = error_msg
                results["operations"]["create_ruleset"] = {
                    "success": False,
                    "error": error_msg
                }
                return results

            results["operations"]["create_ruleset"] = {
                "success": True,
                "message": "Ruleset created/updated successfully",
                "cloud_sync": ticloud
            }
            
            # Step 2: Enable ruleset for local live hunt
            if local_live:
                # Poll to verify ruleset is ready before enabling
                max_wait = 10  # seconds
                poll_interval = 0.5  # seconds
                waited = 0
                ruleset_ready = False
                
                logger.info('Waiting for ruleset to be ready: %s', ruleset_name)
                while waited < max_wait:
                    rulesets = self.sa_client.yara_list_rulesets(ruleset_type='my', source='all', page=1, page_size=1000)
                    if rulesets and rulesets.get('results'):
                        for rs in rulesets['results']:
                            if rs.get('name') == ruleset_name:
                                status = rs.get('status', '')
                                if status not in ['pending', 'error']:
                                    ruleset_ready = True
                                    logger.info('Ruleset ready with status: %s', status)
                                    break
                                else:
                                    logger.debug('Ruleset status: %s, waiting...', status)
                    
                    if ruleset_ready:
                        break
                    
                    time.sleep(poll_interval)
                    waited += poll_interval
                
                if not ruleset_ready:
                    logger.warning('Ruleset may not be ready after %ss, attempting to enable anyway', max_wait)
                
                logger.info('Enabling YARA ruleset for local live hunt: %s', ruleset_name)
                enable_result = self.sa_client.yara_enable_ruleset(ruleset_name)
                
                if not enable_result or enable_result.get('success') is False:
                    error_msg = enable_result.get('error', 'Failed to enable ruleset') if enable_result else 'No response from API'
                    results["operations"]["local_live"] = {
                        "success": False,
                        "error": error_msg
                    }
                    # Don't fail the entire operation, continue with other hunts
                else:
                    results["operations"]["local_live"] = {
                        "success": True,
                        "message": "Local live hunt started successfully"
                    }
            
            # Step 3: Start local retro hunt
            if local_retro:
                logger.info('Starting local retro hunt')
                local_retro_result = self.sa_client.yara_local_retrohunt_control('START')
                
                if not local_retro_result or local_retro_result.get('success') is False:
                    error_msg = local_retro_result.get('error', 'Failed to start local retro hunt') if local_retro_result else 'No response from API'
                    results["operations"]["local_retro"] = {
                        "success": False,
                        "error": error_msg
                    }
                else:
                    results["operations"]["local_retro"] = {
                        "success": True,
                        "message": "Local retro hunt started successfully",
                        "state": local_retro_result.get('status', {}).get('state', 'UNKNOWN')
                    }
            
            # Step 4: Start cloud retro hunt
            if cloud_retro:
                # Poll until cloud_status is ACTIVE before starting the retro hunt.
                # Cloud sync can take 30-60 s after ruleset creation with ticloud=True.
                max_wait = 60  # seconds
                poll_interval = 3  # seconds
                waited = 0
                cloud_ready = False

                logger.info('Waiting for cloud_status ACTIVE for ruleset: %s', ruleset_name)
                while waited < max_wait:
                    status_result = self.sa_client.yara_cloud_retrohunt_status(ruleset_name)
                    if status_result and status_result.get('status'):
                        cloud_status = status_result['status'].get('cloud_status', '')
                        logger.debug('cloud_status=%s, waited=%ss', cloud_status, waited)
                        if cloud_status == 'ACTIVE':
                            cloud_ready = True
                            break
                    time.sleep(poll_interval)
                    waited += poll_interval

                if not cloud_ready:
                    logger.warning(
                        'cloud_status did not reach ACTIVE after %ss, attempting to start anyway',
                        max_wait
                    )

                logger.info('Starting cloud retro hunt for ruleset: %s', ruleset_name)
                cloud_retro_result = self.sa_client.yara_cloud_retrohunt_control(ruleset_name, 'START')
                
                if not cloud_retro_result or cloud_retro_result.get('success') is False:
                    error_msg = cloud_retro_result.get('error', 'Failed to start cloud retro hunt') if cloud_retro_result else 'No response from API'
                    results["operations"]["cloud_retro"] = {
                        "success": False,
                        "error": error_msg
                    }
                else:
                    results["operations"]["cloud_retro"] = {
                        "success": True,
                        "message": "Cloud retro hunt started successfully",
                        "state": cloud_retro_result.get('status', {}).get('state', 'UNKNOWN')
                    }
            
            # Note: cloud_live is automatically started when ticloud=True in create_ruleset
            if cloud_live:
                results["operations"]["cloud_live"] = {
                    "success": True,
                    "message": "Cloud live hunt started automatically (ticloud=True)"
                }

            if not any([local_live, local_retro, cloud_live, cloud_retro]):
                results["message"] = (
                    "Ruleset uploaded only; no hunt was started. Enable local_live, "
                    "local_retro, cloud_live, or cloud_retro to start hunting."
                )

            return results
            
        except Exception as e:
            logger.error('Unexpected error starting YARA hunt: %s', e, exc_info=True)
            return {
                "success": False,
                "error": str(e),
                "ruleset_name": ruleset_name
            }


class YaraHuntStatusAndMatchesTool(BaseMCPTool):
    """Tool for getting YARA hunt status and matches."""
    
    def execute(self, ruleset_name: str, page: int = 1, page_size: int = 100) -> Dict[str, Any]:
        """Get status and matches for all hunt types.
        
        Args:
            ruleset_name: Name of the ruleset
            page: Page number for matches pagination
            page_size: Number of matches per page
            
        Returns:
            Dictionary with status and matches grouped by local/cloud
        """
        results = {
            "success": True,
            "ruleset_name": ruleset_name,
            "total_suspicious_match_count": 0,
            "total_malicious_match_count": 0,
            "total_goodware_match_count": 0,
            "total_unknown_match_count": 0,
            "local": {
                "live": {},
                "retro": {},
                "matches": {
                    "MALICIOUS": [],
                    "SUSPICIOUS": [],
                    "GOODWARE": [],
                    "UNKNOWN": []
                }
            },
            "cloud": {
                "live": {},
                "retro": {},
                "matches": {
                    "MALICIOUS": [],
                    "SUSPICIOUS": [],
                    "GOODWARE": [],
                    "UNKNOWN": []
                }
            }
        }
        
        try:
            # Step 1: Get ruleset info from GET /api/yara/v2/rulesets/?type=my&source=all
            logger.info('Fetching ruleset info for: %s', ruleset_name)
            rulesets_result = self.sa_client.yara_list_rulesets(
                ruleset_type='my',
                source='all',
                page=1,
                page_size=1000  # Get all to find our ruleset
            )
            
            if rulesets_result and rulesets_result.get('results'):
                # Find the matching ruleset
                ruleset_info = None
                for rs in rulesets_result['results']:
                    if rs.get('name') == ruleset_name:
                        ruleset_info = rs
                        break
                
                if ruleset_info:
                    # Extract match counts and move to root level
                    results["total_suspicious_match_count"] = ruleset_info.get('suspicious_match_count', 0)
                    results["total_malicious_match_count"] = ruleset_info.get('malicious_match_count', 0)
                    results["total_goodware_match_count"] = ruleset_info.get('goodware_match_count', 0)
                    results["total_unknown_match_count"] = ruleset_info.get('unknown_match_count', 0)
                    
                    # Extract local live hunt status
                    # Note: status 'active' means the ruleset is enabled for live hunting
                    ruleset_status = ruleset_info.get('status', 'unknown')
                    results["local"]["live"] = {
                        "enabled": ruleset_status == 'active',
                        "status": ruleset_status,
                        "last_matched": ruleset_info.get('last_matched')
                    }
                    
                    # Extract cloud live hunt status
                    results["cloud"]["live"] = {
                        "enabled": ruleset_info.get('cloud_synced', False),
                        "cloud_synced": ruleset_info.get('cloud_synced', False)
                    }
                else:
                    results["local"]["live"]["error"] = f"Ruleset '{ruleset_name}' not found"
                    results["cloud"]["live"]["error"] = f"Ruleset '{ruleset_name}' not found"
            
            # Step 2: Get local retro hunt status
            logger.info('Fetching local retro hunt status')
            local_retro_status = self.sa_client.yara_local_retrohunt_status()
            
            if local_retro_status and local_retro_status.get('status'):
                status = local_retro_status['status']
                results["local"]["retro"] = {
                    "state": status.get('state', 'UNKNOWN'),
                    "started": status.get('started'),
                    "stopped": status.get('stopped'),
                    "processed": status.get('processed', 0),
                    "total_samples": status.get('samples', 0)
                }
            else:
                results["local"]["retro"]["error"] = "Failed to fetch local retro hunt status"
            
            # Step 3: Get cloud retro hunt status
            logger.info('Fetching cloud retro hunt status for: %s', ruleset_name)
            cloud_retro_status = self.sa_client.yara_cloud_retrohunt_status(ruleset_name)
            
            if cloud_retro_status and cloud_retro_status.get('status'):
                status = cloud_retro_status['status']
                results["cloud"]["retro"] = {
                    "cloud_status": status.get('cloud_status', 'UNKNOWN'),
                    "scale_status": status.get('scale_status', 'UNKNOWN'),
                    "retrohunt_status": status.get('retrohunt_status', 'UNKNOWN'),
                    "start_time": status.get('retrohunt_start_time'),
                    "finish_time": status.get('retrohunt_finish_time'),
                    "estimated_finish_time": status.get('retrohunt_estimated_finish_time'),
                    "progress": status.get('retrohunt_progress'),
                    "reason": status.get('reason')
                }
            else:
                error_msg = cloud_retro_status.get('error', 'Failed to fetch cloud retro hunt status') if cloud_retro_status else 'No response from API'
                results["cloud"]["retro"]["error"] = error_msg
            
            # Step 4: Get all matches and group by cloud/local
            logger.info('Fetching YARA matches for: %s', ruleset_name)
            matches_result = self.sa_client.yara_get_matches(
                ruleset_name=ruleset_name,
                page=page,
                page_size=page_size
            )
            
            if matches_result and matches_result.get('results'):
                for match in matches_result['results']:
                    # Check if this is a cloud or local match
                    is_cloud = match.get('cloud', False)
                    
                    # Get classification and normalize to uppercase
                    classification = match.get('classification', 'UNKNOWN')
                    if isinstance(classification, str):
                        classification = classification.upper()
                    else:
                        classification = 'UNKNOWN'
                    
                    # Ensure classification is valid
                    if classification not in ['MALICIOUS', 'SUSPICIOUS', 'GOODWARE', 'UNKNOWN']:
                        classification = 'UNKNOWN'
                    
                    # Remove the 'cloud' field since it's implied by the object it's in
                    match_copy = {k: v for k, v in match.items() if k != 'cloud'}
                    
                    # Group by cloud/local and classification
                    if is_cloud:
                        results["cloud"]["matches"][classification].append(match_copy)
                    else:
                        results["local"]["matches"][classification].append(match_copy)
                
                # Include total match count at root level
                results["total_matches"] = matches_result.get('count', 0)
            else:
                if matches_result and matches_result.get('error'):
                    results["matches_error"] = matches_result.get('error')
            
            return results
            
        except Exception as e:
            logger.error('Unexpected error getting YARA hunt status and matches: %s', e, exc_info=True)
            return {
                "success": False,
                "error": str(e),
                "ruleset_name": ruleset_name
            }


class YaraHuntDeleteTool(BaseMCPTool):
    """Tool for deleting YARA hunts."""
    
    def execute(self, ruleset_name: str) -> Dict[str, Any]:
        """Delete a YARA ruleset.

        Args:
            ruleset_name: Name of the ruleset to delete

        Returns:
            Dictionary with operation results
        """
        results = {
            "success": True,
            "ruleset_name": ruleset_name,
            "operations": {}
        }

        try:
            # Step 1: Stop the cloud retro hunt
            logger.info('Stopping cloud retro hunt for ruleset: %s', ruleset_name)
            stop_result = self.sa_client.yara_cloud_retrohunt_control(ruleset_name, 'STOP')

            if not stop_result or stop_result.get('success') is False:
                error_msg = stop_result.get('error', 'Failed to stop cloud retro hunt') if stop_result else 'No response from API'
                results["operations"]["stop_cloud_retro"] = {
                    "success": False,
                    "warning": error_msg,
                    "message": "Continuing with deletion..."
                }
            else:
                results["operations"]["stop_cloud_retro"] = {
                    "success": True,
                    "message": "Cloud retro hunt stopped successfully"
                }

            # Step 2: Disable the ruleset (stops local live and cloud live hunts).
            logger.info('Disabling YARA ruleset: %s', ruleset_name)
            disable_result = self.sa_client.yara_disable_ruleset(ruleset_name)

            if not disable_result or disable_result.get('success') is False:
                error_msg = disable_result.get('error', 'Failed to disable ruleset') if disable_result else 'No response from API'
                results["operations"]["disable"] = {
                    "success": False,
                    "warning": error_msg,
                    "message": "Continuing with deletion..."
                }
            else:
                results["operations"]["disable"] = {
                    "success": True,
                    "message": "Ruleset disabled successfully"
                }

            # Step 3: Delete the ruleset
            logger.info('Deleting YARA ruleset: %s', ruleset_name)
            delete_result = self.sa_client.yara_delete_ruleset(ruleset_name)
            
            if not delete_result or delete_result.get('success') is False:
                error_msg = delete_result.get('error', 'Failed to delete ruleset') if delete_result else 'No response from API'
                results["success"] = False
                results["operations"]["delete"] = {
                    "success": False,
                    "error": error_msg
                }
            else:
                results["operations"]["delete"] = {
                    "success": True,
                    "message": "Ruleset deleted successfully"
                }
            
            return results
            
        except Exception as e:
            logger.error('Unexpected error deleting YARA hunt: %s', e, exc_info=True)
            return {
                "success": False,
                "error": str(e),
                "ruleset_name": ruleset_name
            }


def register(mcp):
    """Register YARA hunt tools with the MCP server."""
    
    @mcp.tool(
        annotations=ToolAnnotations(
            title="Start YARA Hunt",
            readOnlyHint=False,
            destructiveHint=False,
            idempotentHint=False,
            openWorldHint=True,
        ),
    )
    def yara_hunt_start(
            ruleset_name: Annotated[
                str,
                Field(description="Name of the YARA ruleset (3-48 chars, alphanumeric, underscore)", min_length=3, max_length=48)
            ],
            ruleset_content: Annotated[
                str,
                Field(description="Complete YARA rule(s) in valid YARA syntax", min_length=1)
            ],
            local_live: Annotated[
                bool,
                Field(description="Start local live hunt (scans new samples on appliance)")
            ] = False,
            local_retro: Annotated[
                bool,
                Field(description="Start local retro hunt (scans existing samples on appliance)")
            ] = False,
            cloud_live: Annotated[
                bool,
                Field(description="Start cloud live hunt (continuous hunting in Spectra Intelligence)")
            ] = False,
            cloud_retro: Annotated[
                bool,
                Field(description="Start cloud retro hunt (scan last 90 days in Spectra Intelligence)")
            ] = False
    ) -> Dict[str, Any]:
        """
        Upload a YARA ruleset and optionally start hunt(s) with it.

        This tool creates/updates a YARA ruleset and starts any requested hunt types:

        **Local Live Hunt**: Scans new samples submitted to the appliance against the ruleset
        **Local Retro Hunt**: Scans all existing samples on the appliance against the ruleset
        **Cloud Live Hunt**: Continuously hunts in Spectra Intelligence (auto-starts when enabled)
        **Cloud Retro Hunt**: Scans the last 90 days of samples in Spectra Intelligence
        
        No hunt type is required: if all hunt flags are left disabled, the ruleset is simply
        uploaded (created or updated) without starting any hunt. Multiple hunt types can be
        started simultaneously.
        
        YARA Rule Format Example:
        ```
        rule ExampleMalware {
            meta:
                description = "Detects example malware"
            strings:
                $string1 = "malicious_string" ascii wide
                $hex1 = { 4D 5A 90 00 }
            condition:
                uint16(0) == 0x5A4D and any of ($string*, $hex*)
        }
        ```
        """
        tool = YaraHuntStartTool(
            sa_base_url=config.analyze_base_url,
            sa_verify_ssl=config.analyze_verify_ssl
        )
        return tool.execute(ruleset_name, ruleset_content, local_live, local_retro, cloud_live, cloud_retro)
    
    @mcp.tool(
        annotations=ToolAnnotations(
            title="YARA Hunt Status and Matches",
            readOnlyHint=True,
            destructiveHint=False,
            idempotentHint=True,
            openWorldHint=True,
        ),
    )
    def yara_hunt_status_and_matches(
            ruleset_name: Annotated[
                str,
                Field(description="Name of the YARA ruleset", min_length=1)
            ],
            page: Annotated[
                int,
                Field(description="Page number for matches pagination", ge=1)
            ] = 1,
            page_size: Annotated[
                int,
                Field(description="Number of matches per page", ge=1, le=1000)
            ] = 100
    ) -> Dict[str, Any]:
        """
        Get status and matches for all YARA hunt types (local/cloud, live/retro).
        
        Returns a comprehensive view of:
        - **Local Live Hunt**: Status and configuration
        - **Local Retro Hunt**: Progress and state
        - **Cloud Live Hunt**: Cloud sync status
        - **Cloud Retro Hunt**: Progress and estimated completion
        - **Matches**: Grouped by local vs cloud, with pagination support
        
        The response includes separate `local` and `cloud` objects containing status and matches
        for each hunt type.
        """
        tool = YaraHuntStatusAndMatchesTool(
            sa_base_url=config.analyze_base_url,
            sa_verify_ssl=config.analyze_verify_ssl
        )
        return tool.execute(ruleset_name, page, page_size)
    
    @mcp.tool(
        annotations=ToolAnnotations(
            title="Delete YARA Hunt",
            readOnlyHint=False,
            destructiveHint=True,
            idempotentHint=True,
            openWorldHint=True,
        ),
    )
    def yara_hunt_delete(
            ruleset_name: Annotated[
                str,
                Field(description="Name of the YARA ruleset to delete", min_length=1)
            ]
    ) -> Dict[str, Any]:
        """
        Delete a YARA ruleset.

        This operation:
        1. Stops the cloud retro hunt (the appliance rejects deletion while it is running)
        2. Disables the ruleset (stops local live and cloud live hunts)
        3. Deletes the ruleset and all associated matches

        This is a permanent operation and cannot be undone. All hunt results will be lost.
        """
        tool = YaraHuntDeleteTool(
            sa_base_url=config.analyze_base_url,
            sa_verify_ssl=config.analyze_verify_ssl
        )
        return tool.execute(ruleset_name)
