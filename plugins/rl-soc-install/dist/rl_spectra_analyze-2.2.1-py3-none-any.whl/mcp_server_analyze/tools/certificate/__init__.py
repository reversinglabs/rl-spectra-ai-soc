"""Certificate intelligence tools for Spectra Analyze MCP Server."""
from mcp_server_analyze.tools.certificate.certificate import register

__all__ = ['register']
