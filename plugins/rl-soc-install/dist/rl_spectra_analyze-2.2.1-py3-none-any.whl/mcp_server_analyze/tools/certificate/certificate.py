import json
import logging
import math
import re
from typing import Any, Dict, List, Optional, Annotated, Literal, Union
from pydantic import Field
from mcp.types import ToolAnnotations

from mcp_server_analyze.core import get_config
from mcp_server_analyze.tools.base_tool import BaseMCPTool
from mcp_server_analyze.tools.tool_utils import save_report_data

logger = logging.getLogger(__name__)
config = get_config()

_MAX_LIMIT = 100          # per-page cap enforced by the search API
_MAX_THUMBPRINTS = 100    # bulk analytics cap, matching Intelligence
_DEFAULT_MAX_SAMPLES = 10  # samples to inspect for thumbprint reconstruction
_MAX_MAX_SAMPLES = 50


# ---------------------------------------------------------------------------
# Certificate reshaping helpers
# ---------------------------------------------------------------------------

def _dn_common_name(dn: Optional[str]) -> Optional[str]:
    if not dn:
        return None
    m = re.search(r'commonName=(.+?)(?:,[A-Za-z0-9.]+=|$)', dn)
    return m.group(1).strip() if m else dn


def _cert_thumbprints(cert: Dict[str, Any]) -> List[Dict[str, str]]:
    by_name: Dict[str, str] = {}
    for tp in cert.get('additional_thumbprints') or []:
        name, value = tp.get('name'), tp.get('value')
        if name and value:
            by_name[name.upper()] = value
    algo = (cert.get('thumbprint_algorithm') or '').upper()
    if algo and cert.get('thumbprint'):
        by_name[algo] = cert['thumbprint']
    return [{'name': n, 'value': by_name[n]} for n in ('MD5', 'SHA1', 'SHA256') if n in by_name]


def _map_extensions(cert: Dict[str, Any]) -> List[Dict[str, str]]:
    """Reshape static-analysis extensions to the Intelligence form."""
    out = []
    for ext in cert.get('extensions') or []:
        out.append({
            'name': ext.get('name'),
            'value': ext.get('value'),
            'is_critical': str(bool(ext.get('is_critical'))),
        })
    return out


def _build_cert(cert: Dict[str, Any], by_subject: Dict[str, Dict[str, Any]],
                seen: frozenset) -> Dict[str, Any]:
    """Build an Intelligence-shaped certificate object, nesting the issuer chain.

    ``by_subject`` maps each chain certificate's subject DN to the cert, so the
    issuer can be resolved recursively. When the issuer is not in the chain (or
    is self-signed), ``issuer`` becomes the issuer common-name string, matching
    the native API's treatment of the root.
    """
    obj: Dict[str, Any] = {
        'common_name': _dn_common_name(cert.get('subject')),
        'valid_from': cert.get('valid_from'),
        'valid_to': cert.get('valid_to'),
        'signature_algorithm': cert.get('signature_algorithm'),
        'signature': cert.get('signature'),
        'extensions': _map_extensions(cert),
        'certificate_thumbprints': _cert_thumbprints(cert),
        'serial_number': cert.get('serial_number'),
        'version': str(cert['version']) if cert.get('version') is not None else None,
    }
    issuer_dn = cert.get('issuer')
    subject_dn = cert.get('subject')
    issuer_cert = by_subject.get(issuer_dn) if issuer_dn else None
    if issuer_cert is not None and issuer_dn != subject_dn and issuer_dn not in seen:
        obj['issuer'] = _build_cert(issuer_cert, by_subject, seen | {issuer_dn})
    else:
        obj['issuer'] = _dn_common_name(issuer_dn)
    return obj


def _find_cert_by_thumbprint(certs: List[Dict[str, Any]], thumbprint: str) -> Optional[Dict[str, Any]]:
    """Return the chain certificate matching ``thumbprint`` (any algorithm)."""
    target = thumbprint.strip().lower()
    for cert in certs:
        if (cert.get('thumbprint') or '').lower() == target:
            return cert
        for tp in cert.get('additional_thumbprints') or []:
            if (tp.get('value') or '').lower() == target:
                return cert
    return None


class CertificateTool(BaseMCPTool):
    """Certificate lookups backed by advanced search + static analysis."""

    # -- search / count helpers ---------------------------------------------
    def _search(self, query: str, limit: int, ticloud: bool, page: int = 1) -> Dict[str, Any]:
        """Run an advanced search, returning ``{entries, total_count}``."""
        result = self.sa_client.advanced_search(query, limit=limit, ticloud=ticloud, page=page)
        search_api = (result or {}).get('search_api') or {}
        entries = search_api.get('entries') or []
        total = search_api.get('total_count')
        return {
            'entries': entries,
            'total_count': total if isinstance(total, int) else len(entries),
        }

    def _count(self, query: str, ticloud: bool) -> int:
        """Return the total index match count for a query."""
        return self._search(query, limit=1, ticloud=ticloud)['total_count']

    def _get_certificates(self, hash_value: str) -> List[Dict[str, Any]]:
        """Return the certificate chain from a sample's static analysis."""
        rldata = self.sa_client.get_rldata(hash_value) or {}
        sample = (rldata.get('rl') or {}).get('sample') or {}
        entries = (sample.get('analysis') or {}).get('entries') or []
        if entries:
            report = entries[0].get('tc_report') or {}
            certs = (((report.get('metadata') or {}).get('certificate')) or {}).get('certificates')
            if certs:
                return certs
        ticore = self.sa_client.get_ticore(hash_value) or {}
        certs = (((ticore.get('metadata') or {}).get('certificate')) or {}).get('certificates')
        return certs or []

    # -- TCA-0501 equivalent -------------------------------------------------
    def get_certificate_index(
        self, thumbprint: str, classification: Optional[str], instance: str, limit: int,
        page: Optional[int] = None,
    ) -> Dict[str, Any]:
        """Return SHA-1 hashes of samples signed with a certificate thumbprint."""
        if not thumbprint:
            raise ValueError("thumbprint is required")
        limit = max(1, min(limit, _MAX_LIMIT))
        if not page or page < 1:
            page = 1
        ticloud = instance == "cloud"

        query = f"cert-thumbprint:{thumbprint}"
        if classification:
            query += f" AND classification:{classification}"

        found = self._search(query, limit=limit, ticloud=ticloud, page=page)
        sha1s = [e.get('sha1') for e in found['entries'] if e.get('sha1')]

        total_count = found['total_count']
        total_pages = max(1, math.ceil(total_count / limit)) if isinstance(total_count, int) and limit > 0 else None

        output: Dict[str, Any] = {
            'samples': sha1s,
            'total_count': total_count,
            'current_page': page,
            'records_per_page': limit,
            'total_pages': total_pages,
        }
        # A full page suggests more results; expose the last SHA-1 as a cursor,
        # matching the native API's next_page shape.
        if sha1s and len(sha1s) >= limit and found['total_count'] > (page * limit):
            output['next_page'] = sha1s[-1]
        save_report_data('get_certificate_index', found, output)
        return output

    # -- TCA-0502 equivalent -------------------------------------------------
    def _analytics_for(self, thumbprint: str, ticloud: bool) -> Dict[str, Any]:
        """Build one certificate-analytics object for a single thumbprint."""
        base_query = f"cert-thumbprint:{thumbprint}"
        base = self._search(base_query, limit=_MAX_LIMIT, ticloud=ticloud)
        total = base['total_count']
        malicious = self._count(f"{base_query} AND classification:malicious", ticloud)
        suspicious = self._count(f"{base_query} AND classification:suspicious", ticloud)
        known = self._count(f"{base_query} AND classification:known", ticloud)
        unknown = max(total - malicious - suspicious - known, 0)

        # Reconstruct the certificate chain from a signed sample's static analysis.
        certificate = None
        entries = base['entries']
        if entries:
            certs = self._get_certificates(entries[0].get('sha1'))
            leaf = _find_cert_by_thumbprint(certs, thumbprint)
            if leaf is not None:
                by_subject = {c.get('subject'): c for c in certs if c.get('subject')}
                certificate = _build_cert(leaf, by_subject, frozenset())

        # Approximate the certificate's first-seen from the earliest signed sample.
        first_seens = [e.get('firstseen') or e.get('first_seen') for e in entries]
        first_seens = [fs for fs in first_seens if fs]
        certificate_first_seen = min(first_seens) if first_seens else None

        return {
            'certificate': certificate,
            'statistics': {
                'unknown': unknown,
                'known': known,
                'malicious': malicious,
                'suspicious': suspicious,
                'total': total,
            },
            # being left as hardcoded for now until we get a proper api endpoint for cert
            # since on intelligence MCP the TCA-0502 call has a classification field
            # so we should mirror that
            'classification': {'status': 'undefined'},
            'certificate_first_seen': certificate_first_seen,
        }

    def get_certificate_analytics(self, thumbprints: "str | List[str]", instance: str) -> Any:
        """Return analytics for one or more certificate thumbprints.

        ``thumbprints`` may be a single thumbprint string or a list of strings
        """
        if isinstance(thumbprints, str):
            thumbprints = [thumbprints]
        if not thumbprints:
            raise ValueError("at least one thumbprint is required")
        if len(thumbprints) > _MAX_THUMBPRINTS:
            raise ValueError(
                f"at most {_MAX_THUMBPRINTS} thumbprints per call (got {len(thumbprints)})"
            )
        ticloud = instance == "cloud"

        # Single thumbprint -> the analytics object directly (matches TCA-0502).
        if len(thumbprints) == 1:
            output = self._analytics_for(thumbprints[0], ticloud)
            save_report_data('get_certificate_analytics', thumbprints, output)
            return output

        analytics = [self._analytics_for(tp, ticloud) for tp in thumbprints]
        output = {'certificate_analytics': analytics}
        save_report_data('get_certificate_analytics', thumbprints, output)
        return output

    # -- TCA-0503 equivalent -------------------------------------------------
    def search_certificate_thumbprints(
        self, common_name: str, instance: str, limit: int, max_samples: int,
    ) -> Dict[str, Any]:
        """Return certificate thumbprints for certs matching a common name."""
        if not common_name:
            raise ValueError("common_name is required")
        limit = max(1, min(limit, _MAX_LIMIT))
        max_samples = max(1, min(max_samples, _MAX_MAX_SAMPLES))
        ticloud = instance == "cloud"

        base = self._search(f'cert-subject-name:{common_name}', limit=limit, ticloud=ticloud)
        needle = common_name.replace('*', '').strip().lower()

        seen: set = set()
        thumbprints: List[Dict[str, Any]] = []
        for entry in base['entries'][:max_samples]:
            sha1 = entry.get('sha1')
            if not sha1:
                continue
            for cert in self._get_certificates(sha1):
                subject = cert.get('subject') or ''
                # Keep only the certificate(s) whose subject matches the query.
                if needle and needle not in subject.lower():
                    continue
                tps = _cert_thumbprints(cert)
                if not tps:
                    continue
                key = next((t['value'].lower() for t in tps if t['name'] == 'SHA256'), json.dumps(tps))
                if key in seen:
                    continue
                seen.add(key)
                thumbprints.append({'certificate_thumbprints': tps})

        output = {'search': [{'common_name': common_name, 'thumbprints': thumbprints}]}
        save_report_data('search_certificate_thumbprints', base, output)
        return output


def register(mcp):
    """Register the certificate intelligence tools with the MCP server."""

    def _tool() -> CertificateTool:
        return CertificateTool(
            sa_base_url=config.analyze_base_url,
            sa_verify_ssl=config.analyze_verify_ssl,
        )

    _instance_field = Field(
        default="cloud",
        description=(
            "Search scope. 'cloud' queries Spectra Intelligence (global certificate data); "
            "'local' queries the on-prem appliance index. Defaults to 'cloud'."
        ),
    )

    @mcp.tool(
        structured_output=False,
        annotations=ToolAnnotations(
            title='Get Certificate Index',
            readOnlyHint=True, destructiveHint=False,
            idempotentHint=True, openWorldHint=True,
        ),
    )
    def get_certificate_index(
        thumbprint: Annotated[str, Field(
            description="Certificate thumbprint (MD5, SHA-1, or SHA-256). No wildcards.",
        )],
        classification: Annotated[Optional[Literal["known", "suspicious", "malicious"]], Field(
            description="Optional classification filter for the signed samples.",
        )] = None,
        instance: Annotated[Optional[Literal["local", "cloud"]], _instance_field] = "cloud",
        limit: Annotated[int, Field(
            description="Results per page (1-100, default 100).",
        )] = 100,
        page: Annotated[Optional[int], Field(
            description=(
                "Optional. 1-based page number for paginating through data"
            ),
        )] = None,
    ) -> Dict[str, Any]:
        """
        Return a list of samples signed with a specific certificate thumbprint.

        Returns:
            A dict with ``samples`` (a list of SHA-1 hashes), pagination info
            (``total_count``, ``current_page``, ``records_per_page``,
            ``total_pages``) and, when more results exist, a ``next_page``
            cursor (the last returned SHA-1).
        """
        return _tool().get_certificate_index(thumbprint, classification, instance, limit, page)

    @mcp.tool(
        structured_output=False,
        annotations=ToolAnnotations(
            title='Get Certificate Analytics',
            readOnlyHint=True, destructiveHint=False,
            idempotentHint=True, openWorldHint=True,
        ),
    )
    def get_certificate_analytics(
        thumbprints: Annotated[Union[str, List[str]], Field(
            description=(
                "Certificate thumbprint(s) (MD5, SHA-1, or SHA-256). Accepts a "
                "single thumbprint string or a list of up to 100 thumbprints."
            ),
        )],
        instance: Annotated[Optional[Literal["local", "cloud"]], _instance_field] = "cloud",
    ) -> Any:
        """
        Return analytics for one or more certificate thumbprints.

        """
        return _tool().get_certificate_analytics(thumbprints, instance)

    @mcp.tool(
        structured_output=False,
        annotations=ToolAnnotations(
            title='Search Certificate Thumbprints',
            readOnlyHint=True, destructiveHint=False,
            idempotentHint=True, openWorldHint=True,
        ),
    )
    def search_certificate_thumbprints(
        common_name: Annotated[str, Field(
            description="Certificate subject common name. Supports '*' wildcards, e.g. 'Microsoft*'.",
        )],
        instance: Annotated[Optional[Literal["local", "cloud"]], _instance_field] = "cloud",
        limit: Annotated[int, Field(
            description="Maximum signed samples to scan from the index (1-100, default 100).",
        )] = 100,
        max_samples: Annotated[int, Field(
            description=(
                "Maximum samples to inspect via static analysis to reconstruct "
                f"thumbprints (1-{_MAX_MAX_SAMPLES}, default {_DEFAULT_MAX_SAMPLES}). "
                "Higher values find more distinct certificates but cost more lookups."
            ),
        )] = _DEFAULT_MAX_SAMPLES,
    ) -> Dict[str, Any]:
        """
        Search for certificate thumbprints by subject common name.

        Returns:
            A dict with ``search``: a list of ``{common_name, thumbprints}``
            objects, where each thumbprint entry has ``certificate_thumbprints``
            (MD5, SHA-1, SHA-256).
        """
        return _tool().search_certificate_thumbprints(common_name, instance, limit, max_samples)
