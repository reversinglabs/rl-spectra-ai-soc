"""File reputation tool."""

from mcp_server_analyze.tools.file_reputation.file_reputation import register

__all__ = ['register']
