"""File reputation tool for Spectra Analyze MCP Server."""
import logging
from typing import Any, Dict, List, Optional, Annotated
from pydantic import Field
from mcp.types import ToolAnnotations

from mcp_server_analyze.core import get_config
from mcp_server_analyze.tools.base_tool import BaseMCPTool
from mcp_server_analyze.tools.tool_utils import save_report_data, compress_and_encode_data

logger = logging.getLogger(__name__)
config = get_config()

# The MD5 of a zero-byte file; used to flag empty-file lookups.
EMPTY_FILE_MD5 = 'd41d8cd98f00b204e9800998ecf8427e'


class FileReputationTool(BaseMCPTool):
    """File reputation tool with class-based architecture."""

    def _parse_ticloud_reputation(self, ticloud_data: Dict[str, Any], hash_value: str) -> Dict[str, Any]:
        """Parse Spectra Intelligence TCA-0104 response into file reputation format.

        Args:
            ticloud_data: TCA-0104 API response
            hash_value: The hash that was queried

        Returns:
            Dictionary in the same format as local file reputation
        """
        try:
            sample = ticloud_data.get('rl', {}).get('sample', {})

            # Get file size from rldata
            sample_size = sample.get('sample_size', 0)

            # Get file type and ticore tags from the embedded tc_report (if present)
            file_type = ''
            file_subtype = ''
            ticore_tags = []
            if 'analysis' in sample and 'entries' in sample['analysis']:
                entries = sample['analysis']['entries']
                if len(entries) > 0 and 'tc_report' in entries[0]:
                    tc_report = entries[0]['tc_report']
                    file_info = tc_report.get('info', {}).get('file', {})
                    file_type = file_info.get('file_type', '')
                    file_subtype = file_info.get('file_subtype', '')
                    ticore_tags = tc_report.get('tags', [])

            # Get classification, risk score, hashes, and timestamps from the
            # classification endpoint — a superset of what rca2 provides.
            classification = 'unknown'
            classification_result = ''
            classification_reason = ''
            risk_score = 0
            sha1 = ''
            sha256 = ''
            md5 = ''
            first_seen = ''
            last_seen = ''

            classification_data = self.sa_client.get_sample_classification(hash_value)
            if classification_data:
                classification = classification_data.get('classification', 'unknown')
                classification_result = classification_data.get('classification_result', '')
                classification_reason = classification_data.get('classification_reason', '')
                risk_score = classification_data.get('riskscore', 0)
                sha1 = classification_data.get('sha1', '')
                sha256 = classification_data.get('sha256', '')
                md5 = classification_data.get('md5', '')
                first_seen = classification_data.get('first_seen', '')
                last_seen = classification_data.get('last_seen', '')

            report = {
                'analyze': {
                    'file_reputation': {
                        'classification': classification,
                        'classification_reason': classification_reason,
                        'classification_result': classification_result,
                        'file_size': sample_size,
                        'file_subtype': file_subtype,
                        'file_type': file_type,
                        'first_seen': first_seen,
                        'hash': hash_value,
                        'last_seen': last_seen,
                        'md5': md5,
                        'risk_score': risk_score,
                        'sample_id': '',
                        'sha1': sha1,
                        'sha256': sha256,
                        'source': 'cloud-spectra_intelligence',
                        'tags': ticore_tags,
                    }
                }
            }

            return report

        except Exception as e:
            logger.error('Error parsing Spectra Intelligence reputation data: %s', e)
            return {'error': f'Failed to parse Spectra Intelligence data: {e}', 'hash': hash_value}

    def execute(self, hash_value: str) -> Dict[str, Any]:
        """Execute file reputation lookup.

        Args:
            hash_value: File hash (MD5/SHA1/SHA256)

        Returns:
            File reputation report
        """
        logger.info('Getting file reputation for hash: %s', hash_value)

        try:
            if not hash_value or not isinstance(hash_value, str):
                raise ValueError("Hash must be a non-empty string")
            hash_clean = hash_value.strip().lower()
            if not hash_clean:
                raise ValueError("Hash cannot be empty")

            reputation_fields = [
                'id', 'sha1', 'sha256', 'md5', 'classification', 'classification_result',
                'classification_reason', 'riskscore', 'file_type', 'file_subtype', 'file_size',
                'local_first_seen', 'local_last_seen', 'tags'
            ]

            # Use the SpectraAnalyzeClient for local appliance reputation lookup
            analyze_api_response = self.sa_client.get_file_reputation(hash_clean, fields=reputation_fields)
            logger.info(
                'Successfully retrieved reputation for %s. Result count: %s',
                hash_clean,
                analyze_api_response.get('count', 0),
            )

            if analyze_api_response.get('count', 0) == 0:
                logger.info('File not found on local appliance, attempting file analysis from Spectra Intelligence proxy api for %s', hash_clean)

                # Try file analysis from Spectra Intelligence proxy api
                file_analysis_data = self.sa_client.get_rldata(hash_clean)

                if file_analysis_data:
                    report = self._parse_ticloud_reputation(file_analysis_data, hash_clean)
                else:
                    report = {
                        'error': 'File not found on appliance and Spectra Intelligence not configured',
                        'hash': hash_clean,
                    }
            else:
                sample_data = analyze_api_response['results'][0]
                report = {
                    'analyze': {
                        'file_reputation': {
                            'classification': sample_data.get('classification', 'unknown'),
                            'classification_reason': sample_data.get('classification_reason', ''),
                            'classification_result': sample_data.get('classification_result', ''),
                            'file_size': sample_data.get('file_size', 0),
                            'file_subtype': sample_data.get('file_subtype', ''),
                            'file_type': sample_data.get('file_type', ''),
                            'first_seen': sample_data.get('local_first_seen', ''),
                            'hash': hash_clean,
                            'last_seen': sample_data.get('local_last_seen', ''),
                            'md5': sample_data.get('md5', ''),
                            'risk_score': sample_data.get('riskscore', 0),
                            'sample_id': sample_data.get('id', ''),
                            'sha1': sample_data.get('sha1', ''),
                            'sha256': sample_data.get('sha256', ''),
                            'source': 'local-spectra_analyze',
                            'tags': sample_data.get('tags', {}),
                        }
                    }
                }

            save_report_data('get_file_reputation', analyze_api_response, report)
            return compress_and_encode_data(report)

        except ValueError as e:
            logger.error('Validation error: %s', e)
            error_result = {'error': f'Validation error: {e}', 'hash': hash_value}
            save_report_data('get_file_reputation', error_result, error_result)
            return compress_and_encode_data(error_result)
        except Exception as e:
            logger.error('Unexpected error getting file reputation: %s', e)
            error_result = {'error': f'Unexpected error: {e}', 'hash': hash_clean if 'hash_clean' in locals() else hash_value}
            save_report_data('get_file_reputation', error_result, error_result)
            return compress_and_encode_data(error_result)


class BulkFileReputationTool(BaseMCPTool):
    """Bulk file reputation tool"""

    HASH_TYPES = {32: 'md5', 40: 'sha1', 64: 'sha256'}
    BATCH_SIZE = 100

    @staticmethod
    def _clean(hash_value: str) -> str:
        """Lower-case and strip a hash down to its hex characters."""
        return ''.join(c for c in (hash_value or '').lower() if c in '0123456789abcdef')

    @classmethod
    def _hash_type(cls, hash_value: str) -> Optional[str]:
        """Return the hash type for a hash, or None if unrecognised."""
        return cls.HASH_TYPES.get(len(cls._clean(hash_value)))

    def _build_result(self, entry: Dict[str, Any], query_hash_type: str) -> Dict[str, Any]:
        """Build a per-hash reputation result from a single RCA2 entry."""
        classification = (entry.get('classification') or 'unknown').upper()
        factor = entry.get('factor', 5)
        result_name = entry.get('result', '')
        components = entry.get('components') or []
        ordinal = entry.get('ordinal', 0)


        # taken from MCP Spectra Intelligence to be consistent but may be useless/unnecessary with all the extra
        # fields and outputs derived from the API data 
        mal_count = sum(1 for c in components if (c.get('classification') or '').lower() == 'malicious')
        sus_count = sum(1 for c in components if (c.get('classification') or '').lower() == 'suspicious')
        good_count = sum(1 for c in components if (c.get('classification') or '').lower() == 'goodware')

        final_component = components[ordinal] if 0 <= ordinal < len(components) else None

        detection_count = scanner_count = 0
        detection_rate = 0.0
        for comp in components:
            if comp.get('type') == 'antivirus':
                props = comp.get('properties') or {}
                detection_count = props.get('scanner_match', 0)
                scanner_count = props.get('scanner_count', 0)
                if scanner_count > 0:
                    detection_rate = round((detection_count / scanner_count) * 100, 1)
                break

        best_source = entry.get('best_source') or {}
        network_iocs: List[Dict[str, Any]] = []
        if best_source:
            domain_info = best_source.get('domain') or {}
            if domain_info:
                network_iocs.append({
                    'type': 'domain',
                    'name': domain_info.get('name'),
                    'container_sha1': domain_info.get('container_sha1'),
                    'factor': domain_info.get('factor', 5),
                })

        component_details = []
        for idx, comp in enumerate(components):
            detail: Dict[str, Any] = {
                'index': idx,
                'name': comp.get('name'),
                'type': comp.get('type'),
                'classification': (comp.get('classification') or '').upper(),
                'factor': comp.get('factor', 5),
                'timestamp': comp.get('timestamp'),
                'ignored': comp.get('ignored', False),
            }
            if comp.get('version'):
                detail['version'] = comp['version']
            props = comp.get('properties')
            if props:
                comp_props = dict(props)
                if comp.get('type') == 'antivirus' and comp_props.get('scanner_count', 0) > 0:
                    comp_props['detection_rate'] = round(
                        (comp_props.get('scanner_match', 0) / comp_props['scanner_count']) * 100, 1
                    )
                detail['properties'] = comp_props
            component_details.append(detail)

        if classification == 'MALICIOUS':
            verdict_summary = 'Malicious'
            threat_level = 'HIGH' if factor >= 7 else 'MEDIUM'
        elif classification == 'SUSPICIOUS':
            verdict_summary = 'Suspicious'
            threat_level = 'MEDIUM'
        elif classification == 'GOODWARE':
            verdict_summary = 'No Threat Found'
            threat_level = 'LOW'
        else:
            verdict_summary = 'Unknown'
            threat_level = 'UNKNOWN'

        if factor == 0 and classification == 'GOODWARE':
            confidence = 'HIGH'
        elif factor >= 8:
            confidence = 'HIGH'
        elif factor >= 5:
            confidence = 'MEDIUM'
        else:
            confidence = 'LOW'

        threat_names = list({comp['result'] for comp in components if comp.get('result', '').strip()})

        is_fp_candidate = (
            classification == 'MALICIOUS'
            and detection_rate < 30
            and any(g in (result_name or '').lower() for g in ['generic', 'heur', 'pua', 'tool'])
        )
        requires_enhanced = classification == 'MALICIOUS' and factor >= 6

        
        evidence_score = 0.0
        tier1 = tier2 = tier3 = tier4 = negative = 0
        for comp in components:
            ctype = comp.get('type', '')
            cclass = (comp.get('classification') or '').lower()
            cfactor = comp.get('factor', 5)
            if cclass == 'malicious':
                if ctype in ('user_sample_override', 'analyst_sample_override'):
                    tier1 += 1
                    evidence_score += 3
                elif ctype in ('antivirus', 'sandbox', 'TC_signature', 'TC_antivirus',
                               'TC_certificate', 'YARA', 'best_source'):
                    tier2 += 1
                    evidence_score += 2
                elif ctype in ('TC_RHA1', 'TC_exploit', 'TC_machine_learning', 'TC_format',
                               'TC_byte_pattern', 'next_gen_av', 'TC_document_classifier'):
                    tier3 += 1
                    evidence_score += 1
                elif ctype in ('TC_email_classifier', 'TC_URL_classifier', 'TC_unknown'):
                    tier4 += 1
                    evidence_score += 0.5
            elif cclass == 'goodware':
                if ctype == 'best_certificate' and cfactor == 0:
                    negative += 1
                    evidence_score -= 3
                elif ctype in ('user_sample_override', 'analyst_sample_override'):
                    negative += 1
                    evidence_score -= 3
                elif ctype in ('TC_certificate', 'best_source') and cfactor == 0:
                    negative += 1
                    evidence_score -= 2

        return {
            'hash_info': {
                'md5': entry.get('md5'),
                'sha1': entry.get('sha1'),
                'sha256': entry.get('sha256'),
                'query_hash_type': query_hash_type,
            },
            'verdict': {
                'summary': verdict_summary,
                'classification': classification,
                'threat_level': threat_level,
                'confidence': confidence,
                'factor': factor,
            },
            'rca2_classification': {
                'reason': entry.get('reason', ''),
                'result': result_name,
                'ordinal': ordinal,
                'first_seen': entry.get('first_seen'),
                'last_seen': entry.get('last_seen'),
                'sample_type': entry.get('sample_type'),
            },
            'components': {
                'total': len(components),
                'malicious': mal_count,
                'suspicious': sus_count,
                'goodware': good_count,
                'final_decision': {
                    'name': final_component.get('name'),
                    'type': final_component.get('type'),
                    'classification': (final_component.get('classification') or '').upper(),
                    'factor': final_component.get('factor', 5),
                } if final_component else None,
                'details': component_details,
            },
            'threat_intelligence': {
                'threat_names': threat_names,
                'detection_count': detection_count,
                'scanner_count': scanner_count,
                'detection_rate': detection_rate,
                'propagation': entry.get('propagation'),
            },
            'trust_indicators': {
                'network_iocs': network_iocs,
            },
            'analysis_metadata': {
                'status': 'success',
                'is_empty_file': (entry.get('md5') or '').lower() == EMPTY_FILE_MD5,
                'is_false_positive_candidate': is_fp_candidate,
                'requires_enhanced_analysis': requires_enhanced,
                'evidence_score': round(evidence_score, 1),
                'evidence_breakdown': {
                    'tier1': tier1,
                    'tier2': tier2,
                    'tier3': tier3,
                    'tier4': tier4,
                    'negative': negative,
                },
            },
        }

    def execute(self, hashes: List[str]) -> Dict[str, Any]:
        """Execute a bulk file reputation lookup.

        Hashes are grouped by type (MD5/SHA-1/SHA-256), deduplicated, and
        queried through the Spectra Analyze RCA2 bulk proxy in batches of 100.
        Results are returned in the same order as the input list; a failed or
        missing lookup carries a ``status`` in ``analysis_metadata`` instead of
        a full verdict.

        Args:
            hashes: List of file hashes (MD5, SHA-1, or SHA-256). Mixed types are
                supported. Duplicates are deduplicated before querying.

        Returns:
            Bulk file reputation report with per-hash results in input order
        """
        if not hashes:
            return {'error': "'hashes' cannot be empty."}

        logger.info('Starting bulk file reputation lookup for %d hash(es)', len(hashes))

        # Group by hash type, deduplicate, track originals for result mapping.
        groups: Dict[str, List[str]] = {'md5': [], 'sha1': [], 'sha256': []}
        cleaned_to_originals: Dict[str, List[str]] = {}
        seen: Dict[str, set] = {'md5': set(), 'sha1': set(), 'sha256': set()}
        per_hash_results: Dict[str, Dict[str, Any]] = {}

        for h in hashes:
            htype = self._hash_type(h)
            if not htype:
                per_hash_results[h] = {
                    'hash_info': {'query_hash': h, 'query_hash_type': None},
                    'analysis_metadata': {
                        'status': 'invalid',
                        'error': 'Unrecognised hash format (expected 32/40/64 hex characters)',
                    },
                }
                continue
            cleaned = self._clean(h)
            cleaned_to_originals.setdefault(cleaned, []).append(h)
            if cleaned not in seen[htype]:
                groups[htype].append(cleaned)
                seen[htype].add(cleaned)

        raw_responses = []

        for htype, cleaned_hashes in groups.items():
            for i in range(0, len(cleaned_hashes), self.BATCH_SIZE):
                batch = cleaned_hashes[i:i + self.BATCH_SIZE]
                result = self.sa_client.get_rca2_bulk(batch, htype, max_hashes=self.BATCH_SIZE)

                if not result:
                    for h in batch:
                        for original in cleaned_to_originals.get(h, [h]):
                            per_hash_results[original] = {
                                'hash_info': {'query_hash': original, 'query_hash_type': htype},
                                'analysis_metadata': {
                                    'status': 'error',
                                    'error': 'RCA2 bulk lookup failed or returned no data',
                                },
                            }
                    continue

                raw_responses.append(result)
                rca2 = (result.get('rl') or {}).get('rca2') or {}
                invalid_set = {self._clean(v) for v in (rca2.get('invalid_hashes') or []) if isinstance(v, str)}

                entry_map: Dict[str, Dict[str, Any]] = {}
                for entry in rca2.get('entries') or []:
                    if not isinstance(entry, dict):
                        continue
                    qh = entry.get('query_hash') or {}
                    qv = qh.get(htype) if isinstance(qh, dict) else None
                    if isinstance(qv, str) and qv:
                        entry_map[self._clean(qv)] = entry

                for h in batch:
                    originals = cleaned_to_originals.get(h, [h])
                    if h in invalid_set:
                        r: Dict[str, Any] = {
                            'hash_info': {'query_hash': originals[0], 'query_hash_type': htype},
                            'analysis_metadata': {'status': 'invalid', 'error': 'Hash rejected by API'},
                        }
                    elif h not in entry_map:
                        r = {
                            'hash_info': {'query_hash': originals[0], 'query_hash_type': htype},
                            'analysis_metadata': {'status': 'not_found', 'error': 'Hash not found in Spectra Intelligence'},
                        }
                    else:
                        r = self._build_result(entry_map[h], htype)
                    for original in originals:
                        per_hash_results[original] = r

        total = len(hashes)
        # Count every input hash (duplicates included) whose lookup succeeded.
        successful = sum(
            1 for h in hashes
            if per_hash_results.get(h, {}).get('analysis_metadata', {}).get('status') == 'success'
        )
        report = {
            'bulk_analysis': {
                'total_hashes': total,
                'successful': successful,
                'failed': total - successful,
                'success_rate': round((successful / total) * 100, 1) if total else 0.0,
            },
            'results': [per_hash_results[h] for h in hashes],
        }

        logger.info('Bulk file reputation lookup completed: %d/%d successful', successful, total)

        save_report_data('bulk_file_reputation_lookup', {'rca2_bulk': raw_responses}, report)
        return report


def register(mcp):
    """Register the file reputation tool with the MCP server."""
    @mcp.tool(
        annotations=ToolAnnotations(
            title="Get File Reputation",
            readOnlyHint=True,
            destructiveHint=False,
            idempotentHint=True,
            openWorldHint=True,
        ),
    )
    def get_file_reputation(
            hash: Annotated[
                str,
                Field(description="File hash (MD5/SHA1/SHA256)", min_length=32, max_length=64)
            ]
    ) -> Dict[str, Any]:
        """
        Get malware classification and reputation scoring for a file hash
        """
        tool = FileReputationTool(
            sa_base_url=config.analyze_base_url,
            sa_verify_ssl=config.analyze_verify_ssl
        )
        return tool.execute(hash)

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Bulk File Reputation lookup for multiple hashes",
            readOnlyHint=True,
            destructiveHint=False,
            idempotentHint=True,
            openWorldHint=True,
        ),
    )
    def bulk_file_reputation_lookup(
            hashes: Annotated[
                List[str],
                Field(description="List of file hashes (MD5/SHA1/SHA256, mixed types allowed)")
            ]
    ) -> Dict[str, Any]:
        """
        Get malware classification and reputation scoring for multiple file hashes in a single bulk lookup.
        """
        tool = BulkFileReputationTool(
            sa_base_url=config.analyze_base_url,
            sa_verify_ssl=config.analyze_verify_ssl
        )
        return tool.execute(hashes)
