"""Sample content retrieval tool."""

from mcp_server_analyze.tools.sample_content.sample_content import register

__all__ = ['register']
