"""Server info tool."""

from mcp_server_analyze.tools.server_info.server_info import register

__all__ = ['register']
