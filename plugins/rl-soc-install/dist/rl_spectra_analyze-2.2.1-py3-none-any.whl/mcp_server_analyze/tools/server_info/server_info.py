"""Server info tool for Spectra Analyze MCP Server."""
from typing import Dict
import logging
from mcp.types import ToolAnnotations

from mcp_server_analyze.core import get_config
from mcp_server_analyze.tools.base_tool import BaseMCPTool
from mcp_server_analyze.tools.tool_utils import save_report_data, compress_and_encode_data
from mcp_server_analyze.version import SPECTRA_ANALYZE_MCP_VERSION

logger = logging.getLogger(__name__)
config = get_config()


class ServerInfoTool(BaseMCPTool):
    """Server info tool with class-based architecture."""
    
    def execute(self) -> Dict:
        """Execute server info retrieval.
        
        Returns:
            Server information
        """
        logger.info('Getting server info')
        result = {
            'server_name': 'reversinglabs-spectra-analyze-mcp',
            'base_url': self.sa_base_url,
            'version': SPECTRA_ANALYZE_MCP_VERSION,
        }
        save_report_data('get_server_info', result, result)
        return compress_and_encode_data(result)


def register(mcp):
    """Register the server info tool with the MCP server."""
    @mcp.tool(
        description="Get information about the MCP server configuration.",
        annotations=ToolAnnotations(
            title="Get Server Information",
            readOnlyHint=True,
            destructiveHint=False,
            idempotentHint=True,
            openWorldHint=True,
        ),
    )
    def get_server_info() -> Dict:
        """Get information about the MCP server configuration."""
        tool = ServerInfoTool(
            sa_base_url=config.analyze_base_url,
            sa_verify_ssl=config.analyze_verify_ssl
        )
        return tool.execute()
