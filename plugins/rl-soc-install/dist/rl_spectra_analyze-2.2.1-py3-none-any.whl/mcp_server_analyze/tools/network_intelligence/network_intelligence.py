"""Network threat intelligence tool for Spectra Analyze MCP Server.

Provides ``get_network_intelligence`` which returns detailed threat
intelligence for a URL, domain, or IP address using the Spectra Analyze
Network Threat Intelligence API.

The indicator type is detected automatically:
- URLs contain ``://``
- IP addresses (IPv4 or IPv6) are parsed via the standard library
- Everything else is treated as a domain

**URL**: classification, threat details, third-party reputation, static
analysis, and dynamic analysis (returned as a flat report).

**Domain**: ``{report, related_domains, related_urls, resolutions}``. Only the
report is populated by the Spectra Analyze API; the other keys are present but
empty for parity with the Spectra Intelligence output shape.

**IP**: ``{report, geoip, related_urls, resolutions}`` where ``related_urls``
are URLs hosted on the IP and ``resolutions`` are IP-to-domain mappings.
"""
import ipaddress
import logging
from typing import Any, Dict, Annotated

from pydantic import Field
from mcp.types import ToolAnnotations

from mcp_server_analyze.core import get_config
from mcp_server_analyze.tools.base_tool import BaseMCPTool
from mcp_server_analyze.tools.tool_utils import save_report_data, geoip_for

logger = logging.getLogger(__name__)
config = get_config()


def _classify_indicator(indicator: str) -> str:
    """Return 'url', 'ip', or 'domain' for the given network indicator."""
    if "://" in indicator:
        return "url"

    # Strip a single trailing port (e.g. "example.com:8080" or "1.2.3.4:80").
    # IPv6 addresses contain multiple colons and are handled by ip_address.
    clean = indicator.split(":")[0] if indicator.count(":") == 1 else indicator
    try:
        ipaddress.ip_address(clean)
        return "ip"
    except ValueError:
        return "domain"


def _rename_goodware(stats: Any) -> None:
    """Rename a ``goodware`` file-statistics bucket to ``known`` in-place.

    Applied unconditionally so the key name is stable across responses; the
    Spectra Analyze payload uses ``goodware`` while the rest of the tooling
    (and Spectra Intelligence) uses ``known``.
    """
    if isinstance(stats, dict) and "goodware" in stats:
        stats["known"] = stats.pop("goodware")


def _transform_url_report(report: Dict[str, Any]) -> None:
    """Trim the verbose history arrays from a URL report in-place.

    Every key is preserved as-is except:
    - ``analysis``: drop the bulky ``analysis_history`` and the redundant
      ``first_analysis`` / ``analysis_count`` counters, and rename the
      served-file ``statistics`` to ``downloaded_file_classifications``.
    - ``dynamic_analysis``: drop the ``analysis_history``, keeping
      ``last_analysis``.
    - ``third_party_reputations``: rename the ``statistics`` sub-key to
      ``reputations`` (matching the Spectra Intelligence shape).

    No keys are dropped based on whether their value is present, so the output
    schema stays stable regardless of the data returned.
    """
    if isinstance(analysis := report.get("analysis"), dict):
        analysis.pop("analysis_history", None)
        analysis.pop("first_analysis", None)
        analysis.pop("analysis_count", None)
        if "statistics" in analysis:
            stats = analysis.pop("statistics")
            _rename_goodware(stats)
            analysis["downloaded_file_classifications"] = stats
    if isinstance(dynamic := report.get("dynamic_analysis"), dict):
        dynamic.pop("analysis_history", None)
    if isinstance(rep := report.get("third_party_reputations"), dict):
        if "statistics" in rep:
            rep["reputations"] = rep.pop("statistics")


def _transform_domain_report(report: Dict[str, Any]) -> None:
    """Normalize a domain report in-place, keeping the schema stable.

    Only renames the ``goodware`` file-statistics bucket to ``known``; all
    other keys are preserved exactly as returned (including ``null`` / empty
    values) so the output schema does not change between responses.
    """
    _rename_goodware(report.get("downloaded_files_statistics"))


def _transform_ip_report(report: Dict[str, Any]) -> None:
    """Normalize an IP report in-place, keeping the schema stable.

    Only renames the ``goodware`` file-statistics bucket to ``known``; all
    other keys are preserved exactly as returned.
    """
    _rename_goodware(report.get("downloaded_files_statistics"))


class NetworkIntelligenceTool(BaseMCPTool):
    """Tool for fetching detailed network threat intelligence."""

    def _url_intel(self, url: str) -> Dict[str, Any]:
        """Fetch threat intelligence for a URL.
        """
        report = self.sa_client.get_network_url_intel(url)
        if not report:
            return {"error": f"No network threat intelligence found for URL: {url}"}
        _transform_url_report(report)
        geo = geoip_for(url, report.get("geoip"))
        if geo:
            report["geoip"] = geo
        return report

    def _domain_intel(self, domain: str) -> Dict[str, Any]:
        """Fetch threat intelligence for a domain.
        """
        report = self.sa_client.get_network_domain_intel(domain)
        if not report:
            return {"error": f"No network threat intelligence found for domain: {domain}"}
        _transform_domain_report(report)
        return {
            "report": report,
            "geoip": geoip_for(domain, report.get("geoip")),
            "related_domains": [],
            "related_urls": [],
            "resolutions": [],
        }

    def _ip_intel(self, ip: str) -> Dict[str, Any]:
        """Fetch threat intelligence for an IP address.
        """
        report = self.sa_client.get_network_ip_intel(ip)
        resolutions = self.sa_client.get_network_ip_resolutions(ip)
        urls = self.sa_client.get_network_ip_urls(ip)

        if not (report or resolutions or urls):
            return {"error": f"No network threat intelligence found for IP: {ip}"}

        if report:
            _transform_ip_report(report)

        return {
            "report": report or {},
            "geoip": geoip_for(ip, (report or {}).get("geoip")),
            "related_urls": [u.get("url") for u in (urls or {}).get("urls", []) if u.get("url")],
            "resolutions": (resolutions or {}).get("resolutions", []),
        }

    def execute(self, indicator: str) -> Dict[str, Any]:
        """Execute network threat intelligence lookup.

        Args:
            indicator: URL, domain, or IP address.

        Returns:
            Network threat intelligence report.
        """
        if not indicator:
            return {"error": "indicator is required"}

        indicator_type = _classify_indicator(indicator)
        logger.info('Starting network intelligence lookup for %s (%s)', indicator, indicator_type)

        try:
            if indicator_type == "url":
                report = self._url_intel(indicator)
            elif indicator_type == "ip":
                report = self._ip_intel(indicator)
            else:
                report = self._domain_intel(indicator)
        except Exception as lookup_err:
            logger.error("Network intelligence lookup failed for %s: %s", indicator, lookup_err, exc_info=True)
            return {"error": f"Network intelligence lookup failed for {indicator}: {lookup_err}"}

        save_report_data('get_network_intelligence', {"indicator": indicator, "type": indicator_type}, report)
        return report


def register(mcp):
    """Register the network intelligence tool with the MCP server."""

    @mcp.tool(
        # Return the report dict as-is instead of nesting it under a
        # ``{"result": ...}`` structured-output wrapper.
        structured_output=False,
        annotations=ToolAnnotations(
            title="Get Network Threat Intelligence for a URL, domain, or IP address",
            readOnlyHint=True,
            destructiveHint=False,
            idempotentHint=True,
            openWorldHint=True,
        ),
    )
    def get_network_intelligence(
            indicator: Annotated[
                str,
                Field(description="URL, domain, or IP address")
            ]
    ) -> Dict[str, Any]:
        """
        Get network threat intelligence for a URL, domain, or IP address (type auto-detected).

        - **URL**: flat report with classification, threat_name/threat_level,
          third-party reputation, static ``analysis``, and ``dynamic_analysis``.
        - **Domain**: ``{report, related_domains, related_urls, resolutions}``
          (only ``report`` populated).
        - **IP**: ``{report, geoip, related_urls, resolutions}`` (``related_urls``
          hosted on the IP; ``resolutions`` are IP-to-domain mappings).
        """
        tool = NetworkIntelligenceTool(
            sa_base_url=config.analyze_base_url,
            sa_verify_ssl=config.analyze_verify_ssl
        )
        return tool.execute(indicator)
