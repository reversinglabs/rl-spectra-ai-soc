"""Shared tool registration helpers for the Spectra Analyze MCP server.

This module centralizes imports and registration of all tools so that both the
runtime server and build-time utilities (like manifest generation) can stay in
sync.
"""

from typing import Protocol, Any


class MCPLike(Protocol):
    """Minimal protocol for objects that support the MCP tool decorator."""

    def tool(self, *args: Any, **kwargs: Any):  # pragma: no cover - interface only
        ...


def register_all_tools(mcp: MCPLike) -> None:
    """Register all MCP tools on the given `mcp`-like object.

    Mirrors the imports used in `create_mcp_server` so that any caller using this
    helper (e.g. the real server or the manifest generator) sees the same tool
    surface.
    """

    from mcp_server_analyze.tools.file_reputation import register as register_file_reputation
    from mcp_server_analyze.tools.enhanced_threat_analysis import register as register_enhanced_threat_analysis
    from mcp_server_analyze.tools.server_info import register as register_server_info
    from mcp_server_analyze.tools.network_reputation import register as register_network_reputation
    from mcp_server_analyze.tools.network_intelligence import register as register_network_intelligence
    from mcp_server_analyze.tools.search import register as register_advanced_search
    from mcp_server_analyze.tools.artifact_submission import register as register_artifact_submission
    from mcp_server_analyze.tools.yara_hunt import register as register_yara_hunt
    from mcp_server_analyze.tools.sample_details import register as register_sample_details
    from mcp_server_analyze.tools.sample_strings import register as register_sample_strings
    from mcp_server_analyze.tools.sample_content import register as register_sample_content
    from mcp_server_analyze.tools.sample_similarity import register as register_sample_similarity
    from mcp_server_analyze.tools.sample_behavior import register as register_sample_behavior
    from mcp_server_analyze.tools.downloaded_files import register as register_downloaded_files
    from mcp_server_analyze.tools.certificate import register as register_certificate

    # Core tools
    register_file_reputation(mcp)
    register_enhanced_threat_analysis(mcp)
    register_network_reputation(mcp)
    register_network_intelligence(mcp)
    register_advanced_search(mcp)
    register_server_info(mcp)
    register_artifact_submission(mcp)
    register_sample_details(mcp)
    register_sample_strings(mcp)
    register_sample_content(mcp)
    register_sample_similarity(mcp)
    register_sample_behavior(mcp)
    register_downloaded_files(mcp)
    register_certificate(mcp)

    # YARA hunting tools (streamlined)
    register_yara_hunt(mcp)
