"""Base class for MCP tools."""

import logging
from abc import ABC

from mcp_server_analyze.clients import SpectraAnalyzeClient, SpectraIntelligenceClient
from mcp_server_analyze.core import SpectraIntelligenceCredentials

logger = logging.getLogger(__name__)


class BaseMCPTool(ABC):
    """Base class for all MCP tools."""
    
    def __init__(self, sa_base_url: str, sa_verify_ssl: bool = False):
        """Initialize the base MCP tool.
        
        Args:
            sa_base_url: Base URL for Spectra Analyze appliance
            sa_verify_ssl: Whether to verify SSL certificates
        """
        self.sa_base_url = sa_base_url
        self.sa_verify_ssl = sa_verify_ssl
        
        # Initialize Spectra Analyze client
        self.sa_client = SpectraAnalyzeClient(sa_base_url, sa_verify_ssl)
        
        # Initialize Spectra Intelligence credentials singleton
        self.credentials = SpectraIntelligenceCredentials()
        
        # Initialize Spectra Intelligence client if credentials available
        if self.credentials.is_available_for_use():
            self.si_client = SpectraIntelligenceClient(self.credentials.get_credentials())
            logger.debug('Spectra Intelligence client initialized')
        else:
            self.si_client = None
            logger.debug('Spectra Intelligence client not available')
    
    def is_ticloud_available(self) -> bool:
        """Check if Spectra Intelligence is available.
        
        Returns:
            True if Spectra Intelligence credentials are available
        """
        return self.credentials.is_available_for_use()
