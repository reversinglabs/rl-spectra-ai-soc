"""Enhanced threat analysis tool using OOP architecture."""

import logging
from typing import Dict, Any
from datetime import datetime

from mcp_server_analyze.tools.base_tool import BaseMCPTool
from mcp_server_analyze.tools.enhanced_threat_analysis.network_enricher import NetworkIndicatorEnricher
from mcp_server_analyze.tools.enhanced_threat_analysis.analysis_normalizer import AnalysisResultNormalizer
from mcp_server_analyze.tools.tool_utils import save_report_data, compress_and_encode_data, get_llm_guidance

logger = logging.getLogger(__name__)


class EnhancedThreatAnalysisTool(BaseMCPTool):
    """Enhanced threat analysis tool with OOP architecture."""

    def __init__(self, sa_base_url: str, sa_verify_ssl: bool = False):
        """Initialize the enhanced threat analysis tool.

        Args:
            sa_base_url: Base URL for Spectra Analyze appliance
            sa_verify_ssl: Whether to verify SSL certificates
        """
        super().__init__(sa_base_url, sa_verify_ssl)

        # Initialize normalizer (specific to this tool)
        self.normalizer = AnalysisResultNormalizer()

        # Initialize result structure
        self.result = self._create_default_result()

        # Initialize cached data variables specific to this tool
        self._raw_sa_data = None
        self._raw_tca0104_data = None
        self._raw_tca0106_data = None

    def _create_default_result(self) -> Dict[str, Any]:
        """Create default enhanced threat analysis result structure."""
        return {
            'summary': {
                'hash': '',
                'verdict': 'UNKNOWN',
                'threat_name': '',
                'file_type': '',
                'file_size': 0,
                'extracted_file_count': 0,
                'file_names': [],
                'history': {
                    'scope': '',
                    'first_seen': '',
                    'last_seen': ''
                }
            },
            'story': '',
            'static_indicators': [],
            'av_analysis': {},
            'dynamic_analysis': {},
            'auxiliary_analysis': {},
            'indicators_of_compromise': {
                'file_indicators': {'imphash': ''},
                'network_indicators': {'domains': [], 'ip_addresses': [], 'urls': [], 'emails': []},
                'behavioral_indicators': {'file_paths': [], 'registry_keys': [], 'processes': [], 'mutexes': []},
                'certificate_indicators': {
                    'thumbprints': [], 'common_names': [], 'serial_numbers': [],
                    'issuers': [], 'subjects': [], 'expired_thumbprints': [],
                    'signer_serial_numbers': [], 'signer_issuers': []
                },
                'signatures': {'yara_rules': [], 'sigma_rules': []}
            },
            'extracted_files': {'count': 0, 'hashes': []},
            'mitre_attack': {},
            'enrichment': {
                'comprehensive_similarity': {
                    'target_hash': '',
                    'extracted_imphash': '',
                    'rha1_similar_count': 0,
                    'imphash_similar_count': 0,
                    'similarity_analysis_available': False,
                    'detailed_hashes': []
                }
            },
            'source': '',
            'attribution': 'IP Geolocation by DB-IP'
        }

    def execute(self, hash_value: str) -> Dict[str, Any]:
        """Execute enhanced threat analysis.

        Args:
            hash_value: File hash to analyze

        Returns:
            Complete enhanced threat analysis report
        """
        logger.info('Starting enhanced threat analysis for: %s', hash_value)

        self.result['summary']['hash'] = hash_value
        self.result['enrichment']['comprehensive_similarity']['target_hash'] = hash_value

        # Step 1: Fetch basic analysis
        self._fetch_basic_analysis(hash_value)

        # Step 2: Populate dynamic analysis and behavioral indicators
        self._populate_dynamic_analysis(hash_value)

        # Step 3: Extract IOCs
        self._extract_network_indicators()

        # Step 3b: Extract certificate indicators
        self._extract_certificate_indicators()

        # Step 4: Extract MITRE ATT&CK
        self._extract_mitre_attack()

        # Step 5: Populate comprehensive similarity
        self._populate_comprehensive_similarity(hash_value)

        # Step 6: Populate extracted files (SA only)
        self._populate_extracted_files(hash_value)

        # Step 7: Enrich network indicators with GeoIP (always available)
        self._enrich_network_indicators_geoip()

        # Step 8: Enrich network indicators with reputation (Spectra Intelligence only)
        if self.is_ticloud_available():
            self._enrich_network_indicators_reputation()

        # Deduplicate YARA rules
        yara_rules = self.result['indicators_of_compromise']['signatures']['yara_rules']
        self.result['indicators_of_compromise']['signatures']['yara_rules'] = list(set(yara_rules))

        # Add LLM guidance to behavioral indicators
        bi = self.result['indicators_of_compromise']['behavioral_indicators']
        if bi.get('file_paths') or bi.get('registry_keys') or bi.get('processes') or bi.get('mutexes'):
            bi['llm_guidance'] = (
                'These behavioral artifacts come from sandbox execution and may include benign activity '
                '(e.g., temp folders, common Windows registry keys, installer/updater behavior). '
                'Evaluate each file path and registry key for malicious relevance and context before '
                'treating them as IOCs.'
            )

        # Add LLM prompt
        self.result['llm_prompt'] = get_llm_guidance('enhanced_threat_analysis')

        # Save raw API responses for debugging
        raw_api_response = {}
        if self._raw_sa_data is not None:
            raw_api_response['spectra_analyze'] = self._raw_sa_data
        if self._raw_tca0104_data is not None:
            raw_api_response['spectra_intelligence'] = self._raw_tca0104_data

        # Save report data for debugging
        save_report_data('enhanced_threat_analysis', raw_api_response, self.result)

        logger.info('Enhanced threat analysis completed for: %s', hash_value)

        # Compress and encode data if needed
        return compress_and_encode_data(self.result)

    def _fetch_basic_analysis(self, hash_value: str):
        """Fetch basic file analysis from available sources."""
        # Try Spectra Analyze first
        logger.debug('Fetching file analysis from Spectra Analyze')
        raw_data = self.sa_client.get_file_analysis(hash_value)

        if raw_data:
            self._raw_sa_data = raw_data

            normalized = self.normalizer.normalize_file_analysis(raw_data, 'sa')
            self._populate_from_normalized(normalized)
            self.result['source'] = 'spectra_analyze'

            # Extract file names from ticore
            ticore = raw_data.get('ticore', {})
            if ticore:
                self.result['summary']['file_names'] = self._extract_file_names_from_ticore(ticore)

            # Populate extracted_file_count from sample_summary
            sample_summary = raw_data.get('sample_summary', {})
            self.result['summary']['extracted_file_count'] = sample_summary.get('extracted_file_count', 0)

            return

        # Fallback to Spectra Intelligence bridge api if available
        logger.debug('Fetching file analysis from Spectra Intelligence bridge api')
        raw_data = self.sa_client.get_rldata(hash_value)

        if raw_data:
            normalized = self.normalizer.normalize_file_analysis(raw_data, 'si')
            self._populate_from_normalized(normalized)
            self.result['source'] = 'spectra_intelligence'
            self._raw_tca0104_data = raw_data

            # Get RCA2 data for additional summary fields
            rca2_data = self.sa_client.get_rca2(hash_value)
            if rca2_data:
                rca2 = rca2_data.get('rl', {}).get('rca2', {})
                self.result['summary']['verdict'] = rca2.get('classification', '').upper()
                self.result['summary']['threat_name'] = rca2.get('result', '')
                self.result['summary']['file_type'] = rca2.get('sample_type', '')

                # Get sample data for file_size and imphash
                sample = raw_data.get('rl', {}).get('sample', {})
                self.result['summary']['file_size'] = sample.get('sample_size', 0)

                # Populate imphash from sample (SI specific)
                self.result['indicators_of_compromise']['file_indicators']['imphash'] = sample.get('imphash', '')

                # Populate history
                self.result['summary']['history']['scope'] = 'cloud'
                self.result['summary']['history']['first_seen'] = rca2.get('first_seen', '')
                self.result['summary']['history']['last_seen'] = rca2.get('last_seen', '')

                # Extract file names from TCA-0104 and ticore
            file_names = self._extract_file_names_from_tca0104(raw_data)

            # Also extract from ticore if available
            tc_report = {}
            if 'analysis' in raw_data.get('rl', {}).get('sample', {}):
                entries = raw_data.get('rl', {}).get('sample', {}).get('analysis', {}).get('entries', [])
                if len(entries) > 0 and 'tc_report' in entries[0]:
                    tc_report = entries[0]['tc_report']
                    ticore_names = self._extract_file_names_from_ticore(tc_report)
                    for name in ticore_names:
                        if name not in file_names:
                            file_names.append(name)

            self.result['summary']['file_names'] = file_names

            return

        logger.warning('No analysis data found for: %s', hash_value)

    def _populate_behavioral_indicators(self, normalized_dynamic: Dict[str, Any]):
        """Populate behavioral indicators from normalized dynamic analysis.

        Args:
            normalized_dynamic: Normalized dynamic analysis data
        """
        if 'behavioral_indicators' in normalized_dynamic:
            bi = self.result['indicators_of_compromise']['behavioral_indicators']
            bi['file_paths'] = normalized_dynamic['behavioral_indicators'].get('file_paths', [])
            bi['registry_keys'] = normalized_dynamic['behavioral_indicators'].get('registry_keys', [])
            bi['processes'] = normalized_dynamic['behavioral_indicators'].get('processes', [])
            bi['mutexes'] = normalized_dynamic['behavioral_indicators'].get('mutexes', [])

    def _populate_dynamic_analysis(self, hash_value: str):
        """Populate dynamic analysis and behavioral indicators."""
        normalized_dynamic = None

        # Try to get dynamic analysis from Spectra Analyze
        if self._raw_sa_data is not None:
            normalized_dynamic = self.normalizer.normalize_dynamic_analysis(self._raw_sa_data, 'sa')
        else:
            # Fallback to Spectra Intelligence TCA-0106
            # Cache the TCA-0106 data to avoid multiple API calls
            self._raw_tca0106_data = self.sa_client.get_dynamic_analysis(hash_value)
            if self._raw_tca0106_data:
                normalized_dynamic = self.normalizer.normalize_dynamic_analysis(self._raw_tca0106_data, 'si')

        # Process normalized dynamic analysis if available
        if normalized_dynamic:
            # Extract behavioral indicators before storing dynamic analysis
            self._populate_behavioral_indicators(normalized_dynamic)
            # Extract sigma_rules and populate signatures
            if 'sigma_rules' in normalized_dynamic:
                self.result['indicators_of_compromise']['signatures']['sigma_rules'] = normalized_dynamic['sigma_rules']
            # Extract YARA rules from SA dynamic analysis
            if 'yara_rules' in normalized_dynamic:
                self.result['indicators_of_compromise']['signatures']['yara_rules'].extend(normalized_dynamic['yara_rules'])
            # Remove behavioral_indicators, sigma_rules, and yara_rules from dynamic_analysis to avoid duplication
            normalized_dynamic.pop('behavioral_indicators', None)
            normalized_dynamic.pop('sigma_rules', None)
            normalized_dynamic.pop('yara_rules', None)
            self.result['dynamic_analysis'] = normalized_dynamic

    def _populate_from_normalized(self, normalized: Dict[str, Any]):
        """Populate result from normalized data."""
        # Update summary
        self.result['summary']['verdict'] = normalized.get('classification', 'UNKNOWN')
        self.result['summary']['threat_name'] = normalized.get('threat_name', '')
        self.result['summary']['file_type'] = normalized.get('file_type', '')
        self.result['summary']['file_size'] = normalized.get('file_size', 0)

        # Update history if available
        if 'history' in normalized:
            history = normalized['history']
            self.result['summary']['history']['scope'] = history.get('scope', '')
            self.result['summary']['history']['first_seen'] = history.get('first_seen', '')
            self.result['summary']['history']['last_seen'] = history.get('last_seen', '')

        # Update AV analysis
        if 'av_results' in normalized:
            av_results = normalized['av_results']
            if av_results:
                most_recent = self._get_most_recent_av(av_results)
                self.result['av_analysis'].update(most_recent)

        # Extract static indicators from ticore if available (works for both SA and SI)
        if 'ticore' in normalized:
            ticore = normalized['ticore']
            if ticore:
                # Populate story from ticore
                self.result['story'] = ticore.get('story', '')
                self.result['static_indicators'] = self._get_ticore_indicators(ticore)
                # Extract imphash from ticore (SA only)
                self.result['indicators_of_compromise']['file_indicators']['imphash'] = self._get_imphash_from_sa(ticore)
                # Extract YARA rules from ticore
                yara_rules = self.normalizer.extract_yara_rules_from_ticore(ticore)
                self.result['indicators_of_compromise']['signatures']['yara_rules'].extend(yara_rules)

        # Populate auxiliary_analysis for Spectra Analyze only
        if self._raw_sa_data is not None:
            aux_data = self._raw_sa_data.get('rl_auxiliary_analysis', {})
            if aux_data:
                self.result['auxiliary_analysis'] = self._prune_aux_data(aux_data)

    def _get_most_recent_av(self, av_results: list) -> Dict[str, Any]:
        """Get most recent AV scan results."""
        all_av_scans = {}
        most_recent_str = '2000-01-01T00:00:01'
        fmt = "%Y-%m-%dT%H:%M:%S"

        try:
            most_recent_dt = datetime.strptime(most_recent_str, fmt)

            for av_result in av_results:
                record_str = av_result.get('record_time')
                if record_str:
                    all_av_scans[record_str] = av_result
                    record_dt = datetime.strptime(record_str, fmt)

                    if record_dt > most_recent_dt:
                        most_recent_str = record_str
                        most_recent_dt = record_dt
        except Exception as e:
            logger.error('Error getting most recent AV results: %s', e)

        most_recent = all_av_scans.get(most_recent_str, {})

        # Calculate scanner stats
        if 'scanner_count' not in most_recent:
            most_recent['scanner_count'] = len(most_recent.get('scanners', []))

        if 'scanner_match' not in most_recent:
            matches = sum(1 for s in most_recent.get('scanners', []) if s.get('result', ''))
            most_recent['scanner_match'] = matches

        if 'scanner_percent' not in most_recent:
            count = most_recent['scanner_count']
            match = most_recent['scanner_match']
            most_recent['scanner_percent'] = (match / count * 100) if count > 0 else 0

        # Extract threat names and clean up scanner fields
        threat_names = set()
        for scanner in most_recent.get('scanners', []):
            result = scanner.get('result', '')
            if result:
                threat_names.add(result)
            # Remove unnecessary fields from scanner
            for field in ['scanner', 'nextgen', 'previous_result']:
                if field in scanner:
                    del scanner[field]

        most_recent['threat_names'] = sorted(list(threat_names))

        # Remove unnecessary fields from most_recent
        for field in ['nextgen_scanners', 'regular_scanners', 'info']:
            if field in most_recent:
                del most_recent[field]

        return most_recent

    def _get_ticore_indicators(self, ticore: Dict[str, Any]) -> list:
        """Extract static indicators from ticore data.

        Args:
            ticore: TICore data dictionary

        Returns:
            List of indicator dictionaries with priority >= 5
        """
        indicators = []
        try:
            for indicator in ticore.get('indicators', []):
                priority = indicator.get('priority', 0)
                if priority >= 5:
                    indicators.append({
                        'priority': priority,
                        'description': indicator.get('description', '')
                    })
        except Exception as e:
            logger.error('Failed to extract ticore indicators: %s', e)

        return indicators

    def _get_imphash_from_sa(self, ticore: Dict[str, Any]) -> str:
        """Extract imphash from ticore data (Spectra Analyze).

        Args:
            ticore: TICore data dictionary

        Returns:
            Imphash value or empty string
        """
        try:
            hashes = ticore.get('info', {}).get('file', {}).get('hashes', [])
            for hash_item in hashes:
                if hash_item.get('name', '') == 'imphash':
                    return hash_item.get('value', '')
        except Exception as e:
            logger.error('Error extracting imphash: %s', e)
        return ''

    def _prune_aux_data(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Extract and filter auxiliary analysis data.

        Args:
            data: rl_auxiliary_analysis data

        Returns:
            Filtered auxiliary analysis with heuristics (score >= 300)
        """
        result = {
            'classification': '',
            'heuristics': []
        }

        try:
            results = data.get('results', [])
            for item in results:
                key = item.get('key', '')
                if key == 'heuristics':
                    for heur_list in item.get('value', {}).values():
                        for heur in heur_list:
                            logger.debug('Heuristic data %s', heur)
                            score = heur.get('score', 0)
                            if score >= 300:
                                result['heuristics'].append({
                                    'description': heur.get('name', ''),
                                    'classification': self._aux_score_to_classification(score)
                                })
                elif key == 'max_score':
                    result['classification'] = self._aux_score_to_classification(item.get('value', 0))
        except Exception as e:
            logger.error('Error pruning auxiliary analysis data: %s', e)

        return result

    def _aux_score_to_classification(self, score: int) -> str:
        """Convert auxiliary analysis numeric score to classification.

        Args:
            score: Numeric score value

        Returns:
            Classification string
        """
        if score >= 900:
            return 'MALICIOUS'
        elif score >= 700:
            return 'SUSPICIOUS'
        elif score >= 1:
            return 'KNOWN'
        else:
            return 'UNKNOWN'

    def _extract_file_names_from_ticore(self, ticore: Dict[str, Any]) -> list:
        """Extract file names from ticore report.

        Extracts from:
        - .info.file.proposed_filename
        - .application.pe.version_info[] where name='OriginalFilename'

        Args:
            ticore: TICore report dictionary

        Returns:
            List of file names
        """
        file_names = []

        try:
            # Extract proposed_filename
            proposed = ticore.get('info', {}).get('file', {}).get('proposed_filename', '')
            if proposed:
                file_names.append(proposed)

            # Extract OriginalFilename from PE version_info
            version_info = ticore.get('application', {}).get('pe', {}).get('version_info', [])
            for item in version_info:
                if item.get('name') == 'OriginalFilename':
                    value = item.get('value', '')
                    if value and value not in file_names:
                        file_names.append(value)

        except Exception as e:
            logger.error('Error extracting file names from ticore: %s', e)

        return file_names

    def _extract_file_names_from_tca0104(self, ticloud_data: Dict[str, Any]) -> list:
        """Extract file names from Spectra Intelligence TCA-0104 report.

        Extracts from:
        - .rl.sample.sources.entries[] where tag='external_feed'
          then properties[] where name in ('file_name', 'filename')

        Args:
            ticloud_data: TCA-0104 API response dictionary

        Returns:
            List of file names
        """
        file_names = []

        try:
            sample = ticloud_data.get('rl', {}).get('sample', {})
            sources_entries = sample.get('sources', {}).get('entries', [])

            for entry in sources_entries:
                if entry.get('tag') == 'external_feed':
                    properties = entry.get('properties', [])
                    for prop in properties:
                        if prop.get('name') in ('file_name', 'filename'):
                            value = prop.get('value', '')
                            if value and value not in file_names:
                                file_names.append(value)

        except Exception as e:
            logger.error('Error extracting file names from TCA-0104: %s', e)

        return file_names

    def _extract_network_indicators(self):
        """Extract network indicators from analysis data."""
        network_iocs_static = {'domains': [], 'ip_addresses': [], 'urls': [], 'emails': []}
        network_iocs_dynamic = {'domains': [], 'ip_addresses': [], 'urls': [], 'emails': []}

        # Extract from Spectra Analyze data
        if self._raw_sa_data is not None:
            ticore = self._raw_sa_data.get('ticore', {})
            if ticore:
                network_iocs_static = self.normalizer.extract_network_iocs_from_ticore(ticore)

            rlcs = self._raw_sa_data.get('rl_cloud_sandbox', {})
            if rlcs:
                network_iocs_dynamic = self.normalizer.extract_network_iocs_from_sa_dynamic(rlcs)
        elif self._raw_tca0104_data is not None:
            # Use cached TCA-0104 data
            entries = self._raw_tca0104_data.get('rl', {}).get('sample', {}).get('analysis', {}).get('entries', [])
            if len(entries) > 0:
                network_iocs_static = self.normalizer.extract_network_iocs_from_ticore(entries[0].get('tc_report', {}))

        # Extract from Spectra Intelligence data (TCA-0106)
        if self._raw_tca0106_data is not None:
            # Use cached TCA-0106 data
            network_iocs_dynamic = self.normalizer.extract_network_iocs_from_tca0106(self._raw_tca0106_data)
            # Extract YARA rules from TCA-0106
            yara_rules_tca0106 = self.normalizer.extract_yara_rules_from_tca0106(self._raw_tca0106_data)
            self.result['indicators_of_compromise']['signatures']['yara_rules'].extend(yara_rules_tca0106)

        # Merge network indicators from static and dynamic analysis
        for ioc_type in ['domains', 'ip_addresses', 'urls', 'emails']:
            combined = list(set(network_iocs_static.get(ioc_type, []) + network_iocs_dynamic.get(ioc_type, [])))
            self.result['indicators_of_compromise']['network_indicators'][ioc_type] = combined

    def _extract_certificate_indicators(self):
        """Extract certificate indicators from ticore certificate data.

        Works for both Spectra Analyze (ticore) and Spectra Intelligence
        cloud samples (TCA-0104 tc_report).
        """
        ticore = None

        if self._raw_sa_data is not None:
            ticore = self._raw_sa_data.get('ticore', {})
        elif self._raw_tca0104_data is not None:
            entries = self._raw_tca0104_data.get('rl', {}).get('sample', {}).get('analysis', {}).get('entries', [])
            if len(entries) > 0:
                ticore = entries[0].get('tc_report', {})

        if ticore:
            self.result['indicators_of_compromise']['certificate_indicators'] = \
                self.normalizer.extract_certificate_indicators_from_ticore(ticore)

    def _extract_mitre_attack(self):
        """Extract MITRE ATT&CK techniques using the normalizer."""
        self.result['mitre_attack'] = self.normalizer.extract_mitre_attack(
            sa_data=self._raw_sa_data,
            tca0106_data=self._raw_tca0106_data,
            tca0104_data=self._raw_tca0104_data
        )

    def _fetch_similar(self, hash_value: str, method: str) -> Dict[str, Any]:
        """Fetch similar files using advanced search.

        Uses Spectra Intelligence if available, otherwise falls back to Spectra Analyze.

        Args:
            hash_value: Hash to search for
            method: Search method ('similar-to' or 'imphash')

        Returns:
            Dictionary with count and hashes list
        """
        try:
            sim_query = f"{method}:{hash_value}"

            # Initially try to fetch similar from Spectra Intelligence proxy API
            logger.debug('Using Spectra Intelligence proxy API for similar files search')
            sim_resp = self.sa_client.advanced_search(sim_query, ticloud=True)

            if not (sim_resp or {}).get('search_api', {}).get('total_count'):
                # If no results, try to fetch similar from Spectra Analyze
                logger.debug('Using Spectra Analyze for similar files search')
                sim_resp = self.sa_client.advanced_search(sim_query)

            hashes = []
            seen = set()

            sim_resp = (sim_resp or {}).get('search_api', {})

            if isinstance(sim_resp, dict):
                entries = sim_resp.get('entries', [])
                for entry in entries:
                    hv = entry.get('sha1')
                    if not isinstance(hv, str):
                        continue
                    hvl = hv.lower()
                    # Exclude the queried file itself for RHA1 similarity when possible
                    if method == 'similar-to' and hvl == hash_value.lower():
                        continue
                    if hvl not in seen:
                        seen.add(hvl)
                        hashes.append(hvl)
                    if len(hashes) >= 50:
                        break

            total = None
            if isinstance(sim_resp, dict):
                total = sim_resp.get('total_count')
            if not isinstance(total, int):
                total = len(seen)

            return {
                'count': total,
                'hashes': hashes,
            }
        except Exception as e:
            logger.error("Failed to fetch similar files using method '%s': %s", method, e)
            return {'count': 0, 'hashes': []}

    def _get_similar_files(self, hashstr: str, imphash: str) -> Dict[str, Any]:
        """Get similar files based on RHA1 and imphash.

        Args:
            hashstr: File hash (SHA1, SHA256, or MD5)
            imphash: Import hash

        Returns:
            Dictionary with similar_files_rha1 and similar_files_imphash
        """
        output = {
            'similar_files_rha1': {'count': 0, 'hashes': []},
            'similar_files_imphash': {'count': 0, 'hashes': []},
        }

        try:
            if not hashstr or not isinstance(hashstr, str):
                return {"error": "Hash must be a non-empty string"}
            hash_clean = hashstr.strip().lower()
            if not hash_clean:
                return {"error": "Hash cannot be empty"}

            # RHA1 similarity based on the provided file hash
            output['similar_files_rha1'] = self._fetch_similar(hash_clean, 'similar-to')

            # imphash-based similarity, only if provided
            if isinstance(imphash, str) and imphash.strip():
                imphash_clean = imphash.strip().lower()
                output['similar_files_imphash'] = self._fetch_similar(imphash_clean, 'imphash')
        except Exception as e:
            logger.error('get_similar_files failed: %s', e)

        return output

    def _populate_comprehensive_similarity(self, hash_value: str):
        """Populate comprehensive similarity analysis."""
        try:
            hash_clean = hash_value.strip().lower()
            imphash = self.result['indicators_of_compromise']['file_indicators'].get('imphash', '')

            logger.debug('Getting similar files...')
            similar_files = self._get_similar_files(hash_clean, imphash or None)

            self.result['enrichment']['comprehensive_similarity']['extracted_imphash'] = imphash
            self.result['enrichment']['comprehensive_similarity']['rha1_similar_count'] = similar_files['similar_files_rha1']['count']
            self.result['enrichment']['comprehensive_similarity']['imphash_similar_count'] = similar_files['similar_files_imphash']['count']
            self.result['enrichment']['comprehensive_similarity']['similarity_analysis_available'] = bool(
                similar_files['similar_files_rha1']['count'] or similar_files['similar_files_imphash']['count']
            )
            self.result['enrichment']['comprehensive_similarity']['detailed_hashes'] = (
                similar_files['similar_files_rha1']['hashes'] + similar_files['similar_files_imphash']['hashes']
            )
        except Exception as e:
            logger.error('Failed to get similar files: %s', e)

        # Get RHA1 statistics from Spectra Intelligence if available
        try:
            logger.debug('Getting RHA1 statistics from Spectra Intelligence...')

            # Determine RHA1 type based on file type
            file_type = self.result['summary']['file_type'].lower()
            if file_type.startswith('pe'):
                rha1_type = 'pe01'
            elif file_type.startswith('elf'):
                rha1_type = 'elf01'
            elif file_type.startswith('macho'):
                rha1_type = 'macho01'
            else:
                rha1_type = 'pe01'  # Default to PE

            rha1_data = self.sa_client.get_rha1_analytics(hash_clean, rha1_type)
            if rha1_data:
                rha1_counters = rha1_data.get('rl', {}).get('rha1_counters', {})
                sample_counters = rha1_counters.get('sample_counters', {})

                self.result['enrichment']['comprehensive_similarity']['rha_statistics'] = {
                    'rha1_first_seen': rha1_counters.get('rha1_first_seen', ''),
                    'rha1_last_seen': rha1_counters.get('rha1_last_seen', ''),
                    'rha1_sample_count': {
                        'known': sample_counters.get('known', 0),
                        'malicious': sample_counters.get('malicious', 0),
                        'suspicious': sample_counters.get('suspicious', 0),
                        'total': sample_counters.get('total', 0)
                    }
                }
                logger.info('Retrieved RHA1 statistics: %d total samples', sample_counters.get("total", 0))
        except Exception as e:
            logger.error('Failed to get RHA1 statistics: %s', e)

    def _populate_extracted_files(self, hash_value: str):
        """Populate extracted files data (Spectra Analyze only).

        Args:
            hash_value: File hash to query
        """
        # Only populate for Spectra Analyze data
        if self._raw_sa_data is None:
            return

        extracted_file_count = self.result['summary']['extracted_file_count']

        # Only fetch if count is between 1 and 50
        if extracted_file_count > 0 and extracted_file_count < 51:
            logger.debug('Getting extracted files...')
            try:
                hash_clean = hash_value.strip().lower()
                extracted_files_data = self.sa_client.get_extracted_files(hash_clean)

                if extracted_files_data:
                    self.result['extracted_files']['hashes'] = extracted_files_data
                    self.result['extracted_files']['count'] = len(extracted_files_data)
                    logger.debug('Retrieved %d extracted files', len(extracted_files_data))
            except Exception as e:
                logger.error('Failed to get extracted files: %s', e)

    def _enrich_network_indicators_geoip(self):
        """Enrich network indicators with GeoIP data (always available)."""
        enricher = NetworkIndicatorEnricher(self.sa_client)

        indicators = self.result['indicators_of_compromise']['network_indicators']

        # GeoIP enrichment (doesn't require Spectra Intelligence, modifies in-place)
        enricher.enrich_with_geoip(indicators)

    def _enrich_network_indicators_reputation(self):
        """Enrich network indicators with reputation data (Spectra Intelligence only)."""
        enricher = NetworkIndicatorEnricher(self.sa_client)

        indicators = self.result['indicators_of_compromise']['network_indicators']

        # Reputation enrichment (requires Spectra Intelligence, modifies in-place)
        enricher.enrich_with_reputation(indicators)
