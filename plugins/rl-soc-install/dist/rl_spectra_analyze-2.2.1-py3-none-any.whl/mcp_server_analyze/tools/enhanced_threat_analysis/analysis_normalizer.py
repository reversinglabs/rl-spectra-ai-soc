"""Normalizer for analysis results from different API sources."""

import logging
from datetime import datetime, timezone
from typing import Dict, Any, Optional, List

logger = logging.getLogger(__name__)


class AnalysisResultNormalizer:
    """Normalize analysis results from Spectra Analyze and Spectra Intelligence."""
    
    @staticmethod
    def normalize_file_analysis(raw_data: Dict[str, Any], source: str) -> Dict[str, Any]:
        """Normalize file analysis data from different sources.
        
        Args:
            raw_data: Raw API response data
            source: Source of data ('sa' for Spectra Analyze, 'si' for Spectra Intelligence)
            
        Returns:
            Normalized analysis data
        """
        if source == 'si':
            return AnalysisResultNormalizer._normalize_si_file_analysis(raw_data)
        elif source == 'sa':
            return AnalysisResultNormalizer._normalize_sa_file_analysis(raw_data)
        else:
            logger.warning('Unknown source for file analysis normalization: %s', source)
            return {}
    
    @staticmethod
    def _normalize_si_file_analysis(raw_data: Dict[str, Any]) -> Dict[str, Any]:
        """Normalize Spectra Intelligence file analysis data."""
        result = {}
        
        try:
            rl = raw_data.get('rl', {})
            sample = rl.get('sample', {})
            
            # Extract basic file info
            result['hash_values'] = {
                'sha1': sample.get('sha1', ''),
                'sha256': sample.get('sha256', ''),
                'md5': sample.get('md5', '')
            }
            
            result['file_type'] = sample.get('sample_type', '')
            result['file_size'] = sample.get('sample_size', 0)
            
            # Extract classification
            classification = rl.get('classification', {})
            result['classification'] = classification.get('classification', 'UNKNOWN')
            result['risk_score'] = classification.get('risk_score', 0)
            
            # Extract threat info
            result['threat_name'] = rl.get('malware_family', '')
            result['threat_level'] = classification.get('threat_level', 0)
            
            # Extract AV results from xref entries (tool will process them)
            xref_entries = sample.get('xref', {}).get('entries', [])
            result['av_results'] = xref_entries
            
            # Extract ticore report if available
            if 'analysis' in sample and 'entries' in sample['analysis']:
                entries = sample['analysis'].get('entries', [])
                if len(entries) > 0 and 'tc_report' in entries[0]:
                    result['ticore'] = entries[0]['tc_report']
            
        except Exception as e:
            logger.error('Error normalizing SI file analysis: %s', e)
        
        return result
    
    @staticmethod
    def _normalize_sa_file_analysis(raw_data: Dict[str, Any]) -> Dict[str, Any]:
        """Normalize Spectra Analyze file analysis data."""
        result = {}
        
        try:
            # Extract basic file info from ticore
            ticore = raw_data.get('ticore', {})
            file_info = raw_data.get('sample_summary', {})
            
            result['hash_values'] = {
                'sha1': file_info.get('sha1', ''),
                'sha256': file_info.get('sha256', ''),
                'md5': file_info.get('md5', '')
            }
            result['file_type'] = f"{file_info.get('file_type', '')}/{file_info.get('file_subtype', '')}"
            result['file_size'] = file_info.get('file_size', 0)
            
            # Extract classification
            result['classification'] = file_info.get('classification', 'UNKNOWN').upper()
            
            # Extract threat info
            result['threat_name'] = file_info.get('classification_result', '')
            
            # Extract history information
            result['history'] = {
                'scope': 'local',
                'first_seen': file_info.get('local_first_seen', ''),
                'last_seen': file_info.get('local_last_seen', '')
            }
            
            # Extract AV results from av_scanners array (tool will process them)
            av_scanners = raw_data.get('av_scanners', [])
            result['av_results'] = av_scanners
            
            # Extract ticore report
            result['ticore'] = ticore
            
        except Exception as e:
            logger.error('Error normalizing SA file analysis: %s', e)
        
        return result
    
    @staticmethod
    def normalize_dynamic_analysis(raw_data: Dict[str, Any], source: str) -> Dict[str, Any]:
        """Normalize dynamic analysis data from different sources.
        
        Args:
            raw_data: Raw API response data
            source: Source of data ('sa' or 'si')
            
        Returns:
            Normalized dynamic analysis data
        """
        if source == 'si':
            return AnalysisResultNormalizer._normalize_si_dynamic_analysis(raw_data)
        elif source == 'sa':
            return AnalysisResultNormalizer._normalize_sa_dynamic_analysis(raw_data)
        else:
            logger.warning('Unknown source for dynamic analysis normalization: %s', source)
            return {}
    
    @staticmethod
    def _normalize_si_dynamic_analysis(raw_data: Dict[str, Any]) -> Dict[str, Any]:
        """Normalize Spectra Intelligence (TCA-0106) dynamic analysis data."""
        result = {
            'classification': '',
            'risk_score': 0,
            'threat_names': [],
            'process_tree': [],
            'dropped_files': {},
            'signatures': [],
            'malware_configs': [],
            'sigma_rules': [],
            'behavioral_indicators': {
                'file_paths': [],
                'registry_keys': [],
                'processes': [],
                'mutexes': []
            }
        }
        
        try:
            # Response is flat — no rl.report wrapper.
            report = raw_data

            # Extract classification
            result['classification'] = report.get('classification', 'UNKNOWN')
            result['risk_score'] = report.get('risk_score', 0)

            # Extract process tree from behavioral data
            behavioral_list = report.get('behavioral', [])
            for item in behavioral_list:
                process_obj = item.get('process', {})
                process = process_obj.get('name', '') if isinstance(process_obj, dict) else str(process_obj)
                if process:
                    result['process_tree'].append(process)
            
            # Extract signatures (filter by risk_factor >= 7)
            signatures_list = report.get('signatures', [])
            for item in signatures_list:
                risk_factor = item.get('risk_factor', 0)
                if risk_factor >= 7:
                    result['signatures'].append({
                        'description': item.get('description', ''),
                        'risk_factor': risk_factor
                    })
            
            # Extract dropped files with deduplication
            dropped_files_list = report.get('dropped_files', [])
            for item in dropped_files_list:
                classification = item.get('classification', 'UNKNOWN')
                sha1 = item.get('sha1', '')
                file_name = item.get('file_name', '')
                file_type = item.get('sample_type', '')
                
                if classification not in result['dropped_files']:
                    result['dropped_files'][classification] = []
                
                # Check if this SHA1 already exists in this classification
                existing_file = None
                for f in result['dropped_files'][classification]:
                    if f['sha1'] == sha1:
                        existing_file = f
                        break
                
                if existing_file:
                    # File exists, add file_name to list if not already present
                    if file_name and file_name not in existing_file['file_names']:
                        existing_file['file_names'].append(file_name)
                else:
                    # New file, create entry with file_names as list
                    result['dropped_files'][classification].append({
                        'sha1': sha1,
                        'file_names': [file_name] if file_name else [],
                        'file_type': file_type
                    })
            
            # Extract threat names
            threat_names_list = report.get('threat_names', [])
            for item in threat_names_list:
                threat_name = item.get('threat_name', '')
                if threat_name:
                    result['threat_names'].append(threat_name)
            
            # Extract malware configurations
            malware_configs_list = report.get('malware_configurations', [])
            for item in malware_configs_list:
                new_config = {}
                for k, v in item.items():
                    if k != 'analysis_ids':
                        new_config[k] = v
                result['malware_configs'].append(new_config)
            
            # Extract sigma detections
            sigma_detections_list = report.get('sigma_detections', [])
            for item in sigma_detections_list:
                description = item.get('description', '')
                if description:
                    result['sigma_rules'].append(description)
            
            # Extract behavioral indicators
            for item in behavioral_list:
                if not isinstance(item, dict):
                    continue

                # Extract processes
                process_obj = item.get('process', {})
                process = process_obj.get('name', '') if isinstance(process_obj, dict) else str(process_obj)
                if process:
                    result['behavioral_indicators']['processes'].append(process)
                
                # Extract file actions
                file_actions = item.get('file_actions', [])
                if isinstance(file_actions, list):
                    for act in file_actions:
                        if isinstance(act, dict) and 'file_path' in act and 'file_name' in act:
                            full_path = act['file_path'] + '\\' + act['file_name']
                            result['behavioral_indicators']['file_paths'].append(full_path)
                
                # Extract registry actions
                registry_actions = item.get('registry_actions', [])
                if isinstance(registry_actions, list):
                    for act in registry_actions:
                        if isinstance(act, dict) and 'key_name' in act and 'value_name' in act:
                            reg_path = act['key_name']
                            if act['value_name']:
                                reg_path = reg_path + '\\' + act['value_name']
                            result['behavioral_indicators']['registry_keys'].append(reg_path)
                
                # Extract mutex actions
                mutex_actions = item.get('mutex_actions', [])
                if isinstance(mutex_actions, list):
                    for mtx in mutex_actions:
                        if isinstance(mtx, dict) and 'name' in mtx:
                            result['behavioral_indicators']['mutexes'].append(mtx['name'])
            
        except Exception as e:
            logger.error('Error normalizing SI dynamic analysis: %s', e)
        
        return result
    
    @staticmethod
    def _normalize_sa_dynamic_analysis(raw_data: Dict[str, Any]) -> Dict[str, Any]:
        """Normalize Spectra Analyze dynamic analysis data."""
        result = {
            'classification': '',
            'risk_score': 0,
            'threat_names': [],
            'process_tree': [],
            'dropped_files': {},
            'signatures': [],
            'malware_configs': [],
            'sigma_rules': [],
            'behavioral_indicators': {
                'file_paths': [],
                'registry_keys': [],
                'processes': [],
                'mutexes': []
            }
        }
        
        try:
            rlcs = raw_data.get('rl_cloud_sandbox', {})
            
            # Parse results array (each item has 'key' and 'value')
            results = rlcs.get('results', [])
            
            for result_item in results:
                key = result_item.get('key')
                val = result_item.get('value')
                
                if key == 'classification':
                    result['classification'] = val
                elif key == 'risk_score':
                    result['risk_score'] = val
                elif key == 'behaviour':
                    # Extract process tree and behavioral indicators from behaviour
                    for process_item in val:
                        if not isinstance(process_item, dict):
                            continue
                        
                        # Extract process for process_tree
                        process = process_item.get('process', '')
                        if process:
                            result['process_tree'].append(process)
                            result['behavioral_indicators']['processes'].append(process)
                        
                        # Extract file actions
                        file_actions = process_item.get('file_actions', [])
                        if isinstance(file_actions, list):
                            for act in file_actions:
                                if isinstance(act, dict) and 'file_path' in act and 'file_name' in act:
                                    full_path = act['file_path'] + '\\' + act['file_name']
                                    result['behavioral_indicators']['file_paths'].append(full_path)
                        
                        # Extract registry actions
                        registry_actions = process_item.get('registry_actions', [])
                        if isinstance(registry_actions, list):
                            for act in registry_actions:
                                if isinstance(act, dict) and 'key_name' in act and 'value_name' in act:
                                    reg_path = act['key_name']
                                    if act['value_name']:
                                        reg_path = reg_path + '\\' + act['value_name']
                                    result['behavioral_indicators']['registry_keys'].append(reg_path)
                        
                        # Extract mutex actions
                        mutex_actions = process_item.get('mutex_actions', [])
                        if isinstance(mutex_actions, list):
                            for mtx in mutex_actions:
                                if isinstance(mtx, dict) and 'name' in mtx:
                                    result['behavioral_indicators']['mutexes'].append(mtx['name'])
                
                elif key == 'signatures':
                    # Extract signatures (filter by risk_factor >= 7)
                    for item in val:
                        if item.get('risk_factor', 0) >= 7:
                            result['signatures'].append({
                                'description': item.get('description', ''),
                                'risk_factor': item.get('risk_factor', 0)
                            })
                
                elif key == 'dropped_files':
                    # Extract dropped files with deduplication
                    for item in val:
                        classification = item.get('classification', 'UNKNOWN')
                        sha1 = item.get('sha1', '')
                        file_name = item.get('file_name', '')
                        file_type = item.get('sample_type', '')
                        
                        if classification not in result['dropped_files']:
                            result['dropped_files'][classification] = []
                        
                        # Check if this SHA1 already exists in this classification
                        existing_file = None
                        for f in result['dropped_files'][classification]:
                            if f['sha1'] == sha1:
                                existing_file = f
                                break
                        
                        if existing_file:
                            # File exists, add file_name to list if not already present
                            if file_name and file_name not in existing_file['file_names']:
                                existing_file['file_names'].append(file_name)
                        else:
                            # New file, create entry with file_names as list
                            result['dropped_files'][classification].append({
                                'sha1': sha1,
                                'file_names': [file_name] if file_name else [],
                                'file_type': file_type
                            })
                
                elif key == 'threat_names':
                    # Extract threat names
                    for item in val:
                        threat_name = item.get('threat_name', '')
                        if threat_name:
                            result['threat_names'].append(threat_name)
                
                elif key == 'malware_configurations':
                    # Extract malware configurations
                    for item in val:
                        new_config = {}
                        for k, v in item.items():
                            if k != 'analysis_ids':
                                new_config[k] = v
                        result['malware_configs'].append(new_config)
                
                elif key == 'sigma_detections':
                    # Extract sigma detections
                    for item in val:
                        description = item.get('description', '')
                        if description:
                            result['sigma_rules'].append(description)
                
                elif key == 'yara':
                    # Extract YARA rules from entries
                    entries = val.get('entries', [])
                    for entry in entries:
                        rules = entry.get('rule', [])
                        for rule in rules:
                            description = rule.get('description', '')
                            if description:
                                if 'yara_rules' not in result:
                                    result['yara_rules'] = []
                                result['yara_rules'].append(description)
            
        except Exception as e:
            logger.error('Error normalizing SA dynamic analysis: %s', e)
        
        return result
    
    @staticmethod
    def extract_network_iocs_from_ticore(ticore_data: Dict[str, Any]) -> Dict[str, List[str]]:
        """Extract network IOCs from ticore data.
        
        Args:
            ticore_data: TICore data from Spectra Analyze
            
        Returns:
            Dictionary with domains, ip_addresses, urls, emails
        """
        result = {
            'domains': [],
            'ip_addresses': [],
            'urls': [],
            'emails': []
        }
        
        is_map = {
            'https': 'urls',
            'http': 'urls',
            'mailto': 'emails',
            'domain': 'domains',
            'ipv4': 'ip_addresses',
            'ipv6': 'ip_addresses',
            'ftp': 'urls',
            'telnet': 'urls'
        }
        
        try:
            interesting_strings = ticore_data.get('interesting_strings', [])
            
            for interesting_string in interesting_strings:
                category = interesting_string.get('category')
                if category not in is_map:
                    continue
                
                values = interesting_string.get('values', [])
                for value in values:
                    if isinstance(value, dict):
                        string_value = value.get('value', '')
                    else:
                        string_value = value
                    
                    if not isinstance(string_value, str):
                        continue
                    
                    # Handle IPv4 with port
                    if category == 'ipv4' and ':' in string_value:
                        result[is_map[category]].append(string_value.split(':')[0])
                    else:
                        result[is_map[category]].append(string_value)
                        
        except Exception as e:
            logger.error('Error extracting IOCs from ticore: %s', e)
        
        return result
    
    @staticmethod
    def extract_network_iocs_from_sa_dynamic(dynamic_data: Dict[str, Any]) -> Dict[str, List[str]]:
        """Extract network IOCs from rl_cloud_sandbox data (Spectra Analyze).
        
        Args:
            dynamic_data: Dynamic analysis data (rl_cloud_sandbox format)
            
        Returns:
            Dictionary with domains, ip_addresses, urls, emails
        """
        result = {
            'domains': [],
            'ip_addresses': [],
            'urls': [],
            'emails': []
        }
        
        try:
            results = dynamic_data.get('results', [])
            
            for section in results:
                key = section.get('key', '')
                val = section.get('value', [])
                
                if key == 'dns':
                    tmp_domains = []
                    tmp_ips = []
                    for item in val:
                        domain = item.get('value', '')
                        if domain and domain not in tmp_domains:
                            tmp_domains.append(domain)
                        ip = item.get('address', '')
                        if ip and ip not in tmp_ips:
                            tmp_ips.append(ip)
                    result['domains'].extend(tmp_domains)
                    result['ip_addresses'].extend(tmp_ips)
                
                elif key in ['tcp', 'udp']:
                    tmp_ips = []
                    for item in val:
                        dst = item.get('destination_ip', '')
                        if dst and ':' in dst:
                            ip = dst.split(':')[0]
                            if ip and ip not in tmp_ips:
                                tmp_ips.append(ip)
                    result['ip_addresses'].extend(tmp_ips)
                
                elif key in ['url', 'http']:
                    tmp_urls = []
                    for item in val:
                        url = item.get('url', '')
                        if url and url not in tmp_urls:
                            tmp_urls.append(url)
                    result['urls'].extend(tmp_urls)
                    
        except Exception as e:
            logger.error('Error extracting IOCs from dynamic analysis: %s', e)
        
        return result
    
    @staticmethod
    def extract_network_iocs_from_tca0106(tca0106_data: Dict[str, Any]) -> Dict[str, List[str]]:
        """Extract network IOCs from TCA-0106 dynamic analysis data (Spectra Intelligence).
        
        Args:
            tca0106_data: TCA-0106 API response data
            
        Returns:
            Dictionary with domains, ip_addresses, urls, emails
        """
        result = {
            'domains': [],
            'ip_addresses': [],
            'urls': [],
            'emails': []
        }
        
        try:
            # Response is flat — no rl.report wrapper.
            network = tca0106_data.get('network', {})
            
            # Extract domains and IPs from DNS
            dns_list = network.get('dns', [])
            tmp_domains = []
            tmp_ips = []
            for item in dns_list:
                domain = item.get('value', '')
                if domain and isinstance(domain, str):
                    tmp_domains.append(domain)
                address = item.get('address', '')
                if address and isinstance(address, str):
                    tmp_ips.append(address)
            
            # Extract IPs from TCP and UDP
            ip_list = network.get('tcp', []) + network.get('udp', [])
            for item in ip_list:
                ip = item.get('destination_ip', '')
                if ip and isinstance(ip, str):
                    tmp_ips.append(ip)
            
            # Extract URLs
            url_list = network.get('url', []) + network.get('http', [])
            tmp_urls = []
            for item in url_list:
                url = item.get('url', '')
                if url and isinstance(url, str):
                    tmp_urls.append(url)
            
            result['domains'] = tmp_domains
            result['ip_addresses'] = tmp_ips
            result['urls'] = tmp_urls
                    
        except Exception as e:
            logger.error('Error extracting IOCs from TCA-0106: %s', e)
        
        return result
    
    @staticmethod
    def extract_yara_rules_from_tca0106(tca0106_data: Dict[str, Any]) -> List[str]:
        """Extract YARA rules from TCA-0106 dynamic analysis data.
        
        Args:
            tca0106_data: TCA-0106 API response data
            
        Returns:
            List of YARA rule descriptions
        """
        yara_rules = []
        
        try:
            # Response is flat — no rl.report wrapper.
            yara_data = tca0106_data.get('yara', {})
            entries = yara_data.get('entries', [])
            
            for entry in entries:
                rules = entry.get('rule', [])
                for rule in rules:
                    description = rule.get('description', '')
                    if description:
                        yara_rules.append(description)
                        
        except Exception as e:
            logger.error('Error extracting YARA rules from TCA-0106: %s', e)
        
        return yara_rules
    
    @staticmethod
    def _parse_common_name(subject: Any) -> str:
        """Extract the commonName (CN) value from a certificate subject/issuer.

        Handles both ticore representations:
        - Spectra Analyze: list of ``{'name': ..., 'value': ...}`` entries
        - TCA-0104 (cloud): distinguished name string, e.g.
          'countryName=US,...,commonName=Google LLC'

        Args:
            subject: Certificate subject or issuer (list or string)

        Returns:
            The commonName value, or empty string if not present
        """
        if isinstance(subject, list):
            for part in subject:
                if isinstance(part, dict) and part.get('name', '').lower() == 'commonname':
                    return str(part.get('value', '')).strip()
            return ''
        if isinstance(subject, str):
            for part in subject.split(','):
                part = part.strip()
                if part.lower().startswith('commonname='):
                    return part.split('=', 1)[1].strip()
        return ''

    @staticmethod
    def _dn_to_string(dn: Any) -> str:
        """Render a distinguished name (subject/issuer) as a string.

        Spectra Analyze stores DNs as a list of ``{'name': ..., 'value': ...}``;
        TCA-0104 already stores them as a string. Both are normalized to a
        ``name=value,name=value`` string.

        Args:
            dn: Distinguished name (list or string)

        Returns:
            String representation of the DN
        """
        if isinstance(dn, str):
            return dn.strip()
        if isinstance(dn, list):
            parts = []
            for part in dn:
                if isinstance(part, dict):
                    parts.append(f"{part.get('name', '')}={part.get('value', '')}")
            return ','.join(parts)
        return ''

    @staticmethod
    def _is_expired(valid_to: str) -> bool:
        """Determine whether a certificate is expired from its valid_to date.

        Args:
            valid_to: Expiry timestamp, e.g. '2024-07-10T23:59:59Z'

        Returns:
            True if the certificate is past its valid_to date
        """
        if not valid_to or not isinstance(valid_to, str):
            return False
        try:
            dt = datetime.strptime(valid_to, '%Y-%m-%dT%H:%M:%SZ').replace(tzinfo=timezone.utc)
            return dt < datetime.now(timezone.utc)
        except Exception:
            return False

    @staticmethod
    def _normalize_cert(cert: Dict[str, Any]) -> Dict[str, Any]:
        """Normalize a single certificate across SA and TCA-0104 layouts.

        Returns:
            Dict with thumbprint, common_name, subject, issuer, serial_number, expired
        """
        # Thumbprint: TCA-0104 uses 'thumbprint' string; SA uses a 'thumbprints'
        # list. Prefer SHA256, falling back to the first available value.
        thumbprint = cert.get('thumbprint', '')
        if not thumbprint:
            thumbprints = cert.get('thumbprints', [])
            for item in thumbprints:
                if isinstance(item, dict) and item.get('name', '').upper() == 'SHA256' and item.get('value'):
                    thumbprint = item['value']
                    break
            else:
                for item in thumbprints:
                    if isinstance(item, dict) and item.get('value'):
                        thumbprint = item['value']
                        break

        # Expiry: TCA-0104 has an explicit 'expired' flag; SA must be computed.
        expired = cert.get('expired')
        if expired is None:
            expired = AnalysisResultNormalizer._is_expired(cert.get('valid_to', ''))

        return {
            'thumbprint': thumbprint,
            'common_name': AnalysisResultNormalizer._parse_common_name(cert.get('subject', '')),
            'subject': AnalysisResultNormalizer._dn_to_string(cert.get('subject', '')),
            'issuer': AnalysisResultNormalizer._dn_to_string(cert.get('issuer', '')),
            'serial_number': cert.get('serial_number', ''),
            'expired': bool(expired),
        }

    @staticmethod
    def _walk_cert_chain(cert: Any, acc: List[Dict[str, Any]]) -> None:
        """Collect a certificate and its nested issuer_certificate chain (SA)."""
        if not isinstance(cert, dict):
            return
        acc.append(cert)
        AnalysisResultNormalizer._walk_cert_chain(cert.get('issuer_certificate'), acc)

    @staticmethod
    def extract_certificate_indicators_from_ticore(ticore_data: Dict[str, Any]) -> Dict[str, List[str]]:
        """Extract certificate IOCs from ticore certificate data.

        Collects values across the full certificate chain (signer, CA/intermediate,
        and timestamp counter-signatures) and surfaces signer-specific fields.

        Supports both ticore layouts:
        - Spectra Analyze: ``ticore.signatures[]`` with nested
          ``certificate.issuer_certificate`` chains and ``counter_signatures``
        - TCA-0104 (cloud): ``ticore.certificate.certificates[]`` + ``signer_info``

        Args:
            ticore_data: TICore data (from Spectra Analyze or the TCA-0104 tc_report)

        Returns:
            Dictionary with thumbprints, common_names, serial_numbers, issuers,
            subjects, expired_thumbprints, signer_serial_numbers, signer_issuers
        """
        result = {
            'thumbprints': [],
            'common_names': [],
            'serial_numbers': [],
            'issuers': [],
            'subjects': [],
            'expired_thumbprints': [],
            'signer_serial_numbers': [],
            'signer_issuers': [],
        }

        try:
            raw_certs: List[Dict[str, Any]] = []
            signer_serials: List[str] = []
            signer_issuers: List[str] = []

            signatures = ticore_data.get('signatures')
            certificate = ticore_data.get('certificate', {})

            if isinstance(signatures, list) and signatures:
                # Spectra Analyze: walk each signature's signer chain plus the
                # timestamp counter-signature chains.
                for sig in signatures:
                    if not isinstance(sig, dict):
                        continue
                    serial = sig.get('serial_number', '')
                    if serial:
                        signer_serials.append(serial)
                    issuer = AnalysisResultNormalizer._dn_to_string(sig.get('issuer', ''))
                    if issuer:
                        signer_issuers.append(issuer)

                    AnalysisResultNormalizer._walk_cert_chain(sig.get('certificate'), raw_certs)
                    for cs in sig.get('counter_signatures', []):
                        if isinstance(cs, dict):
                            AnalysisResultNormalizer._walk_cert_chain(cs.get('certificate'), raw_certs)

            elif isinstance(certificate, dict) and certificate.get('certificates'):
                # TCA-0104 (cloud): flat certificate list + signer_info.
                raw_certs = [c for c in certificate.get('certificates', []) if isinstance(c, dict)]

                signer_info = certificate.get('signer_info', {})
                signer_infos = signer_info if isinstance(signer_info, list) else [signer_info]
                for si in signer_infos:
                    if isinstance(si, dict):
                        serial = si.get('serial_number', '')
                        if serial:
                            signer_serials.append(serial)
                        issuer = AnalysisResultNormalizer._dn_to_string(si.get('issuer', ''))
                        if issuer:
                            signer_issuers.append(issuer)

            norm_certs = [AnalysisResultNormalizer._normalize_cert(c) for c in raw_certs]

            def _dedup(values):
                return list(dict.fromkeys(v for v in values if v))

            result['thumbprints'] = _dedup(c['thumbprint'] for c in norm_certs)
            result['common_names'] = _dedup(c['common_name'] for c in norm_certs)
            result['serial_numbers'] = _dedup(c['serial_number'] for c in norm_certs)
            result['issuers'] = _dedup(c['issuer'] for c in norm_certs)
            result['subjects'] = _dedup(c['subject'] for c in norm_certs)
            result['expired_thumbprints'] = _dedup(c['thumbprint'] for c in norm_certs if c['expired'])
            result['signer_serial_numbers'] = _dedup(signer_serials)
            result['signer_issuers'] = _dedup(signer_issuers)

        except Exception as e:
            logger.error('Error extracting certificate indicators from ticore: %s', e)

        return result

    @staticmethod
    def extract_yara_rules_from_ticore(ticore_data: Dict[str, Any]) -> List[str]:
        """Extract YARA rules from ticore data.
        
        Args:
            ticore_data: TICore data from Spectra Analyze or Spectra Intelligence
            
        Returns:
            List of YARA rule identifiers
        """
        yara_rules = []
        
        try:
            yara_hits = ticore_data.get('classification', {}).get('yara', [])
            for hit in yara_hits:
                if 'identifier' in hit:
                    yara_rules.append(hit['identifier'])
                        
        except Exception as e:
            logger.error('Error extracting YARA rules from ticore: %s', e)
        
        return yara_rules
    
    @staticmethod
    def extract_mitre_attack(sa_data: Optional[Dict[str, Any]] = None,
                             tca0106_data: Optional[Dict[str, Any]] = None,
                             tca0104_data: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Extract MITRE ATT&CK techniques from analysis data.

        Args:
            sa_data: Spectra Analyze raw data (optional)
            tca0106_data: TCA-0106 raw data (optional)
            tca0104_data: TCA-0104 (rldata) raw data for cloud samples (optional)

        Returns:
            Dictionary with tactic IDs as keys, technique ID lists as values, and indicators list
        """
        out = {}
        indicator_list = []
        
        try:
            # Extract from rl_cloud_sandbox (Spectra Analyze) if available
            if sa_data is not None:
                rl_cloud_sandbox = sa_data.get('rl_cloud_sandbox', {})
                if rl_cloud_sandbox and isinstance(rl_cloud_sandbox, dict):
                    results = rl_cloud_sandbox.get('results', [])
                    if isinstance(results, list):
                        for section in results:
                            if not isinstance(section, dict):
                                continue
                            if str(section.get('key', '')).lower() != 'mitre_attack':
                                continue
                            val = section.get('value', {})
                            if not isinstance(val, dict):
                                continue
                            atk = val.get('matrix_list', [])
                            for matrix in atk:
                                tactics = matrix.get('tactics', {})
                                if isinstance(tactics, dict):
                                    for tac in tactics.get('tactic_list', []):
                                        if not isinstance(tac, dict):
                                            continue
                                        tactic_id = tac.get('id')
                                        if tactic_id not in out:
                                            out[tactic_id] = set()
                                        techs = tac.get('techniques', {})
                                        if isinstance(techs, dict):
                                            tlist = techs.get('technique_list', [])
                                            for t in tlist:
                                                if not isinstance(t, dict):
                                                    continue
                                                tid = t.get('id')
                                                out[tactic_id].add(tid)
            
            # Extract from TCA-0106 (Spectra Intelligence) if available.
            # Response is flat — no rl.report wrapper.
            if tca0106_data is not None and isinstance(tca0106_data, dict):
                mitre_attack = tca0106_data.get('mitre_attack', {})
                atk = mitre_attack.get('matrix_list', [])
                for matrix in atk:
                    tactics = matrix.get('tactics', {})
                    if isinstance(tactics, dict):
                        for tac in tactics.get('tactic_list', []):
                            if not isinstance(tac, dict):
                                continue
                            tactic_id = tac.get('id')
                            if tactic_id not in out:
                                out[tactic_id] = set()
                            techs = tac.get('techniques', {})
                            if isinstance(techs, dict):
                                tlist = techs.get('technique_list', [])
                                for t in tlist:
                                    if not isinstance(t, dict):
                                        continue
                                    tid = t.get('id')
                                    out[tactic_id].add(tid)
            
            # Extract from ticore if available (presented differently in SA vs. SI)
            ticore = None
            if sa_data is not None:
                ticore = sa_data.get('ticore', {})
            elif tca0104_data is not None and isinstance(tca0104_data, dict):
                # Cloud samples: ticore lives in the TCA-0104 tc_report
                entries = tca0104_data.get('rl', {}).get('sample', {}).get('analysis', {}).get('entries', [])
                if isinstance(entries, list) and len(entries) > 0 and isinstance(entries[0], dict):
                    ticore = entries[0].get('tc_report', {})
            
            matrix = None
            if ticore and isinstance(ticore, dict):
                atk = ticore.get('attack', ticore.get('metadata', {}).get('attack'))
                
                if atk is not None:
                    if isinstance(atk, list):
                        matrix = atk[0]
                    elif isinstance(atk, dict):
                        matrix = atk
            
            if matrix is not None:
                for tac in matrix.get('tactics', []):
                    if not isinstance(tac, dict):
                        continue
                    tactic_id = tac.get('id')
                    if tactic_id not in out:
                        out[tactic_id] = set()
                    techs = tac.get('techniques', [])
                    if isinstance(techs, list):
                        for tech in techs:
                            if not isinstance(tech, dict):
                                continue
                            tid = tech.get('id')
                            out[tactic_id].add(tid)
                            indicators = tech.get('indicators', [])
                            for indicator in indicators:
                                indicator_list.append({
                                    'description': indicator.get('description', ''),
                                    'priority': indicator.get('priority', ''),
                                    'technique_id': tid,
                                    'tactic_id': tactic_id,
                                    'source': 'static_analysis'
                                })
            
            # Build final attack matrix
            attack_matrix = {}
            for k, v in out.items():
                attack_matrix[k] = list(v)
            attack_matrix['indicators'] = indicator_list
            
            return attack_matrix
            
        except Exception as e:
            logger.error('Error extracting MITRE ATT&CK: %s', e)
            return {'indicators': []}
