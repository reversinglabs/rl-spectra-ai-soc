"""Network indicator enrichment with GeoIP and reputation data."""

import logging
from typing import Dict, Any, List

logger = logging.getLogger(__name__)


class NetworkIndicatorEnricher:
    """Enrich network indicators with GeoIP and reputation data."""

    def __init__(self, sa_client=None):
        """Initialize the network enricher.

        Args:
            sa_client: Optional SpectraAnalyzeClient for GeoIP lookups
        """
        self.sa_client = sa_client

    def enrich_with_geoip(self, indicators: Dict[str, List]) -> None:
        """Enrich network indicators with GeoIP data in-place.

        Args:
            indicators: Dictionary with 'domains' and 'ip_addresses' lists (modified in-place)
        """
        try:
            from mcp_server_analyze.geoip import lookup_ip

            logger.info('Starting GeoIP lookup for domains and IP addresses')

            # Process domains
            domains = indicators.get('domains', [])
            if isinstance(domains, list):
                enriched_domains = []
                for domain in domains:
                    if not isinstance(domain, str) or not domain.strip():
                        continue

                    domain = domain.strip()
                    logger.info('Processing domain: %s', domain)

                    # Use geoip lookup_ip which can handle domains directly
                    geo_data = lookup_ip(domain)

                    if geo_data:
                        enriched_domains.append({
                            'domain': domain,
                            'geoip': {
                                'ip': geo_data.get('ip', ''),
                                'country_iso': geo_data.get('country_iso', ''),
                                'country_name': geo_data.get('country_name', ''),
                                'region': geo_data.get('region', ''),
                                'city': geo_data.get('city', ''),
                                'asn': str(geo_data.get('asn', '')) if geo_data.get('asn') is not None else '',
                                'as_org': geo_data.get('as_org', '')
                            }
                        })
                    else:
                        # Return empty geo data if lookup failed
                        enriched_domains.append({
                            'domain': domain,
                            'geoip': {
                                'ip': '',
                                'country_iso': '',
                                'country_name': '',
                                'region': '',
                                'city': '',
                                'asn': '',
                                'as_org': ''
                            }
                        })

                indicators['domains'] = enriched_domains

            # Process IP addresses
            ip_addresses = indicators.get('ip_addresses', [])
            if isinstance(ip_addresses, list):
                enriched_ips = []
                for ip in ip_addresses:
                    if not isinstance(ip, str) or not ip.strip():
                        continue

                    ip = ip.strip()
                    logger.info('Processing IP address: %s', ip)

                    # Get GeoIP data for the IP
                    geo_data = lookup_ip(ip)

                    if geo_data:
                        enriched_ips.append({
                            'ip': ip,
                            'geoip': {
                                'ip': geo_data.get('ip', ''),
                                'country_iso': geo_data.get('country_iso', ''),
                                'country_name': geo_data.get('country_name', ''),
                                'region': geo_data.get('region', ''),
                                'city': geo_data.get('city', ''),
                                'asn': str(geo_data.get('asn', '')) if geo_data.get('asn') is not None else '',
                                'as_org': geo_data.get('as_org', '')
                            }
                        })
                    else:
                        # Return empty geo data if lookup failed
                        enriched_ips.append({
                            'ip': ip,
                            'geoip': {
                                'ip': ip,
                                'country_iso': '',
                                'country_name': '',
                                'region': '',
                                'city': '',
                                'asn': '',
                                'as_org': ''
                            }
                        })

                indicators['ip_addresses'] = enriched_ips

            logger.info(
                'GeoIP lookup completed. Processed %s domains and %s IP addresses',
                len(indicators.get("domains", [])), len(indicators.get("ip_addresses", [])))

        except Exception as e:
            logger.error('Error in enrich_with_geoip: %s', e)

    def enrich_with_reputation(self, indicators: Dict[str, List]) -> Dict[str, List]:
        """Enrich network indicators with reputation data from Spectra Intelligence.

        Args:
            indicators: Dictionary with 'domains', 'ip_addresses', 'urls' lists

        Returns:
            Enriched indicators dictionary
        """
        if not self.sa_client:
            logger.debug('No SpectraAnalyze client available for reputation enrichment')
            return indicators

        try:
            # Collect all network locations
            all_locations = []

            # Extract domain values
            for domain in indicators.get('domains', []):
                if isinstance(domain, dict) and domain.get('domain'):
                    all_locations.append(domain['domain'])

            # Extract IP values
            for ip in indicators.get('ip_addresses', []):
                if isinstance(ip, dict) and ip.get('ip'):
                    all_locations.append(ip['ip'])

            # Extract URL values
            for url in indicators.get('urls', []):
                if isinstance(url, str):
                    all_locations.append(url)

            if not all_locations:
                logger.debug('No network locations to enrich with reputation')
                return indicators

            # Get reputation data
            reputation_data = self.sa_client.get_network_reputation(all_locations)

            if not reputation_data:
                logger.debug('No reputation data returned')
                return indicators

            # Create lookup map
            reputation_map = {}
            for entry in reputation_data.get('rl', {}).get('entries', []):
                location = entry.get('requested_network_location', '')
                if location:
                    reputation_map[location] = entry

            # Enrich indicators in-place

            # Enrich domains
            for domain_obj in indicators.get('domains', []):
                if isinstance(domain_obj, dict):
                    domain_val = domain_obj.get('domain')
                    if domain_val and domain_val in reputation_map:
                        self._add_reputation_fields(domain_obj, reputation_map[domain_val])

            # Enrich IPs
            for ip_obj in indicators.get('ip_addresses', []):
                if isinstance(ip_obj, dict):
                    ip_val = ip_obj.get('ip')
                    if ip_val and ip_val in reputation_map:
                        self._add_reputation_fields(ip_obj, reputation_map[ip_val])

            # Enrich URLs
            enriched_urls = []
            for url in indicators.get('urls', []):
                if isinstance(url, str):
                    url_obj = {'value': url}
                    if url in reputation_map:
                        self._add_reputation_fields(url_obj, reputation_map[url])
                    else:
                        url_obj['first_seen'] = ''
                        url_obj['last_seen'] = ''
                        url_obj['classification'] = ''
                    enriched_urls.append(url_obj)
                else:
                    enriched_urls.append(url)

            indicators['urls'] = enriched_urls

            logger.info('Enriched network indicators with reputation data')

        except Exception as e:
            logger.error('Failed to enrich with reputation: %s', e)
            return indicators

    def _add_reputation_fields(self, indicator_obj: Dict[str, Any], reputation_entry: Dict[str, Any]):
        """Add reputation fields to an indicator object.

        Args:
            indicator_obj: Indicator object to enrich
            reputation_entry: Reputation data from API
        """
        indicator_obj['first_seen'] = reputation_entry.get('first_seen', '')
        indicator_obj['last_seen'] = reputation_entry.get('last_seen', '')

        # Get classification
        classification = reputation_entry.get('classification', '').upper()

        if not classification:
            # Derive classification
            if 'associated_malware' in reputation_entry:
                classification = 'SUSPICIOUS' if reputation_entry['associated_malware'] else 'KNOWN'

            # Check third party reputations
            if 'third_party_reputations' in reputation_entry:
                third_party = reputation_entry['third_party_reputations']
                if isinstance(third_party, dict):
                    stats = third_party.get('statistics', third_party)
                    total = stats.get('total', 0)
                    malicious = stats.get('malicious', 0)
                    suspicious = stats.get('suspicious', 0)

                    if total > 0:
                        risk_ratio = (malicious + suspicious) / total
                        indicator_obj['risk_score'] = int(risk_ratio * 100)

                        if malicious > 0:
                            classification = 'MALICIOUS'
                        elif suspicious > 0:
                            classification = 'SUSPICIOUS'
                        elif total > 0:
                            classification = 'KNOWN'

        indicator_obj['classification'] = classification
