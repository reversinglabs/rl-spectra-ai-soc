"""Enhanced threat analysis tool."""
from mcp.types import ToolAnnotations

from mcp_server_analyze.core import get_config
from mcp_server_analyze.tools.enhanced_threat_analysis.enhanced_threat_analysis import EnhancedThreatAnalysisTool

config = get_config()


def register(mcp):
    """Register the enhanced threat analysis tool with the MCP server."""
    
    @mcp.tool(
        annotations=ToolAnnotations(
            title="Enhanced Threat Analysis",
            readOnlyHint=True,
            destructiveHint=False,
            idempotentHint=True,
            openWorldHint=True,
        ),
    )
    def enhanced_threat_analysis(hash: str) -> dict:
        """Perform comprehensive threat analysis on a file hash.
        
        This tool provides in-depth analysis of a file including:
        - File classification and threat verdict
        - Static and dynamic analysis results
        - Network indicators (domains, IPs, URLs)
        - Behavioral indicators (file paths, registry keys, processes, mutexes)
        - MITRE ATT&CK techniques and tactics
        - File similarity analysis (RHA1 and imphash)
        - Antivirus scan results
        - Extracted files analysis
        
        Args:
            hash: File hash (MD5, SHA1, or SHA256)
            
        Returns:
            Comprehensive threat analysis report
        """
        tool = EnhancedThreatAnalysisTool(
            sa_base_url=config.analyze_base_url,
            sa_verify_ssl=config.analyze_verify_ssl
        )
        result = tool.execute(hash)
        return result


__all__ = ['EnhancedThreatAnalysisTool', 'register']
