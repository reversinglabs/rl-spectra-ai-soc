"""Sample details tools for Spectra Analyze MCP Server.

Provides four tools that operate on the response of
``GET /api/samples/v2/list/details/`` for a single hash:

- ``get_sample_overview`` - file metadata and classification details.
- ``get_sample_indicators`` - IOCs grouped into bot_config / dynamic / static.
- ``get_sample_ttps`` - MITRE ATT&CK TTPs (static + dynamic merged).
- ``get_sample_detection_rules`` - YARA / Suricata / Sigma matches.
"""
import logging
from typing import Any, Dict, List, Optional, Annotated

from pydantic import Field
from mcp.types import ToolAnnotations

from mcp_server_analyze.core import get_config
from mcp_server_analyze.tools.base_tool import BaseMCPTool
from mcp_server_analyze.tools.tool_utils import save_report_data, save_tool_result

logger = logging.getLogger(__name__)
config = get_config()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _hashes_to_dict(hashes: List[Dict[str, Any]]) -> Dict[str, str]:
    """Convert a list of ``{name, value}`` hash entries into a dict."""
    out: Dict[str, str] = {}
    for h in hashes or []:
        name = h.get('name')
        value = h.get('value')
        if name and value is not None:
            out[name] = value
    return out


def _cloud_sandbox_results(sample: Dict[str, Any]) -> Dict[str, Any]:
    """Flatten the ``rl_cloud_sandbox.results`` key/value list into a dict."""
    cs = sample.get('rl_cloud_sandbox') or {}
    entries = cs.get('results') or []
    out: Dict[str, Any] = {}
    for entry in entries:
        key = entry.get('key')
        if key is not None:
            out[key] = entry.get('value')
    return out


def _latest_av_record(sample: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """Return the av_scanners record with the most recent ``record_time``."""
    av = sample.get('av_scanners') or []
    if not av:
        return None
    return max(av, key=lambda r: r.get('record_time') or '')


def _normalize_cloud_sandbox_response(dynamic_data: Dict[str, Any]) -> Dict[str, Any]:
    """Adapt a TCA-0106 cloud sandbox response to the flat ``cs_results`` format
    expected by the indicator / TTP / rule extraction helpers.

    Key differences vs the local ``rl_cloud_sandbox.results`` flat dict:
    - ``behavioral`` (TCA-0106) → ``behaviour``
    - Network fields are nested under ``network.*`` → promoted to top level
    - ``sigma_detections`` → ``sigma``
    """
    if not dynamic_data:
        return {}
    cs: Dict[str, Any] = {}
    if 'behavioral' in dynamic_data:
        cs['behaviour'] = dynamic_data['behavioral']
    network = dynamic_data.get('network') or {}
    for key in ('dns', 'url', 'http', 'tcp', 'udp'):
        if key in network:
            cs[key] = network[key]
    for key in ('classification', 'dropped_files', 'malware_configurations', 'mitre_attack',
                'yara', 'threat_names'):
        if key in dynamic_data:
            cs[key] = dynamic_data[key]
    if 'sigma_detections' in dynamic_data:
        cs['sigma'] = dynamic_data['sigma_detections']
    # suricata_alerts is the TCA-0106 key; suricata is the local key
    if 'suricata_alerts' in dynamic_data:
        cs['suricata'] = dynamic_data['suricata_alerts']
    return cs


def _fetch_cloud_data(sa_client, hash_value: str):
    """Try cloud fallback via the Spectra Intelligence bridge API.

    Returns ``(rl_sample, rca2, cs_results)`` where:
    - ``rl_sample`` is the ``rl.sample`` dict from rldata
    - ``rca2`` is the ``rl.rca2`` dict (may be empty)
    - ``cs_results`` is normalized cloud sandbox data (may be empty)

    Returns ``(None, None, {})`` when the sample is not found in cloud.
    """
    rldata = sa_client.get_rldata(hash_value)
    if not rldata:
        return None, None, {}
    rl_sample = rldata.get('rl', {}).get('sample', {})
    rca2: Dict[str, Any] = {}
    rca2_resp = sa_client.get_rca2(hash_value)
    if rca2_resp:
        rca2 = rca2_resp.get('rl', {}).get('rca2', {})
    dynamic_resp = sa_client.get_dynamic_analysis(hash_value)
    cs_results = _normalize_cloud_sandbox_response(dynamic_resp or {})
    save_tool_result('sample_details_cloud', {
        'hash': hash_value,
        'rldata': rldata,
        'rca2': rca2_resp,
        'dynamic_analysis': dynamic_resp,
    }, 'raw_api_responses')
    return rl_sample, rca2, cs_results


def _dedup_sorted(values) -> List[str]:
    """Return a sorted, de-duplicated list of non-empty string values."""
    seen = set()
    for v in values:
        if v is None:
            continue
        s = v if isinstance(v, str) else str(v)
        if s:
            seen.add(s)
    return sorted(seen)


def _strip_port(addr: str) -> str:
    """Strip a trailing ``:port`` from an IP-like string, IPv4 only."""
    if not addr:
        return addr
    # Only strip if it looks like host:port (not IPv6)
    if addr.count(':') == 1:
        return addr.split(':', 1)[0]
    return addr


# ---------------------------------------------------------------------------
# get_sample_overview
# ---------------------------------------------------------------------------


def _build_pe(ticore: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """Build the ``pe`` block from ticore PE data if present.

    Handles both local (``ticore.application.pe``) and cloud
    (``ticore.metadata.application.pe``) tc_report layouts.
    """
    app = ((ticore or {}).get('application')
           or ((ticore or {}).get('metadata') or {}).get('application')
           or {})
    pe = app.get('pe')
    if not pe:
        return None

    pe_out: Dict[str, Any] = {}
    file_header = pe.get('file_header') or {}
    if 'machine' in file_header:
        pe_out['machine'] = file_header.get('machine')
    if 'time_date_stamp' in file_header:
        pe_out['compile_timestamp'] = file_header.get('time_date_stamp')

    # Sections - keep only name/size/flags
    sections = []
    for s in pe.get('sections') or []:
        sections.append({
            'name': s.get('name'),
            'size': s.get('physical_size'),
            'flags': s.get('flags'),
        })
    if sections:
        pe_out['sections'] = sections

    # Imports - the API already returns name/apis pairs
    imports = pe.get('imports')
    if imports:
        pe_out['imports'] = imports

    # Exports - normalize to a list
    exports = pe.get('exports')
    if exports:
        pe_out['exports'] = exports if isinstance(exports, list) else [exports]

    # Resources - pass through compact form
    resources = pe.get('resources')
    if resources:
        pe_out['resources'] = [
            {
                'type': r.get('type'),
                'name': r.get('name'),
                'size': r.get('size'),
            }
            for r in resources
        ]

    # Version info - already a list of {name, value}
    version_info = pe.get('version_info')
    if version_info:
        pe_out['version_info'] = version_info

    # Certificates / signers when present in ticore.certificate
    cert = (ticore or {}).get('certificate') or {}
    if cert:
        pe_out['certificates'] = cert

    return pe_out

def _build_ticore_extras(ticore: Dict[str, Any]) -> Dict[str, Any]:
    """Extract additional overview fields from the dedicated ticore report"""
    out: Dict[str, Any] = {}
    if not ticore:
        return out
    for key in ('story', 'interesting_strings', 'indicators', 'tags',
                'document', 'mobile', 'media', 'web', 'email'):
        value = ticore.get(key)
        if value:
            out[key] = value

    return out

class SampleOverviewTool(BaseMCPTool):
    """Tool for fetching a sample's overview / metadata."""

    def execute(self, hash_value: str) -> Dict[str, Any]:
        try:
            sample = self.sa_client.get_file_analysis(hash_value)
        except Exception as e:
            logger.error('Error fetching sample analysis: %s', e)
            return {'error': str(e), 'hash': hash_value}

        if not sample:
            return self._execute_cloud(hash_value)

        ticore = sample.get('ticore') or {}
        info = ticore.get('info') or {}
        file_info = info.get('file') or {}
        sample_summary = sample.get('sample_summary') or {}
        cs_results = _cloud_sandbox_results(sample)

        validation = info.get('validation') or {}
        try:
            rldata = self.sa_client.get_rldata(hash_value) or {}
        except Exception as e:
            logger.warning('Error fetching rldata for overview validation: %s', e)
            rldata = {}
        rl_sample = (rldata.get('rl') or {}).get('sample') or {}
        rl_entries = (rl_sample.get('analysis') or {}).get('entries') or []
        rl_tc = rl_entries[0].get('tc_report', {}) if rl_entries else {}
        rl_validation = (rl_tc.get('info') or {}).get('validation')
        if rl_validation:
            validation = rl_validation

        hashes = _hashes_to_dict(file_info.get('hashes') or [])

        # File type combines file_type and file_subtype (e.g. "PE/.Net Exe")
        file_type = file_info.get('file_type') or ''
        file_subtype = file_info.get('file_subtype') or ''
        if file_type and file_subtype:
            sample_type = f'{file_type}/{file_subtype}'
        else:
            sample_type = file_type or file_subtype or None

        # File names: proposed_filename from ticore + relevant PE version_info names
        file_names: List[str] = []
        proposed = file_info.get('proposed_filename')
        if proposed:
            file_names.append(proposed)
        version_info = (((ticore.get('application') or {}).get('pe') or {})
                        .get('version_info') or [])
        for entry in version_info:
            if entry.get('name') in ('InternalName', 'OriginalFilename'):
                v = entry.get('value')
                if v and v not in file_names:
                    file_names.append(v)

        # Threat names: classification_result + cloud sandbox threat_names
        threat_names: List[str] = []
        classification_result = sample_summary.get('classification_result')
        if classification_result:
            threat_names.append(classification_result)
        for tn in cs_results.get('threat_names') or []:
            name = tn.get('threat_name') if isinstance(tn, dict) else None
            if name and name not in threat_names:
                threat_names.append(name)

        # Auxiliary analysis classification derived from max_score
        aux_results = (sample.get('rl_auxiliary_analysis') or {}).get('results') or []
        rl_aux_max_score = next(
            (item.get('value') for item in aux_results if item.get('key') == 'max_score'),
            None
        )
        if rl_aux_max_score is None:
            rl_aux_analysis_classification = None
        elif rl_aux_max_score >= 1000:
            rl_aux_analysis_classification = 'malicious'
        elif rl_aux_max_score >= 300:
            rl_aux_analysis_classification = 'suspicious'
        else:
            rl_aux_analysis_classification = 'unknown'

        # AV scanners: pick the most recent record and flatten the scanners list
        av_block: Optional[Dict[str, Any]] = None
        latest_av = _latest_av_record(sample)
        if latest_av:
            scanners = latest_av.get('scanners') or []
            av_block = {
                'scanned_on': latest_av.get('record_time'),
                'scanner_count': latest_av.get('scanner_count'),
                'scanner_match': latest_av.get('scanner_match'),
                'results': [
                    {'scanner': s.get('scanner'), 'result': s.get('result', '')}
                    for s in scanners
                ],
            }

        result: Dict[str, Any] = {
            'md5': hashes.get('md5'),
            'sha1': hashes.get('sha1'),
            'sha256': hashes.get('sha256'),
            'sha384': hashes.get('sha384'),
            'sha512': hashes.get('sha512'),
            'ripemd160': hashes.get('ripemd160'),
            'ssdeep': hashes.get('ssdeep'),
            'tlsh': hashes.get('tlsh'),
            'imphash': hashes.get('imphash'),
            'file_size': file_info.get('size'),
            'file_type': sample_type,
            'validation': validation or None,
            'file_names': file_names,
            'classification': sample.get('classification'),
            'classification_reason': sample_summary.get('classification_reason'),
            'local_first_seen': sample_summary.get('local_first_seen'),
            'local_last_seen': sample_summary.get('local_last_seen'),
            'sample_type': sample_type,
            'threat_name': classification_result,
            'rl_cloud_sandbox_classification': cs_results.get('classification'),
            'rl_aux_analysis_classification': rl_aux_analysis_classification,
            'threat_names': threat_names,
        }

        if av_block:
            result['av_scanners'] = av_block

        pe_block = _build_pe(ticore)
        if pe_block is not None:
            result['pe'] = pe_block

        # Supplement with the full Spectra Core static analysis report from the
        # dedicated ticore endpoint. Only fields found in the report are added.
        try:
            ticore_report = self.sa_client.get_ticore(hash_value) or {}
        except Exception as e:
            logger.warning('Error fetching ticore report for overview: %s', e)
            ticore_report = {}
        result.update(_build_ticore_extras(ticore_report))

        # Strip keys whose values are ``None`` so the output stays clean.
        output = {k: v for k, v in result.items() if v is not None}
        save_report_data('get_sample_overview', sample, output)
        return output

    def _execute_cloud(self, hash_value: str) -> Dict[str, Any]:
        """Build an overview from Spectra Intelligence cloud data."""
        rl_sample, rca2, cs_results = _fetch_cloud_data(self.sa_client, hash_value)
        if not rl_sample:
            return {'error': 'Sample not found', 'hash': hash_value}

        xref = rl_sample.get('xref') or {}
        tc_entries = (rl_sample.get('analysis') or {}).get('entries') or []
        tc = tc_entries[0].get('tc_report', {}) if tc_entries else {}
        tc_info = tc.get('info') or {}
        file_info = tc_info.get('file') or {}
        validation = tc_info.get('validation') or {}

        file_type = file_info.get('file_type') or ''
        file_subtype = file_info.get('file_subtype') or ''
        if file_type and file_subtype:
            sample_type = f'{file_type}/{file_subtype}'
        else:
            sample_type = file_type or file_subtype or xref.get('sample_type') or None

        classification = rca2.get('classification') or None
        threat_name = rca2.get('result') or None
        reason = rca2.get('reason') or None

        # Threat names: rca2 result + cloud sandbox threat_names
        threat_names: List[str] = []
        if threat_name:
            threat_names.append(threat_name)
        for tn in cs_results.get('threat_names') or []:
            name = tn.get('threat_name') if isinstance(tn, dict) else None
            if name and name not in threat_names:
                threat_names.append(name)

        # AV scanners — xref entries use 'name' key instead of 'scanner'
        av_block: Optional[Dict[str, Any]] = None
        xref_entries = xref.get('entries') or []
        if xref_entries:
            latest = max(xref_entries, key=lambda r: r.get('record_time') or '')
            scanners = latest.get('scanners') or []
            av_block = {
                'scanned_on': latest.get('record_time'),
                'scanner_count': latest.get('scanner_count'),
                'scanner_match': latest.get('scanner_match'),
                'results': [
                    {'scanner': s.get('name'), 'result': s.get('result', '')}
                    for s in scanners
                ],
            }

        result: Dict[str, Any] = {
            'source': 'cloud',
            'md5': rl_sample.get('md5'),
            'sha1': rl_sample.get('sha1'),
            'sha256': rl_sample.get('sha256'),
            'sha384': rl_sample.get('sha384'),
            'sha512': rl_sample.get('sha512'),
            'ripemd160': rl_sample.get('ripemd160'),
            'ssdeep': rl_sample.get('ssdeep'),
            'tlsh': rl_sample.get('tlsh'),
            'imphash': rl_sample.get('imphash'),
            'file_size': rl_sample.get('sample_size'),
            'file_type': sample_type,
            'validation': validation or None,
            'sample_type': sample_type,
            'classification': classification,
            'classification_reason': reason,
            'threat_name': threat_name,
            'threat_names': threat_names or None,
            'rl_cloud_sandbox_classification': cs_results.get('classification'),
            'cloud_first_seen': xref.get('first_seen'),
            'cloud_last_seen': xref.get('last_seen'),
        }
        if av_block:
            result['av_scanners'] = av_block

        # file_names from tc_report (proposed_filename may not always be present)
        file_names: List[str] = []
        proposed = file_info.get('proposed_filename')
        if proposed:
            file_names.append(proposed)
        version_info = (((tc.get('metadata') or {}).get('application') or {})
                        .get('pe') or {}).get('version_info') or []
        for entry in version_info:
            if entry.get('name') in ('InternalName', 'OriginalFilename'):
                v = entry.get('value')
                if v and v not in file_names:
                    file_names.append(v)
        result['file_names'] = file_names

        pe_block = _build_pe(tc)
        if pe_block is not None:
            result['pe'] = pe_block

        output = {k: v for k, v in result.items() if v is not None}
        save_tool_result('get_sample_overview', output, 'mcp_output')
        return output


# ---------------------------------------------------------------------------
# get_sample_indicators
# ---------------------------------------------------------------------------


def _build_dynamic_indicators(cs_results: Dict[str, Any]) -> Dict[str, Any]:
    """Extract dynamic IOCs from the cloud sandbox section."""
    out: Dict[str, Any] = {}

    ips: List[str] = []
    domains: List[str] = []
    for entry in cs_results.get('dns') or []:
        addr = entry.get('address')
        if addr:
            ips.append(addr)
        val = entry.get('value')
        if val:
            domains.append(val)

    urls = [u.get('url') for u in (cs_results.get('url') or []) if u.get('url')]

    behaviour_list = cs_results.get('behaviour') or []
    file_names: List[str] = []
    file_paths: List[str] = []
    registry_keys: List[str] = []
    registry_values: List[str] = []
    mutex_names: List[str] = []
    process_names: List[str] = []
    process_command_lines: List[str] = []

    for beh in behaviour_list:
        proc = beh.get('process') or {}
        if proc.get('name'):
            process_names.append(proc['name'])
        if proc.get('parameters'):
            process_command_lines.append(proc['parameters'])

        for fa in beh.get('file_actions') or []:
            if fa.get('file_name'):
                file_names.append(fa['file_name'])
            if fa.get('file_path'):
                file_paths.append(fa['file_path'])

        for ra in beh.get('registry_actions') or []:
            key_name = ra.get('key_name') or ra.get('key')
            if key_name:
                registry_keys.append(key_name)
            value_name = ra.get('value_name')
            if value_name:
                registry_values.append(value_name)

        for ma in beh.get('mutex_actions') or []:
            if ma.get('name'):
                mutex_names.append(ma['name'])

        for pa in beh.get('process_actions') or []:
            if pa.get('path'):
                process_names.append(pa['path'])

    dropped_md5: List[str] = []
    dropped_sha1: List[str] = []
    dropped_sha256: List[str] = []
    for df in cs_results.get('dropped_files') or []:
        if df.get('md5'):
            dropped_md5.append(df['md5'])
        if df.get('sha1'):
            dropped_sha1.append(df['sha1'])
        if df.get('sha256'):
            dropped_sha256.append(df['sha256'])

    candidates = [
        ('ips', _dedup_sorted(ips)),
        ('domains', _dedup_sorted(domains)),
        ('urls', _dedup_sorted(urls)),
        ('file_names', _dedup_sorted(file_names)),
        ('file_paths', _dedup_sorted(file_paths)),
        ('registry_keys', _dedup_sorted(registry_keys)),
        ('registry_values', _dedup_sorted(registry_values)),
        ('mutex_names', _dedup_sorted(mutex_names)),
        ('process_names', _dedup_sorted(process_names)),
        ('process_command_lines', _dedup_sorted(process_command_lines)),
    ]
    for key, values in candidates:
        if values:
            out[key] = values

    file_hashes: Dict[str, List[str]] = {}
    if dropped_md5:
        file_hashes['md5'] = _dedup_sorted(dropped_md5)
    if dropped_sha1:
        file_hashes['sha1'] = _dedup_sorted(dropped_sha1)
    if dropped_sha256:
        file_hashes['sha256'] = _dedup_sorted(dropped_sha256)
    if file_hashes:
        out['file_hashes'] = file_hashes

    return out


def _build_bot_config_indicators(cs_results: Dict[str, Any]) -> Dict[str, Any]:
    """Extract IOCs from cloud-sandbox malware configurations (C2 servers)."""
    out: Dict[str, Any] = {}
    ips: List[str] = []
    for cfg in cs_results.get('malware_configurations') or []:
        for raw in cfg.get('malware_config_ip') or []:
            ip = _strip_port(raw)
            if ip:
                ips.append(ip)
    if ips:
        out['ips'] = _dedup_sorted(ips)
    return out


def _build_static_indicators(sample: Dict[str, Any], ticore: Dict[str, Any],
                              relationships: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Extract static IOCs from ticore and sample relationships."""
    out: Dict[str, Any] = {}

    info = ticore.get('info') or {}
    file_info = info.get('file') or {}
    pe = (ticore.get('application') or {}).get('pe') or {}

    file_names: List[str] = []
    proposed = file_info.get('proposed_filename')
    if proposed:
        file_names.append(proposed)
    for entry in pe.get('version_info') or []:
        if entry.get('name') in ('InternalName', 'OriginalFilename'):
            v = entry.get('value')
            if v:
                file_names.append(v)
    if file_names:
        out['file_names'] = _dedup_sorted(file_names)

    hashes = _hashes_to_dict(file_info.get('hashes') or [])
    file_hashes: Dict[str, List[str]] = {}
    if hashes.get('md5'):
        file_hashes['md5'] = [hashes['md5']]
    if hashes.get('sha1'):
        file_hashes['sha1'] = [hashes['sha1']]
    if hashes.get('sha256'):
        file_hashes['sha256'] = [hashes['sha256']]
    if file_hashes:
        out['file_hashes'] = file_hashes

    rels = relationships or {}
    out['related_files'] = {
        'container': list(rels.get('container_sample_sha1') or []),
        'parent':    list(rels.get('parent_sample_sha1') or []),
        'child':     list(rels.get('child_sample_sha1') or []),
    }

    return out


class SampleIndicatorsTool(BaseMCPTool):
    """Tool for fetching IOCs from a sample's analysis."""

    def execute(self, hash_value: str) -> Dict[str, Any]:
        try:
            sample = self.sa_client.get_file_analysis(hash_value)
        except Exception as e:
            logger.error('Error fetching sample analysis: %s', e)
            return {'error': str(e), 'hash': hash_value}

        if not sample:
            rl_sample, _, cs_results = _fetch_cloud_data(self.sa_client, hash_value)
            if not rl_sample:
                return {'error': 'Sample not found', 'hash': hash_value}
            tc_entries = (rl_sample.get('analysis') or {}).get('entries') or []
            ticore = tc_entries[0].get('tc_report', {}) if tc_entries else {}
            out: Dict[str, Any] = {'source': 'cloud'}
            bot_config = _build_bot_config_indicators(cs_results)
            if bot_config:
                out['bot_config'] = bot_config
            dynamic = _build_dynamic_indicators(cs_results)
            if dynamic:
                out['dynamic'] = dynamic
            relationships = rl_sample.get('relationships') or {}
            static = _build_static_indicators({}, ticore, relationships=relationships)
            # tc_report doesn't include file hashes; supplement from rl_sample
            file_hashes = static.setdefault('file_hashes', {})
            for key in ('md5', 'sha1', 'sha256'):
                if rl_sample.get(key) and key not in file_hashes:
                    file_hashes[key] = [rl_sample[key]]
            if static:
                out['static'] = static
            save_tool_result('get_sample_indicators', out, 'mcp_output')
            return out

        ticore = sample.get('ticore') or {}
        cs_results = _cloud_sandbox_results(sample)

        rldata = self.sa_client.get_rldata(hash_value)
        relationships = (rldata or {}).get('rl', {}).get('sample', {}).get('relationships') or {}

        out: Dict[str, Any] = {}

        bot_config = _build_bot_config_indicators(cs_results)
        if bot_config:
            out['bot_config'] = bot_config

        dynamic = _build_dynamic_indicators(cs_results)
        if dynamic:
            out['dynamic'] = dynamic

        static = _build_static_indicators(sample, ticore, relationships=relationships)
        if static:
            out['static'] = static

        save_report_data('get_sample_indicators', sample, out)
        return out


# ---------------------------------------------------------------------------
# get_sample_ttps
# ---------------------------------------------------------------------------


def _normalize_ticore_attack(attack_list) -> List[Dict[str, Any]]:
    """Normalize ``ticore.attack`` (list of matrices) to the unified shape."""
    matrices: List[Dict[str, Any]] = []
    for matrix in attack_list or []:
        out_tactics = []
        for tactic in matrix.get('tactics') or []:
            techniques = []
            for tech in tactic.get('techniques') or []:
                t: Dict[str, Any] = {
                    'id': tech.get('id'),
                    'name': tech.get('name'),
                }
                techniques.append(t)
            out_tactics.append({
                'id': tactic.get('id'),
                'name': tactic.get('name'),
                'description': tactic.get('description'),
                'techniques': techniques,
            })
        matrices.append({
            'name': matrix.get('matrix') or matrix.get('name'),
            'tactics': out_tactics,
        })
    return matrices


def _normalize_sandbox_attack(mitre_attack: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Normalize ``rl_cloud_sandbox.results.mitre_attack`` to the unified shape."""
    if not isinstance(mitre_attack, dict):
        return []
    matrices: List[Dict[str, Any]] = []
    for matrix in mitre_attack.get('matrix_list') or []:
        out_tactics = []
        tactics_obj = matrix.get('tactics') or {}
        for tactic in tactics_obj.get('tactic_list') or []:
            techniques = []
            tech_obj = tactic.get('techniques') or {}
            for tech in tech_obj.get('technique_list') or []:
                t: Dict[str, Any] = {
                    'id': tech.get('id'),
                    'name': tech.get('name'),
                }
                if tech.get('analysis_ids'):
                    t['analysis_ids'] = tech['analysis_ids']
                techniques.append(t)
            out_tactics.append({
                'id': tactic.get('id'),
                'name': tactic.get('name'),
                'techniques': techniques,
            })
        matrices.append({
            'name': matrix.get('name'),
            'tactics': out_tactics,
        })
    return matrices


def _merge_attack_matrices(static_m: List[Dict[str, Any]],
                           dynamic_m: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Merge static and dynamic ATT&CK matrices.

    Static entries preserve order and come first. Dynamic-only matrices,
    tactics, and techniques are appended in the order encountered. When the
    same technique exists in both, the static version is kept (it has the
    description-bearing tactic context) and the dynamic ``analysis_ids`` are
    merged in.
    """
    merged: List[Dict[str, Any]] = []
    matrix_index: Dict[str, int] = {}

    def add_matrix(m: Dict[str, Any]) -> int:
        name = m.get('name')
        if name in matrix_index:
            return matrix_index[name]
        merged.append({'name': name, 'tactics': []})
        matrix_index[name] = len(merged) - 1
        return matrix_index[name]

    def add_tactic(matrix_pos: int, tactic: Dict[str, Any]) -> int:
        tactics = merged[matrix_pos]['tactics']
        for i, existing in enumerate(tactics):
            if existing.get('id') == tactic.get('id'):
                # Fill description if missing
                if not existing.get('description') and tactic.get('description'):
                    existing['description'] = tactic['description']
                return i
        new_tactic = {
            'id': tactic.get('id'),
            'name': tactic.get('name'),
            'techniques': [],
        }
        if tactic.get('description'):
            new_tactic['description'] = tactic['description']
        tactics.append(new_tactic)
        return len(tactics) - 1

    def add_technique(matrix_pos: int, tactic_pos: int, tech: Dict[str, Any]) -> None:
        techs = merged[matrix_pos]['tactics'][tactic_pos]['techniques']
        for existing in techs:
            if existing.get('id') == tech.get('id'):
                # Merge analysis_ids if dynamic provides them
                if tech.get('analysis_ids'):
                    existing_ids = existing.setdefault('analysis_ids', [])
                    for aid in tech['analysis_ids']:
                        if aid not in existing_ids:
                            existing_ids.append(aid)
                return
        techs.append({k: v for k, v in tech.items() if v is not None})

    for source in (static_m, dynamic_m):
        for matrix in source:
            mp = add_matrix(matrix)
            for tactic in matrix.get('tactics') or []:
                tp = add_tactic(mp, tactic)
                for tech in tactic.get('techniques') or []:
                    add_technique(mp, tp, tech)

    # Drop empty tactics and matrices for cleanliness.
    cleaned = []
    for m in merged:
        m['tactics'] = [t for t in m['tactics'] if t.get('techniques')]
        if m['tactics']:
            cleaned.append(m)
    return cleaned


class SampleTtpsTool(BaseMCPTool):
    """Tool for fetching MITRE ATT&CK TTPs for a sample."""

    def execute(self, hash_value: str) -> Dict[str, Any]:
        try:
            sample = self.sa_client.get_file_analysis(hash_value)
        except Exception as e:
            logger.error('Error fetching sample analysis: %s', e)
            return {'error': str(e), 'hash': hash_value}

        if not sample:
            rl_sample, _, cs_results = _fetch_cloud_data(self.sa_client, hash_value)
            if not rl_sample:
                return {'error': 'Sample not found', 'hash': hash_value}
            tc_entries = (rl_sample.get('analysis') or {}).get('entries') or []
            ticore = tc_entries[0].get('tc_report', {}) if tc_entries else {}
            # Cloud tc_report has attack at metadata.attack (single dict);
            # local has it at attack (list). Normalise to a list either way.
            metadata_attack = (ticore.get('metadata') or {}).get('attack')
            attack_src = ticore.get('attack') or ([metadata_attack] if metadata_attack else [])
            static_m = _normalize_ticore_attack(attack_src)
            dynamic_m = _normalize_sandbox_attack(cs_results.get('mitre_attack') or {})
            merged = _merge_attack_matrices(static_m, dynamic_m)
            output = {'attack': merged, 'source': 'cloud'}
            save_tool_result('get_sample_ttps', output, 'mcp_output')
            return output

        ticore = sample.get('ticore') or {}
        cs_results = _cloud_sandbox_results(sample)

        static_m = _normalize_ticore_attack(ticore.get('attack') or [])
        dynamic_m = _normalize_sandbox_attack(cs_results.get('mitre_attack') or {})
        merged = _merge_attack_matrices(static_m, dynamic_m)
        output = {'attack': merged}
        save_report_data('get_sample_ttps', sample, output)
        return output


# ---------------------------------------------------------------------------
# get_sample_detection_rules
# ---------------------------------------------------------------------------


def _normalize_yara_entries(entries, source: str) -> List[Dict[str, Any]]:
    """Normalize YARA entries to the standard output shape."""
    out: List[Dict[str, Any]] = []
    for entry in entries or []:
        rules_in = entry.get('rule') or entry.get('rules') or []
        rules_out: List[Dict[str, Any]] = []
        for r in rules_in:
            rule: Dict[str, Any] = {}
            if r.get('description'):
                rule['description'] = r['description']
            if r.get('identifier'):
                rule['identifier'] = r['identifier']
            if r.get('rule_name'):
                rule['rule_name'] = r['rule_name']
            # If the API provides matched strings, pass them through (assumed
            # already base64-encoded by the API).
            if r.get('matched_strings'):
                rule['matched_strings'] = r['matched_strings']
            rules_out.append(rule)

        out.append({
            'source': source,
            'source_type': entry.get('source_type'),
            'rules': rules_out,
        })
    return out


class SampleDetectionRulesTool(BaseMCPTool):
    """Tool for fetching YARA / Suricata / Sigma matches for a sample."""

    def execute(self, hash_value: str) -> Dict[str, Any]:
        try:
            sample = self.sa_client.get_file_analysis(hash_value)
        except Exception as e:
            logger.error('Error fetching sample analysis: %s', e)
            return {'error': str(e), 'hash': hash_value}

        if not sample:
            rl_sample, _, cs_results = _fetch_cloud_data(self.sa_client, hash_value)
            if not rl_sample:
                return {'error': 'Sample not found', 'hash': hash_value}
            tc_entries = (rl_sample.get('analysis') or {}).get('entries') or []
            ticore = tc_entries[0].get('tc_report', {}) if tc_entries else {}
            static_yara_raw = ((ticore.get('classification') or {}).get('yara') or [])
            static_entries = [
                {'source_type': None, 'rule': [{'identifier': m.get('identifier'), 'rule_name': m.get('ns')}]}
                for m in static_yara_raw
            ]
            dynamic_yara = (cs_results.get('yara') or {}).get('entries') or []
            yara: List[Dict[str, Any]] = []
            yara.extend(_normalize_yara_entries(static_entries, source='static'))
            yara.extend(_normalize_yara_entries(dynamic_yara, source='dynamic'))
            suricata = cs_results.get('suricata') or cs_results.get('snort') or []
            sigma = cs_results.get('sigma') or []
            output = {'yara': yara, 'suricata': suricata, 'sigma': sigma, 'source': 'cloud'}
            save_tool_result('get_sample_detection_rules', output, 'mcp_output')
            return output

        ticore = sample.get('ticore') or {}
        cs_results = _cloud_sandbox_results(sample)

        # Static YARA from ticore.classification.yara (list of matches)
        static_yara_raw = ((ticore.get('classification') or {}).get('yara') or [])
        # Wrap each ticore yara match into an "entry" with a single rule so
        # the output shape stays consistent.
        static_entries = []
        for m in static_yara_raw:
            static_entries.append({
                'source_type': None,
                'rule': [{
                    'identifier': m.get('identifier'),
                    'rule_name': m.get('ns'),
                }],
            })

        # Dynamic YARA from cloud sandbox
        dynamic_yara = (cs_results.get('yara') or {}).get('entries') or []

        yara: List[Dict[str, Any]] = []
        yara.extend(_normalize_yara_entries(static_entries, source='static'))
        yara.extend(_normalize_yara_entries(dynamic_yara, source='dynamic'))

        # Suricata: API may use either ``suricata`` or legacy ``snort`` key
        suricata = (cs_results.get('suricata')
                    or cs_results.get('snort')
                    or [])
        if not isinstance(suricata, list):
            suricata = []

        sigma = cs_results.get('sigma') or []
        if not isinstance(sigma, list):
            sigma = []

        output = {'yara': yara, 'suricata': suricata, 'sigma': sigma}
        save_report_data('get_sample_detection_rules', sample, output)
        return output


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------


def register(mcp):
    """Register the sample-analysis tools with the MCP server."""

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Get Sample Overview",
            readOnlyHint=True,
            destructiveHint=False,
            idempotentHint=True,
            openWorldHint=True,
        ),
    )
    def get_sample_overview(
        hash_value: Annotated[
            str,
            Field(description='MD5, SHA-1, or SHA-256 hash of the file to look up.',
                  min_length=32, max_length=64),
        ],
    ) -> Dict[str, Any]:
        """
        Return full metadata and classification details for a file sample.

        Includes hashes, file properties, RCA2 classification, multi-AV scan
        results, cloud sandbox and auxiliary analysis classifications, and a
        deduplicated ``threat_names`` list across all sources. PE-specific
        metadata (sections, imports, exports, certificates, etc.) is included
        under ``pe`` for PE files only. When available from the Spectra Core
        static analysis report, ``story``, ``interesting_strings``,
        ``indicators``, and ``tags`` are also included (fields not found in the
        report are omitted).

        Args:
            hash_value: MD5, SHA-1, or SHA-256 hash of the file to look up.
        """
        tool = SampleOverviewTool(
            sa_base_url=config.analyze_base_url,
            sa_verify_ssl=config.analyze_verify_ssl,
        )
        return tool.execute(hash_value)

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Get Sample Indicators",
            readOnlyHint=True,
            destructiveHint=False,
            idempotentHint=True,
            openWorldHint=True,
        ),
    )
    def get_sample_indicators(
        hash_value: Annotated[
            str,
            Field(description='MD5, SHA-1, or SHA-256 hash of the file to look up.',
                  min_length=32, max_length=64),
        ],
    ) -> Dict[str, Any]:
        """
        Return IOCs associated with a file sample, grouped into three confidence-
        ranked buckets: ``bot_config`` (C2 servers from embedded malware configs),
        ``dynamic`` (sandbox execution), and ``static`` (without execution). Values
        are sorted, deduplicated, and empty categories are omitted.

        Args:
            hash_value: MD5, SHA-1, or SHA-256 hash of the file to look up.
        """
        tool = SampleIndicatorsTool(
            sa_base_url=config.analyze_base_url,
            sa_verify_ssl=config.analyze_verify_ssl,
        )
        return tool.execute(hash_value)

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Get Sample TTPs",
            readOnlyHint=True,
            destructiveHint=False,
            idempotentHint=True,
            openWorldHint=True,
        ),
    )
    def get_sample_ttps(
        hash_value: Annotated[
            str,
            Field(description='MD5, SHA-1, or SHA-256 hash of the file to look up.',
                  min_length=32, max_length=64),
        ],
    ) -> Dict[str, Any]:
        """
        Return MITRE ATT&CK TTPs associated with a file sample.

        Combines static and dynamic analysis into a unified ``attack`` matrix.
        Each matrix has ``name`` and ``tactics``; each tactic has ``id``,
        ``name``, ``description``, and ``techniques``; each technique has
        ``id``, ``name``, and optionally ``subtechniques``.

        Args:
            hash_value: MD5, SHA-1, or SHA-256 hash of the file to look up.
        """
        tool = SampleTtpsTool(
            sa_base_url=config.analyze_base_url,
            sa_verify_ssl=config.analyze_verify_ssl,
        )
        return tool.execute(hash_value)

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Get Sample Detection Rules",
            readOnlyHint=True,
            destructiveHint=False,
            idempotentHint=True,
            openWorldHint=True,
        ),
    )
    def get_sample_detection_rules(
        hash_value: Annotated[
            str,
            Field(description='MD5, SHA-1, or SHA-256 hash of the file to look up.',
                  min_length=32, max_length=64),
        ],
    ) -> Dict[str, Any]:
        """
        Return detection rule matches for a file sample as a dict with keys
        ``yara``, ``suricata``, and ``sigma`` (each an empty list if no matches).
        YARA entries include ``source`` (``"static"`` or ``"dynamic"``) and
        ``source_type``. Per-rule fields (e.g. ``description``, ``identifier``,
        and matched strings if provided by the API) are passed through as-is.

        Args:
            hash_value: MD5, SHA-1, or SHA-256 hash of the file to look up.
        """
        tool = SampleDetectionRulesTool(
            sa_base_url=config.analyze_base_url,
            sa_verify_ssl=config.analyze_verify_ssl,
        )
        return tool.execute(hash_value)
