"""Sample details tools for Spectra Analyze MCP Server."""
from mcp_server_analyze.tools.sample_details.sample_details import register

__all__ = ['register']
