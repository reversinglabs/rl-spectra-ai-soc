"""Sample strings extraction tool for Spectra Analyze MCP Server.

Streams a file from the appliance and extracts printable ASCII and
UTF-16 LE strings without writing the file to disk.
"""
import logging
from typing import Any, Dict, Annotated

from pydantic import Field
from mcp.types import ToolAnnotations

from mcp_server_analyze.core import get_config
from mcp_server_analyze.tools.base_tool import BaseMCPTool

logger = logging.getLogger(__name__)
config = get_config()

# Hard limit to avoid exhausting memory on very large samples.
_MAX_SIZE_MB = 50


class SampleStringsTool(BaseMCPTool):
    """Streams a sample from the appliance and extracts printable strings."""

    def execute(self, hash_value: str, min_length: int = 6) -> Dict[str, Any]:
        """Extract printable ASCII and Unicode strings from a file sample.

        Args:
            hash_value: MD5, SHA-1, or SHA-256 hash of the file.
            min_length: Minimum string length to include (default 6).

        Returns:
            Dict with ``file_content`` (``ascii_strings``, ``unicode_strings``)
            and ``bytes_processed``.
        """
        max_bytes = _MAX_SIZE_MB * 1024 * 1024

        logger.info(
            'get_sample_strings: streaming %s (min_length=%d, max=%dMB)',
            hash_value, min_length, _MAX_SIZE_MB,
        )

        ascii_strings: set[str] = set()
        unicode_strings: set[str] = set()
        ascii_acc = bytearray()
        unicode_acc: list[str] = []
        unicode_carry: int | None = None  # leftover byte for UTF-16 LE pair alignment
        total_bytes = 0

        for chunk in self.sa_client.stream_sample(hash_value):
            total_bytes += len(chunk)
            if total_bytes > max_bytes:
                raise ValueError(
                    f'File exceeds the {_MAX_SIZE_MB} MB size limit; processing aborted.'
                )

            # --- ASCII extraction ---
            for byte in chunk:
                if 0x20 <= byte <= 0x7E:
                    ascii_acc.append(byte)
                else:
                    if len(ascii_acc) >= min_length:
                        ascii_strings.add(ascii_acc.decode('ascii'))
                    ascii_acc = bytearray()

            # --- Unicode (UTF-16 LE) extraction ---
            # Prepend the carry byte from the previous chunk to keep pair alignment.
            scan = bytes([unicode_carry]) + chunk if unicode_carry is not None else chunk
            unicode_carry = None
            i = 0
            while i < len(scan):
                if i + 1 < len(scan):
                    b1, b2 = scan[i], scan[i + 1]
                    if 0x20 <= b1 <= 0x7E and b2 == 0x00:
                        unicode_acc.append(chr(b1))
                        i += 2
                        continue
                else:
                    # One byte left — save for next chunk
                    unicode_carry = scan[i]
                    break
                # Non-matching pair: flush accumulator, advance by one byte
                if len(unicode_acc) >= min_length:
                    unicode_strings.add(''.join(unicode_acc))
                unicode_acc = []
                i += 1

        # Flush any in-progress accumulators at end of file
        if len(ascii_acc) >= min_length:
            ascii_strings.add(ascii_acc.decode('ascii'))
        if len(unicode_acc) >= min_length:
            unicode_strings.add(''.join(unicode_acc))

        ascii_result = sorted(ascii_strings)
        unicode_result = sorted(unicode_strings)
        logger.info(
            'get_sample_strings: extracted %d ascii, %d unicode strings from %d bytes',
            len(ascii_result), len(unicode_result), total_bytes,
        )
        return {
            'file_content': {
                'ascii_strings': ascii_result,
                'unicode_strings': unicode_result,
            },
            'bytes_processed': total_bytes,
        }


def register(mcp):
    """Register the sample strings tool with the MCP server."""

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Get Sample Strings",
            readOnlyHint=True,
            destructiveHint=False,
            idempotentHint=True,
            openWorldHint=True,
        ),
    )
    def get_sample_strings(
        hash_value: Annotated[
            str,
            Field(description='MD5, SHA-1, or SHA-256 hash of the file to extract strings from.',
                  min_length=32, max_length=64),
        ],
        min_length: Annotated[
            int,
            Field(description='Minimum string length to include (default: 6).', ge=1, le=100),
        ] = 6,
    ) -> Dict[str, Any]:
        """
        Extract printable ASCII and Unicode strings from a file sample.

        Streams the file from the appliance without saving it to disk and
        returns sorted, deduplicated ASCII and UTF-16 LE Unicode strings.

        Files larger than 50 MB are rejected to prevent memory exhaustion.
        """
        tool = SampleStringsTool(
            sa_base_url=config.analyze_base_url,
            sa_verify_ssl=config.analyze_verify_ssl,
        )
        return tool.execute(hash_value, min_length=min_length)
