"""Sample strings extraction tool."""

from mcp_server_analyze.tools.sample_strings.sample_strings import register

__all__ = ['register']
