"""Sample similarity tool for Spectra Analyze MCP Server."""
from mcp_server_analyze.tools.sample_similarity.sample_similarity import register

__all__ = ['register']
