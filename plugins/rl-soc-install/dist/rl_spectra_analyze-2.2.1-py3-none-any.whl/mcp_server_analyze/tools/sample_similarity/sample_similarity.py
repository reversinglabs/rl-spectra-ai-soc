import asyncio
import logging
from typing import Any, Dict, List, Optional, Annotated

from pydantic import Field
from mcp.types import ToolAnnotations

from mcp_server_analyze.core import get_config
from mcp_server_analyze.tools.base_tool import BaseMCPTool
from mcp_server_analyze.tools.tool_utils import save_report_data

logger = logging.getLogger(__name__)
config = get_config()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _hashes_to_dict(hashes: List[Dict[str, Any]]) -> Dict[str, str]:
    """Convert a list of ``{name, value}`` hash entries into a dict."""
    out: Dict[str, str] = {}
    for h in hashes or []:
        name = h.get('name')
        value = h.get('value')
        if name and value is not None:
            out[name] = value
    return out


def _detect_rha1_type(tc_report: Dict[str, Any]) -> Optional[str]:
    """Infer the RHA1 precision level from a ticore report.

    RHA1 (functional similarity) applies only to executables. Maps the
    report's to ``pe01`` / ``elf01`` / ``macho01``, or returns ``None`` for
    non-executable files.
    """
    info = (tc_report or {}).get('info') or {}
    file = info.get('file') or {}
    file_type = str(file.get('file_type') or '').strip().lower()

    if file_type.startswith('pe'):
        return 'pe01'
    if file_type.startswith('elf'):
        return 'elf01'
    if file_type.startswith('macho') or file_type.startswith('mach-o'):
        #some minor difference between SA and SI API calls for rha_type again where rha1 type need to have a capital O(like octopus)
        return 'machO01'
    return None


def _count_search_classifications(entries: List[Dict[str, Any]]) -> Dict[str, int]:
    """Tally search entries into malicious/suspicious/known/unknown.

    Search entries carry a string ``classification`` (e.g. ``Malicious``,
    ``Goodware``, ``Suspicious``, ``Unclassified``); ``Goodware`` maps to
    ``known`` and anything unrecognized falls into ``unknown``.
    """
    counts = {'malicious': 0, 'suspicious': 0, 'known': 0, 'unknown': 0}
    for entry in entries or []:
        cls = str(entry.get('classification') or '').strip().lower()
        if cls == 'goodware':
            cls = 'known'
        counts[cls if cls in counts else 'unknown'] += 1
    return counts


# ---------------------------------------------------------------------------
# Tool
# ---------------------------------------------------------------------------


class SampleSimilarityTool(BaseMCPTool):
    """Tool for fetching similarity-based classification breakdowns.

    Resolves the sample's SHA-1, imphash, and RHA1 type from the rldata
    endpoint (ticore as a fallback), then queries RHA1 analytics and an
    advanced search for the two similarity signals.
    """

    def _resolve_metadata(self, hash_value: str) -> Dict[str, Optional[str]]:
        """Resolve ``sha1``, ``imphash``, and ``rha1_type`` for the sample.

        Primary source is the rldata proxy endpoint; if that returns nothing,
        falls back to the ticore report.
        """
        try:
            rldata = self.sa_client.get_rldata(hash_value)
            if rldata:
                logger.info('inside rl data branch')
                sample = (rldata.get('rl') or {}).get('sample') or {}
                tc_entries = (sample.get('analysis') or {}).get('entries') or []
                tc_report = tc_entries[0].get('tc_report', {}) if tc_entries else {}
                return {
                    'sha1': sample.get('sha1'),
                    'imphash': sample.get('imphash'),
                    'tlsh': sample.get('tlsh'),
                    'ssdeep': sample.get('ssdeep'),
                    'rha1_type': _detect_rha1_type(tc_report),
                }
        except Exception as e:
            logger.warning('get_sample_similarity: rldata lookup failed for %s: %s', hash_value, e)

        logger.info('get_sample_similarity: rldata unavailable, falling back to ticore for %s', hash_value)
        try:
            ticore = self.sa_client.get_ticore(hash_value) or {}
            file_info = (ticore.get('info') or {}).get('file') or {}
            hashes = _hashes_to_dict(file_info.get('hashes') or [])
            imphash = hashes.get('imphash') or ((ticore.get('application') or {}).get('pe') or {}).get('imphash')
            return {
                'sha1': hashes.get('sha1'),
                'imphash': imphash,
                'tlsh': hashes.get('tlsh'),
                'ssdeep': hashes.get('ssdeep'),
                'rha1_type': _detect_rha1_type(ticore),
            }
        except Exception as e:
            logger.warning('get_sample_similarity: ticore lookup failed for %s: %s', hash_value, e)
            return {}

    def _build_rha1_signal(self, sha1: str, rha1_type: str) -> Optional[Dict[str, Any]]:
        """Build the ``rha1`` signal from RHA1 analytics."""
        try:
            result = self.sa_client.get_rha1_analytics(sha1, rha1_type)
        except Exception as e:
            logger.warning('get_sample_similarity: RHA1 analytics failed for %s: %s', sha1, e)
            return None
        res = result or {}
        counters = res.get('rha1_counters') or (res.get('rl') or {}).get('rha1_counters')
        if not counters:
            logger.debug('get_sample_similarity: RHA1 response missing rha1_counters')
            return None

        sample_counters = counters.get('sample_counters') or {}
        malicious = sample_counters.get('malicious', 0)
        suspicious = sample_counters.get('suspicious', 0)
        known = sample_counters.get('known', 0)
        total = sample_counters.get('total', malicious + suspicious + known)

        rha1_out: Dict[str, Any] = {
            'rha1_type': rha1_type,
            'total': total,
            'malicious': malicious,
            'suspicious': suspicious,
            'known': known,
        }
        if first_seen := counters.get('rha1_first_seen'):
            rha1_out['first_seen'] = first_seen
        if last_seen := counters.get('rha1_last_seen'):
            rha1_out['last_seen'] = last_seen
        return rha1_out

    def _build_search_signal(self, keyword: str, value: str) -> Optional[Dict[str, Any]]:
        """Build a similarity signal from an advanced search on ``keyword:value``. """
        query = f'{keyword}:"{value}"' if keyword == 'ssdeep' else f'{keyword}:{value}'
        logger.info('get_sample_similarity: %s search query=%s', keyword, query)
        result = self.sa_client.advanced_search(query, limit=100, ticloud=True)

        search_api = (result or {}).get('search_api')
        if not search_api:
            logger.debug('get_sample_similarity: %s search missing search_api', keyword)
            return None

        entries = search_api.get('entries') or []
        total_in_index = search_api.get('total_count')
        return {
            'value': value,
            'total_in_index': total_in_index if isinstance(total_in_index, int) else len(entries),
            'sampled': len(entries),
            **_count_search_classifications(entries),
        }

    @staticmethod
    def _rha1_placeholder(note: str, rha1_type: Optional[str] = None) -> Dict[str, Any]:
        """Empty placeholder for rha1 with note so we do not just return empty object but something 
        immediately meaningful """
        return {
            'rha1_type': rha1_type,
            'total': 0,
            'malicious': 0,
            'suspicious': 0,
            'known': 0,
            'note': note,
        }

    @staticmethod
    def _search_placeholder(note: str, value: Optional[str] = None) -> Dict[str, Any]:
        """Empty placeholder for remaining keys with note so we do not just return empty object but something 
        immediately meaningful"""
        return {
            'value': value,
            'total_in_index': 0,
            'sampled': 0,
            'malicious': 0,
            'suspicious': 0,
            'known': 0,
            'unknown': 0,
            'note': note,
        }

    async def _gather_signals(self, meta: Dict[str, Optional[str]]) -> Dict[str, Any]:
        """Build all similarity signals concurrently."""
        sha1 = meta.get('sha1')
        rha1_type = meta.get('rha1_type')

        output: Dict[str, Any] = {}
        tasks: List[tuple[str, Any]] = []

        if rha1_type is None:
            output['rha1'] = self._rha1_placeholder(
                'this file is not an executable (PE, ELF, or Mach-O), so no RHA1 lookup was performed'
            )
        elif not sha1:
            output['rha1'] = self._rha1_placeholder(
                'this file has no SHA-1 hash in Spectra Intelligence, so no RHA1 lookup was performed',
                rha1_type=rha1_type,
            )
        else:
            tasks.append(('rha1', asyncio.to_thread(self._build_rha1_signal, sha1, rha1_type)))

        for key in ('imphash', 'tlsh', 'ssdeep'):
            value = meta.get(key)
            if value:
                tasks.append((key, asyncio.to_thread(self._build_search_signal, key, value)))
            else:
                output[key] = self._search_placeholder(
                    f'this file has no {key} hash in Spectra Analyze, so no {key} search was performed'
                )

        results = await asyncio.gather(
            *(coro for _, coro in tasks), return_exceptions=True,
        )
        for (key, _), signal in zip(tasks, results):
            if isinstance(signal, asyncio.CancelledError):
                raise signal
            if isinstance(signal, BaseException):
                logger.warning(
                    'get_sample_similarity: %s lookup raised: %s', key, signal, exc_info=signal,
                )
                if key == 'rha1':
                    output[key] = self._rha1_placeholder(
                        'the RHA1 lookup failed, so no functional similarity data is available '
                        'for this file',
                        rha1_type=rha1_type,
                    )
                else:
                    output[key] = self._search_placeholder(
                        f'the {key} search failed, so no {key} similarity data is available '
                        'for this file',
                        value=meta.get(key),
                    )
            elif signal is not None:
                output[key] = signal
            elif key == 'rha1':
                output[key] = self._rha1_placeholder(
                    'no functionally similar samples were found for this file in Spectra Analyze',
                    rha1_type=rha1_type,
                )
            else:
                output[key] = self._search_placeholder(
                    f'no samples sharing this {key} hash were found in Spectra Analyze',
                    value=meta.get(key),
                )

        return {k: output[k] for k in ('rha1', 'imphash', 'tlsh', 'ssdeep') if k in output}

    async def execute(self, hash_value: str) -> Dict[str, Any]:
        logger.info('get_sample_similarity: resolving metadata for %s', hash_value)
        meta = await asyncio.to_thread(self._resolve_metadata, hash_value)

        logger.info(
            'get_sample_similarity: %s (rha1_type=%s, sha1=%s, imphash=%s, tlsh=%s, ssdeep=%s)',
            hash_value, meta.get('rha1_type'), meta.get('sha1'),
            meta.get('imphash'), meta.get('tlsh'), meta.get('ssdeep'),
        )

        output = await self._gather_signals(meta)

        try:
            save_report_data('get_sample_similarity', meta, output)
        except Exception as e:
            logger.warning('get_sample_similarity: saving report data failed: %s', e)
        return output


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------


def register(mcp):
    """Register the sample similarity tool with the MCP server."""

    @mcp.tool(
        structured_output=False,
        annotations=ToolAnnotations(
            title='Get Sample Similarity',
            readOnlyHint=True,
            destructiveHint=False,
            idempotentHint=True,
            openWorldHint=True,
        ),
    )
    async def get_sample_similarity(
        hash_value: Annotated[
            str,
            Field(description='MD5, SHA-1, or SHA-256 hash of the file.',
                  min_length=32, max_length=64),
        ],
    ) -> Dict[str, Any]:
        """
        Return classification breakdowns for samples similar to the given file.

        Provides several similarity signals for false positive / true positive
        validation:
        - **rha1**: how many functionally similar executables are malicious vs
          goodware
        - **imphash**: classification breakdown of PE samples sharing the same
          import hash
        - **tlsh**: classification breakdown of samples sharing the same TLSH
          fuzzy hash
        - **ssdeep**: classification breakdown of samples sharing the same
          ssdeep fuzzy hash

        Args:
            hash_value: MD5, SHA-1, or SHA-256 hash of the file.

        Returns:
            A dict that always contains the keys ``rha1``, ``imphash``,
            ``tlsh`` and ``ssdeep``.
        """
        tool = SampleSimilarityTool(
            sa_base_url=config.analyze_base_url,
            sa_verify_ssl=config.analyze_verify_ssl,
        )
        return await tool.execute(hash_value)
