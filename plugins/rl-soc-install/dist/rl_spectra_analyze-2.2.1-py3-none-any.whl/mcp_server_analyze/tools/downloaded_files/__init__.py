"""Downloaded (unpacked) files retrieval tool."""

from mcp_server_analyze.tools.downloaded_files.downloaded_files import register

__all__ = ['register']
