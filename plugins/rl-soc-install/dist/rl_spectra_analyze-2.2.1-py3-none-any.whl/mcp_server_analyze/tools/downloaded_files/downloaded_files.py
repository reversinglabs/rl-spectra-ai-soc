"""Downloaded files retrieval tool for Spectra Analyze MCP Server.

Returns SHA1 hashes of files downloaded from a URL, domain, or IP address,
grouped by classification. The indicator type is detected automatically, then
the matching network-threat-intel endpoint is queried.
"""
import ipaddress
import logging
from typing import Any, Dict, List, Annotated

from pydantic import Field
from mcp.types import ToolAnnotations

from mcp_server_analyze.core import get_config
from mcp_server_analyze.tools.base_tool import BaseMCPTool

logger = logging.getLogger(__name__)
config = get_config()


def _classify_indicator(indicator: str) -> str:
    """Return 'url', 'ip', or 'domain' for the given network indicator."""
    if '://' in indicator:
        return 'url'
    try:
        ipaddress.ip_address(indicator)
        return 'ip'
    except ValueError:
        return 'domain'


class DownloadedFilesTool(BaseMCPTool):
    """Lists files downloaded from a network indicator, grouped by classification."""

    def execute(self, indicator: str) -> Dict[str, List[str]]:
        """Return SHA1 hashes of downloaded files grouped by classification.

        Args:
            indicator: A URL, domain, or IP address.

        Returns:
            A dict keyed by classification (``MALICIOUS``, ``SUSPICIOUS``,
            ``GOODWARE``, ``UNKNOWN``). Each value is a list of SHA1 hashes.
        """
        kind = _classify_indicator(indicator)
        logger.info('get_downloaded_files: indicator %s classified as %s', indicator, kind)

        if kind == 'url':
            response = self.sa_client.get_network_url_downloaded_files(indicator)
        elif kind == 'ip':
            response = self.sa_client.get_network_ip_downloaded_files(indicator)
        else:
            response = self.sa_client.get_network_domain_downloaded_files(indicator)

        if not response:
            logger.info('get_downloaded_files: no data for %s', indicator)
            return {}

        files = response.get('downloaded_files') or []

        grouped: Dict[str, List[str]] = {}
        for file in files:
            sha1 = file.get('sha1')
            if sha1:
                classification = file.get('classification') or 'UNKNOWN'
                grouped.setdefault(classification, []).append(sha1)

        return grouped


def register(mcp):
    """Register the downloaded files tool with the MCP server."""

    @mcp.tool(
        annotations=ToolAnnotations(
            title='Get Downloaded Files',
            readOnlyHint=True,
            destructiveHint=False,
            idempotentHint=True,
            openWorldHint=True,
        ),
    )
    def get_downloaded_files(
        indicator: Annotated[
            str,
            Field(description='A URL, domain, or IP address. The indicator type '
                              'is detected automatically.'),
        ],
    ) -> Dict[str, List[str]]:
        """
        Return SHA1 hashes of files downloaded from a URL, domain, or IP
        address (type auto-detected), grouped by classification.

        Returns a dict keyed by classification (``MALICIOUS``, ``SUSPICIOUS``,
        ``GOODWARE``, ``UNKNOWN``), each value a list of SHA1 hashes; empty
        dict when the indicator has no downloaded files.
        """
        tool = DownloadedFilesTool(
            sa_base_url=config.analyze_base_url,
            sa_verify_ssl=config.analyze_verify_ssl,
        )
        return tool.execute(indicator)
