"""Sample behavior tool for Spectra Analyze MCP Server."""
from mcp_server_analyze.tools.sample_behavior.sample_behavior import register

__all__ = ['register']
