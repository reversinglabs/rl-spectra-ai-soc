"""Sample behavior tool for Spectra Analyze MCP Server.

Provides ``get_sample_behavior`` which returns dynamic analysis (sandbox)
behavioral data for a file. Results are grouped by sandbox run in ``analyses``,
each containing per-run metadata plus a ``process_tree`` and an
``activity_timeline``. Aggregate ``indicators`` (mutexes, file paths, registry
keys, modules), ``dropped_files``, ``signatures``, and
``malware_configurations`` are also returned across all runs.

Data is fetched through the Spectra Analyze appliance's Spectra Intelligence
proxy (TCA-0106 cloud sandbox report). Unlike the raw Spectra Intelligence API,
the appliance bridge returns the merged report fields at the top level rather
than nested under ``rl.report``.
"""
import json
import logging
from typing import Any, Dict, List, Optional, Annotated

from pydantic import Field
from mcp.types import ToolAnnotations

from mcp_server_analyze.core import get_config
from mcp_server_analyze.tools.base_tool import BaseMCPTool
from mcp_server_analyze.tools.tool_utils import save_report_data

logger = logging.getLogger(__name__)
config = get_config()

_INDICATOR_LIMIT = 1000


# ---------------------------------------------------------------------------
# Helpers (pure transformation, no client dependency)
# ---------------------------------------------------------------------------


def _clean_process_tree_entry(entry: Dict[str, Any]) -> Dict[str, Any]:
    """Strip noisy fields from a behavioral entry for process_tree output."""
    _REMOVE = {'mutex_actions', 'file_actions', 'registry', 'registry_actions', 'modules_loaded'}
    cleaned = {k: v for k, v in entry.items() if k not in _REMOVE}
    # Strip analysis_ids from process
    if isinstance(cleaned.get('process'), dict):
        cleaned['process'] = {
            k: v for k, v in cleaned['process'].items() if k != 'analysis_ids'
        }
    # Strip analysis_ids and status from process_actions entries
    if isinstance(cleaned.get('process_actions'), list):
        _REMOVE_ACTION = {'analysis_ids', 'status'}
        cleaned['process_actions'] = [
            {k: v for k, v in pa.items() if k not in _REMOVE_ACTION}
            for pa in cleaned['process_actions']
            if isinstance(pa, dict)
        ]
    return cleaned


def _transform_timeline_process(process: Dict[str, Any]) -> Dict[str, Any]:
    """Rename fields and strip analysis_ids from an activity_timeline process."""
    _RENAMES = {'sigs': 'actions', 'files': 'dropped_files', 'ips': 'network_connections'}
    result: Dict[str, Any] = {}
    for key, value in process.items():
        if key == 'analysis_ids':
            continue
        out_key = _RENAMES.get(key, key)
        if isinstance(value, list) and key in _RENAMES:
            result[out_key] = [
                {k: v for k, v in item.items() if k != 'analysis_ids'}
                for item in value
            ]
        else:
            result[out_key] = value
    return result


def _build_indicators(behavioral_entries: List[Dict[str, Any]]) -> Dict[str, List[str]]:
    """Collect aggregate indicators from all behavioral entries."""
    ind_mutexes: set[str] = set()
    ind_file_paths: set[str] = set()
    ind_registry: set[str] = set()
    ind_modules: set[str] = set()

    for entry in behavioral_entries:
        for ma in entry.get('mutex_actions') or []:
            if isinstance(ma, dict):
                name = ma.get('name')
                if name and str(name).upper() != 'NULL':
                    ind_mutexes.add(name)

        for fa in entry.get('file_actions') or []:
            if isinstance(fa, dict):
                fp = fa.get('file_path')
                fn = fa.get('file_name')
                if fp and fn:
                    sep = '\\' if '\\' in fp else '/'
                    ind_file_paths.add(f'{fp}{sep}{fn}')
                elif fp:
                    ind_file_paths.add(fp)
                elif fn:
                    ind_file_paths.add(fn)

        registry = entry.get('registry')
        registry_actions: list = []
        if isinstance(registry, dict):
            registry_actions = registry.get('registry_actions') or []
        if not registry_actions:
            registry_actions = entry.get('registry_actions') or []
        for ra in registry_actions:
            if isinstance(ra, dict):
                key = ra.get('key_name')
                val = ra.get('value_name')
                if key:
                    ind_registry.add(f'{key}:{val}' if val else key)

        for mod in entry.get('modules_loaded') or []:
            if isinstance(mod, dict):
                name = mod.get('name') or mod.get('module_name')
                if name:
                    ind_modules.add(name)
            elif isinstance(mod, str) and mod:
                ind_modules.add(mod)

    return {
        'mutexes':    sorted(ind_mutexes)[:_INDICATOR_LIMIT],
        'file_paths': sorted(ind_file_paths)[:_INDICATOR_LIMIT],
        'registry':   sorted(ind_registry)[:_INDICATOR_LIMIT],
        'modules':    sorted(ind_modules)[:_INDICATOR_LIMIT],
    }


def _transform_report(report: Dict[str, Any], analysis_id: Optional[str]) -> Dict[str, Any]:
    """Transform a merged TCA-0106 report dict into the behavior output shape.

    ``report`` is the top-level dynamic analysis dict as returned by the Spectra
    Analyze appliance (fields such as ``history_analysis``, ``behavioral``,
    ``activity_timeline`` live directly on it, not under ``rl.report``).
    """
    history = report.get('history_analysis')
    if history is None:
        logger.warning("get_sample_behavior: report missing 'history_analysis'")
        return {}

    behavioral_entries = report.get('behavioral') or []

    indicators = _build_indicators(behavioral_entries)

    # Group behavioral entries by analysis_id for process_tree
    process_tree_by_analysis: Dict[str, list] = {}
    for i, entry in enumerate(behavioral_entries):
        proc = entry.get('process')
        if not proc:
            logger.warning('get_sample_behavior: behavioral[%d] missing \'process\'', i)
            continue
        aids = proc.get('analysis_ids')
        if not aids:
            logger.warning('get_sample_behavior: behavioral[%d].process missing \'analysis_ids\'', i)
            continue
        cleaned = _clean_process_tree_entry(entry)
        for aid in aids:
            if isinstance(aid, dict):
                continue
            process_tree_by_analysis.setdefault(aid, []).append(cleaned)

    # Build activity_timeline per analysis from activity_timeline.processes
    timeline_by_analysis: Dict[str, list] = {}
    activity_timeline = report.get('activity_timeline')
    if activity_timeline is not None:
        tl_processes = activity_timeline.get('processes') or []
        for i, process in enumerate(tl_processes):
            aids = process.get('analysis_ids')
            if not aids:
                logger.debug(
                    'get_sample_behavior: missing \'analysis_ids\' in activity_timeline.processes[%d]', i
                )
                continue
            transformed = _transform_timeline_process(process)
            for aid in aids:
                timeline_by_analysis.setdefault(aid, []).append(transformed)
    else:
        logger.debug("get_sample_behavior: report missing 'activity_timeline'")

    # Dropped files don't carry usable analysis_ids — read directly from the report
    _REMOVE_DF = {'md5', 'sha256', 'sample_size', 'file_path', 'analysis_ids'}
    seen_dropped: set[str] = set()
    dropped_files_output: List[Dict[str, Any]] = []
    for df in report.get('dropped_files') or []:
        if not isinstance(df, dict):
            continue
        file_path = df.get('file_path') or ''
        file_name = df.get('file_name') or ''
        if file_path and file_name:
            sep = '\\' if '\\' in file_path else '/'
            full_name = f'{file_path}{sep}{file_name}'
        else:
            full_name = file_path or file_name
        cleaned = {k: v for k, v in df.items() if k not in _REMOVE_DF}
        if full_name:
            cleaned['file_name'] = full_name
        key = df.get('sha1') or full_name or ''
        if key and key not in seen_dropped:
            seen_dropped.add(key)
            dropped_files_output.append(cleaned)

    # Aggregate deduplicated malware configurations (dedup on full object after
    # stripping analysis_ids)
    seen_configs: set[str] = set()
    all_malware_configs: List[Dict[str, Any]] = []
    for cfg in report.get('malware_configurations') or []:
        if not isinstance(cfg, dict):
            continue
        cleaned_cfg = {k: v for k, v in cfg.items() if k != 'analysis_ids'}
        key = json.dumps(cleaned_cfg, sort_keys=True)
        if key not in seen_configs:
            seen_configs.add(key)
            all_malware_configs.append(cleaned_cfg)

    # Aggregate deduplicated signatures, deduped by description
    seen_sigs: set[str] = set()
    all_signatures: List[Dict[str, Any]] = []
    for sig in report.get('signatures') or []:
        if not isinstance(sig, dict):
            continue
        cleaned_sig = {k: v for k, v in sig.items() if k not in {'sig_id', 'analysis_ids'}}
        key = cleaned_sig.get('description') or ''
        if key and key not in seen_sigs:
            seen_sigs.add(key)
            all_signatures.append(cleaned_sig)

    _REMOVE_HIST = {'warnings', 'classification_version'}

    # Build output ordered by analysis run as they appear in history_analysis
    analyses = []
    for entry in history:
        aid = entry.get('analysis_id')
        if aid is None:
            logger.warning("get_sample_behavior: history_analysis entry missing 'analysis_id'")
            continue
        analysis_output = {k: v for k, v in entry.items() if k not in _REMOVE_HIST}
        analysis_output['process_tree'] = process_tree_by_analysis.get(aid, [])
        analysis_output['activity_timeline'] = timeline_by_analysis.get(aid, [])
        analyses.append(analysis_output)

    if analysis_id is not None:
        analyses = [a for a in analyses if a.get('analysis_id') == analysis_id]

    return {
        'analyses': analyses,
        'malware_configurations': all_malware_configs,
        'signatures': all_signatures,
        'dropped_files': dropped_files_output,
        'indicators': indicators,
    }


# ---------------------------------------------------------------------------
# Tool
# ---------------------------------------------------------------------------


class SampleBehaviorTool(BaseMCPTool):
    """Return dynamic analysis (sandbox) behavioral data for a file."""

    def execute(self, hash_value: str, analysis_id: Optional[str] = None) -> Dict[str, Any]:
        logger.info('get_sample_behavior: fetching dynamic analysis for %s', hash_value)

        data = self.sa_client.get_dynamic_analysis(hash_value)
        if not data:
            logger.info('get_sample_behavior: no dynamic analysis found for %s', hash_value)
            return {'hash': hash_value, 'analyses': []}

        try:
            transformed = _transform_report(data, analysis_id)
        except Exception:
            logger.exception(
                'get_sample_behavior: unexpected error processing report for %s', hash_value
            )
            raise

        output: Dict[str, Any] = {'hash': hash_value}
        output.update(transformed)

        save_report_data('get_sample_behavior', data, output)
        return output


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------


def register(mcp):
    """Register the sample behavior tool with the MCP server."""

    @mcp.tool(
        # Return the result dict as-is instead of nesting it under a
        # ``{"result": ...}`` structured-output wrapper.
        structured_output=False,
        annotations=ToolAnnotations(
            title='Get Sample Behavior',
            readOnlyHint=True,
            destructiveHint=False,
            idempotentHint=True,
            openWorldHint=True,
        ),
    )
    def get_sample_behavior(
        hash_value: Annotated[
            str,
            Field(description='MD5, SHA-1, or SHA-256 hash of the file.',
                  min_length=32, max_length=64),
        ],
        analysis_id: Annotated[
            Optional[str],
            Field(description='When provided, filter results to a single sandbox '
                              'analysis run.'),
        ] = None,
    ) -> Dict[str, Any]:
        """
        Return dynamic analysis (sandbox) behavioral data for a file.

        Results are grouped by sandbox run in ``analyses``, each with per-run
        platform/classification metadata plus ``process_tree`` and
        ``activity_timeline``. Aggregate ``indicators`` (mutexes, file paths,
        registry keys, modules), ``dropped_files``, ``signatures``, and
        ``malware_configurations`` span all runs. Pass ``analysis_id`` to
        filter to one run.
        """
        tool = SampleBehaviorTool(
            sa_base_url=config.analyze_base_url,
            sa_verify_ssl=config.analyze_verify_ssl,
        )
        return tool.execute(hash_value, analysis_id)
