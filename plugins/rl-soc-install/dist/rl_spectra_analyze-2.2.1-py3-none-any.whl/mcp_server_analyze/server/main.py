"""Streamlined MCP server for ReversingLabs Spectra Analyze.

This server provides a single enhanced threat analysis tool using the refactored
OOP architecture. It supports only streamable HTTP transport.

Authentication:
- Supports both legacy bearer tokens and OAuth/Keycloak JWT tokens
- Legacy tokens are validated against the Spectra Analyze API
- OAuth tokens are validated using JWT/JWKS and exchange for appliance tokens
"""
import logging
import sys
from urllib.parse import urlparse

from mcp.server.auth.settings import AuthSettings
from mcp.server.fastmcp import FastMCP
from mcp.server.transport_security import TransportSecuritySettings
from pydantic import AnyHttpUrl

from mcp_server_analyze.core import get_config
from mcp_server_analyze.prompts import mcp_prompts
from mcp_server_analyze.tools.tool_registry import register_all_tools
from mcp_server_analyze.version import SPECTRA_ANALYZE_MCP_VERSION
from mcp_server_analyze.auth import (
    LegacyTokenAuthenticator,
    OAuthTokenAuthenticator,
    CompositeAuthenticator,
)
from mcp_server_analyze.auth.mcp_token_verifier import MCPTokenVerifier

# Module-specific logger for this file (includes module name in log output)
logger = logging.getLogger(__name__)


def setup_logging(log_level_int: int) -> None:
    """Configure logging for the application.
    
    Args:
        log_level_int: Logging level as integer
    """
    # Root logger - configures logging infrastructure for entire application
    root_logger = logging.getLogger()
    root_logger.setLevel(log_level_int)
    
    # Create console handler that logs to stderr
    handler = logging.StreamHandler(sys.stderr)
    handler.setLevel(log_level_int)
    
    # Create formatter and add it to the handler
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)
    
    # Add the handler to the root logger (all module loggers inherit this)
    if not root_logger.handlers:
        root_logger.addHandler(handler)


def create_authenticator(config) -> CompositeAuthenticator:
    """Create the composite authenticator based on configuration.
    
    Returns:
        CompositeAuthenticator instance with enabled authenticators
    """
    authenticators = []
    
    # Add legacy authenticator if enabled
    if config.enable_legacy_auth:
        logger.info('Legacy token authentication enabled')
        legacy_auth = LegacyTokenAuthenticator(
            base_url=config.analyze_base_url,
            verify_ssl=config.analyze_verify_ssl,
        )
        authenticators.append(legacy_auth)
    
    # Add OAuth authenticator if enabled
    if config.enable_oauth_auth:
        logger.info('OAuth token authentication enabled')
        oauth_auth = OAuthTokenAuthenticator(
            keycloak_issuer=config.keycloak_issuer,
            keycloak_jwks_url=config.keycloak_jwks_url,
            keycloak_appliance_token_endpoint=config.keycloak_appliance_token_endpoint,
            appliance_id=config.appliance_id,
            appliance_url=config.appliance_url,
            required_scopes=config.oauth_required_scopes,
            cache_ttl=config.appliance_token_cache_ttl,
            cache_refresh_skew=config.appliance_token_refresh_skew,
        )
        authenticators.append(oauth_auth)
    
    if not authenticators:
        raise RuntimeError('No authentication methods enabled')
    
    return CompositeAuthenticator(authenticators)


def create_auth_settings(config) -> AuthSettings:
    """Create auth settings based on configuration.
    
    Args:
        config: Configuration instance
        
    Returns:
        AuthSettings instance
    """
    # Determine MCP server URL (use public URL if configured)
    mcp_server_url = config.mcp_public_url or f"http://{config.mcp_host}:{config.mcp_port}"
    logger.info('Resource server URL for AuthSettings: %s', mcp_server_url)
    
    # Use OAuth issuer if OAuth is enabled, otherwise use appliance URL
    if config.enable_oauth_auth:
        logger.info('OAuth required scopes: %s', config.oauth_required_scopes)
        logger.info('OAuth will use audience claim for appliance binding: %s', mcp_server_url)
        
        return AuthSettings(
            issuer_url=AnyHttpUrl(config.keycloak_issuer),
            resource_server_url=AnyHttpUrl(mcp_server_url),
            required_scopes=config.oauth_required_scopes,
        )
    else:
        return AuthSettings(
            issuer_url=AnyHttpUrl(f"{config.analyze_base_url}"),
            resource_server_url=AnyHttpUrl(f"{config.analyze_base_url}"),
            required_scopes=[],
        )


def create_mcp_server(config, auth_settings: AuthSettings, token_verifier: MCPTokenVerifier) -> FastMCP:
    """Create and configure the MCP server.
    
    Args:
        config: Configuration instance
        auth_settings: Authentication settings
        token_verifier: Token verifier instance
    
    Returns:
        Configured FastMCP instance
    """
    mcp = FastMCP(
        'reversinglabs-spectra-analyze-refactored',
        auth=auth_settings,
        token_verifier=token_verifier,
    )
    
    # Configure transport security with allowed hosts for OAuth discovery
    if config.enable_oauth_auth and config.mcp_public_url:
        parsed = urlparse(config.mcp_public_url)
        # Extract host (with port if present)
        allowed_host = parsed.netloc
        
        transport_security = TransportSecuritySettings(
            enable_dns_rebinding_protection=True,
            allowed_hosts=[allowed_host, "localhost:*", "127.0.0.1:*"],
            allowed_origins=[]
        )
        mcp.settings.transport_security = transport_security
        logger.info('Configured transport security with allowed host: %s', allowed_host)

    # Register all tools using the centralized registry
    register_all_tools(mcp)

    # Register all prompts
    mcp_prompts.register(mcp)

    # mcp SDK 1.27 has no public API for server version;
    # version is on the underlying low-level Server object.
    # If this breaks on upgrade, check FastMCP._mcp_server.version
    mcp._mcp_server.version = SPECTRA_ANALYZE_MCP_VERSION

    return mcp


def log_configuration(config) -> None:
    """Log current configuration (without sensitive data).
    
    Args:
        config: Configuration instance
    """
    logger.info('Spectra Analyze Base URL: %s', config.analyze_base_url)
    logger.info('SSL Verify for Spectra Analyze: %s', config.analyze_verify_ssl)
    logger.info('Log Level: %s', config.log_level)
    logger.info('MCP Host: %s', config.mcp_host)
    logger.info('MCP Port: %s', config.mcp_port)
    logger.info('MCP Path: %s', config.mcp_path)
    
    # Log authentication configuration
    logger.info('Authentication Configuration:')
    logger.info('  Legacy Auth: %s', "enabled" if config.enable_legacy_auth else "disabled")
    logger.info('  OAuth Auth: %s', "enabled" if config.enable_oauth_auth else "disabled")
    if config.enable_oauth_auth:
        logger.info('  Keycloak Issuer: %s', config.keycloak_issuer)
        logger.info('  Appliance ID: %s', config.appliance_id)
        if config.oauth_required_scopes:
            logger.info('  Required Scopes: %s', ", ".join(config.oauth_required_scopes))


def main():
    """Main entry point for the MCP server."""
    # Get configuration
    config = get_config()
    
    # Setup logging
    setup_logging(config.log_level_int)
    
    logger.info('Initializing Spectra Analyze MCP Server')
    
    # Validate configuration
    if not config.validate():
        logger.error('Invalid Configuration')
        raise RuntimeError('Configuration validation failed. Please check config.ini')
    
    logger.info('Configuration validated successfully')
    
    # Log configuration
    log_configuration(config)
    
    # Create authentication components
    try:
        authenticator = create_authenticator(config)
        token_verifier = MCPTokenVerifier(authenticator)
        auth_settings = create_auth_settings(config)
    except Exception as e:
        logger.error('Failed to create authentication components: %s', e)
        raise
    
    # Create MCP server
    mcp = create_mcp_server(config, auth_settings, token_verifier)
    
    # Run with streamable HTTP transport only
    logger.info('Starting MCP server with streamable HTTP transport')
    mcp.settings.host = config.mcp_host
    mcp.settings.port = config.mcp_port
    mcp.settings.streamable_http_path = config.mcp_path
    mcp.run(transport='streamable-http')


if __name__ == '__main__':
    main()

