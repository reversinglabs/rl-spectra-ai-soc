"""MCP token verifier that integrates with FastMCP framework."""

import logging
from typing import Optional

from mcp.server.auth.provider import AccessToken, TokenVerifier

from mcp_server_analyze.core import token_manager
from mcp_server_analyze.core.token_manager import current_bearer_token
from .composite_authenticator import CompositeAuthenticator
from .models import AuthContext, AuthType

logger = logging.getLogger(__name__)


class MCPTokenVerifier(TokenVerifier):
    """Token verifier for FastMCP that uses our composite authenticator.
    
    This class bridges between FastMCP's TokenVerifier interface and our
    pluggable authentication system.
    """
    
    def __init__(self, authenticator: CompositeAuthenticator):
        """Initialize MCP token verifier.
        
        Args:
            authenticator: Composite authenticator instance
        """
        self.authenticator = authenticator
        self._auth_context_store = {}  # Store auth contexts by token
    
    async def verify_token(self, token: str) -> Optional[AccessToken]:
        """Verify token using composite authenticator.
        
        This method is called by FastMCP to verify bearer tokens.
        
        Args:
            token: Bearer token from Authorization header
            
        Returns:
            AccessToken if valid, None otherwise
        """
        try:
            # Authenticate using composite authenticator
            auth_context = await self.authenticator.authenticate(token)
            
            if not auth_context:
                logger.warning('Token verification failed')
                return None
            
            # Store auth context in local store
            self._auth_context_store[token] = auth_context
            
            # Set current bearer token in context for downstream API calls
            current_bearer_token.set(token)
            
            # Update global token_manager for downstream API calls
            if auth_context.auth_type == AuthType.LEGACY:
                # For legacy auth, store the token directly
                token_manager.set_token(auth_context.subject)
            else:
                # For OAuth, store the auth context with appliance token
                token_manager.set_auth_context(token, auth_context)
            
            # Convert AuthContext to FastMCP AccessToken
            access_token = AccessToken(
                token=token,
                client_id=auth_context.client_id,
                scopes=auth_context.scopes,
                expires_at=auth_context.expires_at,
            )
            
            logger.info(
                'Token verified successfully - type: %s, client: %s',
                auth_context.auth_type.value,
                auth_context.client_id
            )
            
            return access_token
            
        except Exception as e:
            logger.error('Unexpected error during token verification: %s', e)
            return None
    
    def get_auth_context(self, token: str) -> Optional[AuthContext]:
        """Get the full auth context for a verified token.
        
        This allows downstream code to access the complete authentication
        context including appliance tokens for OAuth.
        
        Args:
            token: Bearer token
            
        Returns:
            AuthContext if token was verified, None otherwise
        """
        return self._auth_context_store.get(token)
    
    def clear_context(self, token: str) -> None:
        """Clear stored auth context for a token.
        
        Args:
            token: Bearer token
        """
        if token in self._auth_context_store:
            del self._auth_context_store[token]
