"""Appliance token cache implementation."""

import logging
import time
from typing import Optional, Dict, Any
from threading import Lock

logger = logging.getLogger(__name__)


class ApplianceTokenCache:
    """Thread-safe cache for appliance tokens.
    
    This cache stores appliance tokens retrieved from Keycloak and
    automatically refreshes them before expiry.
    """
    
    def __init__(self, ttl: int = 3600, refresh_skew: int = 300):
        """Initialize appliance token cache.
        
        Args:
            ttl: Default TTL in seconds if expires_at not provided
            refresh_skew: Refresh tokens this many seconds before expiry
        """
        self.ttl = ttl
        self.refresh_skew = refresh_skew
        self._cache: Dict[str, Dict[str, Any]] = {}
        self._lock = Lock()
    
    def get(self, key: str) -> Optional[Dict[str, Any]]:
        """Get cached appliance token if valid.
        
        Args:
            key: Cache key (typically subject:appliance_id)
            
        Returns:
            Token data dict if cached and valid, None otherwise
        """
        with self._lock:
            if key not in self._cache:
                return None
            
            entry = self._cache[key]
            expires_at = entry.get('expires_at', 0)
            
            # Check if token is expired or needs refresh
            now = int(time.time())
            if expires_at <= now + self.refresh_skew:
                logger.debug('Cached token expired or needs refresh for key: %s...', key[:20])
                del self._cache[key]
                return None
            
            logger.debug('Cache hit for key: %s...', key[:20])
            return entry
    
    def set(self, key: str, token_data: Dict[str, Any]) -> None:
        """Cache an appliance token.
        
        Args:
            key: Cache key (typically subject:appliance_id)
            token_data: Token data dict with 'appliance_token' and 'expires_at'
        """
        with self._lock:
            # Ensure expires_at is set
            if 'expires_at' not in token_data:
                token_data['expires_at'] = int(time.time()) + self.ttl
            
            self._cache[key] = token_data
            logger.debug('Cached token for key: %s...', key[:20])
    
    def clear(self) -> None:
        """Clear all cached tokens."""
        with self._lock:
            self._cache.clear()
            logger.debug('Cleared appliance token cache')
    
    def remove(self, key: str) -> None:
        """Remove a specific cached token.
        
        Args:
            key: Cache key to remove
        """
        with self._lock:
            if key in self._cache:
                del self._cache[key]
                logger.debug('Removed cached token for key: %s...', key[:20])
