"""Legacy token authenticator implementation."""

import logging
import time
from typing import Optional

import httpx

from .authenticator import Authenticator
from .models import AuthContext, AuthType

logger = logging.getLogger(__name__)


class LegacyTokenAuthenticator(Authenticator):
    """Authenticator for legacy static API tokens.
    
    This authenticator validates tokens against the Spectra Analyze appliance
    API using the existing legacy authentication mechanism.
    """
    
    def __init__(self, base_url: str, verify_ssl: bool = True, timeout: int = 30):
        """Initialize legacy token authenticator.
        
        Args:
            base_url: Base URL for Spectra Analyze appliance
            verify_ssl: Whether to verify SSL certificates
            timeout: Request timeout in seconds
        """
        self.base_url = base_url.rstrip('/')
        self.verify_ssl = verify_ssl
        self.timeout = timeout
        self.verification_endpoint = "/api/v1/license/"
    
    def can_handle(self, token: str) -> bool:
        """Check if this authenticator can handle the token.
        
        Legacy tokens are any tokens that are NOT JWTs (i.e., don't have
        3 dot-separated base64url segments).
        
        Args:
            token: Bearer token
            
        Returns:
            True if token appears to be a legacy token
        """
        # JWT tokens have exactly 3 parts separated by dots
        parts = token.split('.')
        
        # If it has 3 parts, it might be a JWT - let OAuth handler try it
        if len(parts) == 3:
            return False
        
        # Otherwise, treat as legacy token
        return True
    
    async def authenticate(self, token: str) -> Optional[AuthContext]:
        """Authenticate a legacy bearer token.
        
        Args:
            token: Legacy bearer token
            
        Returns:
            AuthContext if valid, None otherwise
        """
        try:
            logger.debug('Attempting legacy token authentication')
            start = time.perf_counter()
            async with httpx.AsyncClient(
                base_url=self.base_url,
                timeout=self.timeout,
                verify=self.verify_ssl,
            ) as client:
                resp = await client.get(
                    self.verification_endpoint,
                    headers={"Authorization": f"Token {token}"},
                )
            end = time.perf_counter()
            # old timeout time for legacy auth request (5 seconds)
            if end - start > 5.0: 
                logger.warning('Legacy auth took longer then 5 seconds, took: %.2f seconds', end-start)
            if resp.status_code != 200:
                logger.warning('Legacy auth verification returned %d', resp.status_code)
                return None
            
            logger.info('Legacy token authentication successful')
            
            # Create auth context for legacy token
            # Note: For legacy auth, the token itself is stored in subject
            # and will be used for downstream API calls
            return AuthContext(
                auth_type=AuthType.LEGACY,
                subject=token,  # Store token in subject for downstream use
                scopes=["user"],  # Legacy tokens have basic user scope
                client_id="legacy-client",
                expires_at=int(time.time()) + 3600,  # Default 1 hour
                appliance_token=None,  # Legacy doesn't use separate appliance token
                claims=None,
            )
            
        except httpx.TimeoutException:
            logger.error('Legacy token verification timed out after %.2fs (limit=%ss)', end - start, self.timeout)
            return None
        except httpx.RequestError as e:
            logger.error(
                'Legacy token verification request failed (%s) — target: %s%s — error: %s',
                type(e).__name__,
                self.base_url,
                self.verification_endpoint,
                e,
            )
            return None
        except Exception as e:
            logger.error('Unexpected error during legacy token authentication: %s', e)
            return None
