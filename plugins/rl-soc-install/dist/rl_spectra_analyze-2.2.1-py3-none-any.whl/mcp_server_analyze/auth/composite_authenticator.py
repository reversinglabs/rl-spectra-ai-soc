"""Composite authenticator that routes to legacy or OAuth authenticators."""

import logging
from typing import Optional, List

from .authenticator import Authenticator
from .models import AuthContext

logger = logging.getLogger(__name__)


class CompositeAuthenticator(Authenticator):
    """Composite authenticator that routes tokens to appropriate handlers.
    
    This authenticator:
    1. Detects token type (legacy vs OAuth JWT)
    2. Routes to the appropriate authenticator
    3. Returns unified AuthContext
    
    Token detection logic:
    - If token has 3 dot-separated segments, treat as JWT (OAuth)
    - Otherwise, treat as legacy bearer token
    """
    
    def __init__(self, authenticators: List[Authenticator]):
        """Initialize composite authenticator.
        
        Args:
            authenticators: List of authenticators to try in order
        """
        self.authenticators = authenticators
        
        if not authenticators:
            raise ValueError('At least one authenticator must be provided')
        
        logger.info('Initialized composite authenticator with %d handlers', len(authenticators))
    
    def can_handle(self, token: str) -> bool:
        """Check if any authenticator can handle the token.
        
        Args:
            token: Bearer token
            
        Returns:
            True if at least one authenticator can handle the token
        """
        return any(auth.can_handle(token) for auth in self.authenticators)
    
    async def authenticate(self, token: str) -> Optional[AuthContext]:
        """Authenticate a token using the appropriate authenticator.
        
        This method:
        1. Iterates through authenticators in order
        2. Checks if each can handle the token
        3. Attempts authentication with the first matching authenticator
        4. Falls back to next authenticator if authentication fails
        
        Args:
            token: Bearer token from Authorization header
            
        Returns:
            AuthContext if authentication succeeds, None otherwise
        """
        if not token or not token.strip():
            logger.warning('Empty token provided')
            return None
        
        # Find authenticators that can handle this token
        capable_authenticators = [
            auth for auth in self.authenticators
            if auth.can_handle(token)
        ]
        
        if not capable_authenticators:
            logger.warning('No authenticator can handle this token format')
            return None
        
        # Try each capable authenticator in order
        for auth in capable_authenticators:
            auth_name = auth.__class__.__name__
            logger.debug('Trying authenticator: %s', auth_name)
            
            try:
                context = await auth.authenticate(token)
                if context:
                    logger.info('Authentication successful using %s', auth_name)
                    return context
                else:
                    logger.debug('%s authentication failed, trying next', auth_name)
            except Exception as e:
                logger.error('Error in %s: %s', auth_name, e)
                continue
        
        logger.warning('All capable authenticators failed')
        return None
