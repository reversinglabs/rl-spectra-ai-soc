"""Authentication module for MCP server.

This module provides pluggable authentication supporting both legacy bearer tokens
and OAuth/Keycloak JWT tokens.
"""

from .models import AuthContext, AuthType
from .authenticator import Authenticator
from .legacy_authenticator import LegacyTokenAuthenticator
from .oauth_authenticator import OAuthTokenAuthenticator
from .composite_authenticator import CompositeAuthenticator
from .mcp_token_verifier import MCPTokenVerifier

__all__ = [
    'AuthContext',
    'AuthType',
    'Authenticator',
    'LegacyTokenAuthenticator',
    'OAuthTokenAuthenticator',
    'CompositeAuthenticator',
    'MCPTokenVerifier',
]
