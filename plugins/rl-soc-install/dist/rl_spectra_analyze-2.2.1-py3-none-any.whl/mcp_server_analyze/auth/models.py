"""Authentication models and data structures."""

from dataclasses import dataclass
from enum import Enum
from typing import Optional, List, Dict, Any


class AuthType(Enum):
    """Authentication type enumeration."""
    LEGACY = "legacy"
    OAUTH = "oauth"


@dataclass
class AuthContext:
    """Authentication context containing validated auth information.
    
    This context is returned after successful authentication and contains
    all necessary information for downstream API calls.
    """
    
    auth_type: AuthType
    subject: str
    scopes: List[str]
    client_id: str
    expires_at: int
    appliance_token: Optional[str] = None
    claims: Optional[Dict[str, Any]] = None
    
    def is_legacy(self) -> bool:
        """Check if this is legacy authentication."""
        return self.auth_type == AuthType.LEGACY
    
    def is_oauth(self) -> bool:
        """Check if this is OAuth authentication."""
        return self.auth_type == AuthType.OAUTH
    
    def has_scope(self, scope: str) -> bool:
        """Check if context has a specific scope.
        
        Args:
            scope: Scope to check
            
        Returns:
            True if scope is present
        """
        return scope in self.scopes
    
    def has_all_scopes(self, required_scopes: List[str]) -> bool:
        """Check if context has all required scopes.
        
        Args:
            required_scopes: List of required scopes
            
        Returns:
            True if all scopes are present
        """
        return all(self.has_scope(scope) for scope in required_scopes)
