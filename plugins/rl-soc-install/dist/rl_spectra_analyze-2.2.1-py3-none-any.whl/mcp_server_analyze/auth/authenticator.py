"""Base authenticator interface."""

from abc import ABC, abstractmethod
from typing import Optional
from .models import AuthContext


class Authenticator(ABC):
    """Base interface for authentication implementations.
    
    All authenticators must implement the authenticate method which takes
    a bearer token and returns an AuthContext if valid, None otherwise.
    """
    
    @abstractmethod
    async def authenticate(self, token: str) -> Optional[AuthContext]:
        """Authenticate a bearer token.
        
        Args:
            token: Bearer token from Authorization header
            
        Returns:
            AuthContext if authentication succeeds, None otherwise
        """
        pass
    
    @abstractmethod
    def can_handle(self, token: str) -> bool:
        """Check if this authenticator can handle the given token.
        
        This is used by the composite authenticator to determine which
        authenticator should process the token.
        
        Args:
            token: Bearer token from Authorization header
            
        Returns:
            True if this authenticator can handle the token
        """
        pass
