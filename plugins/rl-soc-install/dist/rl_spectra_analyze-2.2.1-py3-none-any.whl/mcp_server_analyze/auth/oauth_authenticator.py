"""OAuth/Keycloak JWT token authenticator implementation."""

import base64
import json
import logging
import time
from typing import Optional, Dict, Any, List

import httpx
import jwt
from jwt import PyJWKClient

from .authenticator import Authenticator
from .models import AuthContext, AuthType
from .appliance_token_cache import ApplianceTokenCache

logger = logging.getLogger(__name__)


def _decode_jwt_exp_unverified(token: str) -> Optional[int]:
    """Extract exp claim from a JWT without verifying the signature."""
    try:
        parts = token.split('.')
        if len(parts) != 3:
            return None
        padded = parts[1] + '=' * ((4 - len(parts[1]) % 4) % 4)
        payload = json.loads(base64.urlsafe_b64decode(padded))
        return int(payload['exp']) if payload.get('exp') else None
    except Exception:
        return None


class OAuthTokenAuthenticator(Authenticator):
    """Authenticator for OAuth/Keycloak JWT tokens.

    This authenticator:
    1. Validates JWT signature using Keycloak JWKS
    2. Validates issuer, expiration, audience/appliance_id
    3. Validates required scopes
    4. Retrieves the SA appliance_token from Keycloak's /appliance-token endpoint.
       Keycloak owns the underlying SA token lifecycle (issue/refresh/revoke);
       this server only caches the appliance_token locally until its JWT exp claim.
    """

    def __init__(
        self,
        keycloak_issuer: str,
        keycloak_jwks_url: str,
        keycloak_appliance_token_endpoint: str,
        appliance_id: str,
        appliance_url: str,
        required_scopes: Optional[List[str]] = None,
        cache_ttl: int = 3600,
        cache_refresh_skew: int = 300,
    ):
        """Initialize OAuth token authenticator.

        Args:
            keycloak_issuer: Expected JWT issuer URL
            keycloak_jwks_url: Keycloak JWKS endpoint URL
            keycloak_appliance_token_endpoint: Keycloak endpoint that returns the SA appliance_token
            appliance_id: MCP server public URL for audience validation
            appliance_url: Appliance URL sent in token-exchange body
            required_scopes: List of required scopes (optional)
            cache_ttl: Fallback cache TTL used when no exp can be derived
            cache_refresh_skew: Evict cached appliance tokens this many seconds before their exp
        """
        self.keycloak_issuer = keycloak_issuer
        self.keycloak_jwks_url = keycloak_jwks_url
        self.keycloak_appliance_token_endpoint = keycloak_appliance_token_endpoint
        self.appliance_id = appliance_id
        self.appliance_url = appliance_url
        self.required_scopes = required_scopes or []
        self.cache_ttl = cache_ttl
        self.cache_refresh_skew = cache_refresh_skew

        self.jwks_client = PyJWKClient(keycloak_jwks_url)

        self.token_cache = ApplianceTokenCache(
            ttl=cache_ttl,
            refresh_skew=cache_refresh_skew,
        )

    def can_handle(self, token: str) -> bool:
        """Return True if the token looks like a JWT (3 dot-separated segments)."""
        return len(token.split('.')) == 3

    async def authenticate(self, token: str) -> Optional[AuthContext]:
        """Authenticate an OAuth JWT token."""
        try:
            logger.debug('Attempting OAuth token authentication')

            claims = self._validate_jwt(token)
            if not claims:
                return None

            if not self._validate_issuer(claims):
                return None

            if not self._validate_audience(claims):
                return None

            scopes = self._extract_scopes(claims)
            if not self._validate_scopes(scopes):
                return None

            subject = claims.get('sub')
            if not subject:
                logger.warning('JWT missing subject claim')
                return None

            token_data = await self._get_appliance_token(token, subject)
            if not token_data:
                logger.error('Failed to retrieve SA appliance_token')
                return None

            logger.info('OAuth token authentication successful for subject: %s...', subject[:8])

            return AuthContext(
                auth_type=AuthType.OAUTH,
                subject=subject,
                scopes=scopes,
                client_id=claims.get('azp') or claims.get('client_id', 'oauth-client'),
                expires_at=claims.get('exp', int(time.time()) + 3600),
                appliance_token=token_data['appliance_token'],
                claims=claims,
            )

        except jwt.InvalidTokenError as e:
            logger.warning('Invalid JWT token: %s', e)
            return None
        except Exception as e:
            logger.error('Unexpected error during OAuth authentication: %s', e)
            return None

    # ------------------------------------------------------------------
    # JWT validation helpers
    # ------------------------------------------------------------------

    def _validate_jwt(self, token: str) -> Optional[Dict[str, Any]]:
        try:
            signing_key = self.jwks_client.get_signing_key_from_jwt(token)
            return jwt.decode(
                token,
                signing_key.key,
                algorithms=["RS256", "RS384", "RS512"],
                options={
                    "verify_signature": True,
                    "verify_exp": True,
                    "verify_nbf": True,
                    "verify_iat": True,
                    "verify_aud": False,
                    "verify_iss": False,
                }
            )
        except jwt.InvalidSignatureError:
            logger.warning('JWT signature validation failed')
            return None
        except jwt.ExpiredSignatureError:
            logger.warning('JWT token has expired')
            return None
        except jwt.InvalidTokenError as e:
            logger.warning('JWT validation failed: %s', e)
            return None

    def _validate_issuer(self, claims: Dict[str, Any]) -> bool:
        issuer = claims.get('iss')
        if issuer != self.keycloak_issuer:
            logger.warning('Invalid issuer: expected %s, got %s', self.keycloak_issuer, issuer)
            return False
        return True

    def _validate_audience(self, claims: Dict[str, Any]) -> bool:
        aud = claims.get('aud')
        audiences = [aud] if isinstance(aud, str) else (aud if isinstance(aud, list) else [])
        logger.debug('JWT audiences: %s', audiences)
        logger.debug('Expected appliance_id: %s', self.appliance_id)
        if self.appliance_id in audiences:
            logger.debug('Valid audience found: %s', self.appliance_id)
            return True
        logger.warning('Appliance ID not found in audience claim. Expected: %s, Got: %s', self.appliance_id, audiences)
        return False

    def _extract_scopes(self, claims: Dict[str, Any]) -> List[str]:
        scope_str = claims.get('scope')
        if scope_str and isinstance(scope_str, str):
            return scope_str.split()
        scopes_arr = claims.get('scopes')
        if scopes_arr and isinstance(scopes_arr, list):
            return scopes_arr
        return []

    def _validate_scopes(self, scopes: List[str]) -> bool:
        if not self.required_scopes:
            return True
        missing_scopes = set(self.required_scopes) - set(scopes)
        if missing_scopes:
            logger.warning('Token missing required scopes: %s', missing_scopes)
            return False
        return True

    # ------------------------------------------------------------------
    # Appliance token retrieval
    # ------------------------------------------------------------------

    async def _get_appliance_token(
        self,
        keycloak_token: str,
        subject: str,
    ) -> Optional[Dict[str, Any]]:
        """Return a valid appliance_token from cache, or fetch a new one from Keycloak."""
        access_key = f"{subject}:{self.appliance_id}"
        cached = self.token_cache.get(access_key)
        if cached:
            logger.debug('Using cached appliance_token for subject: %s...', subject[:8])
            return cached

        return await self._fetch_from_keycloak(keycloak_token, subject)

    async def _fetch_from_keycloak(
        self,
        keycloak_token: str,
        subject: str,
    ) -> Optional[Dict[str, Any]]:
        """Call the Keycloak appliance-token endpoint to obtain an SA appliance_token.

        The endpoint returns:
            {"appliance_token": "<short-lived SA JWT>"}

        Keycloak owns the underlying SA-token lifecycle (issuing, refreshing on its
        side, and revoking on logout). The MCP server caches the returned JWT
        locally until its exp claim and re-fetches on expiry.
        """
        try:
            logger.debug('Fetching appliance_token from Keycloak endpoint')
            async with httpx.AsyncClient(timeout=10.0) as client:
                resp = await client.post(
                    self.keycloak_appliance_token_endpoint,
                    headers={"Authorization": f"Bearer {keycloak_token}"},
                    json={"appliance_url": self.appliance_url},
                )

            if resp.status_code != 200:
                logger.error(
                    'Keycloak appliance-token endpoint returned %s: %s',
                    resp.status_code,
                    resp.text
                )
                return None

            return self._process_token_response(resp.json(), subject)

        except httpx.TimeoutException:
            logger.error('Keycloak appliance-token request timed out')
            return None
        except httpx.RequestError as e:
            logger.error('Keycloak appliance-token request failed: %s', e)
            return None
        except Exception as e:
            logger.error('Unexpected error fetching from Keycloak: %s', e)
            return None

    def _process_token_response(
        self,
        data: Dict[str, Any],
        subject: str,
    ) -> Optional[Dict[str, Any]]:
        """Validate, cache, and return the appliance_token from a Keycloak response."""
        appliance_token = data.get('appliance_token')

        if not appliance_token:
            logger.error('Keycloak response missing appliance_token: %s', data)
            return None

        expires_at = _decode_jwt_exp_unverified(appliance_token)
        if not expires_at:
            logger.error('Could not decode exp claim from appliance_token; refusing to cache')
            return None

        access_key = f"{subject}:{self.appliance_id}"
        token_entry = {
            'appliance_token': appliance_token,
            'expires_at': expires_at,
        }
        self.token_cache.set(access_key, token_entry)

        logger.info('Obtained and cached appliance_token for subject: %s...', subject[:8])
        return token_entry
