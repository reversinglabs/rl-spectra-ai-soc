"""
Spectra Analyze CLI

Invoke any registered Spectra Analyze MCP tool from the command line and print
the result as JSON to stdout. Mirrors the `rl-spectra-intel` CLI but some changes were 
made due to differing implementations between the two MCP's. 

  * Tools are registered as closures via `register_all_tools()` and the
    `@mcp.tool()` decorator (they are not importable by name), so the registry
    is harvested with a lightweight collector shim.
  * Tools may be sync or async; async tools are run with asyncio.run().
  * Configuration is read from the same `config.ini` as the MCP server

Usage:
    rl-spectra-analyze --list-tools
    rl-spectra-analyze <tool_name> [--args '<json_object>'] [--config PATH]

Exit codes:
    0  Success            - JSON result printed to stdout
    1  API / runtime error - JSON error object printed to stderr
    2  Bad arguments      - plain error message printed to stderr
"""

import argparse
import inspect
import json
import os
import sys
import types as _builtin_types
import typing
from pathlib import Path
from typing import NoReturn

from mcp_server_analyze.version import SPECTRA_ANALYZE_MCP_VERSION

__version__ = SPECTRA_ANALYZE_MCP_VERSION


# ---------------------------------------------------------------------------
# CLI-specific config accessors
#
# These read keys from the [authentication] section of config.ini that only the
# CLI uses (the server obtains its bearer token differently). They live here,
# not on mcp_server_analyze.core.config.Config, so the server package carries no
# CLI-only knowledge. `_get_str` is the generic config primitive on Config.
# ---------------------------------------------------------------------------

def _analyze_token(cfg) -> str:
    """Spectra Analyze appliance API token for CLI use.

    Resolved from config.ini `[authentication] token`, falling back to the
    SPECTRA_ANALYZE_TOKEN environment variable.
    """
    return cfg._get_str('authentication', 'token', '') or os.environ.get('SPECTRA_ANALYZE_TOKEN', '')


def _analyze_token_endpoint(cfg) -> str:
    """Path of the Spectra Analyze Authentication API used by the `--login` flow."""
    return cfg._get_str('authentication', 'token_endpoint', '/api-token-auth/')


# ---------------------------------------------------------------------------
# Exit helpers
# ---------------------------------------------------------------------------

def _exit_api_error(message: str, **extra) -> NoReturn:
    """Print a JSON error object to stderr and exit with code 1."""
    err = {"error": message, **{k: v for k, v in extra.items() if v is not None}}
    print(json.dumps(err), file=sys.stderr)
    sys.exit(1)


def _exit_usage_error(message: str) -> NoReturn:
    """Print a plain error message to stderr and exit with code 2."""
    print(f"error: {message}", file=sys.stderr)
    sys.exit(2)


# ---------------------------------------------------------------------------
# Schema generation (for --list-tools)
# ---------------------------------------------------------------------------

def _annotation_to_schema(annotation) -> dict:
    """Recursively convert a Python type annotation to a JSON Schema fragment."""
    origin = typing.get_origin(annotation)
    args = typing.get_args(annotation)

    if origin is typing.Annotated:
        return _annotation_to_schema(args[0])

    if origin is typing.Union or isinstance(annotation, _builtin_types.UnionType):
        non_none = [a for a in args if a is not type(None)]
        if len(non_none) == 1:
            return _annotation_to_schema(non_none[0])
        return {"anyOf": [_annotation_to_schema(a) for a in non_none]}

    if origin is list:
        schema: dict = {"type": "array"}
        if args:
            schema["items"] = _annotation_to_schema(args[0])
        return schema

    return {
        str:   {"type": "string"},
        int:   {"type": "integer"},
        bool:  {"type": "boolean"},
        float: {"type": "number"},
    }.get(annotation, {})


def _field_description(annotation) -> "str | None":
    """Extract a description from a pydantic Field carried in Annotated metadata."""
    if typing.get_origin(annotation) is typing.Annotated:
        for meta in typing.get_args(annotation)[1:]:
            desc = getattr(meta, "description", None)
            if desc:
                return desc
    return None


def _example_value(name: str, schema: dict) -> object:
    """Return a plausible placeholder value for an arg given its name and schema."""
    t = schema.get("type")
    if t == "string":
        if any(h in name for h in ("hash", "sha", "md5")):
            return "a1b2c3d4e5f6..."
        if "url" in name:
            return "https://example.com"
        return f"<{name}>"
    if t == "integer":
        return 0
    if t == "boolean":
        return False
    if t == "array":
        return [_example_value("value", schema.get("items", {}))]
    if "anyOf" in schema:
        return _example_value(name, schema["anyOf"][0])
    return f"<{name}>"


def _build_tool_schema(fn) -> dict:
    """Build the JSON Schema descriptor dict for a single tool function."""
    original = inspect.unwrap(fn)
    summary = " ".join((original.__doc__ or "").split()) if original.__doc__ else ""

    # include_extras=True keeps Annotated metadata (pydantic Field) intact.
    try:
        hints = typing.get_type_hints(original, include_extras=True)
    except Exception:
        hints = getattr(original, "__annotations__", {})

    sig = inspect.signature(original)
    required: list[str] = []
    properties: dict = {}
    example_args: dict = {}

    for param_name, param in sig.parameters.items():
        if param.kind in (
            inspect.Parameter.VAR_POSITIONAL,
            inspect.Parameter.VAR_KEYWORD,
        ):
            continue

        annotation = hints.get(param_name, inspect.Parameter.empty)
        has_default = param.default is not inspect.Parameter.empty

        prop: dict = {}
        if annotation is not inspect.Parameter.empty:
            prop = _annotation_to_schema(annotation)
            desc = _field_description(annotation)
            if desc:
                prop["description"] = desc

        properties[param_name] = prop

        if not has_default:
            required.append(param_name)
            example_args[param_name] = _example_value(param_name, prop)

    args_schema: dict = {"type": "object", "properties": properties}
    if required:
        args_schema["required"] = required

    example = f"rl-spectra-analyze {fn.__name__} --args '{json.dumps(example_args)}'"

    return {
        "name": fn.__name__,
        "description": summary,
        "args_schema": args_schema,
        "example": example,
    }


# ---------------------------------------------------------------------------
# Tool registry
# ---------------------------------------------------------------------------

class _Collector:
    """Minimal MCP-like object whose `.tool()` decorator records the tool function.

    Passing this to `register_all_tools()` harvests the exact same tool surface
    the real server exposes, without duplicating the tool list here.
    """

    def __init__(self) -> None:
        self.tools: dict = {}

    def tool(self, *args, **kwargs):
        def decorator(fn):
            self.tools[fn.__name__] = fn
            return fn
        return decorator


def _build_registry() -> dict:
    """Return a mapping of tool name -> callable for every registered tool."""
    from mcp_server_analyze.tools.tool_registry import register_all_tools
    collector = _Collector()
    register_all_tools(collector)
    return collector.tools


# ---------------------------------------------------------------------------
# Interactive login (--login)
# ---------------------------------------------------------------------------

def _resolve_config_path(cli_config: typing.Optional[str]) -> Path:
    """Pick the config.ini path to read/write for --login.

    Honours an explicit --config, otherwise prefers an existing ./config.ini,
    then the system path, and finally falls back to ./config.ini so a fresh
    file can be created.
    """
    if cli_config:
        return Path(cli_config).expanduser()
    cwd_cfg = Path.cwd() / "config.ini"
    if cwd_cfg.exists():
        return cwd_cfg
    etc_cfg = Path("/etc/mcp-server-analyze/config.ini")
    if etc_cfg.exists():
        return etc_cfg
    return cwd_cfg


def _obtain_api_token(
    base_url: str,
    verify_ssl: bool,
    username: str,
    password: str,
    endpoint_path: str,
) -> str:
    """Exchange username/password for a Spectra Analyze API token.

    POSTs credentials to the appliance Authentication API and returns the token
    from the response body. The credentials are used only for this request and
    are never persisted. Exits the process with a helpful message on failure.
    """
    import httpx

    url = f"{base_url.rstrip('/')}{endpoint_path}"
    try:
        resp = httpx.post(
            url,
            json={"username": username, "password": password},
            verify=verify_ssl,
            timeout=15,
        )
    except httpx.RequestError as exc:
        _exit_api_error(f"could not reach the authentication API at {url}: {exc}")

    if resp.status_code == 200:
        try:
            body = resp.json()
        except ValueError:
            body = None
        token = None
        if isinstance(body, dict):
            token = body.get("token") or body.get("access_token") or body.get("key")
        elif isinstance(body, str):
            token = body.strip()
        if not token:
            _exit_api_error(
                "authentication succeeded but no token was found in the response: "
                f"{resp.text.strip()[:200]}"
            )
        return token

    if resp.status_code in (400, 401, 403):
        detail = resp.text.strip()[:200] or "invalid username or password"
        _exit_usage_error(f"authentication failed (HTTP {resp.status_code}): {detail}")

    _exit_api_error(
        f"authentication API returned HTTP {resp.status_code}: "
        f"{resp.text.strip()[:200]}"
    )


def _do_login(config_path: Path) -> NoReturn:
    """Prompt for username/password, obtain an API token, and save it, then exit.

    Only the resulting API token is written to config.ini — the username and
    password are used solely to request the token and are never stored.
    """
    import configparser
    import getpass
    import os
    import stat

    if not sys.stdin.isatty():
        _exit_usage_error("--login requires an interactive terminal")

    from mcp_server_analyze.core import config as _config_mod
    _config_mod._config = _config_mod.Config(config_path)
    cfg = _config_mod._config

    base_url = cfg.analyze_base_url.rstrip("/")
    if not base_url or base_url == "https://localhost":
        _exit_usage_error(
            "no appliance base_url configured — set [analyze_host] base_url in "
            f"{config_path} before logging in"
        )

    print(f"Spectra Analyze login at {base_url}", file=sys.stderr)
    print("Username and password are used only to obtain an API token and are "
          "never saved.", file=sys.stderr)
    username = input("Username: ").strip()
    if not username:
        _exit_usage_error("no username entered")
    password = getpass.getpass("Password: ")
    if not password:
        _exit_usage_error("no password entered")

    token = _obtain_api_token(
        base_url, cfg.analyze_verify_ssl, username, password, _analyze_token_endpoint(cfg)
    )

    parser = configparser.ConfigParser()
    if config_path.exists():
        parser.read(config_path)
    if not parser.has_section("authentication"):
        parser.add_section("authentication")
    parser.set("authentication", "token", token)

    config_path.parent.mkdir(parents=True, exist_ok=True)
    with open(config_path, "w") as fh:
        parser.write(fh)
    try:
        os.chmod(config_path, stat.S_IRUSR | stat.S_IWUSR)  # 0600
    except OSError:
        pass

    print(f"Login successful. API token saved to {config_path} "
          "(permissions set to 600).", file=sys.stderr)
    sys.exit(0)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    # Suppress logging below ERROR in CLI mode so tool logging does not pollute
    # the JSON emitted on stdout/stderr.
    import logging as _logging
    _logging.disable(_logging.ERROR)

    parser = argparse.ArgumentParser(
        prog="rl-spectra-analyze",
        description=(
            "Invoke a Spectra Analyze tool from the command line.\n"
            "Results are printed as JSON to stdout.\n\n"
            "Exit codes: 0=success  1=API/runtime error  2=bad arguments"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )
    parser.add_argument(
        "tool",
        nargs="?",
        metavar="TOOL",
        help="Name of the tool to invoke (see --list-tools).",
    )
    parser.add_argument(
        "--args",
        default="{}",
        metavar="JSON",
        help='Tool arguments as a JSON object, e.g. \'{"hash": "abc123"}\'.',
    )
    parser.add_argument(
        "--config",
        metavar="PATH",
        help="Path to config.ini. Defaults to ./config.ini then "
             "/etc/mcp-server-analyze/config.ini.",
    )
    parser.add_argument(
        "--token",
        metavar="TOKEN",
        help="Spectra Analyze appliance API token. Overrides the token from "
             "config.ini / the SPECTRA_ANALYZE_TOKEN environment variable.",
    )
    parser.add_argument(
        "--list-tools",
        action="store_true",
        help="Print all available tool schemas as JSON to stdout and exit.",
    )
    parser.add_argument(
        "--login",
        action="store_true",
        help="Prompt for a Spectra Analyze username and password, obtain an API "
             "token from the appliance, and save it to config.ini (chmod 600), "
             "then exit. Credentials are never stored.",
    )

    parsed = parser.parse_args()

    if parsed.config:
        from mcp_server_analyze.core import config as _config_mod
        _config_mod._config = _config_mod.Config(Path(parsed.config))

    if parsed.login:
        _do_login(_resolve_config_path(parsed.config))

    if parsed.list_tools:
        registry = _build_registry()
        schemas = [_build_tool_schema(registry[name]) for name in sorted(registry)]
        print(json.dumps(schemas, indent=2))
        sys.exit(0)

    if not parsed.tool:
        parser.print_help(sys.stderr)
        sys.exit(2)

    # Parse --args
    try:
        tool_kwargs = json.loads(parsed.args)
    except json.JSONDecodeError as exc:
        _exit_usage_error(f"--args is not valid JSON: {exc}")

    if not isinstance(tool_kwargs, dict):
        _exit_usage_error("--args must be a JSON object (not an array or scalar)")

    # Resolve the tool function
    registry = _build_registry()
    tool_fn = registry.get(parsed.tool)
    if tool_fn is None:
        _exit_usage_error(
            f"unknown tool '{parsed.tool}' — run --list-tools to see available tools"
        )

    from mcp_server_analyze.core import get_config
    from mcp_server_analyze.core.token_manager import token_manager
    token = parsed.token or _analyze_token(get_config())
    if token:
        token_manager.set_token(token)
    else:
        _exit_usage_error(
            "no appliance API token found — run "
            "`rl-spectra-analyze --login`, set [authentication] token in "
            "config.ini, or pass --token / SPECTRA_ANALYZE_TOKEN"
        )

    # Invoke the tool — tools may be sync or async
    try:
        import asyncio
        result = tool_fn(**tool_kwargs)
        if asyncio.iscoroutine(result):
            result = asyncio.run(result)
    except TypeError as exc:
        _exit_usage_error(f"invalid arguments for '{parsed.tool}': {exc}")
    except ValueError as exc:
        _exit_usage_error(f"invalid argument value for '{parsed.tool}': {exc}")
    except Exception as exc:
        import httpx
        if isinstance(exc, httpx.HTTPStatusError):
            body = exc.response.text.strip() if exc.response.text else None
            _exit_api_error(
                str(exc),
                status_code=exc.response.status_code,
                response_body=body,
                exception_type="HTTPStatusError",
            )
        _exit_api_error(str(exc), exception_type=type(exc).__name__)

    # Serialize result to stdout
    try:
        print(json.dumps(result, default=str))
    except (TypeError, ValueError) as exc:
        _exit_api_error(f"failed to serialize result to JSON: {exc}")


if __name__ == "__main__":
    main()
