"""Spectra Analyze command-line interface.

A thin CLI frontend over the ``mcp_server_analyze`` package (vendored as a git
submodule). It harvests the exact tool surface the MCP server exposes and lets
you invoke any tool from the shell.
"""

from mcp_server_analyze.version import SPECTRA_ANALYZE_MCP_VERSION

__version__ = SPECTRA_ANALYZE_MCP_VERSION
